"""
models.py

Data models for spark_job_runner: enums, dataclasses for job specs, results, and run state.
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Optional


class JobStatus(Enum):
    PENDING = "PENDING"
    RUNNING = "RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    SKIPPED = "SKIPPED"
    CANCELLED = "CANCELLED"
    TIMED_OUT = "TIMED_OUT"


class RunStatus(Enum):
    CREATED = "CREATED"
    VALIDATED = "VALIDATED"
    DDL_RUNNING = "DDL_RUNNING"
    SCHEMA_VERIFIED = "SCHEMA_VERIFIED"
    SQL_RUNNING = "SQL_RUNNING"
    SUCCESS = "SUCCESS"
    FAILED = "FAILED"
    CANCELLED = "CANCELLED"


class ErrorCategory(Enum):
    CONFIG = "CONFIG"
    SECURITY = "SECURITY"
    SQL_PARSE = "SQL_PARSE"
    SPARK_ANALYSIS = "SPARK_ANALYSIS"
    SPARK_TRANSIENT = "SPARK_TRANSIENT"
    SPARK_EXECUTION = "SPARK_EXECUTION"
    DATA_QUALITY = "DATA_QUALITY"
    TIMEOUT = "TIMEOUT"
    CANCELLED = "CANCELLED"
    CANCELLATION_UNCONFIRMED = "CANCELLATION_UNCONFIRMED"
    AUDIT = "AUDIT"
    LOCK_LOST = "LOCK_LOST"
    INTERNAL = "INTERNAL"


class RunMode(Enum):
    VALIDATE = "validate"
    PLAN = "plan"
    DEPLOY_DDL = "deploy-ddl"
    RUN_SQL = "run-sql"
    FULL_RUN = "full-run"


@dataclass
class RetrySpec:
    max_attempts: int = 1
    backoff_seconds: List[int] = field(default_factory=list)
    retryable_categories: List[str] = field(default_factory=list)


@dataclass
class ScheduleSpec:
    cron: str
    include_upstream: bool
    enabled: bool


@dataclass
class RetryAttempt:
    attempt: int
    error_category: str
    sanitized_error: str
    retried: bool
    waited_seconds: int


@dataclass
class PostCheck:
    id: str
    sql_file: str
    expect: object
    severity: str


@dataclass
class RollbackSpec:
    strategy: str  # snapshot/staging_publish/backup_restore/none
    restore_test_id: Optional[str] = None
    rpo_minutes: Optional[int] = None
    rto_minutes: Optional[int] = None


@dataclass
class MetadataExpectation:
    internal_gold_dependencies: List[str] = field(default_factory=list)
    runtime_requirements: List[str] = field(default_factory=list)
    output_tables: List[str] = field(default_factory=list)


@dataclass
class JobSpec:
    job_id: str
    sql_file: str
    ddl_file: str
    output_tables: List[str]
    enabled: bool = True
    depends_on: List[str] = field(default_factory=list)
    schema_fingerprint: str = "pending"
    idempotency: str = "unknown"
    retry: RetrySpec = field(default_factory=RetrySpec)
    timeout_seconds: Optional[int] = None
    post_checks: List[PostCheck] = field(default_factory=list)
    metadata_expectation: MetadataExpectation = field(default_factory=MetadataExpectation)
    rollback: RollbackSpec = field(default_factory=lambda: RollbackSpec(strategy="none"))
    schedule: Optional[ScheduleSpec] = None


@dataclass
class JobResult:
    job_id: str
    status: JobStatus
    ddl_status: JobStatus = JobStatus.PENDING
    sql_status: JobStatus = JobStatus.PENDING
    stage: int = 0
    started_at: Optional[datetime.datetime] = None
    finished_at: Optional[datetime.datetime] = None
    elapsed_ms: Optional[float] = None
    error_category: Optional[ErrorCategory] = None
    sanitized_error: Optional[str] = None
    attempts: int = 0
    blocked_by: List[str] = field(default_factory=list)
    spark_job_group: Optional[str] = None
    retry_attempts: List[RetryAttempt] = field(default_factory=list)


@dataclass
class RunResult:
    run_id: str
    status: RunStatus
    mode: RunMode
    started_at: datetime.datetime
    finished_at: Optional[datetime.datetime] = None
    job_results: List[JobResult] = field(default_factory=list)
    exit_code: int = 0

"""
reporting.py

Run result serialization and human-readable summary output.

- write_run_report: writes JSON run report to output_dir/<run_id>.json
- print_summary: prints a human-readable summary to stdout

SQL text is never written to reports or logs (log sanitization).
"""

from __future__ import annotations

import datetime
import json
import os
import sys
import zoneinfo
from pathlib import Path
from typing import Any, Dict

from spark_job_runner.models import JobResult, JobStatus, RetryAttempt, RunResult, RunStatus


def _job_result_to_dict(result: JobResult) -> Dict[str, Any]:
    """Serialize a JobResult to a JSON-serializable dict."""
    return {
        "job_id": result.job_id,
        "status": result.status.value,
        "ddl_status": result.ddl_status.value,
        "sql_status": result.sql_status.value,
        "stage": result.stage,
        "started_at": result.started_at.isoformat() if result.started_at else None,
        "finished_at": result.finished_at.isoformat() if result.finished_at else None,
        "elapsed_ms": result.elapsed_ms,
        "error_category": result.error_category.value if result.error_category else None,
        "sanitized_error": result.sanitized_error,
        "attempts": result.attempts,
        "blocked_by": result.blocked_by,
        "spark_job_group": result.spark_job_group,
    }


def _run_result_to_dict(run_result: RunResult) -> Dict[str, Any]:
    """Serialize a RunResult to a JSON-serializable dict."""
    return {
        "run_id": run_result.run_id,
        "status": run_result.status.value,
        "mode": run_result.mode.value,
        "started_at": run_result.started_at.isoformat(),
        "finished_at": run_result.finished_at.isoformat() if run_result.finished_at else None,
        "exit_code": run_result.exit_code,
        "job_results": [_job_result_to_dict(jr) for jr in run_result.job_results],
        "summary": {
            "total": len(run_result.job_results),
            "success": sum(1 for jr in run_result.job_results if jr.status == JobStatus.SUCCESS),
            "failed": sum(1 for jr in run_result.job_results if jr.status == JobStatus.FAILED),
            "skipped": sum(1 for jr in run_result.job_results if jr.status == JobStatus.SKIPPED),
            "cancelled": sum(1 for jr in run_result.job_results if jr.status == JobStatus.CANCELLED),
            "timed_out": sum(1 for jr in run_result.job_results if jr.status == JobStatus.TIMED_OUT),
        },
    }


def write_run_report(run_result: RunResult, output_dir: str) -> str:
    """
    Write a JSON run report to output_dir/<run_id>.json.

    Args:
        run_result: The completed RunResult.
        output_dir: Directory where the report file will be written.

    Returns:
        Absolute path to the written report file.
    """
    out_path = Path(output_dir).resolve()
    out_path.mkdir(parents=True, exist_ok=True)

    report_file = out_path / f"{run_result.run_id}.json"
    data = _run_result_to_dict(run_result)

    with report_file.open("w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)

    return str(report_file)


def print_summary(run_result: RunResult) -> None:
    """
    Print a human-readable execution summary to stdout.

    SQL text is never printed (log sanitization).
    """
    results = run_result.job_results
    total = len(results)
    success = sum(1 for jr in results if jr.status == JobStatus.SUCCESS)
    failed = sum(1 for jr in results if jr.status == JobStatus.FAILED)
    skipped = sum(1 for jr in results if jr.status == JobStatus.SKIPPED)
    cancelled = sum(1 for jr in results if jr.status == JobStatus.CANCELLED)
    timed_out = sum(1 for jr in results if jr.status == JobStatus.TIMED_OUT)

    elapsed_total = 0.0
    if run_result.finished_at and run_result.started_at:
        elapsed_total = (run_result.finished_at - run_result.started_at).total_seconds()

    line = "=" * 80
    print(line)
    print(f"Run Summary  run_id={run_result.run_id}  mode={run_result.mode.value}")
    print(f"Status       : {run_result.status.value}  exit_code={run_result.exit_code}")
    print(f"Total jobs   : {total}")
    print(f"  SUCCESS    : {success}")
    print(f"  FAILED     : {failed}")
    print(f"  SKIPPED    : {skipped}")
    print(f"  CANCELLED  : {cancelled}")
    print(f"  TIMED_OUT  : {timed_out}")
    print(f"Elapsed      : {elapsed_total:.2f} sec")
    print("-" * 80)

    for jr in sorted(results, key=lambda r: r.job_id):
        elapsed_ms = f"{jr.elapsed_ms:.0f}ms" if jr.elapsed_ms is not None else "-"
        status_label = jr.status.value
        detail = ""
        if jr.status == JobStatus.SKIPPED and jr.blocked_by:
            detail = f"  blocked_by={jr.blocked_by}"
        elif jr.status in (JobStatus.FAILED, JobStatus.TIMED_OUT, JobStatus.CANCELLED):
            if jr.sanitized_error:
                detail = f"  error={jr.sanitized_error}"
        print(f"  [{status_label:<9}] {jr.job_id:<40} {elapsed_ms:>10}{detail}")

    print(line)
    sys.stdout.flush()


def write_failure_log(
    job_result: JobResult,
    run_id: str,
    failure_log_dir: str,
    timezone: str = "Asia/Tokyo",
) -> None:
    """
    Append a FAILED job result to failures-YYYY-MM-DD.log.

    SQL text is never written. Does nothing if status is not FAILED.
    """
    if job_result.status != JobStatus.FAILED:
        return

    try:
        tz = zoneinfo.ZoneInfo(timezone)
    except Exception:
        tz = datetime.timezone.utc

    now_local = datetime.datetime.now(tz=tz)
    date_str = now_local.strftime("%Y-%m-%d")
    ts_str = now_local.isoformat(timespec="seconds")

    log_dir = Path(failure_log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"failures-{date_str}.log"

    cat = job_result.error_category.value if job_result.error_category else "UNKNOWN"
    lines = [
        f"{ts_str}  run_id={run_id}  job_id={job_result.job_id}",
        f"  status=FAILED  error_category={cat}",
        f"  error={job_result.sanitized_error or '(none)'}",
    ]

    if job_result.retry_attempts:
        lines.append("  retries:")
        for ra in job_result.retry_attempts:
            action = f"RETRIED(waited={ra.waited_seconds}s)" if ra.retried else "GAVE_UP"
            lines.append(
                f"    attempt={ra.attempt}  category={ra.error_category}"
                f"  error={ra.sanitized_error}  action={action}"
            )

    with log_file.open("a", encoding="utf-8") as fh:
        fh.write("\n".join(lines) + "\n\n")

"""
spark_runtime.py

SparkSession lifecycle management for spark_job_runner.

PySpark is imported only inside this module to avoid ImportError in
environments where PySpark is not installed (e.g., unit test environments).
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


class SparkRuntime:
    """
    Manages SparkSession creation and job group lifecycle.

    PySpark import is deferred to get_session() so that importing this
    module in test environments without PySpark installed does not fail.
    """

    def __init__(self, timezone: str = "Asia/Tokyo") -> None:
        self.timezone = timezone
        self._session = None

    def get_session(self):
        """
        Get or create a SparkSession with the configured timezone.

        Returns:
            pyspark.sql.SparkSession
        """
        if self._session is not None:
            return self._session

        # Deferred import — only runs when a session is actually needed
        from pyspark.sql import SparkSession  # type: ignore[import]

        self._session = (
            SparkSession.builder
            .appName("spark-job-runner")
            .config("spark.sql.session.timeZone", self.timezone)
            .enableHiveSupport()
            .getOrCreate()
        )
        logger.info("SparkSession created with timezone=%s", self.timezone)
        return self._session

    def set_job_group(self, run_id: str, job_id: str, description: str) -> None:
        """
        Set the Spark job group for the current thread.

        Used to enable cancellation of all Spark jobs belonging to a logical job.

        Args:
            run_id: Unique identifier for the current run.
            job_id: Unique identifier for the job within the run.
            description: Human-readable description of the job group.
        """
        group_id = f"{run_id}/{job_id}"
        spark = self.get_session()
        spark.sparkContext.setJobGroup(group_id, description, interruptOnCancel=True)
        logger.debug("Set job group: %s", group_id)

    def cancel_job_group(self, run_id: str, job_id: str) -> None:
        """
        Cancel all Spark jobs in the given job group.

        Args:
            run_id: Unique identifier for the current run.
            job_id: Unique identifier for the job within the run.
        """
        group_id = f"{run_id}/{job_id}"
        spark = self.get_session()
        spark.sparkContext.cancelJobGroup(group_id)
        logger.info("Cancelled job group: %s", group_id)

    def execute_sql(self, sql: str, job_id: str) -> None:
        """
        Execute a single SQL statement via SparkSession.

        SQL content is not logged at INFO level (log sanitization).

        Args:
            sql: The SQL statement to execute.
            job_id: Job identifier used for debug context only.

        Raises:
            Exception: Any Spark exception propagated to the caller.
        """
        spark = self.get_session()
        # Do NOT log the SQL text at INFO or WARNING level
        logger.debug("[%s] Executing SQL statement (content omitted from standard log)", job_id)
        spark.sql(sql)

    def stop(self) -> None:
        """Stop the SparkSession if it was started."""
        if self._session is not None:
            self._session.stop()
            self._session = None
            logger.info("SparkSession stopped")

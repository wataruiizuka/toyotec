"""
sql_parser.py

Safe SQL statement splitter for Spark SQL.

- Removes /* ... */ block comments
- Removes -- line comments (outside string literals)
- Splits on semicolons (outside string literals)
- Filters empty statements
"""

from __future__ import annotations

import re
from typing import List


def _remove_block_comments(sql_text: str) -> str:
    """Remove /* ... */ block comments, supporting nested content but not nested comments."""
    return re.sub(r"/\*.*?\*/", "", sql_text, flags=re.DOTALL)


def _remove_line_comments_and_split(sql_text: str) -> List[str]:
    """
    Remove -- line comments (outside string literals) and split on semicolons.

    Tracks single-quote and double-quote string literals to avoid
    incorrectly removing comment markers or splitting on semicolons inside strings.
    """
    statements: List[str] = []
    current: List[str] = []

    in_single_quote = False
    in_double_quote = False
    i = 0
    n = len(sql_text)

    while i < n:
        ch = sql_text[i]

        # Handle -- line comment (only outside strings)
        if ch == "-" and not in_single_quote and not in_double_quote:
            if i + 1 < n and sql_text[i + 1] == "-":
                # Skip to end of line
                while i < n and sql_text[i] != "\n":
                    i += 1
                # Add a newline so we don't merge adjacent tokens
                current.append("\n")
                continue

        # Track string delimiters
        if ch == "'" and not in_double_quote:
            in_single_quote = not in_single_quote
            current.append(ch)
            i += 1
            continue

        if ch == '"' and not in_single_quote:
            in_double_quote = not in_double_quote
            current.append(ch)
            i += 1
            continue

        # Split on semicolon outside strings
        if ch == ";" and not in_single_quote and not in_double_quote:
            stmt = "".join(current).strip()
            if stmt:
                statements.append(stmt)
            current = []
            i += 1
            continue

        current.append(ch)
        i += 1

    # Tail (no trailing semicolon)
    tail = "".join(current).strip()
    if tail:
        statements.append(tail)

    return statements


def split_sql_statements(sql_text: str) -> List[str]:
    """
    Safely split SQL text into individual statements.

    Steps:
    1. Remove /* ... */ block comments.
    2. Remove -- line comments (outside string literals).
    3. Split on semicolons (outside string literals).
    4. Filter empty statements.

    Returns:
        List of non-empty SQL statement strings, stripped of leading/trailing whitespace.
    """
    if not sql_text or not sql_text.strip():
        return []

    # Step 1: remove block comments
    no_block_comments = _remove_block_comments(sql_text)

    # Step 2 & 3: remove line comments and split by semicolon
    statements = _remove_line_comments_and_split(no_block_comments)

    # Step 4: filter truly empty statements
    return [s for s in statements if s.strip()]

"""
validator.py

Static validation for spark_job_runner.

Validates:
1. DDL/SQL pair existence (stem must match)
2. DDL contains CREATE TABLE IF NOT EXISTS
3. SQL contains INSERT OVERWRITE
4. DDL target table, SQL target, and config output_tables are consistent
5. depends_on references only defined job IDs
6. No circular dependencies
7. No two jobs share the same output_table
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Dict, List, Set

from spark_job_runner.config import load_config
from spark_job_runner.models import JobSpec


def _extract_ddl_target(ddl_text: str) -> str | None:
    """
    Extract the target table name from a DDL statement.
    Expects: CREATE TABLE IF NOT EXISTS <table_name>
    Returns table name (lowercased) or None if not found.
    """
    pattern = re.compile(
        r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS\s+([\w.`]+)",
        re.IGNORECASE,
    )
    m = pattern.search(ddl_text)
    if m:
        return m.group(1).strip("`").lower()
    return None


def _extract_sql_target(sql_text: str) -> str | None:
    """
    Extract the target table name from an INSERT OVERWRITE statement.
    Returns table name (lowercased) or None if not found.
    """
    # INSERT OVERWRITE TABLE <name> or INSERT OVERWRITE <name>
    pattern = re.compile(
        r"INSERT\s+OVERWRITE\s+(?:TABLE\s+)?([\w.`]+)",
        re.IGNORECASE,
    )
    m = pattern.search(sql_text)
    if m:
        return m.group(1).strip("`").lower()
    return None


def _has_cycle(job_id: str, graph: Dict[str, List[str]], visited: Set[str], stack: Set[str]) -> bool:
    """DFS cycle detection."""
    visited.add(job_id)
    stack.add(job_id)
    for dep in graph.get(job_id, []):
        if dep not in visited:
            if _has_cycle(dep, graph, visited, stack):
                return True
        elif dep in stack:
            return True
    stack.discard(job_id)
    return False


def validate(config_path: str, ddl_root: str, sql_root: str) -> List[str]:
    """
    Perform static validation of the configuration and DDL/SQL files.

    Args:
        config_path: Path to the YAML config file.
        ddl_root: Root directory for DDL files.
        sql_root: Root directory for SQL files.

    Returns:
        List of validation error messages. Empty list means valid.
    """
    errors: List[str] = []

    # Load config
    try:
        raw_config, jobs = load_config(config_path)
    except Exception as exc:
        return [f"CONFIG: Failed to load config: {exc}"]

    ddl_root_path = Path(ddl_root).resolve()
    sql_root_path = Path(sql_root).resolve()

    job_ids = {j.job_id for j in jobs}
    output_table_owners: Dict[str, str] = {}  # table -> job_id

    for job in jobs:
        job_id = job.job_id

        # Resolve DDL and SQL absolute paths
        ddl_abs = (ddl_root_path / job.ddl_file).resolve()
        sql_abs = (sql_root_path / job.sql_file).resolve()

        # 1. DDL/SQL pair: check both files exist
        ddl_exists = ddl_abs.exists() and ddl_abs.is_file()
        sql_exists = sql_abs.exists() and sql_abs.is_file()

        if not ddl_exists:
            errors.append(f"[{job_id}] DDL file not found: {ddl_abs}")
        if not sql_exists:
            errors.append(f"[{job_id}] SQL file not found: {sql_abs}")

        # 1b. Stem consistency check: ddl_file and sql_file must share the same stem
        ddl_stem = Path(job.ddl_file).stem
        sql_stem = Path(job.sql_file).stem
        if ddl_stem != sql_stem:
            errors.append(
                f"[{job_id}] DDL stem ({ddl_stem!r}) and SQL stem ({sql_stem!r}) do not match"
            )

        if not ddl_exists or not sql_exists:
            # Can't do further content checks without both files
            continue

        ddl_text = ddl_abs.read_text(encoding="utf-8")
        sql_text = sql_abs.read_text(encoding="utf-8")

        # 2. DDL must contain CREATE TABLE IF NOT EXISTS
        if not re.search(r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS", ddl_text, re.IGNORECASE):
            errors.append(
                f"[{job_id}] DDL file does not contain 'CREATE TABLE IF NOT EXISTS': {ddl_abs}"
            )

        # 3. SQL must contain INSERT OVERWRITE
        if not re.search(r"INSERT\s+OVERWRITE", sql_text, re.IGNORECASE):
            errors.append(
                f"[{job_id}] SQL file does not contain 'INSERT OVERWRITE': {sql_abs}"
            )

        # 4. Target table consistency: DDL target == SQL target == config output_tables
        ddl_target = _extract_ddl_target(ddl_text)
        sql_target = _extract_sql_target(sql_text)
        config_targets = [t.lower() for t in job.output_tables]

        if ddl_target is None:
            errors.append(
                f"[{job_id}] Could not extract target table from DDL: {ddl_abs}"
            )
        if sql_target is None:
            errors.append(
                f"[{job_id}] Could not extract target table from SQL: {sql_abs}"
            )

        if ddl_target and sql_target:
            if ddl_target != sql_target:
                errors.append(
                    f"[{job_id}] DDL target ({ddl_target!r}) != SQL target ({sql_target!r})"
                )
            if ddl_target not in config_targets:
                errors.append(
                    f"[{job_id}] DDL target ({ddl_target!r}) not in config output_tables: "
                    f"{config_targets}"
                )
            if sql_target not in config_targets:
                errors.append(
                    f"[{job_id}] SQL target ({sql_target!r}) not in config output_tables: "
                    f"{config_targets}"
                )

        # 7. Check output_table exclusivity (no two jobs share same output table)
        for tbl in job.output_tables:
            tbl_lower = tbl.lower()
            if tbl_lower in output_table_owners:
                errors.append(
                    f"[{job_id}] output_table {tbl!r} is also claimed by job "
                    f"{output_table_owners[tbl_lower]!r}"
                )
            else:
                output_table_owners[tbl_lower] = job_id

        # 5. depends_on references only defined job IDs
        for dep in job.depends_on:
            if dep not in job_ids:
                errors.append(
                    f"[{job_id}] depends_on references undefined job: {dep!r}"
                )

    # 6. Cycle detection (full graph)
    graph: Dict[str, List[str]] = {j.job_id: j.depends_on for j in jobs}
    visited: Set[str] = set()
    stack: Set[str] = set()
    for job_id in graph:
        if job_id not in visited:
            if _has_cycle(job_id, graph, visited, stack):
                errors.append(
                    f"Cyclic dependency detected involving job: {job_id!r}"
                )

    return errors

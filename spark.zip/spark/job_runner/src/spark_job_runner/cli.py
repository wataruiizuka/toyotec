"""
cli.py

Command-line interface for spark_job_runner.

Usage:
    python -m spark_job_runner validate  --config config/jobs.yaml
    python -m spark_job_runner plan      --config config/jobs.yaml [--job dx_doujyou.vbi000001]
    python -m spark_job_runner deploy-ddl --config config/jobs.yaml [--job dx_doujyou.vbi000001]
    python -m spark_job_runner run-sql   --config config/jobs.yaml [--job dx_doujyou.vbi000001]
    python -m spark_job_runner full-run  --config config/jobs.yaml [--job dx_doujyou.vbi000001]

Exit codes:
    0  - Success
    2  - Validation error or 0-job execution (allow_empty=false)
    3  - One or more jobs failed
    4  - One or more jobs skipped
    5  - Run cancelled
    130 - SIGINT received
"""

from __future__ import annotations

import argparse
import datetime
import logging
import signal
import sys
import uuid
from pathlib import Path
from typing import List, Optional

logger = logging.getLogger(__name__)


def _setup_logging(verbose: bool = False) -> None:
    level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=level,
        format="%(asctime)s %(levelname)-8s %(name)s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="spark-job-runner",
        description="Spark SQL job runner with DAG-aware parallel execution.",
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable DEBUG logging.",
    )

    subparsers = parser.add_subparsers(dest="command", metavar="COMMAND")
    subparsers.required = True

    # Shared options factory
    def _add_common(sub: argparse.ArgumentParser) -> None:
        sub.add_argument(
            "--config",
            required=True,
            metavar="PATH",
            help="Path to jobs.yaml configuration file.",
        )
        sub.add_argument(
            "--job",
            action="append",
            default=[],
            dest="jobs",
            metavar="JOB_ID",
            help=(
                "Restrict execution to this job ID and its upstream dependencies. "
                "May be specified multiple times."
            ),
        )
        sub.add_argument(
            "--no-upstream",
            action="store_true",
            default=False,
            dest="no_upstream",
            help=(
                "When --job is used, run only the specified job(s) "
                "without pulling in upstream dependencies."
            ),
        )

    def _add_output(sub: argparse.ArgumentParser) -> None:
        sub.add_argument(
            "--output-dir",
            default="./run_reports",
            metavar="DIR",
            help="Directory for JSON run reports (default: ./run_reports).",
        )

    # validate
    p_validate = subparsers.add_parser("validate", help="Static validation only.")
    _add_common(p_validate)

    # plan
    p_plan = subparsers.add_parser("plan", help="Print execution plan without running.")
    _add_common(p_plan)
    p_plan.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format for the plan (default: text).",
    )

    # deploy-ddl
    p_ddl = subparsers.add_parser("deploy-ddl", help="Execute DDL files to create empty tables.")
    _add_common(p_ddl)
    _add_output(p_ddl)

    # run-sql
    p_sql = subparsers.add_parser("run-sql", help="Execute SQL DAG (schema verify only, no DDL).")
    _add_common(p_sql)
    _add_output(p_sql)

    # full-run
    p_full = subparsers.add_parser("full-run", help="Execute DDL phase then SQL DAG phase.")
    _add_common(p_full)
    _add_output(p_full)

    # generate-crontab
    p_cron = subparsers.add_parser(
        "generate-crontab",
        help="Generate crontab entries for scheduled jobs.",
    )
    p_cron.add_argument("--config", required=True, metavar="PATH",
                        help="Path to jobs.yaml configuration file.")
    p_cron.add_argument("--base-dir", required=True, metavar="DIR",
                        help="Base directory for cd in cron entries.")
    p_cron.add_argument("--log-dir", required=True, metavar="DIR",
                        help="Directory for per-job cron log files.")
    p_cron.add_argument("--output", default=None, metavar="FILE",
                        help="Write crontab to file instead of stdout.")

    return parser


def _load_config_and_jobs(config_path: str):
    from spark_job_runner.config import load_config
    return load_config(config_path)


def _run_validate(args: argparse.Namespace) -> int:
    """Run static validation and print results."""
    from spark_job_runner.config import load_config
    from spark_job_runner.validator import validate

    config_path = str(Path(args.config).resolve())

    # Load config to get roots
    try:
        raw_config, _ = load_config(config_path)
    except Exception as exc:
        print(f"[ERROR] Config load failed: {exc}", file=sys.stderr)
        return 2

    env = raw_config.get("environment", {})
    ddl_root = env.get("allowed_ddl_root", ".")
    sql_root = env.get("allowed_sql_root", ".")

    errors = validate(config_path, ddl_root, sql_root)

    if errors:
        print(f"Validation FAILED: {len(errors)} error(s)")
        for err in errors:
            print(f"  {err}")
        return 2

    print("Validation PASSED: no errors found.")
    return 0


def _run_plan(args: argparse.Namespace) -> int:
    """Build and print execution plan."""
    from spark_job_runner.config import load_config
    from spark_job_runner.planner import build_plan, format_plan_json, format_plan_text

    config_path = str(Path(args.config).resolve())

    try:
        raw_config, jobs = load_config(config_path)
    except Exception as exc:
        print(f"[ERROR] Config load failed: {exc}", file=sys.stderr)
        return 2

    # Filter disabled jobs
    enabled_jobs = [j for j in jobs if j.enabled]

    try:
        target_ids = args.jobs if args.jobs else None
        stages = build_plan(enabled_jobs, target_job_ids=target_ids)
    except ValueError as exc:
        print(f"[ERROR] Plan failed: {exc}", file=sys.stderr)
        return 2

    # allow_empty check
    allow_empty = raw_config.get("runtime", {}).get("allow_empty", False)
    if not stages and not allow_empty:
        print("[ERROR] No jobs selected and allow_empty is false.", file=sys.stderr)
        return 2

    fmt = getattr(args, "format", "text")
    if fmt == "json":
        print(format_plan_json(stages))
    else:
        print(format_plan_text(stages))

    return 0


def _make_run_id() -> str:
    now = datetime.datetime.now(tz=datetime.timezone.utc)
    return now.strftime("run-%Y%m%dT%H%M%S-") + str(uuid.uuid4())[:8]


def _run_deploy_ddl(args: argparse.Namespace) -> int:
    """Execute DDL phase to create empty tables."""
    from spark_job_runner.config import load_config
    from spark_job_runner.executor import JobRunner
    from spark_job_runner.models import RunMode, RunResult, RunStatus
    from spark_job_runner.planner import build_plan
    from spark_job_runner.reporting import print_summary, write_run_report
    from spark_job_runner.spark_runtime import SparkRuntime

    config_path = str(Path(args.config).resolve())

    try:
        raw_config, jobs = load_config(config_path)
    except Exception as exc:
        print(f"[ERROR] Config load failed: {exc}", file=sys.stderr)
        return 2

    env = raw_config.get("environment", {})
    runtime_cfg = raw_config.get("runtime", {})
    ddl_root = env.get("allowed_ddl_root", ".")
    sql_root = env.get("allowed_sql_root", ".")
    parallelism = runtime_cfg.get("parallelism", 1)
    timezone = runtime_cfg.get("timezone", "Asia/Tokyo")
    allow_empty = runtime_cfg.get("allow_empty", False)

    enabled_jobs = [j for j in jobs if j.enabled]

    try:
        target_ids = args.jobs if args.jobs else None
        stages = build_plan(enabled_jobs, target_job_ids=target_ids)
    except ValueError as exc:
        print(f"[ERROR] Plan failed: {exc}", file=sys.stderr)
        return 2

    flat_jobs = [job for stage in stages for job in stage]

    if not flat_jobs and not allow_empty:
        print("[ERROR] No jobs selected and allow_empty is false.", file=sys.stderr)
        return 2

    run_id = _make_run_id()
    started_at = datetime.datetime.now(tz=datetime.timezone.utc)

    spark = SparkRuntime(timezone=timezone)
    runner = JobRunner(
        config=raw_config,
        jobs=flat_jobs,
        runtime=spark,
        parallelism=parallelism,
        ddl_root=ddl_root,
        sql_root=sql_root,
        run_id=run_id,
    )

    ddl_results = runner.run_ddl_phase(flat_jobs)
    finished_at = datetime.datetime.now(tz=datetime.timezone.utc)

    from spark_job_runner.models import JobStatus
    any_failed = any(r.ddl_status == JobStatus.FAILED for r in ddl_results.values())
    exit_code = 3 if any_failed else 0
    run_status = RunStatus.FAILED if any_failed else RunStatus.SUCCESS

    run_result = RunResult(
        run_id=run_id,
        status=run_status,
        mode=RunMode.DEPLOY_DDL,
        started_at=started_at,
        finished_at=finished_at,
        job_results=list(ddl_results.values()),
        exit_code=exit_code,
    )

    print_summary(run_result)
    write_run_report(run_result, args.output_dir)
    return exit_code


def _run_sql_dag(args: argparse.Namespace) -> int:
    """Execute SQL DAG phase (no DDL)."""
    from spark_job_runner.config import load_config
    from spark_job_runner.executor import JobRunner
    from spark_job_runner.models import JobStatus, RunMode, RunResult, RunStatus
    from spark_job_runner.planner import build_plan
    from spark_job_runner.reporting import print_summary, write_run_report
    from spark_job_runner.spark_runtime import SparkRuntime

    config_path = str(Path(args.config).resolve())

    try:
        raw_config, jobs = load_config(config_path)
    except Exception as exc:
        print(f"[ERROR] Config load failed: {exc}", file=sys.stderr)
        return 2

    env = raw_config.get("environment", {})
    runtime_cfg = raw_config.get("runtime", {})
    ddl_root = env.get("allowed_ddl_root", ".")
    sql_root = env.get("allowed_sql_root", ".")
    parallelism = runtime_cfg.get("parallelism", 1)
    timezone = runtime_cfg.get("timezone", "Asia/Tokyo")
    allow_empty = runtime_cfg.get("allow_empty", False)
    retry_default = runtime_cfg.get("retry_default")

    enabled_jobs = [j for j in jobs if j.enabled]

    try:
        target_ids = args.jobs if args.jobs else None
        stages = build_plan(
            enabled_jobs,
            target_job_ids=target_ids,
            include_upstream=not args.no_upstream,
        )
    except ValueError as exc:
        print(f"[ERROR] Plan failed: {exc}", file=sys.stderr)
        return 2

    if not stages and not allow_empty:
        print("[ERROR] No jobs selected and allow_empty is false.", file=sys.stderr)
        return 2

    run_id = _make_run_id()
    started_at = datetime.datetime.now(tz=datetime.timezone.utc)

    spark = SparkRuntime(timezone=timezone)
    flat_jobs = [job for stage in stages for job in stage]
    runner = JobRunner(
        config=raw_config,
        jobs=flat_jobs,
        runtime=spark,
        parallelism=parallelism,
        ddl_root=ddl_root,
        sql_root=sql_root,
        run_id=run_id,
        retry_default=retry_default,
    )

    sql_results = runner.run_sql_phase(stages)
    finished_at = datetime.datetime.now(tz=datetime.timezone.utc)

    job_results = list(sql_results.values())
    any_failed = any(r.status == JobStatus.FAILED for r in job_results)
    any_skipped = any(r.status == JobStatus.SKIPPED for r in job_results)

    if any_failed:
        exit_code = 3
        run_status = RunStatus.FAILED
    elif any_skipped:
        exit_code = 4
        run_status = RunStatus.FAILED
    else:
        exit_code = 0
        run_status = RunStatus.SUCCESS

    run_result = RunResult(
        run_id=run_id,
        status=run_status,
        mode=RunMode.RUN_SQL,
        started_at=started_at,
        finished_at=finished_at,
        job_results=job_results,
        exit_code=exit_code,
    )

    print_summary(run_result)
    write_run_report(run_result, args.output_dir)

    failure_log_dir = runtime_cfg.get("failure_log_dir")
    if failure_log_dir:
        from spark_job_runner.reporting import write_failure_log
        for jr in job_results:
            write_failure_log(jr, run_id, failure_log_dir, timezone)

    return exit_code


def _run_full(args: argparse.Namespace) -> int:
    """Execute DDL phase then SQL DAG phase."""
    from spark_job_runner.config import load_config
    from spark_job_runner.executor import JobRunner
    from spark_job_runner.models import JobStatus, RunMode, RunResult, RunStatus
    from spark_job_runner.planner import build_plan
    from spark_job_runner.reporting import print_summary, write_run_report
    from spark_job_runner.spark_runtime import SparkRuntime

    config_path = str(Path(args.config).resolve())

    try:
        raw_config, jobs = load_config(config_path)
    except Exception as exc:
        print(f"[ERROR] Config load failed: {exc}", file=sys.stderr)
        return 2

    env = raw_config.get("environment", {})
    runtime_cfg = raw_config.get("runtime", {})
    ddl_root = env.get("allowed_ddl_root", ".")
    sql_root = env.get("allowed_sql_root", ".")
    parallelism = runtime_cfg.get("parallelism", 1)
    timezone = runtime_cfg.get("timezone", "Asia/Tokyo")
    allow_empty = runtime_cfg.get("allow_empty", False)
    retry_default = runtime_cfg.get("retry_default")

    enabled_jobs = [j for j in jobs if j.enabled]

    try:
        target_ids = args.jobs if args.jobs else None
        stages = build_plan(
            enabled_jobs,
            target_job_ids=target_ids,
            include_upstream=not args.no_upstream,
        )
    except ValueError as exc:
        print(f"[ERROR] Plan failed: {exc}", file=sys.stderr)
        return 2

    flat_jobs = [job for stage in stages for job in stage]

    if not flat_jobs and not allow_empty:
        print("[ERROR] No jobs selected and allow_empty is false.", file=sys.stderr)
        return 2

    run_id = _make_run_id()
    started_at = datetime.datetime.now(tz=datetime.timezone.utc)

    spark = SparkRuntime(timezone=timezone)
    runner = JobRunner(
        config=raw_config,
        jobs=flat_jobs,
        runtime=spark,
        parallelism=parallelism,
        ddl_root=ddl_root,
        sql_root=sql_root,
        run_id=run_id,
        retry_default=retry_default,
    )

    # DDL phase
    ddl_results = runner.run_ddl_phase(flat_jobs)

    ddl_failed = any(r.ddl_status == JobStatus.FAILED for r in ddl_results.values())
    if ddl_failed:
        finished_at = datetime.datetime.now(tz=datetime.timezone.utc)
        all_results = list(ddl_results.values())
        run_result = RunResult(
            run_id=run_id,
            status=RunStatus.FAILED,
            mode=RunMode.FULL_RUN,
            started_at=started_at,
            finished_at=finished_at,
            job_results=all_results,
            exit_code=3,
        )
        print_summary(run_result)
        write_run_report(run_result, args.output_dir)
        return 3

    # SQL DAG phase
    sql_results = runner.run_sql_phase(stages, ddl_results=ddl_results)
    finished_at = datetime.datetime.now(tz=datetime.timezone.utc)

    # Merge DDL-only results with SQL results
    all_results = []
    for job in flat_jobs:
        if job.job_id in sql_results:
            all_results.append(sql_results[job.job_id])
        elif job.job_id in ddl_results:
            all_results.append(ddl_results[job.job_id])

    any_failed = any(r.status == JobStatus.FAILED for r in all_results)
    any_skipped = any(r.status == JobStatus.SKIPPED for r in all_results)

    if any_failed:
        exit_code = 3
        run_status = RunStatus.FAILED
    elif any_skipped:
        exit_code = 4
        run_status = RunStatus.FAILED
    else:
        exit_code = 0
        run_status = RunStatus.SUCCESS

    run_result = RunResult(
        run_id=run_id,
        status=run_status,
        mode=RunMode.FULL_RUN,
        started_at=started_at,
        finished_at=finished_at,
        job_results=all_results,
        exit_code=exit_code,
    )

    print_summary(run_result)
    write_run_report(run_result, args.output_dir)

    failure_log_dir = runtime_cfg.get("failure_log_dir")
    if failure_log_dir:
        from spark_job_runner.reporting import write_failure_log
        for jr in all_results:
            write_failure_log(jr, run_id, failure_log_dir, timezone)

    return exit_code


def _run_generate_crontab(args: argparse.Namespace) -> int:
    from spark_job_runner.config import load_config
    from spark_job_runner.scheduler import generate_crontab

    config_path = str(Path(args.config).resolve())
    try:
        _, jobs = load_config(config_path)
    except Exception as exc:
        print(f"[ERROR] Config load failed: {exc}", file=sys.stderr)
        return 2

    enabled_jobs = [j for j in jobs if j.enabled]
    crontab_text = generate_crontab(
        enabled_jobs,
        config_path=args.config,
        base_dir=args.base_dir,
        log_dir=args.log_dir,
    )

    if args.output:
        Path(args.output).write_text(crontab_text, encoding="utf-8")
        print(f"Crontab written to: {args.output}")
    else:
        print(crontab_text, end="")

    return 0


def main(argv: Optional[List[str]] = None) -> int:
    """Entry point for the CLI."""
    parser = _build_parser()
    args = parser.parse_args(argv)
    _setup_logging(getattr(args, "verbose", False))

    # SIGINT -> exit code 130
    original_sigint = signal.getsignal(signal.SIGINT)

    def _sigint_handler(signum, frame):
        print("\n[WARN] Interrupted by user (SIGINT).", file=sys.stderr)
        sys.exit(130)

    signal.signal(signal.SIGINT, _sigint_handler)

    try:
        command = args.command
        if command == "validate":
            return _run_validate(args)
        elif command == "plan":
            return _run_plan(args)
        elif command == "deploy-ddl":
            return _run_deploy_ddl(args)
        elif command == "run-sql":
            return _run_sql_dag(args)
        elif command == "full-run":
            return _run_full(args)
        elif command == "generate-crontab":
            return _run_generate_crontab(args)
        else:
            print(f"[ERROR] Unknown command: {command}", file=sys.stderr)
            return 2
    finally:
        signal.signal(signal.SIGINT, original_sigint)


if __name__ == "__main__":
    sys.exit(main())

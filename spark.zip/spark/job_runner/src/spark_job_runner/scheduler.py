"""
scheduler.py

Generates crontab entries from jobs.yaml schedule blocks.
"""

from __future__ import annotations

from typing import List

from spark_job_runner.models import JobSpec


def generate_crontab(
    jobs: List[JobSpec],
    config_path: str,
    base_dir: str,
    log_dir: str,
) -> str:
    """
    Generate crontab lines for all jobs with schedule.enabled=True.

    Args:
        jobs: Enabled JobSpec objects to consider.
        config_path: Path passed to --config in generated cron commands.
        base_dir: Root directory for `cd` in cron entries.
        log_dir: Directory for per-job cron log files.

    Returns:
        String of crontab lines, one blank line between entries.
    """
    lines: List[str] = []

    for job in jobs:
        if job.schedule is None or not job.schedule.enabled:
            continue

        stem = job.job_id.split(".")[-1]
        job_log = f"{log_dir.rstrip('/')}/{stem}.log"

        cmd_parts = [
            f"cd {base_dir}",
            "&&",
            "PYTHONPATH=job_runner/src",
            "python3 -m spark_job_runner run-sql",
            f"--config {config_path}",
            f"--job {job.job_id}",
        ]
        if not job.schedule.include_upstream:
            cmd_parts.append("--no-upstream")

        cmd = " ".join(cmd_parts)
        lines.append(
            f"# {job.job_id}  include_upstream={str(job.schedule.include_upstream).lower()}"
        )
        lines.append(f"{job.schedule.cron} {cmd} >> {job_log} 2>&1")
        lines.append("")

    return "\n".join(lines)

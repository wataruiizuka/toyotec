"""
config.py

Strict YAML configuration loader for spark_job_runner.

- Only version: 1 is accepted.
- Unknown keys are rejected.
- All paths are resolved and validated.
- Returns parsed raw config dict and list of JobSpec dataclasses.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from spark_job_runner.models import (
    JobSpec,
    MetadataExpectation,
    PostCheck,
    RetrySpec,
    RollbackSpec,
    ScheduleSpec,
)

# Allowed top-level keys
_ALLOWED_ROOT_KEYS = {"version", "environment", "runtime", "jobs", "approved_exceptions"}

_ALLOWED_ENVIRONMENT_KEYS = {
    "environment_id",
    "mode",
    "allowed_ddl_root",
    "allowed_sql_root",
    "allowed_source_namespaces",
    "source_inventory_sha256",
    "expected_spark",
    "production_write_allowed",
}

_ALLOWED_RUNTIME_KEYS = {
    "timezone",
    "parallelism",
    "allow_empty",
    "sql_parser",
    "statement_preview",
    "cancel_grace_seconds",
    "audit",
    "lock",
    "retry_default",
    "failure_log_dir",
}

_ALLOWED_JOB_KEYS = {
    "sql_file",
    "ddl_file",
    "enabled",
    "depends_on",
    "output_tables",
    "schema_fingerprint",
    "idempotency",
    "retry",
    "timeout_seconds",
    "post_checks",
    "metadata_expectation",
    "rollback",
    "schedule",
}
_ALLOWED_SCHEDULE_KEYS = {"cron", "include_upstream", "enabled"}
_ALLOWED_RETRY_DEFAULT_KEYS = {"max_attempts", "backoff_seconds", "retryable_categories"}

_ALLOWED_RETRY_KEYS = {"max_attempts", "backoff_seconds", "retryable_categories"}
_ALLOWED_ROLLBACK_KEYS = {"strategy", "restore_test_id", "rpo_minutes", "rto_minutes"}
_ALLOWED_METADATA_KEYS = {"internal_gold_dependencies", "runtime_requirements", "output_tables"}
_ALLOWED_POST_CHECK_KEYS = {"id", "sql_file", "expect", "severity"}
_ALLOWED_AUDIT_KEYS = {"provider", "uri", "retention_days", "encryption_required", "acl_profile"}
_ALLOWED_LOCK_KEYS = {"provider", "uri", "lease_seconds", "renew_seconds"}
_ALLOWED_EXPECTED_SPARK_KEYS = {"distribution", "version"}


def _check_unknown_keys(mapping: Dict[str, Any], allowed: set, context: str) -> None:
    """Raise ValueError if mapping contains keys not in allowed set."""
    unknown = set(mapping.keys()) - allowed
    if unknown:
        raise ValueError(
            f"Unknown key(s) in {context}: {sorted(unknown)}. "
            f"Allowed keys: {sorted(allowed)}"
        )


def _parse_retry(raw: Any, job_id: str) -> RetrySpec:
    if raw is None:
        return RetrySpec()
    if not isinstance(raw, dict):
        raise ValueError(f"jobs.{job_id}.retry must be a mapping")
    _check_unknown_keys(raw, _ALLOWED_RETRY_KEYS, f"jobs.{job_id}.retry")
    return RetrySpec(
        max_attempts=raw.get("max_attempts", 1),
        backoff_seconds=raw.get("backoff_seconds", []),
        retryable_categories=raw.get("retryable_categories", []),
    )


def _parse_rollback(raw: Any, job_id: str) -> RollbackSpec:
    if raw is None:
        return RollbackSpec(strategy="none")
    if not isinstance(raw, dict):
        raise ValueError(f"jobs.{job_id}.rollback must be a mapping")
    _check_unknown_keys(raw, _ALLOWED_ROLLBACK_KEYS, f"jobs.{job_id}.rollback")
    strategy = raw.get("strategy", "none")
    if strategy not in ("snapshot", "staging_publish", "backup_restore", "none"):
        raise ValueError(
            f"jobs.{job_id}.rollback.strategy must be one of "
            f"snapshot/staging_publish/backup_restore/none, got: {strategy!r}"
        )
    return RollbackSpec(
        strategy=strategy,
        restore_test_id=raw.get("restore_test_id"),
        rpo_minutes=raw.get("rpo_minutes"),
        rto_minutes=raw.get("rto_minutes"),
    )


def _parse_metadata_expectation(raw: Any, job_id: str) -> MetadataExpectation:
    if raw is None:
        return MetadataExpectation()
    if not isinstance(raw, dict):
        raise ValueError(f"jobs.{job_id}.metadata_expectation must be a mapping")
    _check_unknown_keys(raw, _ALLOWED_METADATA_KEYS, f"jobs.{job_id}.metadata_expectation")
    return MetadataExpectation(
        internal_gold_dependencies=raw.get("internal_gold_dependencies", []),
        runtime_requirements=raw.get("runtime_requirements", []),
        output_tables=raw.get("output_tables", []),
    )


def _parse_post_checks(raw: Any, job_id: str) -> List[PostCheck]:
    if raw is None:
        return []
    if not isinstance(raw, list):
        raise ValueError(f"jobs.{job_id}.post_checks must be a list")
    checks = []
    for i, item in enumerate(raw):
        if not isinstance(item, dict):
            raise ValueError(f"jobs.{job_id}.post_checks[{i}] must be a mapping")
        _check_unknown_keys(item, _ALLOWED_POST_CHECK_KEYS, f"jobs.{job_id}.post_checks[{i}]")
        checks.append(PostCheck(
            id=item["id"],
            sql_file=item["sql_file"],
            expect=item.get("expect"),
            severity=item.get("severity", "error"),
        ))
    return checks


def _parse_schedule(raw: Any, job_id: str) -> "Optional[ScheduleSpec]":
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise ValueError(f"jobs.{job_id}.schedule must be a mapping")
    _check_unknown_keys(raw, _ALLOWED_SCHEDULE_KEYS, f"jobs.{job_id}.schedule")
    for req in ("cron", "include_upstream", "enabled"):
        if req not in raw:
            raise ValueError(f"jobs.{job_id}.schedule is missing required field: {req!r}")
    return ScheduleSpec(
        cron=raw["cron"],
        include_upstream=bool(raw["include_upstream"]),
        enabled=bool(raw["enabled"]),
    )


def _parse_job_spec(job_id: str, raw: Dict[str, Any]) -> JobSpec:
    """Parse a single job entry from the YAML jobs mapping."""
    if not isinstance(raw, dict):
        raise ValueError(f"jobs.{job_id} must be a mapping, got {type(raw).__name__}")
    _check_unknown_keys(raw, _ALLOWED_JOB_KEYS, f"jobs.{job_id}")

    # Required fields
    for req in ("sql_file", "ddl_file", "output_tables"):
        if req not in raw:
            raise ValueError(f"jobs.{job_id} is missing required field: {req!r}")

    output_tables = raw["output_tables"]
    if not isinstance(output_tables, list) or len(output_tables) == 0:
        raise ValueError(f"jobs.{job_id}.output_tables must be a non-empty list")

    depends_on = raw.get("depends_on", [])
    if depends_on is None:
        depends_on = []
    if not isinstance(depends_on, list):
        raise ValueError(f"jobs.{job_id}.depends_on must be a list")

    return JobSpec(
        job_id=job_id,
        sql_file=raw["sql_file"],
        ddl_file=raw["ddl_file"],
        output_tables=output_tables,
        enabled=raw.get("enabled", True),
        depends_on=depends_on,
        schema_fingerprint=raw.get("schema_fingerprint", "pending"),
        idempotency=raw.get("idempotency", "unknown"),
        retry=_parse_retry(raw.get("retry"), job_id),
        timeout_seconds=raw.get("timeout_seconds"),
        post_checks=_parse_post_checks(raw.get("post_checks"), job_id),
        metadata_expectation=_parse_metadata_expectation(raw.get("metadata_expectation"), job_id),
        rollback=_parse_rollback(raw.get("rollback"), job_id),
        schedule=_parse_schedule(raw.get("schedule"), job_id),
    )


def load_config(config_path: str) -> Tuple[Dict[str, Any], List[JobSpec]]:
    """
    Load and strictly validate the jobs.yaml configuration file.

    Args:
        config_path: Absolute or relative path to the YAML file.

    Returns:
        (raw_config_dict, list_of_JobSpec)

    Raises:
        FileNotFoundError: If config file does not exist.
        ValueError: If the config is invalid (wrong version, unknown keys, etc.).
    """
    path = Path(config_path).resolve()
    if not path.exists():
        raise FileNotFoundError(f"Config file not found: {path}")
    if not path.is_file():
        raise ValueError(f"Config path is not a file: {path}")

    with path.open("r", encoding="utf-8") as fh:
        raw = yaml.safe_load(fh)

    if not isinstance(raw, dict):
        raise ValueError("Config YAML root must be a mapping (dictionary)")

    _check_unknown_keys(raw, _ALLOWED_ROOT_KEYS, "root")

    # version check
    version = raw.get("version")
    if version != 1:
        raise ValueError(
            f"Config version must be 1, got: {version!r}. "
            "Only version 1 is supported."
        )

    # environment block
    env = raw.get("environment")
    if not isinstance(env, dict):
        raise ValueError("'environment' must be a mapping")
    _check_unknown_keys(env, _ALLOWED_ENVIRONMENT_KEYS, "environment")

    # expected_spark sub-block
    expected_spark = env.get("expected_spark")
    if expected_spark is not None:
        if not isinstance(expected_spark, dict):
            raise ValueError("environment.expected_spark must be a mapping")
        _check_unknown_keys(expected_spark, _ALLOWED_EXPECTED_SPARK_KEYS, "environment.expected_spark")

    # runtime block
    runtime = raw.get("runtime")
    if not isinstance(runtime, dict):
        raise ValueError("'runtime' must be a mapping")
    _check_unknown_keys(runtime, _ALLOWED_RUNTIME_KEYS, "runtime")

    # audit sub-block
    audit = runtime.get("audit")
    if audit is not None:
        if not isinstance(audit, dict):
            raise ValueError("runtime.audit must be a mapping")
        _check_unknown_keys(audit, _ALLOWED_AUDIT_KEYS, "runtime.audit")

    # lock sub-block
    lock = runtime.get("lock")
    if lock is not None:
        if not isinstance(lock, dict):
            raise ValueError("runtime.lock must be a mapping")
        _check_unknown_keys(lock, _ALLOWED_LOCK_KEYS, "runtime.lock")

    # parallelism range check
    parallelism = runtime.get("parallelism", 1)
    if not isinstance(parallelism, int) or not (1 <= parallelism <= 32):
        raise ValueError(
            f"runtime.parallelism must be an integer in [1, 32], got: {parallelism!r}"
        )

    # retry_default validation
    retry_default_raw = runtime.get("retry_default")
    if retry_default_raw is not None:
        if not isinstance(retry_default_raw, dict):
            raise ValueError("runtime.retry_default must be a mapping")
        _check_unknown_keys(retry_default_raw, _ALLOWED_RETRY_DEFAULT_KEYS, "runtime.retry_default")

    # jobs block
    jobs_raw = raw.get("jobs")
    if not isinstance(jobs_raw, dict):
        raise ValueError("'jobs' must be a mapping")

    job_specs: List[JobSpec] = []
    for job_id, job_raw in jobs_raw.items():
        if not isinstance(job_id, str):
            raise ValueError(f"Job ID must be a string, got: {type(job_id).__name__}")
        spec = _parse_job_spec(job_id, job_raw)
        job_specs.append(spec)

    return raw, job_specs

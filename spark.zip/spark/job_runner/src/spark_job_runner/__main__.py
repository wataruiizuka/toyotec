"""Allow `python -m spark_job_runner` invocation."""
import sys
from spark_job_runner.cli import main

sys.exit(main())

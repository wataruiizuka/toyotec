"""
planner.py

Builds a deterministic execution plan (list of parallel stages) from a set of JobSpec
objects using topological sort.

When target_job_ids is specified, only those jobs and their upstream transitive
dependencies are included.
"""

from __future__ import annotations

import json
from typing import Dict, List, Optional, Set

from spark_job_runner.models import JobSpec


def _upstream_closure(
    target_ids: List[str],
    job_map: Dict[str, JobSpec],
) -> Set[str]:
    """
    Compute the transitive upstream closure of the given target job IDs.

    Raises:
        ValueError: If a target job ID is not found in job_map.
    """
    closure: Set[str] = set()
    stack = list(target_ids)

    for tid in target_ids:
        if tid not in job_map:
            raise ValueError(f"Target job ID not found: {tid!r}")

    while stack:
        jid = stack.pop()
        if jid in closure:
            continue
        closure.add(jid)
        job = job_map.get(jid)
        if job is None:
            raise ValueError(f"Job {jid!r} referenced as dependency but not defined")
        for dep in job.depends_on:
            if dep not in closure:
                stack.append(dep)

    return closure


def build_plan(
    jobs: List[JobSpec],
    target_job_ids: Optional[List[str]] = None,
    include_upstream: bool = True,
) -> List[List[JobSpec]]:
    """
    Build an ordered list of execution stages using topological sort (Kahn's algorithm).

    Each stage is a list of JobSpec objects that can be run in parallel because
    all their dependencies have been satisfied by previous stages.

    Args:
        jobs: All job definitions.
        target_job_ids: If provided, restrict execution to these jobs and their
                        upstream transitive dependencies.

    Returns:
        List of stages; each stage is a list of JobSpec.

    Raises:
        ValueError: On cyclic dependencies or undefined dependency references.
    """
    if not jobs:
        return []

    job_map: Dict[str, JobSpec] = {}
    for job in jobs:
        if job.job_id in job_map:
            raise ValueError(f"Duplicate job_id: {job.job_id!r}")
        job_map[job.job_id] = job

    # Filter to target set if specified
    if target_job_ids:
        if include_upstream:
            included_ids = _upstream_closure(target_job_ids, job_map)
        else:
            unknown = [jid for jid in target_job_ids if jid not in job_map]
            if unknown:
                raise ValueError(f"Unknown job IDs: {unknown}")
            included_ids = set(target_job_ids)
        active_jobs = [j for j in jobs if j.job_id in included_ids]
    else:
        active_jobs = list(jobs)

    active_ids = {j.job_id for j in active_jobs}

    # Build dependency map restricted to active jobs
    in_edges: Dict[str, Set[str]] = {}
    for job in active_jobs:
        in_edges[job.job_id] = set()
        for dep in job.depends_on:
            if dep not in active_ids:
                raise ValueError(
                    f"Job {job.job_id!r} depends on {dep!r} which is not in the active set"
                )
            in_edges[job.job_id].add(dep)

    # Kahn's algorithm for topological stages
    stages: List[List[JobSpec]] = []
    resolved: Set[str] = set()
    remaining = {j.job_id for j in active_jobs}

    while remaining:
        # Jobs whose all dependencies are resolved
        ready = sorted(
            jid for jid in remaining if in_edges[jid].issubset(resolved)
        )
        if not ready:
            unresolved = {jid: sorted(in_edges[jid] - resolved) for jid in remaining}
            raise ValueError(
                f"Cyclic dependency detected or unresolvable dependencies: {unresolved}"
            )

        stage = [job_map[jid] for jid in ready]
        stages.append(stage)
        for jid in ready:
            resolved.add(jid)
            remaining.discard(jid)

    return stages


def format_plan_text(stages: List[List[JobSpec]]) -> str:
    """Format the execution plan as a human-readable text string."""
    lines = []
    total = sum(len(s) for s in stages)
    lines.append(f"Execution plan: {len(stages)} stage(s), {total} job(s) total")
    lines.append("")
    for i, stage in enumerate(stages, start=1):
        lines.append(f"Stage {i} ({len(stage)} job(s)):")
        for job in stage:
            deps = ", ".join(job.depends_on) if job.depends_on else "-"
            lines.append(f"  {job.job_id}  depends_on=[{deps}]  output_tables={job.output_tables}")
    return "\n".join(lines)


def format_plan_json(stages: List[List[JobSpec]]) -> str:
    """Format the execution plan as a JSON string."""
    plan = []
    for i, stage in enumerate(stages, start=1):
        plan.append({
            "stage": i,
            "jobs": [
                {
                    "job_id": job.job_id,
                    "ddl_file": job.ddl_file,
                    "sql_file": job.sql_file,
                    "output_tables": job.output_tables,
                    "depends_on": job.depends_on,
                    "enabled": job.enabled,
                }
                for job in stage
            ],
        })
    return json.dumps({"stages": plan}, indent=2, ensure_ascii=False)

"""
executor.py

JobRunner manages DDL phase and SQL DAG phase execution.

- DDL phase: executes all DDL files to create empty tables (CREATE TABLE IF NOT EXISTS).
- SQL DAG phase: executes SQL stages in order; jobs within a stage run in parallel
  (bounded by parallelism setting).
- State transitions: PENDING -> RUNNING -> SUCCESS/FAILED/SKIPPED/TIMED_OUT/CANCELLED
- Dependency failure causes downstream jobs to be SKIPPED.
- SQL text is never written to standard logs (sanitization).
"""

from __future__ import annotations

import datetime
import logging
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Dict, List, Optional, Set

from spark_job_runner.models import (
    ErrorCategory,
    JobResult,
    JobSpec,
    JobStatus,
    RetryAttempt,
    RetrySpec,
)
from spark_job_runner.spark_runtime import SparkRuntime
from spark_job_runner.sql_parser import split_sql_statements

logger = logging.getLogger(__name__)


def _now() -> datetime.datetime:
    return datetime.datetime.now(tz=datetime.timezone.utc)


def _elapsed_ms(start: datetime.datetime, end: datetime.datetime) -> float:
    return (end - start).total_seconds() * 1000.0


def _sanitize_error(exc: Exception, category: ErrorCategory) -> str:
    """
    Build a sanitized error string: exception type + short message only.
    Full tracebacks and SQL text are never included.
    """
    raw_msg = str(exc)
    # Truncate at 500 chars; no newlines
    truncated = raw_msg.replace("\n", " ").replace("\r", " ")[:500]
    return f"{category.value}: {type(exc).__name__}: {truncated}"


def _resolve_retry_spec(job: JobSpec, retry_default: Optional[dict]) -> RetrySpec:
    """Return effective RetrySpec: job-level config overrides retry_default."""
    if job.retry.max_attempts > 1 or job.retry.retryable_categories:
        return job.retry
    if retry_default:
        return RetrySpec(
            max_attempts=retry_default.get("max_attempts", 3),
            backoff_seconds=retry_default.get("backoff_seconds", [30, 60, 120]),
            retryable_categories=retry_default.get(
                "retryable_categories", ["SPARK_TRANSIENT", "SPARK_EXECUTION"]
            ),
        )
    return job.retry


def _categorize_exception(exc: Exception) -> ErrorCategory:
    """
    Map an exception to an ErrorCategory.
    Only well-known exception classes are categorized; all else are INTERNAL.
    """
    exc_type = type(exc).__name__
    exc_module = type(exc).__module__ or ""

    if "AnalysisException" in exc_type:
        return ErrorCategory.SPARK_ANALYSIS
    if exc_type in ("ParseException",):
        return ErrorCategory.SQL_PARSE
    if "pyspark" in exc_module:
        return ErrorCategory.SPARK_EXECUTION
    if isinstance(exc, (FileNotFoundError, PermissionError)):
        return ErrorCategory.CONFIG
    return ErrorCategory.INTERNAL


class JobRunner:
    """
    Orchestrates DDL and SQL execution for a set of jobs.

    Args:
        config: Raw config dict from load_config().
        jobs: List of JobSpec objects.
        runtime: SparkRuntime instance.
        parallelism: Maximum number of jobs to run concurrently within a stage.
        ddl_root: Root directory for DDL files (resolved against config paths).
        sql_root: Root directory for SQL files.
        run_id: Unique identifier for this run (used for Spark job groups).
    """

    def __init__(
        self,
        config: dict,
        jobs: List[JobSpec],
        runtime: SparkRuntime,
        parallelism: int = 1,
        ddl_root: str = ".",
        sql_root: str = ".",
        run_id: str = "run-0",
        retry_default: Optional[dict] = None,
    ) -> None:
        self.config = config
        self.jobs = jobs
        self.runtime = runtime
        self.parallelism = parallelism
        self.ddl_root = Path(ddl_root).resolve()
        self.sql_root = Path(sql_root).resolve()
        self.run_id = run_id
        self.retry_default = retry_default

    # ------------------------------------------------------------------
    # DDL phase
    # ------------------------------------------------------------------

    def run_ddl_phase(self, jobs: List[JobSpec]) -> Dict[str, JobResult]:
        """
        Execute DDL files for all specified jobs to create empty tables.

        DDL files use CREATE TABLE IF NOT EXISTS, so this is safe to re-run.
        All DDLs run serially (parallelism=1 for DDL phase per design).

        Returns:
            Mapping of job_id -> JobResult with ddl_status set.
        """
        results: Dict[str, JobResult] = {}

        for job in jobs:
            result = self._execute_ddl(job)
            results[job.job_id] = result

            if result.ddl_status == JobStatus.FAILED:
                logger.warning(
                    "[%s] DDL phase failed. Stopping DDL execution for remaining jobs.",
                    job.job_id,
                )
                # Mark remaining jobs as FAILED (DDL barrier)
                remaining_jobs = [j for j in jobs if j.job_id not in results]
                for remaining in remaining_jobs:
                    results[remaining.job_id] = JobResult(
                        job_id=remaining.job_id,
                        status=JobStatus.FAILED,
                        ddl_status=JobStatus.SKIPPED,
                        sql_status=JobStatus.PENDING,
                        error_category=ErrorCategory.CONFIG,
                        sanitized_error="CONFIG: DDL phase aborted due to earlier DDL failure",
                    )
                break

        return results

    def _execute_ddl(self, job: JobSpec) -> JobResult:
        """Execute the DDL file for a single job."""
        started_at = _now()
        ddl_path = (self.ddl_root / job.ddl_file).resolve()

        result = JobResult(
            job_id=job.job_id,
            status=JobStatus.RUNNING,
            ddl_status=JobStatus.RUNNING,
            sql_status=JobStatus.PENDING,
            started_at=started_at,
        )

        try:
            ddl_text = ddl_path.read_text(encoding="utf-8")
            statements = split_sql_statements(ddl_text)

            if not statements:
                raise ValueError(f"No SQL statements found in DDL file: {ddl_path}")

            group_id = f"{self.run_id}/{job.job_id}"
            self.runtime.set_job_group(self.run_id, job.job_id, f"DDL: {job.job_id}")

            for stmt in statements:
                self.runtime.execute_sql(stmt, job.job_id)

            finished_at = _now()
            result.ddl_status = JobStatus.SUCCESS
            result.status = JobStatus.RUNNING  # Still waiting for SQL phase
            result.finished_at = finished_at
            result.elapsed_ms = _elapsed_ms(started_at, finished_at)
            result.spark_job_group = group_id
            logger.info("[%s] DDL phase succeeded", job.job_id)

        except Exception as exc:
            finished_at = _now()
            category = _categorize_exception(exc)
            result.ddl_status = JobStatus.FAILED
            result.status = JobStatus.FAILED
            result.finished_at = finished_at
            result.elapsed_ms = _elapsed_ms(started_at, finished_at)
            result.error_category = category
            result.sanitized_error = _sanitize_error(exc, category)
            logger.error("[%s] DDL phase failed: %s", job.job_id, result.sanitized_error)

        return result

    # ------------------------------------------------------------------
    # SQL DAG phase
    # ------------------------------------------------------------------

    def run_sql_phase(
        self,
        stages: List[List[JobSpec]],
        ddl_results: Optional[Dict[str, JobResult]] = None,
    ) -> Dict[str, JobResult]:
        """
        Execute SQL files for all jobs organized into dependency stages.

        Jobs in the same stage run in parallel up to self.parallelism.
        A job is SKIPPED if any of its direct dependencies failed or were skipped.

        Args:
            stages: Output from planner.build_plan().
            ddl_results: DDL phase results; used to carry over ddl_status.

        Returns:
            Mapping of job_id -> JobResult with sql_status and final status set.
        """
        ddl_results = ddl_results or {}
        sql_results: Dict[str, JobResult] = {}
        terminal_failed: Set[str] = set()  # job_ids that are FAILED or SKIPPED

        for stage_num, stage_jobs in enumerate(stages, start=1):
            logger.info(
                "SQL stage %d: %d job(s): %s",
                stage_num,
                len(stage_jobs),
                [j.job_id for j in stage_jobs],
            )

            runnable: List[JobSpec] = []
            for job in stage_jobs:
                blocked_by = [dep for dep in job.depends_on if dep in terminal_failed]
                if blocked_by:
                    # SKIPPED due to upstream failure
                    prev_ddl = ddl_results.get(job.job_id)
                    skip_result = JobResult(
                        job_id=job.job_id,
                        status=JobStatus.SKIPPED,
                        ddl_status=prev_ddl.ddl_status if prev_ddl else JobStatus.PENDING,
                        sql_status=JobStatus.SKIPPED,
                        stage=stage_num,
                        blocked_by=blocked_by,
                        sanitized_error=f"SKIPPED: blocked by upstream jobs: {blocked_by}",
                    )
                    sql_results[job.job_id] = skip_result
                    terminal_failed.add(job.job_id)
                    logger.warning("[%s] SKIPPED (blocked_by=%s)", job.job_id, blocked_by)
                else:
                    runnable.append(job)

            if not runnable:
                continue

            # Run jobs in this stage in parallel (bounded by parallelism)
            max_workers = min(self.parallelism, len(runnable))
            with ThreadPoolExecutor(max_workers=max_workers) as pool:
                future_to_job = {
                    pool.submit(self.execute_job_sql, job): job for job in runnable
                }
                for future in as_completed(future_to_job):
                    job = future_to_job[future]
                    try:
                        result = future.result()
                    except Exception as exc:
                        # Unexpected executor-level failure
                        result = JobResult(
                            job_id=job.job_id,
                            status=JobStatus.FAILED,
                            sql_status=JobStatus.FAILED,
                            stage=stage_num,
                            error_category=ErrorCategory.INTERNAL,
                            sanitized_error=_sanitize_error(exc, ErrorCategory.INTERNAL),
                        )

                    # Merge DDL result data if available
                    prev_ddl = ddl_results.get(job.job_id)
                    if prev_ddl:
                        result.ddl_status = prev_ddl.ddl_status
                        if result.spark_job_group is None:
                            result.spark_job_group = prev_ddl.spark_job_group

                    result.stage = stage_num
                    sql_results[job.job_id] = result

                    if result.status in (JobStatus.FAILED, JobStatus.SKIPPED,
                                         JobStatus.CANCELLED, JobStatus.TIMED_OUT):
                        terminal_failed.add(job.job_id)

        return sql_results

    def execute_job_sql(self, job: JobSpec) -> JobResult:
        """Execute a single job's SQL file with retry logic."""
        started_at = _now()
        sql_path = (self.sql_root / job.sql_file).resolve()
        group_id = f"{self.run_id}/{job.job_id}"

        retry_spec = _resolve_retry_spec(job, self.retry_default)
        max_attempts = max(1, retry_spec.max_attempts)
        retryable = set(retry_spec.retryable_categories)
        backoff = retry_spec.backoff_seconds

        result = JobResult(
            job_id=job.job_id,
            status=JobStatus.RUNNING,
            sql_status=JobStatus.RUNNING,
            started_at=started_at,
            spark_job_group=group_id,
            attempts=0,
        )

        try:
            sql_text = sql_path.read_text(encoding="utf-8")
            statements = split_sql_statements(sql_text)
            if not statements:
                raise ValueError(f"No executable SQL statements found in: {sql_path}")
        except Exception as exc:
            finished_at = _now()
            category = _categorize_exception(exc)
            result.sql_status = JobStatus.FAILED
            result.status = JobStatus.FAILED
            result.finished_at = finished_at
            result.elapsed_ms = _elapsed_ms(started_at, finished_at)
            result.error_category = category
            result.sanitized_error = _sanitize_error(exc, category)
            result.attempts = 1
            logger.error("[%s] SQL file read failed: %s", job.job_id, result.sanitized_error)
            return result

        for attempt in range(1, max_attempts + 1):
            result.attempts = attempt
            try:
                self.runtime.set_job_group(self.run_id, job.job_id, f"SQL: {job.job_id}")
                logger.info(
                    "[%s] Attempt %d/%d: executing %d SQL statement(s)",
                    job.job_id, attempt, max_attempts, len(statements),
                )
                for idx, stmt in enumerate(statements, start=1):
                    logger.debug(
                        "[%s] Statement %d/%d (content omitted)",
                        job.job_id, idx, len(statements),
                    )
                    self.runtime.execute_sql(stmt, job.job_id)

                finished_at = _now()
                result.sql_status = JobStatus.SUCCESS
                result.status = JobStatus.SUCCESS
                result.finished_at = finished_at
                result.elapsed_ms = _elapsed_ms(started_at, finished_at)
                logger.info(
                    "[%s] SQL phase succeeded on attempt %d (%.0f ms)",
                    job.job_id, attempt, result.elapsed_ms,
                )
                return result

            except Exception as exc:
                category = _categorize_exception(exc)
                sanitized = _sanitize_error(exc, category)
                will_retry = (attempt < max_attempts) and (category.value in retryable)
                wait = 0
                if will_retry:
                    wait = backoff[attempt - 1] if attempt - 1 < len(backoff) else (backoff[-1] if backoff else 0)

                result.retry_attempts.append(RetryAttempt(
                    attempt=attempt,
                    error_category=category.value,
                    sanitized_error=sanitized,
                    retried=will_retry,
                    waited_seconds=wait,
                ))

                if will_retry:
                    logger.warning(
                        "[%s] Attempt %d/%d failed (%s). Retrying in %ds. reason=%s",
                        job.job_id, attempt, max_attempts, category.value, wait, sanitized,
                    )
                    time.sleep(wait)
                else:
                    finished_at = _now()
                    result.sql_status = JobStatus.FAILED
                    result.status = JobStatus.FAILED
                    result.finished_at = finished_at
                    result.elapsed_ms = _elapsed_ms(started_at, finished_at)
                    result.error_category = category
                    result.sanitized_error = sanitized
                    logger.error(
                        "[%s] Attempt %d/%d failed (%s). Not retrying. reason=%s",
                        job.job_id, attempt, max_attempts, category.value, sanitized,
                    )
                    return result

        return result

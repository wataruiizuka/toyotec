"""Tests for static validator."""
import os
import tempfile
from pathlib import Path

import pytest
import yaml

from spark_job_runner.validator import validate


def _write_file(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content, encoding="utf-8")


def _make_config(tmp: str, jobs: dict) -> str:
    cfg = {
        "version": 1,
        "environment": {
            "environment_id": "test",
            "mode": "development",
            "allowed_ddl_root": str(tmp) + "/ddl",
            "allowed_sql_root": str(tmp) + "/sql",
            "allowed_source_namespaces": ["ns"],
            "source_inventory_sha256": "pending",
            "expected_spark": {"distribution": "pending", "version": "3.3"},
            "production_write_allowed": False,
        },
        "runtime": {
            "timezone": "Asia/Tokyo",
            "parallelism": 1,
            "allow_empty": False,
            "sql_parser": "spark_sql_v1",
            "statement_preview": False,
            "cancel_grace_seconds": 60,
            "audit": {
                "provider": "posix",
                "uri": "/tmp/audit",
                "retention_days": 90,
                "encryption_required": False,
                "acl_profile": "test",
            },
            "lock": {
                "provider": "posix",
                "uri": "/tmp/locks",
                "lease_seconds": 300,
                "renew_seconds": 60,
            },
        },
        "jobs": jobs,
        "approved_exceptions": [],
    }
    config_path = os.path.join(tmp, "jobs.yaml")
    with open(config_path, "w") as f:
        yaml.dump(cfg, f)
    return config_path


def test_valid_job_no_errors():
    with tempfile.TemporaryDirectory() as tmp:
        ddl_root = Path(tmp) / "ddl"
        sql_root = Path(tmp) / "sql"

        _write_file(ddl_root / "dx_doujyou" / "vbi000001.ddl",
                    "CREATE TABLE IF NOT EXISTS gold.vbi000001 (id INT)")
        _write_file(sql_root / "dx_doujyou" / "vbi000001.sql",
                    "INSERT OVERWRITE gold.vbi000001 SELECT id FROM src")

        config_path = _make_config(tmp, {
            "dx_doujyou.vbi000001": {
                "sql_file": "dx_doujyou/vbi000001.sql",
                "ddl_file": "dx_doujyou/vbi000001.ddl",
                "output_tables": ["gold.vbi000001"],
                "schema_fingerprint": "pending",
                "idempotency": "unknown",
                "metadata_expectation": {},
                "rollback": {"strategy": "none"},
            }
        })

        errors = validate(config_path, str(ddl_root), str(sql_root))
        assert errors == []


def test_missing_ddl_file_error():
    with tempfile.TemporaryDirectory() as tmp:
        ddl_root = Path(tmp) / "ddl"
        sql_root = Path(tmp) / "sql"

        # Only create SQL, not DDL
        _write_file(sql_root / "dx_doujyou" / "vbi000001.sql",
                    "INSERT OVERWRITE gold.vbi000001 SELECT id FROM src")

        config_path = _make_config(tmp, {
            "dx_doujyou.vbi000001": {
                "sql_file": "dx_doujyou/vbi000001.sql",
                "ddl_file": "dx_doujyou/vbi000001.ddl",
                "output_tables": ["gold.vbi000001"],
                "schema_fingerprint": "pending",
                "idempotency": "unknown",
                "metadata_expectation": {},
                "rollback": {"strategy": "none"},
            }
        })

        errors = validate(config_path, str(ddl_root), str(sql_root))
        assert any("DDL file not found" in e for e in errors)


def test_ddl_without_create_table_if_not_exists():
    with tempfile.TemporaryDirectory() as tmp:
        ddl_root = Path(tmp) / "ddl"
        sql_root = Path(tmp) / "sql"

        _write_file(ddl_root / "dx_doujyou" / "vbi000001.ddl",
                    "CREATE TABLE gold.vbi000001 (id INT)")  # Missing IF NOT EXISTS
        _write_file(sql_root / "dx_doujyou" / "vbi000001.sql",
                    "INSERT OVERWRITE gold.vbi000001 SELECT id FROM src")

        config_path = _make_config(tmp, {
            "dx_doujyou.vbi000001": {
                "sql_file": "dx_doujyou/vbi000001.sql",
                "ddl_file": "dx_doujyou/vbi000001.ddl",
                "output_tables": ["gold.vbi000001"],
                "schema_fingerprint": "pending",
                "idempotency": "unknown",
                "metadata_expectation": {},
                "rollback": {"strategy": "none"},
            }
        })

        errors = validate(config_path, str(ddl_root), str(sql_root))
        assert any("CREATE TABLE IF NOT EXISTS" in e for e in errors)


def test_undefined_dependency_error():
    with tempfile.TemporaryDirectory() as tmp:
        ddl_root = Path(tmp) / "ddl"
        sql_root = Path(tmp) / "sql"

        _write_file(ddl_root / "dx_doujyou" / "vbi000002.ddl",
                    "CREATE TABLE IF NOT EXISTS gold.vbi000002 (id INT)")
        _write_file(sql_root / "dx_doujyou" / "vbi000002.sql",
                    "INSERT OVERWRITE gold.vbi000002 SELECT id FROM src")

        config_path = _make_config(tmp, {
            "dx_doujyou.vbi000002": {
                "sql_file": "dx_doujyou/vbi000002.sql",
                "ddl_file": "dx_doujyou/vbi000002.ddl",
                "output_tables": ["gold.vbi000002"],
                "depends_on": ["dx_doujyou.vbi000001"],  # not defined
                "schema_fingerprint": "pending",
                "idempotency": "unknown",
                "metadata_expectation": {},
                "rollback": {"strategy": "none"},
            }
        })

        errors = validate(config_path, str(ddl_root), str(sql_root))
        assert any("undefined job" in e for e in errors)


def test_duplicate_output_table_error():
    with tempfile.TemporaryDirectory() as tmp:
        ddl_root = Path(tmp) / "ddl"
        sql_root = Path(tmp) / "sql"

        for name in ("vbi000001", "vbi000002"):
            _write_file(ddl_root / "dx_doujyou" / f"{name}.ddl",
                        "CREATE TABLE IF NOT EXISTS gold.shared_table (id INT)")
            _write_file(sql_root / "dx_doujyou" / f"{name}.sql",
                        "INSERT OVERWRITE gold.shared_table SELECT id FROM src")

        config_path = _make_config(tmp, {
            "dx_doujyou.vbi000001": {
                "sql_file": "dx_doujyou/vbi000001.sql",
                "ddl_file": "dx_doujyou/vbi000001.ddl",
                "output_tables": ["gold.shared_table"],
                "schema_fingerprint": "pending",
                "idempotency": "unknown",
                "metadata_expectation": {},
                "rollback": {"strategy": "none"},
            },
            "dx_doujyou.vbi000002": {
                "sql_file": "dx_doujyou/vbi000002.sql",
                "ddl_file": "dx_doujyou/vbi000002.ddl",
                "output_tables": ["gold.shared_table"],
                "schema_fingerprint": "pending",
                "idempotency": "unknown",
                "metadata_expectation": {},
                "rollback": {"strategy": "none"},
            },
        })

        errors = validate(config_path, str(ddl_root), str(sql_root))
        assert any("also claimed by" in e for e in errors)

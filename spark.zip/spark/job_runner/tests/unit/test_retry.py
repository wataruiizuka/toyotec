"""Tests for retry logic in executor.py."""
from unittest.mock import MagicMock, patch

import pytest

from spark_job_runner.executor import JobRunner, _resolve_retry_spec
from spark_job_runner.models import ErrorCategory, JobSpec, JobStatus, RetrySpec


def _make_job(job_id="dx_doujyou.test", retry=None):
    return JobSpec(
        job_id=job_id,
        sql_file="test.sql",
        ddl_file="test_ddl.sql",
        output_tables=["gold.test"],
        retry=retry or RetrySpec(),
    )


def _make_runner(tmp_path, retry_default=None):
    sql = tmp_path / "test.sql"
    sql.write_text("SELECT 1;")
    runtime = MagicMock()
    return JobRunner(
        config={},
        jobs=[],
        runtime=runtime,
        ddl_root=str(tmp_path),
        sql_root=str(tmp_path),
        run_id="run-test",
        retry_default=retry_default,
    ), runtime


def test_success_on_first_attempt(tmp_path):
    runner, runtime = _make_runner(tmp_path)
    job = _make_job()
    result = runner.execute_job_sql(job)
    assert result.status == JobStatus.SUCCESS
    assert result.attempts == 1
    assert result.retry_attempts == []


def test_retries_on_transient_error(tmp_path):
    runner, runtime = _make_runner(
        tmp_path,
        retry_default={
            "max_attempts": 3,
            "backoff_seconds": [0, 0, 0],
            "retryable_categories": ["SPARK_TRANSIENT", "SPARK_EXECUTION"],
        },
    )
    job = _make_job()
    call_count = 0

    def fake_execute(sql, job_id):
        nonlocal call_count
        call_count += 1
        if call_count < 3:
            raise RuntimeError("connection reset")

    runtime.execute_sql.side_effect = fake_execute

    with patch("spark_job_runner.executor._categorize_exception",
               return_value=ErrorCategory.SPARK_TRANSIENT):
        with patch("spark_job_runner.executor.time.sleep"):
            result = runner.execute_job_sql(job)

    assert result.status == JobStatus.SUCCESS
    assert result.attempts == 3
    assert len(result.retry_attempts) == 2
    assert result.retry_attempts[0].retried is True
    assert result.retry_attempts[1].retried is True


def test_gives_up_after_max_attempts(tmp_path):
    runner, runtime = _make_runner(
        tmp_path,
        retry_default={
            "max_attempts": 3,
            "backoff_seconds": [0, 0],
            "retryable_categories": ["SPARK_TRANSIENT"],
        },
    )
    job = _make_job()
    runtime.execute_sql.side_effect = RuntimeError("always fails")

    with patch("spark_job_runner.executor._categorize_exception",
               return_value=ErrorCategory.SPARK_TRANSIENT):
        with patch("spark_job_runner.executor.time.sleep"):
            result = runner.execute_job_sql(job)

    assert result.status == JobStatus.FAILED
    assert result.attempts == 3
    assert len(result.retry_attempts) == 3
    assert result.retry_attempts[-1].retried is False


def test_no_retry_for_non_retryable_category(tmp_path):
    runner, runtime = _make_runner(
        tmp_path,
        retry_default={
            "max_attempts": 3,
            "backoff_seconds": [0, 0],
            "retryable_categories": ["SPARK_TRANSIENT"],
        },
    )
    job = _make_job()
    runtime.execute_sql.side_effect = RuntimeError("analysis error")

    with patch("spark_job_runner.executor._categorize_exception",
               return_value=ErrorCategory.SPARK_ANALYSIS):
        result = runner.execute_job_sql(job)

    assert result.status == JobStatus.FAILED
    assert result.attempts == 1
    assert len(result.retry_attempts) == 1
    assert result.retry_attempts[0].retried is False


def test_resolve_retry_spec_uses_job_retry_when_configured():
    job = _make_job(retry=RetrySpec(
        max_attempts=5,
        backoff_seconds=[10],
        retryable_categories=["SPARK_TRANSIENT"],
    ))
    spec = _resolve_retry_spec(job, {"max_attempts": 3, "backoff_seconds": [30]})
    assert spec.max_attempts == 5


def test_resolve_retry_spec_falls_back_to_default():
    job = _make_job()
    spec = _resolve_retry_spec(job, {
        "max_attempts": 3,
        "backoff_seconds": [30, 60, 120],
        "retryable_categories": ["SPARK_TRANSIENT"],
    })
    assert spec.max_attempts == 3

"""Tests for config loading and validation."""
import os
import tempfile

import pytest
import yaml

from spark_job_runner.config import load_config


def write_yaml(content: dict) -> str:
    f = tempfile.NamedTemporaryFile(mode="w", suffix=".yaml", delete=False)
    yaml.dump(content, f)
    f.close()
    return f.name


def _minimal_config() -> dict:
    return {
        "version": 1,
        "environment": {
            "environment_id": "test",
            "mode": "development",
            "allowed_ddl_root": "/tmp/ddl",
            "allowed_sql_root": "/tmp/sql",
            "allowed_source_namespaces": ["ns1"],
            "source_inventory_sha256": "pending",
            "expected_spark": {"distribution": "pending", "version": "3.3"},
            "production_write_allowed": False,
        },
        "runtime": {
            "timezone": "Asia/Tokyo",
            "parallelism": 1,
            "allow_empty": False,
            "sql_parser": "spark_sql_v1",
            "statement_preview": False,
            "cancel_grace_seconds": 60,
            "audit": {
                "provider": "posix",
                "uri": "/tmp/audit",
                "retention_days": 90,
                "encryption_required": False,
                "acl_profile": "test",
            },
            "lock": {
                "provider": "posix",
                "uri": "/tmp/locks",
                "lease_seconds": 300,
                "renew_seconds": 60,
            },
        },
        "jobs": {},
        "approved_exceptions": [],
    }


def test_valid_config_loads():
    config_data = _minimal_config()
    path = write_yaml(config_data)
    try:
        raw, jobs = load_config(path)
        assert raw["version"] == 1
        assert jobs == []
    finally:
        os.unlink(path)


def test_wrong_version_raises():
    config_data = {"version": 2, "environment": {}, "runtime": {}, "jobs": {}}
    path = write_yaml(config_data)
    try:
        with pytest.raises(ValueError, match="version"):
            load_config(path)
    finally:
        os.unlink(path)


def test_unknown_root_key_raises():
    config_data = _minimal_config()
    config_data["unknown_key"] = "value"
    path = write_yaml(config_data)
    try:
        with pytest.raises(ValueError, match="Unknown key"):
            load_config(path)
    finally:
        os.unlink(path)


def test_unknown_job_key_raises():
    config_data = _minimal_config()
    config_data["jobs"] = {
        "test.job": {
            "sql_file": "test.sql",
            "ddl_file": "test.ddl",
            "output_tables": ["gold.test"],
            "schema_fingerprint": "pending",
            "idempotency": "unknown",
            "metadata_expectation": {},
            "rollback": {"strategy": "none"},
            "bad_unknown_field": True,
        }
    }
    path = write_yaml(config_data)
    try:
        with pytest.raises(ValueError, match="Unknown key"):
            load_config(path)
    finally:
        os.unlink(path)


def test_valid_job_parses():
    config_data = _minimal_config()
    config_data["jobs"] = {
        "dx_doujyou.vbi000001": {
            "sql_file": "dx_doujyou/vbi000001.sql",
            "ddl_file": "dx_doujyou/vbi000001.ddl",
            "output_tables": ["gold.vbi000001"],
            "enabled": True,
            "depends_on": [],
            "schema_fingerprint": "pending",
            "idempotency": "unknown",
            "retry": {"max_attempts": 1, "backoff_seconds": [], "retryable_categories": []},
            "timeout_seconds": None,
            "post_checks": [],
            "metadata_expectation": {
                "internal_gold_dependencies": [],
                "runtime_requirements": [],
                "output_tables": ["gold.vbi000001"],
            },
            "rollback": {"strategy": "none", "restore_test_id": None,
                         "rpo_minutes": None, "rto_minutes": None},
        }
    }
    path = write_yaml(config_data)
    try:
        raw, jobs = load_config(path)
        assert len(jobs) == 1
        job = jobs[0]
        assert job.job_id == "dx_doujyou.vbi000001"
        assert job.sql_file == "dx_doujyou/vbi000001.sql"
        assert job.output_tables == ["gold.vbi000001"]
    finally:
        os.unlink(path)


def test_file_not_found_raises():
    with pytest.raises(FileNotFoundError):
        load_config("/nonexistent/path/jobs.yaml")


def test_parallelism_out_of_range_raises():
    config_data = _minimal_config()
    config_data["runtime"]["parallelism"] = 100
    path = write_yaml(config_data)
    try:
        with pytest.raises(ValueError, match="parallelism"):
            load_config(path)
    finally:
        os.unlink(path)

"""Tests for generate_crontab in scheduler.py."""
from spark_job_runner.models import JobSpec, ScheduleSpec
from spark_job_runner.scheduler import generate_crontab


def _make_job(job_id, cron="0 3 * * *", include_upstream=True, enabled=True):
    return JobSpec(
        job_id=job_id,
        sql_file="test.sql",
        ddl_file="test_ddl.sql",
        output_tables=["gold.test"],
        schedule=ScheduleSpec(cron=cron, include_upstream=include_upstream, enabled=enabled),
    )


def test_single_job_generates_crontab():
    jobs = [_make_job("dx_doujyou.vbi000001")]
    output = generate_crontab(
        jobs,
        config_path="job_runner/config/jobs.yaml",
        base_dir="/opt/blue_crystal/spark",
        log_dir="/var/log/cron",
    )
    assert "0 3 * * *" in output
    assert "--job dx_doujyou.vbi000001" in output
    assert "vbi000001.log" in output
    assert "# dx_doujyou.vbi000001" in output


def test_disabled_job_excluded():
    jobs = [_make_job("dx_doujyou.vbi000001", enabled=False)]
    output = generate_crontab(jobs, "cfg.yaml", "/base", "/logs")
    assert output.strip() == ""


def test_no_schedule_excluded():
    job = JobSpec(
        job_id="dx_doujyou.vbi000002",
        sql_file="test.sql",
        ddl_file="test_ddl.sql",
        output_tables=["gold.test"],
    )
    output = generate_crontab([job], "cfg.yaml", "/base", "/logs")
    assert output.strip() == ""


def test_no_upstream_flag_when_include_upstream_false():
    jobs = [_make_job("dx_doujyou.vbi000003", include_upstream=False)]
    output = generate_crontab(jobs, "cfg.yaml", "/base", "/logs")
    assert "--no-upstream" in output


def test_include_upstream_true_no_no_upstream_flag():
    jobs = [_make_job("dx_doujyou.vbi000004", include_upstream=True)]
    output = generate_crontab(jobs, "cfg.yaml", "/base", "/logs")
    assert "--no-upstream" not in output


def test_multiple_jobs():
    jobs = [
        _make_job("dx_doujyou.vbi000001", cron="0 3 * * *"),
        _make_job("dx_doujyou.vbi000002", cron="0 4 * * *"),
    ]
    output = generate_crontab(jobs, "cfg.yaml", "/base", "/logs")
    assert "0 3 * * *" in output
    assert "0 4 * * *" in output
    assert "vbi000001.log" in output
    assert "vbi000002.log" in output

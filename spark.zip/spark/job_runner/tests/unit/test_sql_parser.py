"""Tests for SQL statement splitting."""
from spark_job_runner.sql_parser import split_sql_statements


def test_single_statement():
    sql = "SELECT 1"
    stmts = split_sql_statements(sql)
    assert stmts == ["SELECT 1"]


def test_multiple_statements():
    sql = "SELECT 1; SELECT 2; SELECT 3"
    stmts = split_sql_statements(sql)
    assert len(stmts) == 3


def test_removes_comments():
    sql = "-- comment\nSELECT 1"
    stmts = split_sql_statements(sql)
    assert len(stmts) == 1
    assert "comment" not in stmts[0]


def test_semicolon_in_string_not_split():
    sql = "SELECT 'a;b' AS val"
    stmts = split_sql_statements(sql)
    assert len(stmts) == 1


def test_block_comment_removed():
    sql = "/* block comment */ SELECT 1"
    stmts = split_sql_statements(sql)
    assert len(stmts) == 1
    assert "block comment" not in stmts[0]


def test_empty_string_returns_empty():
    assert split_sql_statements("") == []
    assert split_sql_statements("   ") == []


def test_trailing_semicolon():
    sql = "SELECT 1;"
    stmts = split_sql_statements(sql)
    assert len(stmts) == 1
    assert stmts[0] == "SELECT 1"


def test_only_comments_returns_empty():
    sql = "-- this is all comments\n/* and a block too */"
    stmts = split_sql_statements(sql)
    assert stmts == []


def test_multiline_block_comment():
    sql = """/*
This is a
multiline comment
*/
SELECT 1"""
    stmts = split_sql_statements(sql)
    assert len(stmts) == 1
    assert "multiline" not in stmts[0]


def test_insert_overwrite_statement():
    sql = """
    -- Insert statement
    INSERT OVERWRITE gold.my_table
    SELECT col1, col2
    FROM source_table
    WHERE dt = '2024-01-01';
    """
    stmts = split_sql_statements(sql)
    assert len(stmts) == 1
    assert "INSERT OVERWRITE" in stmts[0]


def test_double_quote_string_not_split():
    sql = 'SELECT "a;b" AS val'
    stmts = split_sql_statements(sql)
    assert len(stmts) == 1

"""Tests for dependency resolution and stage building."""
import pytest
from spark_job_runner.models import JobSpec
from spark_job_runner.planner import build_plan


def make_job(job_id, depends_on=None, output_tables=None):
    return JobSpec(
        job_id=job_id,
        sql_file=f"{job_id}.sql",
        ddl_file=f"{job_id}.ddl",
        output_tables=output_tables or [f"gold.{job_id}"],
        depends_on=depends_on or [],
    )


def test_no_deps_single_stage():
    jobs = [make_job("dx_doujyou.a"), make_job("dx_doujyou.b")]
    stages = build_plan(jobs)
    assert len(stages) == 1
    assert len(stages[0]) == 2


def test_simple_chain():
    jobs = [
        make_job("dx_doujyou.a"),
        make_job("dx_doujyou.b", depends_on=["dx_doujyou.a"]),
        make_job("dx_doujyou.c", depends_on=["dx_doujyou.b"]),
    ]
    stages = build_plan(jobs)
    assert len(stages) == 3


def test_cycle_raises():
    jobs = [
        make_job("dx_doujyou.a", depends_on=["dx_doujyou.b"]),
        make_job("dx_doujyou.b", depends_on=["dx_doujyou.a"]),
    ]
    with pytest.raises(ValueError, match="Cyclic"):
        build_plan(jobs)


def test_target_job_upstream_closure():
    jobs = [
        make_job("dx_doujyou.a"),
        make_job("dx_doujyou.b", depends_on=["dx_doujyou.a"]),
        make_job("dx_doujyou.c", depends_on=["dx_doujyou.b"]),
        make_job("dx_doujyou.d"),  # unrelated
    ]
    stages = build_plan(jobs, target_job_ids=["dx_doujyou.c"])
    all_ids = {j.job_id for stage in stages for j in stage}
    assert "dx_doujyou.d" not in all_ids
    assert "dx_doujyou.a" in all_ids
    assert "dx_doujyou.c" in all_ids


def test_empty_jobs_returns_empty():
    assert build_plan([]) == []


def test_diamond_dependency():
    # a -> b, a -> c, b -> d, c -> d
    jobs = [
        make_job("a"),
        make_job("b", depends_on=["a"]),
        make_job("c", depends_on=["a"]),
        make_job("d", depends_on=["b", "c"]),
    ]
    stages = build_plan(jobs)
    # Stage 1: [a], Stage 2: [b, c], Stage 3: [d]
    assert len(stages) == 3
    stage_ids = [[j.job_id for j in s] for s in stages]
    assert stage_ids[0] == ["a"]
    assert sorted(stage_ids[1]) == ["b", "c"]
    assert stage_ids[2] == ["d"]


def test_undefined_dependency_raises():
    jobs = [
        make_job("a", depends_on=["nonexistent"]),
    ]
    with pytest.raises(ValueError):
        build_plan(jobs)


def test_multiple_targets_closure():
    jobs = [
        make_job("a"),
        make_job("b", depends_on=["a"]),
        make_job("c"),
        make_job("d", depends_on=["c"]),
        make_job("e"),  # unrelated
    ]
    stages = build_plan(jobs, target_job_ids=["b", "d"])
    all_ids = {j.job_id for stage in stages for j in stage}
    assert "e" not in all_ids
    assert all_ids == {"a", "b", "c", "d"}

"""Tests for write_failure_log in reporting.py."""
from spark_job_runner.models import ErrorCategory, JobResult, JobStatus, RetryAttempt
from spark_job_runner.reporting import write_failure_log


def _failed_result(job_id="dx_doujyou.vbi000001", with_retries=False):
    ra = []
    if with_retries:
        ra = [
            RetryAttempt(1, "SPARK_TRANSIENT", "SPARK_TRANSIENT: conn reset", True, 30),
            RetryAttempt(2, "SPARK_EXECUTION", "SPARK_EXECUTION: table not found", False, 0),
        ]
    return JobResult(
        job_id=job_id,
        status=JobStatus.FAILED,
        error_category=ErrorCategory.SPARK_EXECUTION,
        sanitized_error="SPARK_EXECUTION: AnalysisException: table not found",
        retry_attempts=ra,
    )


def test_creates_log_file(tmp_path):
    result = _failed_result()
    write_failure_log(result, "run-test-001", str(tmp_path))
    files = list(tmp_path.iterdir())
    assert len(files) == 1
    assert files[0].name.startswith("failures-")


def test_log_contains_job_id_and_run_id(tmp_path):
    result = _failed_result()
    write_failure_log(result, "run-test-001", str(tmp_path))
    content = list(tmp_path.iterdir())[0].read_text()
    assert "dx_doujyou.vbi000001" in content
    assert "run-test-001" in content


def test_log_contains_retry_history(tmp_path):
    result = _failed_result(with_retries=True)
    write_failure_log(result, "run-test-002", str(tmp_path))
    content = list(tmp_path.iterdir())[0].read_text()
    assert "RETRIED(waited=30s)" in content
    assert "GAVE_UP" in content
    assert "attempt=1" in content
    assert "attempt=2" in content


def test_no_log_for_success(tmp_path):
    result = JobResult(job_id="dx_doujyou.vbi000001", status=JobStatus.SUCCESS)
    write_failure_log(result, "run-test-003", str(tmp_path))
    assert list(tmp_path.iterdir()) == []


def test_appends_multiple_failures(tmp_path):
    r1 = _failed_result("dx_doujyou.job_a")
    r2 = _failed_result("dx_doujyou.job_b")
    write_failure_log(r1, "run-001", str(tmp_path))
    write_failure_log(r2, "run-001", str(tmp_path))
    files = list(tmp_path.iterdir())
    assert len(files) == 1
    content = files[0].read_text()
    assert "job_a" in content
    assert "job_b" in content

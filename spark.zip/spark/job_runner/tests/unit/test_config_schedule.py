"""Tests for schedule block and retry_default parsing in config.py."""
import pytest
from spark_job_runner.config import load_config
from spark_job_runner.models import ScheduleSpec


def _write_yaml(tmp_path, jobs_extra="", runtime_extra=""):
    content = f"""version: 1
environment:
  environment_id: test
  mode: development
  allowed_ddl_root: /tmp
  allowed_sql_root: /tmp
  production_write_allowed: false
runtime:
  parallelism: 1
  {runtime_extra}
jobs:
  dx_doujyou.vbi000001:
    sql_file: sql/vbi000001.sql
    ddl_file: ddl/vbi000001.sql
    output_tables: [gold.vbi000001]
    {jobs_extra}
"""
    p = tmp_path / "jobs.yaml"
    p.write_text(content)
    return str(p)


def test_schedule_parsed(tmp_path):
    path = _write_yaml(tmp_path, jobs_extra="""schedule:
      cron: "0 3 * * *"
      include_upstream: true
      enabled: true""")
    _, jobs = load_config(path)
    assert jobs[0].schedule == ScheduleSpec(cron="0 3 * * *", include_upstream=True, enabled=True)


def test_no_schedule_is_none(tmp_path):
    path = _write_yaml(tmp_path)
    _, jobs = load_config(path)
    assert jobs[0].schedule is None


def test_schedule_unknown_key_rejected(tmp_path):
    path = _write_yaml(tmp_path, jobs_extra="""schedule:
      cron: "0 3 * * *"
      include_upstream: true
      enabled: true
      extra_key: bad""")
    with pytest.raises(ValueError, match="Unknown key"):
        load_config(path)


def test_schedule_missing_required_key(tmp_path):
    path = _write_yaml(tmp_path, jobs_extra="""schedule:
      cron: "0 3 * * *"
      include_upstream: true""")
    with pytest.raises(ValueError, match="missing required field"):
        load_config(path)


def test_retry_default_parsed(tmp_path):
    path = _write_yaml(tmp_path, runtime_extra="""retry_default:
    max_attempts: 3
    backoff_seconds: [30, 60, 120]
    retryable_categories: [SPARK_TRANSIENT, SPARK_EXECUTION]""")
    raw, _ = load_config(path)
    rd = raw["runtime"]["retry_default"]
    assert rd["max_attempts"] == 3
    assert rd["backoff_seconds"] == [30, 60, 120]


def test_retry_default_unknown_key_rejected(tmp_path):
    path = _write_yaml(tmp_path, runtime_extra="""retry_default:
    max_attempts: 3
    bad_key: x""")
    with pytest.raises(ValueError, match="Unknown key"):
        load_config(path)

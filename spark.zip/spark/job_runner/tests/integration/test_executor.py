"""
Integration tests for executor.py.

These tests mock SparkRuntime to avoid requiring a real Spark cluster.
They verify state transitions, skip logic, and error propagation.
"""

from __future__ import annotations

import pytest
from unittest.mock import MagicMock, patch

from spark_job_runner.executor import JobRunner
from spark_job_runner.models import JobSpec, JobStatus, RetrySpec, RollbackSpec, MetadataExpectation
from spark_job_runner.spark_runtime import SparkRuntime


def make_job(job_id: str, depends_on=None, sql_content="INSERT OVERWRITE gold.t SELECT 1",
             ddl_content="CREATE TABLE IF NOT EXISTS gold.t (id INT)") -> JobSpec:
    return JobSpec(
        job_id=job_id,
        sql_file=f"{job_id}.sql",
        ddl_file=f"{job_id}.ddl",
        output_tables=[f"gold.{job_id}"],
        depends_on=depends_on or [],
    )


def _make_runner(jobs, tmp_path, runtime, parallelism=1):
    # Write dummy SQL and DDL files
    for job in jobs:
        ddl_file = tmp_path / job.ddl_file
        ddl_file.parent.mkdir(parents=True, exist_ok=True)
        ddl_file.write_text(
            f"CREATE TABLE IF NOT EXISTS gold.{job.job_id} (id INT)", encoding="utf-8"
        )
        sql_file = tmp_path / job.sql_file
        sql_file.parent.mkdir(parents=True, exist_ok=True)
        sql_file.write_text(
            f"INSERT OVERWRITE gold.{job.job_id} SELECT 1", encoding="utf-8"
        )

    return JobRunner(
        config={},
        jobs=jobs,
        runtime=runtime,
        parallelism=parallelism,
        ddl_root=str(tmp_path),
        sql_root=str(tmp_path),
        run_id="test-run-001",
    )


def test_ddl_phase_success(tmp_path):
    """DDL phase succeeds for a single job."""
    runtime = MagicMock(spec=SparkRuntime)
    jobs = [make_job("job_a")]
    runner = _make_runner(jobs, tmp_path, runtime)

    results = runner.run_ddl_phase(jobs)

    assert "job_a" in results
    assert results["job_a"].ddl_status == JobStatus.SUCCESS


def test_ddl_phase_failure_stops_remaining(tmp_path):
    """When the first DDL fails, remaining DDLs are skipped."""
    runtime = MagicMock(spec=SparkRuntime)
    runtime.execute_sql.side_effect = Exception("DDL execution error")

    jobs = [make_job("job_a"), make_job("job_b")]
    runner = _make_runner(jobs, tmp_path, runtime)

    results = runner.run_ddl_phase(jobs)

    # First job failed
    failed_ids = [jid for jid, r in results.items() if r.ddl_status == JobStatus.FAILED]
    assert len(failed_ids) >= 1
    # At least one of the two jobs is failed
    all_statuses = {r.ddl_status for r in results.values()}
    assert JobStatus.FAILED in all_statuses


def test_sql_phase_success(tmp_path):
    """SQL phase succeeds for two independent jobs."""
    from spark_job_runner.planner import build_plan

    runtime = MagicMock(spec=SparkRuntime)
    jobs = [make_job("job_a"), make_job("job_b")]
    stages = build_plan(jobs)
    runner = _make_runner(jobs, tmp_path, runtime)

    results = runner.run_sql_phase(stages)

    assert results["job_a"].status == JobStatus.SUCCESS
    assert results["job_b"].status == JobStatus.SUCCESS


def test_sql_phase_skips_downstream_on_failure(tmp_path):
    """When job_a fails, job_b (which depends on job_a) is skipped."""
    from spark_job_runner.planner import build_plan

    fail_for = {"job_a"}

    def side_effect(sql, job_id):
        if job_id in fail_for:
            raise Exception("Intentional test failure")

    runtime = MagicMock(spec=SparkRuntime)
    runtime.execute_sql.side_effect = side_effect

    jobs = [
        make_job("job_a"),
        make_job("job_b", depends_on=["job_a"]),
    ]
    stages = build_plan(jobs)
    runner = _make_runner(jobs, tmp_path, runtime)

    results = runner.run_sql_phase(stages)

    assert results["job_a"].status == JobStatus.FAILED
    assert results["job_b"].status == JobStatus.SKIPPED
    assert "job_a" in results["job_b"].blocked_by


def test_execute_job_sql_success(tmp_path):
    """execute_job_sql returns SUCCESS for a valid job."""
    runtime = MagicMock(spec=SparkRuntime)
    job = make_job("job_x")
    runner = _make_runner([job], tmp_path, runtime)

    result = runner.execute_job_sql(job)

    assert result.status == JobStatus.SUCCESS
    assert result.sql_status == JobStatus.SUCCESS
    assert result.elapsed_ms is not None


def test_execute_job_sql_failure(tmp_path):
    """execute_job_sql returns FAILED when Spark raises."""
    runtime = MagicMock(spec=SparkRuntime)
    runtime.execute_sql.side_effect = Exception("Spark error")

    job = make_job("job_y")
    runner = _make_runner([job], tmp_path, runtime)

    result = runner.execute_job_sql(job)

    assert result.status == JobStatus.FAILED
    assert result.sql_status == JobStatus.FAILED
    assert result.error_category is not None
    assert result.sanitized_error is not None
    # SQL text must not appear in sanitized_error
    assert "INSERT OVERWRITE" not in (result.sanitized_error or "")

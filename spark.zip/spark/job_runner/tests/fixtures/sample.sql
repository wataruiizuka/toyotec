-- Sample SQL fixture for testing
/* Multi-line
   block comment */
INSERT OVERWRITE gold.sample_table
SELECT
    id,
    name,
    current_timestamp() AS created_at
FROM source.raw_table
WHERE dt = '2024-01-01'

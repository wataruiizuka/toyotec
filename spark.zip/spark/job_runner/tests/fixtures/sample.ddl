-- Sample DDL fixture for testing
CREATE TABLE IF NOT EXISTS gold.sample_table (
    id          BIGINT      COMMENT 'Primary key',
    name        STRING      COMMENT 'Name field',
    created_at  TIMESTAMP   COMMENT 'Record creation timestamp'
)
USING DELTA
COMMENT 'Sample table for testing spark_job_runner'

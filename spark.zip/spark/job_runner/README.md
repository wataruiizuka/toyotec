# spark-job-runner

DDL/SQL DAG対応のSparkジョブランナー。`spark/legacy/` の並行導入版。

## ディレクトリ構成

```
job_runner/
├── config/
│   └── jobs.yaml          # 115ジョブの設定（依存関係・DDL/SQLパス）
├── src/spark_job_runner/
│   ├── cli.py             # CLIエントリポイント
│   ├── config.py          # 厳密YAMLローダー
│   ├── models.py          # データモデル（JobSpec, JobResult, RunResult等）
│   ├── validator.py       # 静的検証
│   ├── planner.py         # DAGプランナー（トポロジカルソート）
│   ├── sql_parser.py      # SQL文分割
│   ├── spark_runtime.py   # SparkSession管理
│   ├── executor.py        # DDL/SQL実行エンジン
│   └── reporting.py       # JSON実行レポート出力
└── tests/
    └── unit/              # 単体テスト31件
```

## 実行モード

| コマンド | DDL | SQL | 用途 |
|---|:---:|:---:|---|
| `validate` | - | - | 静的整合確認のみ |
| `plan` | - | - | 実行計画の表示 |
| `deploy-ddl` | ✓ | - | 空テーブル作成（初回・リリース時） |
| `run-sql` | - | ✓ | 定期バッチ実行 |
| `full-run` | ✓ | ✓ | DDL+SQL一括実行 |

## 使い方

```bash
# PYTHONPATH設定
export PYTHONPATH=src

# 全ジョブのプラン確認
python3 -m spark_job_runner plan --config config/jobs.yaml

# 特定テーブルとその上流だけを実行（テーブル単位の個別実行）
python3 -m spark_job_runner plan --config config/jobs.yaml --job dx_doujyou.vbi022004

# 空テーブルを作成（DDLフェーズ）
python3 -m spark_job_runner deploy-ddl --config config/jobs.yaml

# 特定テーブルのみDDL実行
python3 -m spark_job_runner deploy-ddl --config config/jobs.yaml --job dx_doujyou.vbi022004

# SQLバッチ実行（全ジョブ）
python3 -m spark_job_runner run-sql --config config/jobs.yaml

# 特定テーブルのみSQLバッチ実行
python3 -m spark_job_runner run-sql --config config/jobs.yaml --job dx_doujyou.vbi022004

# 静的検証
python3 -m spark_job_runner validate --config config/jobs.yaml
```

## 並列実行

`config/jobs.yaml` の `runtime.parallelism` で同一ステージ内の並列数を制御します。
- デフォルト: `1`（設計書の初期承認値）
- 最大: `32`
- 同一ステージ内のジョブは `ThreadPoolExecutor` で並列実行

## テーブル単位の定期実行

`--job` オプションで特定テーブルと上流依存のみを実行できます。

```bash
# cron設定例（毎日3時にvbi022004を実行）
0 3 * * * cd /path/to/spark && PYTHONPATH=job_runner/src python3 -m spark_job_runner run-sql \
  --config job_runner/config/jobs.yaml \
  --job dx_doujyou.vbi022004

# 複数テーブルを指定
python3 -m spark_job_runner run-sql --config config/jobs.yaml \
  --job dx_doujyou.vbi000001 \
  --job dx_doujyou.vbi000002
```

## 実行ステージ（115ジョブ・4ステージ）

| ステージ | ジョブ数 | 内容 |
|:---:|:---:|---|
| 1 | 64 | 依存なし（独立ジョブ） |
| 2 | 41 | Stage 1の出力に依存 |
| 3 | 8 | Stage 2の出力に依存 |
| 4 | 2 | Stage 3の出力に依存（vbi022004等） |

## 終了コード

| Code | 意味 |
|:---:|---|
| 0 | 全ジョブ成功 |
| 2 | 設定エラー / 対象ジョブ0件 |
| 3 | 1件以上FAILED |
| 4 | 1件以上SKIPPED |
| 5 | Run cancelled |
| 130 | SIGINT受信 |

## テスト実行

```bash
cd job_runner
python3 -m pytest tests/unit/ -v
```

## レガシーとの関係

`spark/legacy/` は変更せず並行稼働します。
問題発生時は旧コマンドへ切り替えてください。

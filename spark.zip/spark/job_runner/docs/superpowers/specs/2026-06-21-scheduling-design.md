# Scheduling, Retry & Failure Log — Design Spec

**Date:** 2026-06-21  
**Status:** Approved

---

## 1. Overview

Adds three capabilities to `spark-job-runner`:

1. **Per-table cron scheduling** — each job in `jobs.yaml` can declare a `schedule` block; `generate-crontab` command emits ready-to-install crontab entries.
2. **Retry with reason logging** — failed jobs whose error category is `SPARK_TRANSIENT` or `SPARK_EXECUTION` are retried up to 3 times (30 s → 60 s → 120 s backoff). Every attempt records _why_ it retried.
3. **Daily failure log** — all FAILED job results are appended to `failures-YYYY-MM-DD.log` with full retry history.

---

## 2. jobs.yaml Schema Changes

### 2.1 `runtime` block additions

```yaml
runtime:
  # existing keys unchanged ...
  retry_default:
    max_attempts: 3
    backoff_seconds: [30, 60, 120]
    retryable_categories: [SPARK_TRANSIENT, SPARK_EXECUTION]
  failure_log_dir: /var/log/spark-job-runner/failures
```

- `retry_default` is optional; if absent the existing per-job `retry` defaults apply.
- `failure_log_dir` is optional; if absent, failure logging is skipped.

### 2.2 Per-job `schedule` block

```yaml
jobs:
  dx_doujyou.vbi022004:
    # existing keys unchanged ...
    schedule:
      cron: "0 3 * * *"
      include_upstream: true
      enabled: true
```

- `schedule` is optional; jobs without it are excluded from crontab generation.
- All three sub-keys are required when `schedule` is present.

---

## 3. New Models

### `ScheduleSpec`

```python
@dataclass
class ScheduleSpec:
    cron: str
    include_upstream: bool
    enabled: bool
```

Added as optional field on `JobSpec`: `schedule: Optional[ScheduleSpec] = None`

### `RetryAttempt`

```python
@dataclass
class RetryAttempt:
    attempt: int
    error_category: str
    sanitized_error: str
    retried: bool
    waited_seconds: int
```

`JobResult.retry_attempts: List[RetryAttempt]` — ordered list of all attempts.

---

## 4. Retry Logic (`executor.py`)

`execute_job_sql` wraps execution in a retry loop:

- Categories `SPARK_TRANSIENT` and `SPARK_EXECUTION` are retryable.
- 3 max attempts, backoff 30 s → 60 s → 120 s.
- Per-job `retry` spec overrides `runtime.retry_default`.
- Each attempt logs: `[job_id] Attempt N failed (CATEGORY). Retrying in Xs.` or `Not retrying.`
- `RetryAttempt` records are accumulated in `JobResult.retry_attempts`.

---

## 5. Failure Log (`reporting.py`)

`write_failure_log(job_result, failure_log_dir, timezone)` appends to `failures-YYYY-MM-DD.log`.

Entry format:
```
2026-06-21T03:00:12+09:00  run_id=run-...  job_id=dx_doujyou.vbi022004
  status=FAILED  error_category=SPARK_EXECUTION
  error=SPARK_EXECUTION: AnalysisException: ...
  retries:
    attempt=1  category=SPARK_TRANSIENT  error=...  action=RETRIED(waited=30s)
    attempt=2  category=SPARK_EXECUTION  error=...  action=GAVE_UP
```

- Append mode, UTF-8, blank line between entries.
- SQL text is never written.

---

## 6. `generate-crontab` Command

New module `scheduler.py`:

```bash
python3 -m spark_job_runner generate-crontab \
    --config config/jobs.yaml \
    --base-dir /opt/blue_crystal/spark \
    --log-dir /var/log/spark-job-runner/cron \
    [--output crontab.txt]
```

Generated crontab line per job with `schedule.enabled=true`:
```
# dx_doujyou.vbi022004  include_upstream=true
0 3 * * * cd /opt/blue_crystal/spark && PYTHONPATH=job_runner/src python3 -m spark_job_runner run-sql --config job_runner/config/jobs.yaml --job dx_doujyou.vbi022004 >> /var/log/spark-job-runner/cron/vbi022004.log 2>&1
```

- `include_upstream=true` → `--job <job_id>` (includes upstream via existing planner closure).
- `include_upstream=false` → `--job <job_id> --no-upstream` (new planner flag for single-job execution without closure).

---

## 7. Files Changed

| File | Action |
|---|---|
| `src/spark_job_runner/models.py` | Add `ScheduleSpec`, `RetryAttempt`; update `JobSpec`, `JobResult` |
| `src/spark_job_runner/config.py` | Add schedule parsing, `retry_default`, `failure_log_dir` |
| `src/spark_job_runner/executor.py` | Add retry loop in `execute_job_sql` |
| `src/spark_job_runner/reporting.py` | Add `write_failure_log` |
| `src/spark_job_runner/scheduler.py` | New — crontab generation |
| `src/spark_job_runner/cli.py` | Add `generate-crontab`; call `write_failure_log` after SQL runs |
| `src/spark_job_runner/planner.py` | Add `--no-upstream` support (`build_plan` with `include_upstream=False`) |
| `config/jobs.yaml` | Add `runtime.retry_default`, `failure_log_dir`; add `schedule` to sample jobs |
| `tests/unit/test_retry.py` | New |
| `tests/unit/test_failure_log.py` | New |
| `tests/unit/test_scheduler.py` | New |
| `tests/unit/test_config_schedule.py` | New |

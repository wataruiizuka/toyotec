# Scheduling, Retry & Failure Log Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Add per-table cron scheduling, retry-with-reason-logging, and daily failure log to spark-job-runner.

**Architecture:** Extend `models.py` with `ScheduleSpec`/`RetryAttempt`, update `config.py` to parse new YAML keys, wrap `executor.py:execute_job_sql` in a retry loop, add `write_failure_log` to `reporting.py`, create `scheduler.py` + `generate-crontab` CLI command, and add `--no-upstream` planner flag.

**Tech Stack:** Python 3.9+, PyYAML, dataclasses, standard library only (no new deps).

---

## File Map

| File | Change |
|---|---|
| `src/spark_job_runner/models.py` | Add `ScheduleSpec`, `RetryAttempt`; update `JobSpec.schedule`, `JobResult.retry_attempts` |
| `src/spark_job_runner/config.py` | Parse `schedule`, `runtime.retry_default`, `runtime.failure_log_dir` |
| `src/spark_job_runner/executor.py` | Retry loop in `execute_job_sql`; accept `retry_default` |
| `src/spark_job_runner/reporting.py` | Add `write_failure_log` |
| `src/spark_job_runner/scheduler.py` | New — `generate_crontab` |
| `src/spark_job_runner/planner.py` | Add `include_upstream` param to `build_plan` |
| `src/spark_job_runner/cli.py` | Add `generate-crontab`; `--no-upstream`; pass `retry_default`; call `write_failure_log` |
| `config/jobs.yaml` | Add `runtime.retry_default`, `failure_log_dir`; add `schedule` to 3 sample jobs |
| `tests/unit/test_retry.py` | New |
| `tests/unit/test_failure_log.py` | New |
| `tests/unit/test_scheduler.py` | New |
| `tests/unit/test_config_schedule.py` | New |

---

### Task 1: Add `ScheduleSpec` and `RetryAttempt` to `models.py`

**Files:**
- Modify: `src/spark_job_runner/models.py`

- [ ] **Step 1: Add new dataclasses**

  In `models.py`, after the `RetrySpec` dataclass and before `PostCheck`, insert:

  ```python
  @dataclass
  class ScheduleSpec:
      cron: str
      include_upstream: bool
      enabled: bool


  @dataclass
  class RetryAttempt:
      attempt: int
      error_category: str
      sanitized_error: str
      retried: bool
      waited_seconds: int
  ```

- [ ] **Step 2: Add `schedule` field to `JobSpec`**

  In `JobSpec`, add after the `rollback` field:
  ```python
  schedule: Optional[ScheduleSpec] = None
  ```

- [ ] **Step 3: Add `retry_attempts` field to `JobResult`**

  In `JobResult`, add after the `spark_job_group` field:
  ```python
  retry_attempts: List[RetryAttempt] = field(default_factory=list)
  ```

- [ ] **Step 4: Verify no test breakage**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 31 tests pass.

---

### Task 2: Update `config.py` to parse `schedule`, `retry_default`, `failure_log_dir`

**Files:**
- Modify: `src/spark_job_runner/config.py`

- [ ] **Step 1: Add allowed key sets**

  After `_ALLOWED_POST_CHECK_KEYS`, add:
  ```python
  _ALLOWED_SCHEDULE_KEYS = {"cron", "include_upstream", "enabled"}
  _ALLOWED_RETRY_DEFAULT_KEYS = {"max_attempts", "backoff_seconds", "retryable_categories"}
  ```

- [ ] **Step 2: Add `schedule` to `_ALLOWED_JOB_KEYS`**

  ```python
  _ALLOWED_JOB_KEYS = {
      "sql_file", "ddl_file", "enabled", "depends_on", "output_tables",
      "schema_fingerprint", "idempotency", "retry", "timeout_seconds",
      "post_checks", "metadata_expectation", "rollback",
      "schedule",
  }
  ```

- [ ] **Step 3: Add `retry_default` and `failure_log_dir` to `_ALLOWED_RUNTIME_KEYS`**

  ```python
  _ALLOWED_RUNTIME_KEYS = {
      "timezone", "parallelism", "allow_empty", "sql_parser",
      "statement_preview", "cancel_grace_seconds", "audit", "lock",
      "retry_default",
      "failure_log_dir",
  }
  ```

- [ ] **Step 4: Add `_parse_schedule` function and update import**

  Add `ScheduleSpec` to the import from `spark_job_runner.models`.

  After `_parse_post_checks`, add:
  ```python
  def _parse_schedule(raw: Any, job_id: str) -> "Optional[ScheduleSpec]":
      if raw is None:
          return None
      if not isinstance(raw, dict):
          raise ValueError(f"jobs.{job_id}.schedule must be a mapping")
      _check_unknown_keys(raw, _ALLOWED_SCHEDULE_KEYS, f"jobs.{job_id}.schedule")
      for req in ("cron", "include_upstream", "enabled"):
          if req not in raw:
              raise ValueError(f"jobs.{job_id}.schedule is missing required field: {req!r}")
      return ScheduleSpec(
          cron=raw["cron"],
          include_upstream=bool(raw["include_upstream"]),
          enabled=bool(raw["enabled"]),
      )
  ```

- [ ] **Step 5: Call `_parse_schedule` in `_parse_job_spec`**

  In the `JobSpec(...)` constructor call inside `_parse_job_spec`, add:
  ```python
  schedule=_parse_schedule(raw.get("schedule"), job_id),
  ```

- [ ] **Step 6: Validate `retry_default` in `load_config`**

  In `load_config`, after the `parallelism` check, add:
  ```python
  retry_default_raw = runtime.get("retry_default")
  if retry_default_raw is not None:
      if not isinstance(retry_default_raw, dict):
          raise ValueError("runtime.retry_default must be a mapping")
      _check_unknown_keys(retry_default_raw, _ALLOWED_RETRY_DEFAULT_KEYS, "runtime.retry_default")
  ```

- [ ] **Step 7: Run tests**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 31 pass.

---

### Task 3: Add config schedule tests

**Files:**
- Create: `tests/unit/test_config_schedule.py`

- [ ] **Step 1: Write tests**

  ```python
  """Tests for schedule block and retry_default parsing in config.py."""
  import pytest
  from spark_job_runner.config import load_config
  from spark_job_runner.models import ScheduleSpec


  def _write_yaml(tmp_path, jobs_extra="", runtime_extra=""):
      content = f"""version: 1
  environment:
    environment_id: test
    mode: development
    allowed_ddl_root: /tmp
    allowed_sql_root: /tmp
    production_write_allowed: false
  runtime:
    parallelism: 1
    {runtime_extra}
  jobs:
    dx_doujyou.vbi000001:
      sql_file: sql/vbi000001.sql
      ddl_file: ddl/vbi000001.sql
      output_tables: [gold.vbi000001]
      {jobs_extra}
  """
      p = tmp_path / "jobs.yaml"
      p.write_text(content)
      return str(p)


  def test_schedule_parsed(tmp_path):
      path = _write_yaml(tmp_path, jobs_extra="""schedule:
        cron: "0 3 * * *"
        include_upstream: true
        enabled: true""")
      _, jobs = load_config(path)
      assert jobs[0].schedule == ScheduleSpec(cron="0 3 * * *", include_upstream=True, enabled=True)


  def test_no_schedule_is_none(tmp_path):
      path = _write_yaml(tmp_path)
      _, jobs = load_config(path)
      assert jobs[0].schedule is None


  def test_schedule_unknown_key_rejected(tmp_path):
      path = _write_yaml(tmp_path, jobs_extra="""schedule:
        cron: "0 3 * * *"
        include_upstream: true
        enabled: true
        extra_key: bad""")
      with pytest.raises(ValueError, match="Unknown key"):
          load_config(path)


  def test_schedule_missing_required_key(tmp_path):
      path = _write_yaml(tmp_path, jobs_extra="""schedule:
        cron: "0 3 * * *"
        include_upstream: true""")
      with pytest.raises(ValueError, match="missing required field"):
          load_config(path)


  def test_retry_default_parsed(tmp_path):
      path = _write_yaml(tmp_path, runtime_extra="""retry_default:
        max_attempts: 3
        backoff_seconds: [30, 60, 120]
        retryable_categories: [SPARK_TRANSIENT, SPARK_EXECUTION]""")
      raw, _ = load_config(path)
      rd = raw["runtime"]["retry_default"]
      assert rd["max_attempts"] == 3
      assert rd["backoff_seconds"] == [30, 60, 120]


  def test_retry_default_unknown_key_rejected(tmp_path):
      path = _write_yaml(tmp_path, runtime_extra="""retry_default:
        max_attempts: 3
        bad_key: x""")
      with pytest.raises(ValueError, match="Unknown key"):
          load_config(path)
  ```

- [ ] **Step 2: Run new tests**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/test_config_schedule.py -v
  ```
  Expected: 6 tests pass.

- [ ] **Step 3: Run full suite**

  ```bash
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 37 pass.

---

### Task 4: Add retry loop to `executor.py`

**Files:**
- Modify: `src/spark_job_runner/executor.py`

- [ ] **Step 1: Add imports**

  Add `import time` after existing imports.
  Add `RetryAttempt` and `RetrySpec` to the import from `spark_job_runner.models`.

- [ ] **Step 2: Add `_resolve_retry_spec` helper**

  After `_categorize_exception`, add:
  ```python
  def _resolve_retry_spec(job: JobSpec, retry_default: Optional[dict]) -> RetrySpec:
      """Return effective RetrySpec: job-level overrides retry_default."""
      if job.retry.max_attempts > 1 or job.retry.retryable_categories:
          return job.retry
      if retry_default:
          return RetrySpec(
              max_attempts=retry_default.get("max_attempts", 3),
              backoff_seconds=retry_default.get("backoff_seconds", [30, 60, 120]),
              retryable_categories=retry_default.get(
                  "retryable_categories", ["SPARK_TRANSIENT", "SPARK_EXECUTION"]
              ),
          )
      return job.retry
  ```

- [ ] **Step 3: Add `retry_default` to `JobRunner.__init__`**

  ```python
  def __init__(
      self,
      config: dict,
      jobs: List[JobSpec],
      runtime: SparkRuntime,
      parallelism: int = 1,
      ddl_root: str = ".",
      sql_root: str = ".",
      run_id: str = "run-0",
      retry_default: Optional[dict] = None,
  ) -> None:
      ...
      self.retry_default = retry_default
  ```

- [ ] **Step 4: Replace `execute_job_sql` with retry-aware version**

  Replace the entire `execute_job_sql` method with:

  ```python
  def execute_job_sql(self, job: JobSpec) -> JobResult:
      """Execute a single job's SQL file with retry logic."""
      started_at = _now()
      sql_path = (self.sql_root / job.sql_file).resolve()
      group_id = f"{self.run_id}/{job.job_id}"

      retry_spec = _resolve_retry_spec(job, self.retry_default)
      max_attempts = max(1, retry_spec.max_attempts)
      retryable = set(retry_spec.retryable_categories)
      backoff = retry_spec.backoff_seconds

      result = JobResult(
          job_id=job.job_id,
          status=JobStatus.RUNNING,
          sql_status=JobStatus.RUNNING,
          started_at=started_at,
          spark_job_group=group_id,
          attempts=0,
      )

      try:
          sql_text = sql_path.read_text(encoding="utf-8")
          statements = split_sql_statements(sql_text)
          if not statements:
              raise ValueError(f"No executable SQL statements found in: {sql_path}")
      except Exception as exc:
          finished_at = _now()
          category = _categorize_exception(exc)
          result.sql_status = JobStatus.FAILED
          result.status = JobStatus.FAILED
          result.finished_at = finished_at
          result.elapsed_ms = _elapsed_ms(started_at, finished_at)
          result.error_category = category
          result.sanitized_error = _sanitize_error(exc, category)
          result.attempts = 1
          logger.error("[%s] SQL file read failed: %s", job.job_id, result.sanitized_error)
          return result

      for attempt in range(1, max_attempts + 1):
          result.attempts = attempt
          try:
              self.runtime.set_job_group(self.run_id, job.job_id, f"SQL: {job.job_id}")
              logger.info(
                  "[%s] Attempt %d/%d: executing %d SQL statement(s)",
                  job.job_id, attempt, max_attempts, len(statements),
              )
              for idx, stmt in enumerate(statements, start=1):
                  logger.debug(
                      "[%s] Statement %d/%d (content omitted)",
                      job.job_id, idx, len(statements),
                  )
                  self.runtime.execute_sql(stmt, job.job_id)

              finished_at = _now()
              result.sql_status = JobStatus.SUCCESS
              result.status = JobStatus.SUCCESS
              result.finished_at = finished_at
              result.elapsed_ms = _elapsed_ms(started_at, finished_at)
              logger.info(
                  "[%s] SQL phase succeeded on attempt %d (%.0f ms)",
                  job.job_id, attempt, result.elapsed_ms,
              )
              return result

          except Exception as exc:
              category = _categorize_exception(exc)
              sanitized = _sanitize_error(exc, category)
              will_retry = (attempt < max_attempts) and (category.value in retryable)
              wait = 0
              if will_retry:
                  wait = backoff[attempt - 1] if attempt - 1 < len(backoff) else (backoff[-1] if backoff else 0)

              result.retry_attempts.append(RetryAttempt(
                  attempt=attempt,
                  error_category=category.value,
                  sanitized_error=sanitized,
                  retried=will_retry,
                  waited_seconds=wait,
              ))

              if will_retry:
                  logger.warning(
                      "[%s] Attempt %d/%d failed (%s). Retrying in %ds. reason=%s",
                      job.job_id, attempt, max_attempts, category.value, wait, sanitized,
                  )
                  time.sleep(wait)
              else:
                  finished_at = _now()
                  result.sql_status = JobStatus.FAILED
                  result.status = JobStatus.FAILED
                  result.finished_at = finished_at
                  result.elapsed_ms = _elapsed_ms(started_at, finished_at)
                  result.error_category = category
                  result.sanitized_error = sanitized
                  logger.error(
                      "[%s] Attempt %d/%d failed (%s). Not retrying. reason=%s",
                      job.job_id, attempt, max_attempts, category.value, sanitized,
                  )
                  return result

      return result
  ```

- [ ] **Step 5: Run full suite**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 37 pass.

---

### Task 5: Add retry tests

**Files:**
- Create: `tests/unit/test_retry.py`

- [ ] **Step 1: Write tests**

  ```python
  """Tests for retry logic in executor.py."""
  from unittest.mock import MagicMock, patch
  import pytest
  from spark_job_runner.executor import JobRunner, _resolve_retry_spec
  from spark_job_runner.models import JobSpec, RetrySpec, JobStatus, ErrorCategory


  def _make_job(job_id="dx_doujyou.test", retry=None):
      return JobSpec(
          job_id=job_id,
          sql_file="test.sql",
          ddl_file="test_ddl.sql",
          output_tables=["gold.test"],
          retry=retry or RetrySpec(),
      )


  def _make_runner(tmp_path, retry_default=None):
      sql = tmp_path / "test.sql"
      sql.write_text("SELECT 1;")
      runtime = MagicMock()
      return JobRunner(
          config={},
          jobs=[],
          runtime=runtime,
          ddl_root=str(tmp_path),
          sql_root=str(tmp_path),
          run_id="run-test",
          retry_default=retry_default,
      ), runtime


  def test_success_on_first_attempt(tmp_path):
      runner, runtime = _make_runner(tmp_path)
      job = _make_job()
      result = runner.execute_job_sql(job)
      assert result.status == JobStatus.SUCCESS
      assert result.attempts == 1
      assert result.retry_attempts == []


  def test_retries_on_transient_error(tmp_path):
      runner, runtime = _make_runner(
          tmp_path,
          retry_default={
              "max_attempts": 3,
              "backoff_seconds": [0, 0, 0],
              "retryable_categories": ["SPARK_TRANSIENT", "SPARK_EXECUTION"],
          },
      )
      job = _make_job()
      call_count = 0

      def fake_execute(sql, job_id):
          nonlocal call_count
          call_count += 1
          if call_count < 3:
              raise RuntimeError("connection reset")

      runtime.execute_sql.side_effect = fake_execute

      with patch("spark_job_runner.executor._categorize_exception",
                 return_value=ErrorCategory.SPARK_TRANSIENT):
          with patch("spark_job_runner.executor.time.sleep"):
              result = runner.execute_job_sql(job)

      assert result.status == JobStatus.SUCCESS
      assert result.attempts == 3
      assert len(result.retry_attempts) == 2
      assert result.retry_attempts[0].retried is True
      assert result.retry_attempts[1].retried is True


  def test_gives_up_after_max_attempts(tmp_path):
      runner, runtime = _make_runner(
          tmp_path,
          retry_default={
              "max_attempts": 3,
              "backoff_seconds": [0, 0],
              "retryable_categories": ["SPARK_TRANSIENT"],
          },
      )
      job = _make_job()
      runtime.execute_sql.side_effect = RuntimeError("always fails")

      with patch("spark_job_runner.executor._categorize_exception",
                 return_value=ErrorCategory.SPARK_TRANSIENT):
          with patch("spark_job_runner.executor.time.sleep"):
              result = runner.execute_job_sql(job)

      assert result.status == JobStatus.FAILED
      assert result.attempts == 3
      assert len(result.retry_attempts) == 3
      assert result.retry_attempts[-1].retried is False


  def test_no_retry_for_non_retryable_category(tmp_path):
      runner, runtime = _make_runner(
          tmp_path,
          retry_default={
              "max_attempts": 3,
              "backoff_seconds": [0, 0],
              "retryable_categories": ["SPARK_TRANSIENT"],
          },
      )
      job = _make_job()
      runtime.execute_sql.side_effect = RuntimeError("analysis error")

      with patch("spark_job_runner.executor._categorize_exception",
                 return_value=ErrorCategory.SPARK_ANALYSIS):
          result = runner.execute_job_sql(job)

      assert result.status == JobStatus.FAILED
      assert result.attempts == 1
      assert len(result.retry_attempts) == 1
      assert result.retry_attempts[0].retried is False


  def test_resolve_retry_spec_uses_job_retry_when_configured():
      job = _make_job(retry=RetrySpec(
          max_attempts=5,
          backoff_seconds=[10],
          retryable_categories=["SPARK_TRANSIENT"],
      ))
      spec = _resolve_retry_spec(job, {"max_attempts": 3, "backoff_seconds": [30]})
      assert spec.max_attempts == 5


  def test_resolve_retry_spec_falls_back_to_default():
      job = _make_job()
      spec = _resolve_retry_spec(job, {
          "max_attempts": 3,
          "backoff_seconds": [30, 60, 120],
          "retryable_categories": ["SPARK_TRANSIENT"],
      })
      assert spec.max_attempts == 3
  ```

- [ ] **Step 2: Run retry tests**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/test_retry.py -v
  ```
  Expected: 6 tests pass.

- [ ] **Step 3: Run full suite**

  ```bash
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 43 pass.

---

### Task 6: Add `write_failure_log` to `reporting.py`

**Files:**
- Modify: `src/spark_job_runner/reporting.py`

- [ ] **Step 1: Add `zoneinfo` import and `RetryAttempt` import**

  At top of `reporting.py`, add:
  ```python
  import zoneinfo
  ```

  Add `RetryAttempt` to the import from `spark_job_runner.models`.

- [ ] **Step 2: Add `write_failure_log` function at end of file**

  ```python
  def write_failure_log(
      job_result: JobResult,
      run_id: str,
      failure_log_dir: str,
      timezone: str = "Asia/Tokyo",
  ) -> None:
      """
      Append a FAILED job result to failures-YYYY-MM-DD.log.

      SQL text is never written. Does nothing if status is not FAILED.
      """
      if job_result.status != JobStatus.FAILED:
          return

      try:
          tz = zoneinfo.ZoneInfo(timezone)
      except Exception:
          tz = datetime.timezone.utc

      now_local = datetime.datetime.now(tz=tz)
      date_str = now_local.strftime("%Y-%m-%d")
      ts_str = now_local.isoformat(timespec="seconds")

      log_dir = Path(failure_log_dir)
      log_dir.mkdir(parents=True, exist_ok=True)
      log_file = log_dir / f"failures-{date_str}.log"

      cat = job_result.error_category.value if job_result.error_category else "UNKNOWN"
      lines = [
          f"{ts_str}  run_id={run_id}  job_id={job_result.job_id}",
          f"  status=FAILED  error_category={cat}",
          f"  error={job_result.sanitized_error or '(none)'}",
      ]

      if job_result.retry_attempts:
          lines.append("  retries:")
          for ra in job_result.retry_attempts:
              action = f"RETRIED(waited={ra.waited_seconds}s)" if ra.retried else "GAVE_UP"
              lines.append(
                  f"    attempt={ra.attempt}  category={ra.error_category}"
                  f"  error={ra.sanitized_error}  action={action}"
              )

      with log_file.open("a", encoding="utf-8") as fh:
          fh.write("\n".join(lines) + "\n\n")
  ```

- [ ] **Step 3: Run tests**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 43 pass.

---

### Task 7: Add failure log tests

**Files:**
- Create: `tests/unit/test_failure_log.py`

- [ ] **Step 1: Write tests**

  ```python
  """Tests for write_failure_log in reporting.py."""
  from spark_job_runner.models import ErrorCategory, JobResult, JobStatus, RetryAttempt
  from spark_job_runner.reporting import write_failure_log


  def _failed_result(job_id="dx_doujyou.vbi000001", with_retries=False):
      ra = []
      if with_retries:
          ra = [
              RetryAttempt(1, "SPARK_TRANSIENT", "SPARK_TRANSIENT: conn reset", True, 30),
              RetryAttempt(2, "SPARK_EXECUTION", "SPARK_EXECUTION: table not found", False, 0),
          ]
      return JobResult(
          job_id=job_id,
          status=JobStatus.FAILED,
          error_category=ErrorCategory.SPARK_EXECUTION,
          sanitized_error="SPARK_EXECUTION: AnalysisException: table not found",
          retry_attempts=ra,
      )


  def test_creates_log_file(tmp_path):
      result = _failed_result()
      write_failure_log(result, "run-test-001", str(tmp_path))
      files = list(tmp_path.iterdir())
      assert len(files) == 1
      assert files[0].name.startswith("failures-")


  def test_log_contains_job_id_and_run_id(tmp_path):
      result = _failed_result()
      write_failure_log(result, "run-test-001", str(tmp_path))
      content = list(tmp_path.iterdir())[0].read_text()
      assert "dx_doujyou.vbi000001" in content
      assert "run-test-001" in content


  def test_log_contains_retry_history(tmp_path):
      result = _failed_result(with_retries=True)
      write_failure_log(result, "run-test-002", str(tmp_path))
      content = list(tmp_path.iterdir())[0].read_text()
      assert "RETRIED(waited=30s)" in content
      assert "GAVE_UP" in content
      assert "attempt=1" in content
      assert "attempt=2" in content


  def test_no_log_for_success(tmp_path):
      result = JobResult(job_id="dx_doujyou.vbi000001", status=JobStatus.SUCCESS)
      write_failure_log(result, "run-test-003", str(tmp_path))
      assert list(tmp_path.iterdir()) == []


  def test_appends_multiple_failures(tmp_path):
      r1 = _failed_result("dx_doujyou.job_a")
      r2 = _failed_result("dx_doujyou.job_b")
      write_failure_log(r1, "run-001", str(tmp_path))
      write_failure_log(r2, "run-001", str(tmp_path))
      files = list(tmp_path.iterdir())
      assert len(files) == 1
      content = files[0].read_text()
      assert "job_a" in content
      assert "job_b" in content
  ```

- [ ] **Step 2: Run failure log tests**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/test_failure_log.py -v
  ```
  Expected: 5 tests pass.

- [ ] **Step 3: Run full suite**

  ```bash
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 48 pass.

---

### Task 8: Create `scheduler.py`

**Files:**
- Create: `src/spark_job_runner/scheduler.py`

- [ ] **Step 1: Write `scheduler.py`**

  ```python
  """
  scheduler.py

  Generates crontab entries from jobs.yaml schedule blocks.
  """

  from __future__ import annotations

  from typing import List

  from spark_job_runner.models import JobSpec


  def generate_crontab(
      jobs: List[JobSpec],
      config_path: str,
      base_dir: str,
      log_dir: str,
  ) -> str:
      """
      Generate crontab lines for all jobs with schedule.enabled=True.

      Args:
          jobs: Enabled JobSpec objects to consider.
          config_path: Path passed to --config in generated cron commands.
          base_dir: Root directory for `cd` in cron entries.
          log_dir: Directory for per-job cron log files.

      Returns:
          String of crontab lines, one blank line between entries.
      """
      lines: List[str] = []

      for job in jobs:
          if job.schedule is None or not job.schedule.enabled:
              continue

          stem = job.job_id.split(".")[-1]
          job_log = f"{log_dir.rstrip('/')}/{stem}.log"

          cmd_parts = [
              f"cd {base_dir}",
              "&&",
              "PYTHONPATH=job_runner/src",
              "python3 -m spark_job_runner run-sql",
              f"--config {config_path}",
              f"--job {job.job_id}",
          ]
          if not job.schedule.include_upstream:
              cmd_parts.append("--no-upstream")

          cmd = " ".join(cmd_parts)
          lines.append(
              f"# {job.job_id}  include_upstream={str(job.schedule.include_upstream).lower()}"
          )
          lines.append(f"{job.schedule.cron} {cmd} >> {job_log} 2>&1")
          lines.append("")

      return "\n".join(lines)
  ```

- [ ] **Step 2: Run tests**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 48 pass.

---

### Task 9: Add scheduler tests

**Files:**
- Create: `tests/unit/test_scheduler.py`

- [ ] **Step 1: Write tests**

  ```python
  """Tests for generate_crontab in scheduler.py."""
  from spark_job_runner.models import JobSpec, ScheduleSpec
  from spark_job_runner.scheduler import generate_crontab


  def _make_job(job_id, cron="0 3 * * *", include_upstream=True, enabled=True):
      return JobSpec(
          job_id=job_id,
          sql_file="test.sql",
          ddl_file="test_ddl.sql",
          output_tables=["gold.test"],
          schedule=ScheduleSpec(cron=cron, include_upstream=include_upstream, enabled=enabled),
      )


  def test_single_job_generates_crontab():
      jobs = [_make_job("dx_doujyou.vbi000001")]
      output = generate_crontab(
          jobs,
          config_path="job_runner/config/jobs.yaml",
          base_dir="/opt/blue_crystal/spark",
          log_dir="/var/log/cron",
      )
      assert "0 3 * * *" in output
      assert "--job dx_doujyou.vbi000001" in output
      assert "vbi000001.log" in output
      assert "# dx_doujyou.vbi000001" in output


  def test_disabled_job_excluded():
      jobs = [_make_job("dx_doujyou.vbi000001", enabled=False)]
      output = generate_crontab(jobs, "cfg.yaml", "/base", "/logs")
      assert output.strip() == ""


  def test_no_schedule_excluded():
      job = JobSpec(
          job_id="dx_doujyou.vbi000002",
          sql_file="test.sql",
          ddl_file="test_ddl.sql",
          output_tables=["gold.test"],
      )
      output = generate_crontab([job], "cfg.yaml", "/base", "/logs")
      assert output.strip() == ""


  def test_no_upstream_flag_when_include_upstream_false():
      jobs = [_make_job("dx_doujyou.vbi000003", include_upstream=False)]
      output = generate_crontab(jobs, "cfg.yaml", "/base", "/logs")
      assert "--no-upstream" in output


  def test_include_upstream_true_no_no_upstream_flag():
      jobs = [_make_job("dx_doujyou.vbi000004", include_upstream=True)]
      output = generate_crontab(jobs, "cfg.yaml", "/base", "/logs")
      assert "--no-upstream" not in output


  def test_multiple_jobs():
      jobs = [
          _make_job("dx_doujyou.vbi000001", cron="0 3 * * *"),
          _make_job("dx_doujyou.vbi000002", cron="0 4 * * *"),
      ]
      output = generate_crontab(jobs, "cfg.yaml", "/base", "/logs")
      assert "0 3 * * *" in output
      assert "0 4 * * *" in output
      assert "vbi000001.log" in output
      assert "vbi000002.log" in output
  ```

- [ ] **Step 2: Run scheduler tests**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/test_scheduler.py -v
  ```
  Expected: 6 tests pass.

- [ ] **Step 3: Run full suite**

  ```bash
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 54 pass.

---

### Task 10: Update `planner.py` with `include_upstream` param

**Files:**
- Modify: `src/spark_job_runner/planner.py`

- [ ] **Step 1: Add `include_upstream` parameter to `build_plan`**

  Change the signature:
  ```python
  def build_plan(
      jobs: List[JobSpec],
      target_job_ids: Optional[List[str]] = None,
      include_upstream: bool = True,
  ) -> List[List[JobSpec]]:
  ```

  In the `if target_job_ids is not None:` block, replace:
  ```python
  selected_ids = _upstream_closure(target_job_ids, job_map)
  ```
  with:
  ```python
  if include_upstream:
      selected_ids = _upstream_closure(target_job_ids, job_map)
  else:
      unknown = [jid for jid in target_job_ids if jid not in job_map]
      if unknown:
          raise ValueError(f"Unknown job IDs: {unknown}")
      selected_ids = set(target_job_ids)
  ```

- [ ] **Step 2: Run tests (existing planner tests must still pass)**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 54 pass.

---

### Task 11: Update `cli.py` — `generate-crontab`, `--no-upstream`, `retry_default`, `write_failure_log`

**Files:**
- Modify: `src/spark_job_runner/cli.py`

- [ ] **Step 1: Add `--no-upstream` to `_add_common`**

  In `_add_common`, after the `--job` argument:
  ```python
  sub.add_argument(
      "--no-upstream",
      action="store_true",
      default=False,
      dest="no_upstream",
      help=(
          "When --job is used, run only the specified job(s) "
          "without pulling in upstream dependencies."
      ),
  )
  ```

- [ ] **Step 2: Pass `include_upstream` to `build_plan` in `_run_sql_dag` and `_run_full`**

  In both functions, change `build_plan(enabled_jobs, target_job_ids=target_ids)` to:
  ```python
  stages = build_plan(
      enabled_jobs,
      target_job_ids=target_ids,
      include_upstream=not args.no_upstream,
  )
  ```

- [ ] **Step 3: Add `retry_default` to `JobRunner` in `_run_sql_dag` and `_run_full`**

  In both functions, after `parallelism = runtime_cfg.get("parallelism", 1)`, add:
  ```python
  retry_default = runtime_cfg.get("retry_default")
  ```

  Pass `retry_default=retry_default` to each `JobRunner(...)` call.

- [ ] **Step 4: Add `write_failure_log` calls in `_run_sql_dag` and `_run_full`**

  In `_run_sql_dag`, after `print_summary(run_result)`:
  ```python
  failure_log_dir = runtime_cfg.get("failure_log_dir")
  if failure_log_dir:
      from spark_job_runner.reporting import write_failure_log
      timezone = runtime_cfg.get("timezone", "Asia/Tokyo")
      for jr in job_results:
          write_failure_log(jr, run_id, failure_log_dir, timezone)
  ```

  In `_run_full`, after `print_summary(run_result)` (the final one):
  ```python
  failure_log_dir = runtime_cfg.get("failure_log_dir")
  if failure_log_dir:
      from spark_job_runner.reporting import write_failure_log
      timezone = runtime_cfg.get("timezone", "Asia/Tokyo")
      for jr in all_results:
          write_failure_log(jr, run_id, failure_log_dir, timezone)
  ```

- [ ] **Step 5: Add `generate-crontab` subparser to `_build_parser`**

  After the `full-run` subparser block:
  ```python
  p_cron = subparsers.add_parser(
      "generate-crontab",
      help="Generate crontab entries for scheduled jobs.",
  )
  p_cron.add_argument("--config", required=True, metavar="PATH",
                      help="Path to jobs.yaml configuration file.")
  p_cron.add_argument("--base-dir", required=True, metavar="DIR",
                      help="Base directory for cd in cron entries.")
  p_cron.add_argument("--log-dir", required=True, metavar="DIR",
                      help="Directory for per-job cron log files.")
  p_cron.add_argument("--output", default=None, metavar="FILE",
                      help="Write crontab to file instead of stdout.")
  ```

- [ ] **Step 6: Add `_run_generate_crontab` function**

  After `_run_full`, add:
  ```python
  def _run_generate_crontab(args: argparse.Namespace) -> int:
      from spark_job_runner.config import load_config
      from spark_job_runner.scheduler import generate_crontab

      config_path = str(Path(args.config).resolve())
      try:
          _, jobs = load_config(config_path)
      except Exception as exc:
          print(f"[ERROR] Config load failed: {exc}", file=sys.stderr)
          return 2

      enabled_jobs = [j for j in jobs if j.enabled]
      crontab_text = generate_crontab(
          enabled_jobs,
          config_path=args.config,
          base_dir=args.base_dir,
          log_dir=args.log_dir,
      )

      if args.output:
          Path(args.output).write_text(crontab_text, encoding="utf-8")
          print(f"Crontab written to: {args.output}")
      else:
          print(crontab_text, end="")

      return 0
  ```

- [ ] **Step 7: Add dispatch in `main`**

  After `elif command == "full-run":`, add:
  ```python
  elif command == "generate-crontab":
      return _run_generate_crontab(args)
  ```

- [ ] **Step 8: Run full suite**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 54 pass.

---

### Task 12: Update `config/jobs.yaml`

**Files:**
- Modify: `config/jobs.yaml`

- [ ] **Step 1: Add `retry_default` and `failure_log_dir` to `runtime` block**

  Find the `runtime:` section and add inside it:
  ```yaml
  retry_default:
    max_attempts: 3
    backoff_seconds: [30, 60, 120]
    retryable_categories: [SPARK_TRANSIENT, SPARK_EXECUTION]
  failure_log_dir: /var/log/spark-job-runner/failures
  ```

- [ ] **Step 2: Add `schedule` to `dx_doujyou.vbi000001`**

  Under `dx_doujyou.vbi000001:` add:
  ```yaml
  schedule:
    cron: "0 3 * * *"
    include_upstream: false
    enabled: true
  ```

- [ ] **Step 3: Add `schedule` to `dx_doujyou.vbi011008`**

  Under `dx_doujyou.vbi011008:` add:
  ```yaml
  schedule:
    cron: "0 4 * * *"
    include_upstream: true
    enabled: true
  ```

- [ ] **Step 4: Add `schedule` to `dx_doujyou.vbi022004`**

  Under `dx_doujyou.vbi022004:` add:
  ```yaml
  schedule:
    cron: "30 3 * * *"
    include_upstream: true
    enabled: true
  ```

- [ ] **Step 5: Validate**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  PYTHONPATH=src python3 -m spark_job_runner validate --config config/jobs.yaml
  ```
  Expected: `Validation PASSED`

- [ ] **Step 6: Run full test suite**

  ```bash
  python3 -m pytest tests/unit/ -q
  ```
  Expected: 54 pass.

---

### Final: Smoke tests

- [ ] **Step 1: generate-crontab smoke test**

  ```bash
  cd /Users/celesiizuka/Documents/blue_crystal/spark/job_runner
  PYTHONPATH=src python3 -m spark_job_runner generate-crontab \
    --config config/jobs.yaml \
    --base-dir /opt/blue_crystal/spark \
    --log-dir /var/log/spark-job-runner/cron
  ```
  Expected: 3 crontab blocks (vbi000001, vbi011008, vbi022004).

- [ ] **Step 2: validate smoke test**

  ```bash
  PYTHONPATH=src python3 -m spark_job_runner validate --config config/jobs.yaml
  ```
  Expected: `Validation PASSED`

- [ ] **Step 3: Full test suite**

  ```bash
  python3 -m pytest tests/unit/ -v
  ```
  Expected: 54 tests pass, 0 failures.

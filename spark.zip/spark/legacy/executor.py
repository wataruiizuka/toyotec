#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
executor.py

1つの SQL ファイルを実行するためのモジュール。

仕様:
- main.py から execute_sql_file(job_name, sql_file_path) で呼ばれる
- 1ファイル内に複数SQL文が含まれていてもよい
- SQL文はファイル内の順番どおりに直列実行する
- SQLファイル単位で SUCCESS / FAILED を返す
- DB / スキーマ指定は SQL 内で完結させる
"""

from __future__ import annotations

import re
import threading
import time
import traceback
from pathlib import Path
from typing import List, Optional, Tuple, Dict, Any

from pyspark.sql import SparkSession


# ============================================================
# SparkSession 取得
# ============================================================

_thread_local = threading.local()
_spark_lock = threading.Lock()


def _build_default_spark_session() -> SparkSession:
    """
    utils.spark_session が未実装でも動くようにするための
    フォールバック用 SparkSession 生成処理。

    必要に応じて、あなたの環境に合わせて appName や conf を追加してください。
    """
    return (
        SparkSession.builder
        .appName("data-transformation")
        .enableHiveSupport()
        .getOrCreate()
    )


def get_spark_session() -> SparkSession:
    """
    スレッドごとに SparkSession を取得する。

    優先:
    1. utils.spark_session.get_spark_session()
    2. フォールバック実装

    補足:
    - SparkSession 自体は JVM 側では基本的に singleton 的に扱われる
    - ただし Python 側ではスレッド経由で呼ばれるため、
      スレッドローカルに保持して再利用する
    """
    if getattr(_thread_local, "spark", None) is not None:
        return _thread_local.spark

    with _spark_lock:
        if getattr(_thread_local, "spark", None) is None:
            try:
                from utils.spark_session import get_spark_session as external_get_spark_session
                spark = external_get_spark_session()
            except Exception:
                spark = _build_default_spark_session()

            _thread_local.spark = spark

    return _thread_local.spark


# ============================================================
# SQL ファイル読み込み
# ============================================================

def read_sql_file(sql_file_path: str) -> str:
    """
    SQLファイルを読み込んで文字列で返す。
    """
    path = Path(sql_file_path)

    if not path.exists():
        raise FileNotFoundError(f"SQL file does not exist: {sql_file_path}")

    if not path.is_file():
        raise FileNotFoundError(f"SQL path is not a file: {sql_file_path}")

    return path.read_text(encoding="utf-8")


# ============================================================
# SQL 分割
# ============================================================

def _remove_sql_comments(sql_text: str) -> str:
    """
    SQLコメントを除去する。

    対応:
    - -- 行コメント
    - /* ... */ ブロックコメント

    注意:
    - 文字列リテラル内コメント記号まで完全厳密には扱わない
    - Gold作成SQLの一般的なDDL/DML用途を想定した軽量実装
    """
    # ブロックコメント除去
    sql_text = re.sub(r"/\*.*?\*/", "", sql_text, flags=re.DOTALL)

    # 行コメント除去
    lines = []
    for line in sql_text.splitlines():
        stripped = re.sub(r"--.*$", "", line)
        lines.append(stripped)

    return "\n".join(lines)


def _split_sql_statements_fallback(sql_text: str) -> List[str]:
    """
    SQL文字列をセミコロン区切りで分割する軽量実装。

    対応:
    - シングルクォート文字列内の ; は無視
    - ダブルクォート文字列内の ; は無視

    非対応/制限:
    - 非常に複雑な方言SQL
    - $$...$$ のような特殊ブロック
    - 完全なSQLパーサほどの厳密性はない

    一般的な Spark SQL / Iceberg 用DDL,DMLなら実務上かなり使える。
    """
    statements: List[str] = []
    current: List[str] = []

    in_single_quote = False
    in_double_quote = False
    escape_next = False

    for ch in sql_text:
        if escape_next:
            current.append(ch)
            escape_next = False
            continue

        if ch == "\\":
            current.append(ch)
            escape_next = True
            continue

        if ch == "'" and not in_double_quote:
            in_single_quote = not in_single_quote
            current.append(ch)
            continue

        if ch == '"' and not in_single_quote:
            in_double_quote = not in_double_quote
            current.append(ch)
            continue

        if ch == ";" and not in_single_quote and not in_double_quote:
            statement = "".join(current).strip()
            if statement:
                statements.append(statement)
            current = []
            continue

        current.append(ch)

    tail = "".join(current).strip()
    if tail:
        statements.append(tail)

    return statements


def split_sql_statements(sql_text: str) -> List[str]:
    """
    SQL文字列を実行単位の文に分割する。

    優先:
    1. utils.sql_parser.split_sql_statements()
    2. executor.py 内のフォールバック実装
    """
    cleaned = _remove_sql_comments(sql_text)

    try:
        from utils.sql_parser import split_sql_statements as external_split_sql_statements
        statements = external_split_sql_statements(cleaned)
    except Exception:
        statements = _split_sql_statements_fallback(cleaned)

    normalized = [stmt.strip() for stmt in statements if stmt and stmt.strip()]
    return normalized


# ============================================================
# SQL 実行
# ============================================================

def execute_statement(
    spark: SparkSession,
    statement: str,
    statement_index: int,
    job_name: str,
) -> None:
    """
    単一SQL文を実行する。
    SELECT系でも spark.sql() を実行するだけでよい。

    補足:
    - CREATE TABLE AS SELECT
    - DROP TABLE
    - INSERT OVERWRITE
    - CREATE OR REPLACE VIEW
    などを想定
    """
    print(
        f"[INFO] [{job_name}] Execute statement {statement_index} started."
    )

    start = time.time()
    spark.sql(statement)
    elapsed = time.time() - start

    print(
        f"[INFO] [{job_name}] Execute statement {statement_index} succeeded "
        f"({elapsed:.2f} sec)"
    )


def _shorten_sql(statement: str, max_length: int = 300) -> str:
    """
    ログ出力用にSQL文字列を短くする。
    """
    one_line = " ".join(statement.split())
    if len(one_line) <= max_length:
        return one_line
    return one_line[:max_length] + " ..."


def execute_sql_file(job_name: str, sql_file_path: str) -> Dict[str, Any]:
    """
    1つのSQLファイルを読み込み、複数SQL文に分割して順番に実行する。

    Returns:
        {
            "job_name": str,
            "sql_file": str,
            "status": "SUCCESS" | "FAILED",
            "elapsed_seconds": float,
            "error": Optional[str],
        }
    """
    file_start = time.time()
    sql_file = str(Path(sql_file_path).resolve())

    print("=" * 100)
    print(f"[INFO] [{job_name}] SQL file execution started")
    print(f"[INFO] [{job_name}] sql_file={sql_file}")

    try:
        spark = get_spark_session()

        sql_text = read_sql_file(sql_file)
        statements = split_sql_statements(sql_text)

        if not statements:
            raise ValueError(f"No executable SQL statements found in file: {sql_file}")

        print(f"[INFO] [{job_name}] statement_count={len(statements)}")

        for idx, statement in enumerate(statements, start=1):
            preview = _shorten_sql(statement)
            print(f"[INFO] [{job_name}] statement_{idx}_preview={preview}")
            execute_statement(
                spark=spark,
                statement=statement,
                statement_index=idx,
                job_name=job_name,
            )

        elapsed = time.time() - file_start

        print(
            f"[INFO] [{job_name}] SQL file execution succeeded "
            f"({elapsed:.2f} sec)"
        )
        print("=" * 100)

        return {
            "job_name": job_name,
            "sql_file": sql_file,
            "status": "SUCCESS",
            "elapsed_seconds": elapsed,
            "error": None,
        }

    except Exception as exc:
        elapsed = time.time() - file_start
        error_message = f"{type(exc).__name__}: {exc}"

        print(f"[ERROR] [{job_name}] SQL file execution failed")
        print(f"[ERROR] [{job_name}] error={error_message}")
        print(f"[ERROR] [{job_name}] traceback=\n{traceback.format_exc()}")
        print("=" * 100)

        return {
            "job_name": job_name,
            "sql_file": sql_file,
            "status": "FAILED",
            "elapsed_seconds": elapsed,
            "error": error_message,
        }

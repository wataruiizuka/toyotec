#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
scheduler.py

jobs.yaml を読み込み、ジョブの有効/無効判定と depends_on を解決して
実行ステージを作るためのモジュール。

主な役割:
- jobs.yaml の読込
- default / jobs 設定の正規化
- enabled 判定
- depends_on 判定
- 実行対象ジョブの抽出
- depends_on に基づくステージ分割
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Set

import yaml


def load_job_config(config_path: str) -> Dict[str, Any]:
    """
    jobs.yaml を読み込んで dict を返す。

    ファイルが存在しない場合は、最小のデフォルト設定を返す。

    Returns:
        {
            "default": {
                "enabled": True,
                "parallelism": 4,
            },
            "jobs": {
                ...
            }
        }
    """
    path = Path(config_path)

    if not path.exists():
        return {
            "default": {
                "enabled": True,
                "parallelism": 4,
            },
            "jobs": {},
        }

    if not path.is_file():
        raise FileNotFoundError(f"Config path is not a file: {config_path}")

    with path.open("r", encoding="utf-8") as f:
        loaded = yaml.safe_load(f) or {}

    if not isinstance(loaded, dict):
        raise ValueError("jobs.yaml root must be a mapping (dictionary).")

    default_conf = loaded.get("default", {})
    jobs_conf = loaded.get("jobs", {})

    if default_conf is None:
        default_conf = {}
    if jobs_conf is None:
        jobs_conf = {}

    if not isinstance(default_conf, dict):
        raise ValueError("jobs.yaml 'default' must be a mapping (dictionary).")

    if not isinstance(jobs_conf, dict):
        raise ValueError("jobs.yaml 'jobs' must be a mapping (dictionary).")

    normalized_default = {
        "enabled": default_conf.get("enabled", True),
        "parallelism": default_conf.get("parallelism", 4),
    }

    return {
        "default": normalized_default,
        "jobs": jobs_conf,
    }


def _normalize_depends_on(depends_on: Any, job_name: str) -> List[str]:
    """
    depends_on を正規化して list[str] で返す。

    許可:
    - 未指定 / None -> []
    - list[str]

    不許可:
    - 文字列単体
    - 数値
    - list以外
    """
    if depends_on is None:
        return []

    if isinstance(depends_on, str):
        raise ValueError(
            f"jobs.{job_name}.depends_on must be a list, not a string. "
            f"Example: depends_on: ['job_a', 'job_b']"
        )

    if not isinstance(depends_on, list):
        raise ValueError(
            f"jobs.{job_name}.depends_on must be a list, but got {type(depends_on).__name__}"
        )

    normalized: List[str] = []
    for idx, item in enumerate(depends_on):
        if not isinstance(item, str):
            raise ValueError(
                f"jobs.{job_name}.depends_on[{idx}] must be a string, "
                f"but got {type(item).__name__}"
            )

        value = item.strip()
        if not value:
            raise ValueError(
                f"jobs.{job_name}.depends_on[{idx}] must not be empty"
            )

        normalized.append(value)

    # 重複除去しつつ順序維持
    deduped = list(dict.fromkeys(normalized))
    return deduped


def resolve_runnable_jobs(
    jobs: List[Dict[str, Any]],
    config: Dict[str, Any],
    include_disabled: bool = False,
) -> List[Dict[str, Any]]:
    """
    SQLファイル一覧と jobs.yaml を突き合わせて、
    実行対象ジョブに設定情報を付与して返す。

    Args:
        jobs:
            main.py 側で組み立てたジョブ定義一覧
            例:
            [
                {"job_name": "sales_summary", "sql_file": Path(...)},
                {"job_name": "customer_mart", "sql_file": Path(...)},
            ]

        config:
            load_job_config() の返り値

        include_disabled:
            True の場合、enabled: false のジョブも対象に含める

    Returns:
        [
            {
                "job_name": "sales_summary",
                "sql_file": Path(...),
                "enabled": True,
                "depends_on": [],
            },
            ...
        ]
    """
    if not isinstance(jobs, list):
        raise ValueError("jobs must be a list")

    default_conf = config.get("default", {})
    jobs_conf = config.get("jobs", {})

    if not isinstance(default_conf, dict):
        raise ValueError("config['default'] must be a dictionary")

    if not isinstance(jobs_conf, dict):
        raise ValueError("config['jobs'] must be a dictionary")

    default_enabled = default_conf.get("enabled", True)

    runnable_jobs: List[Dict[str, Any]] = []
    seen_job_names: Set[str] = set()

    for job in jobs:
        if not isinstance(job, dict):
            raise ValueError("Each job definition must be a dictionary")

        if "job_name" not in job:
            raise ValueError("Each job definition must contain 'job_name'")

        if "sql_file" not in job:
            raise ValueError("Each job definition must contain 'sql_file'")

        job_name = job["job_name"]
        sql_file = job["sql_file"]

        if not isinstance(job_name, str) or not job_name.strip():
            raise ValueError(f"Invalid job_name: {job_name}")

        if job_name in seen_job_names:
            raise ValueError(f"Duplicate job_name detected: {job_name}")
        seen_job_names.add(job_name)

        job_conf = jobs_conf.get(job_name, {})
        if job_conf is None:
            job_conf = {}

        if not isinstance(job_conf, dict):
            raise ValueError(
                f"jobs.{job_name} must be a mapping (dictionary), "
                f"but got {type(job_conf).__name__}"
            )

        enabled = job_conf.get("enabled", default_enabled)
        if not isinstance(enabled, bool):
            raise ValueError(
                f"jobs.{job_name}.enabled must be boolean, "
                f"but got {type(enabled).__name__}"
            )

        depends_on = _normalize_depends_on(job_conf.get("depends_on"), job_name)

        if not enabled and not include_disabled:
            continue

        runnable_jobs.append(
            {
                "job_name": job_name,
                "sql_file": sql_file,
                "enabled": enabled,
                "depends_on": depends_on,
            }
        )

    return runnable_jobs


def build_execution_stages(jobs: List[Dict[str, Any]]) -> List[List[Dict[str, Any]]]:
    """
    depends_on を解決して、実行ステージのリストを返す。

    ステージとは:
    - 同じステージ内のジョブは並列実行可能
    - 次ステージは前ステージ完了後に実行する

    Args:
        jobs:
            resolve_runnable_jobs() の結果

    Returns:
        例:
        [
            [job_a, job_b],   # Stage 1
            [job_c, job_d],   # Stage 2
        ]

    Raises:
        ValueError:
        - depends_on で未定義ジョブを参照している
        - 循環依存がある
    """
    if not jobs:
        return []

    job_map: Dict[str, Dict[str, Any]] = {}
    for job in jobs:
        job_name = job["job_name"]
        if job_name in job_map:
            raise ValueError(f"Duplicate job_name detected: {job_name}")
        job_map[job_name] = job

    all_job_names = set(job_map.keys())
    remaining_dependencies: Dict[str, Set[str]] = {}

    # 依存先の存在チェック
    for job in jobs:
        job_name = job["job_name"]
        depends_on = set(job.get("depends_on", []))

        missing = depends_on - all_job_names
        if missing:
            raise ValueError(
                f"Job '{job_name}' depends on undefined or non-runnable jobs: "
                f"{sorted(missing)}"
            )

        # 自分自身への依存も禁止
        if job_name in depends_on:
            raise ValueError(
                f"Job '{job_name}' cannot depend on itself."
            )

        remaining_dependencies[job_name] = depends_on

    stages: List[List[Dict[str, Any]]] = []
    resolved: Set[str] = set()

    while remaining_dependencies:
        current_stage_names = sorted(
            [
                job_name
                for job_name, deps in remaining_dependencies.items()
                if deps.issubset(resolved)
            ]
        )

        if not current_stage_names:
            unresolved_detail = {
                job_name: sorted(list(deps))
                for job_name, deps in remaining_dependencies.items()
            }
            raise ValueError(
                "Cyclic dependency detected or dependencies cannot be resolved: "
                f"{unresolved_detail}"
            )

        current_stage = [job_map[job_name] for job_name in current_stage_names]
        stages.append(current_stage)

        for job_name in current_stage_names:
            resolved.add(job_name)
            del remaining_dependencies[job_name]

    return stages

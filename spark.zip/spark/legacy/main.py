#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
main.py

Spark を使って sql/ 配下の .sql ファイルを実行するエントリポイント。

仕様:
- SQLファイル名 = ジョブ名
- SQLファイル単位でジョブ化する
- 1ファイル内の複数SQL文は executor.py 側で直列実行する
- ジョブ間の depends_on は scheduler.py 側で解決する
- depends_on のないジョブ同士は並列実行する
- 依存先が失敗したジョブは SKIPPED とする
- DB / スキーマ指定は設定ファイルに持たせず、SQL内で完結させる
"""

from __future__ import annotations

import argparse
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from executor import execute_sql_file
from scheduler import (
    build_execution_stages,
    load_job_config,
    resolve_runnable_jobs,
)


DEFAULT_BASE_DIR = Path(__file__).resolve().parent
DEFAULT_SQL_DIR = DEFAULT_BASE_DIR / "sql"
DEFAULT_CONFIG_PATH = DEFAULT_BASE_DIR / "config" / "jobs.yaml"


def parse_args() -> argparse.Namespace:
    """
    コマンドライン引数を解析する。
    """
    parser = argparse.ArgumentParser(
        description="Run SQL files under sql/ with dependency-aware parallel execution."
    )

    parser.add_argument(
        "--sql-dir",
        default=str(DEFAULT_SQL_DIR),
        help="SQLファイル格納ディレクトリ。デフォルト: ./sql",
    )
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG_PATH),
        help="ジョブ設定YAMLファイル。デフォルト: ./config/jobs.yaml",
    )
    parser.add_argument(
        "--parallelism",
        type=int,
        default=None,
        help="並列実行数。未指定時は jobs.yaml の default.parallelism を使用。",
    )
    parser.add_argument(
        "--job",
        action="append",
        default=[],
        help=(
            "実行対象ジョブ名を限定する。複数指定可。"
            "例: --job sales_summary --job customer_mart"
        ),
    )
    parser.add_argument(
        "--include-disabled",
        action="store_true",
        help="jobs.yaml で enabled: false のジョブも強制的に対象へ含める。",
    )

    return parser.parse_args()


def discover_sql_files(sql_dir: Path) -> List[Path]:
    """
    sql/ 配下の .sql ファイルを列挙する。
    ファイル名順にソートして返す。
    """
    if not sql_dir.exists():
        raise FileNotFoundError(f"SQL directory does not exist: {sql_dir}")

    if not sql_dir.is_dir():
        raise NotADirectoryError(f"SQL directory is not a directory: {sql_dir}")

    sql_files = sorted(sql_dir.glob("*.sql"))
    return [f for f in sql_files if f.is_file()]


def build_job_definitions(sql_files: List[Path]) -> List[Dict[str, Any]]:
    """
    SQLファイル一覧からジョブ定義を作成する。
    ジョブ名 = SQLファイル名（拡張子除く）
    """
    jobs: List[Dict[str, Any]] = []

    for sql_file in sql_files:
        jobs.append(
            {
                "job_name": sql_file.stem,
                "sql_file": sql_file,
            }
        )

    return jobs


def filter_jobs_by_name(
    jobs: List[Dict[str, Any]],
    selected_job_names: List[str],
) -> List[Dict[str, Any]]:
    """
    --job 指定がある場合、対象ジョブだけに絞る。
    """
    if not selected_job_names:
        return jobs

    selected_set = set(selected_job_names)
    filtered = [job for job in jobs if job["job_name"] in selected_set]

    missing = selected_set - {job["job_name"] for job in jobs}
    if missing:
        print(
            "[WARN] The following jobs were requested but no matching SQL files were found: "
            + ", ".join(sorted(missing)),
            file=sys.stderr,
        )

    return filtered


def resolve_parallelism(
    cli_parallelism: Optional[int],
    config: Dict[str, Any],
) -> int:
    """
    並列数を決定する。

    優先順位:
    1. CLI引数
    2. jobs.yaml の default.parallelism
    3. 4
    """
    if cli_parallelism is not None:
        if cli_parallelism < 1:
            raise ValueError("--parallelism must be >= 1")
        return cli_parallelism

    default_parallelism = 4
    if isinstance(config, dict):
        default_conf = config.get("default", {})
        if isinstance(default_conf, dict):
            value = default_conf.get("parallelism", 4)
            if isinstance(value, int) and value >= 1:
                default_parallelism = value

    return default_parallelism


def print_execution_plan(
    execution_stages: List[List[Dict[str, Any]]],
    parallelism: int,
    config_path: Path,
    sql_dir: Path,
) -> None:
    """
    実行計画を標準出力に表示する。
    """
    total_jobs = sum(len(stage) for stage in execution_stages)

    print("=" * 100)
    print("[INFO] Data Transformation Job Started")
    print(f"[INFO] Config file : {config_path}")
    print(f"[INFO] SQL dir      : {sql_dir}")
    print(f"[INFO] Parallelism  : {parallelism}")
    print(f"[INFO] Stage count  : {len(execution_stages)}")
    print(f"[INFO] Target jobs  : {total_jobs}")

    if not execution_stages:
        print("[INFO] No runnable jobs found.")
        print("=" * 100)
        return

    for stage_index, stage_jobs in enumerate(execution_stages, start=1):
        print(f"[INFO] Stage {stage_index}:")
        for job in stage_jobs:
            depends = job.get("depends_on", [])
            depends_str = ", ".join(depends) if depends else "-"
            print(
                f"  - {job['job_name']} "
                f"({job['sql_file']}) "
                f"depends_on=[{depends_str}]"
            )

    print("=" * 100)


def filter_stage_jobs_by_dependency_result(
    stage_jobs: List[Dict[str, Any]],
    failed_job_names: Set[str],
    skipped_job_names: Set[str],
) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
    """
    依存先に FAILED / SKIPPED があるジョブを SKIPPED として除外する。

    Returns:
        runnable_jobs: 実行可能なジョブ一覧
        skipped_results: スキップ結果一覧
    """
    blocked_job_names = failed_job_names | skipped_job_names

    runnable_jobs: List[Dict[str, Any]] = []
    skipped_results: List[Dict[str, Any]] = []

    for job in stage_jobs:
        depends_on = set(job.get("depends_on", []))
        blocked_by = sorted(depends_on & blocked_job_names)

        if blocked_by:
            skipped_results.append(
                {
                    "job_name": job["job_name"],
                    "sql_file": str(job["sql_file"]),
                    "status": "SKIPPED",
                    "elapsed_seconds": 0.0,
                    "error": f"blocked by upstream jobs: {blocked_by}",
                }
            )
        else:
            runnable_jobs.append(job)

    return runnable_jobs, skipped_results


def submit_jobs(
    runnable_jobs: List[Dict[str, Any]],
    parallelism: int,
) -> List[Dict[str, Any]]:
    """
    ジョブを並列実行し、結果一覧を返す。

    戻り値の各要素:
    {
        "job_name": str,
        "sql_file": str,
        "status": "SUCCESS" | "FAILED",
        "elapsed_seconds": float,
        "error": Optional[str],
    }
    """
    results: List[Dict[str, Any]] = []
    submitted_futures = {}

    if not runnable_jobs:
        return results

    max_workers = min(parallelism, len(runnable_jobs))

    with ThreadPoolExecutor(max_workers=max_workers) as executor_pool:
        for job in runnable_jobs:
            future = executor_pool.submit(
                execute_sql_file,
                job["job_name"],
                str(job["sql_file"]),
            )
            submitted_futures[future] = job

        for future in as_completed(submitted_futures):
            job = submitted_futures[future]
            job_name = job["job_name"]
            sql_file = str(job["sql_file"])

            try:
                result = future.result()

                if not isinstance(result, dict):
                    raise TypeError(
                        f"execute_sql_file() must return dict, but got {type(result).__name__}"
                    )

                normalized_result = {
                    "job_name": result.get("job_name", job_name),
                    "sql_file": result.get("sql_file", sql_file),
                    "status": result.get("status", "FAILED"),
                    "elapsed_seconds": float(result.get("elapsed_seconds", 0.0)),
                    "error": result.get("error"),
                }

                results.append(normalized_result)

                if normalized_result["status"] == "SUCCESS":
                    print(
                        f"[INFO] Job succeeded: {normalized_result['job_name']} "
                        f"({normalized_result['elapsed_seconds']:.2f} sec)"
                    )
                else:
                    print(
                        f"[ERROR] Job failed: {normalized_result['job_name']} "
                        f"(error={normalized_result['error']})"
                    )

            except Exception as exc:
                failed_result = {
                    "job_name": job_name,
                    "sql_file": sql_file,
                    "status": "FAILED",
                    "elapsed_seconds": 0.0,
                    "error": str(exc),
                }
                results.append(failed_result)
                print(f"[ERROR] Job raised exception: {job_name} (error={exc})")

    return sorted(results, key=lambda x: x["job_name"])


def print_summary(results: List[Dict[str, Any]], total_elapsed_seconds: float) -> None:
    """
    実行結果サマリを表示する。
    """
    success_count = sum(1 for r in results if r["status"] == "SUCCESS")
    failure_count = sum(1 for r in results if r["status"] == "FAILED")
    skipped_count = sum(1 for r in results if r["status"] == "SKIPPED")

    print("\n" + "=" * 100)
    print("[INFO] Execution Summary")
    print(f"[INFO] Total jobs      : {len(results)}")
    print(f"[INFO] Success count   : {success_count}")
    print(f"[INFO] Failure count   : {failure_count}")
    print(f"[INFO] Skipped count   : {skipped_count}")
    print(f"[INFO] Total elapsed   : {total_elapsed_seconds:.2f} sec")
    print("-" * 100)

    for result in sorted(results, key=lambda x: x["job_name"]):
        status = result["status"]
        job_name = result["job_name"]
        elapsed = result["elapsed_seconds"]
        error = result["error"]

        if status == "SUCCESS":
            print(f"[SUCCESS] {job_name:<35} {elapsed:>10.2f} sec")
        elif status == "SKIPPED":
            print(f"[SKIPPED] {job_name:<35} {elapsed:>10.2f} sec  reason={error}")
        else:
            print(f"[FAILED ] {job_name:<35} {elapsed:>10.2f} sec  error={error}")

    print("=" * 100)


def main() -> int:
    """
    メイン処理。
    """
    args = parse_args()

    sql_dir = Path(args.sql_dir).resolve()
    config_path = Path(args.config).resolve()

    start_time = time.time()

    try:
        config = load_job_config(str(config_path))

        sql_files = discover_sql_files(sql_dir)
        all_jobs = build_job_definitions(sql_files)
        all_jobs = filter_jobs_by_name(all_jobs, args.job)

        runnable_jobs = resolve_runnable_jobs(
            jobs=all_jobs,
            config=config,
            include_disabled=args.include_disabled,
        )

        parallelism = resolve_parallelism(args.parallelism, config)

        execution_stages = build_execution_stages(runnable_jobs)

        print_execution_plan(
            execution_stages=execution_stages,
            parallelism=parallelism,
            config_path=config_path,
            sql_dir=sql_dir,
        )

        if not execution_stages:
            print("[INFO] No jobs to run. Exit with code 0.")
            return 0

        all_results: List[Dict[str, Any]] = []
        failed_job_names: Set[str] = set()
        skipped_job_names: Set[str] = set()

        for stage_index, stage_jobs in enumerate(execution_stages, start=1):
            print("\n" + "-" * 100)
            print(f"[INFO] Start Stage {stage_index} ({len(stage_jobs)} jobs)")
            print("-" * 100)

            runnable_stage_jobs, skipped_results = filter_stage_jobs_by_dependency_result(
                stage_jobs=stage_jobs,
                failed_job_names=failed_job_names,
                skipped_job_names=skipped_job_names,
            )

            for skipped in skipped_results:
                print(
                    f"[WARN] Job skipped: {skipped['job_name']} "
                    f"(reason={skipped['error']})"
                )
                skipped_job_names.add(skipped["job_name"])

            all_results.extend(skipped_results)

            if not runnable_stage_jobs:
                print(f"[INFO] No runnable jobs in Stage {stage_index}.")
                continue

            stage_results = submit_jobs(
                runnable_jobs=runnable_stage_jobs,
                parallelism=parallelism,
            )
            all_results.extend(stage_results)

            for result in stage_results:
                if result["status"] == "FAILED":
                    failed_job_names.add(result["job_name"])

        total_elapsed_seconds = time.time() - start_time
        print_summary(all_results, total_elapsed_seconds)

        has_non_success = any(
            result["status"] in {"FAILED", "SKIPPED"}
            for result in all_results
        )
        return 1 if has_non_success else 0

    except Exception as exc:
        total_elapsed_seconds = time.time() - start_time
        print("[FATAL] Job execution aborted.", file=sys.stderr)
        print(f"[FATAL] error={exc}", file=sys.stderr)
        print(f"[FATAL] elapsed={total_elapsed_seconds:.2f} sec", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())

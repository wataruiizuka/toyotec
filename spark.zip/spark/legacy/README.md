# Spark SQL 軽量DAG実行基盤 仕様書

## 1. 概要

本READMEは、添付された以下3ファイルをベースに作成した処理仕様書です。

- `main.py`（アップロードファイル名: `main(1).py`）
- `executor.py`
- `scheduler.py`

このプログラム群は、`sql/` 配下に配置された `.sql` ファイルを **SQLファイル単位のジョブ** として扱い、`config/jobs.yaml` に定義された依存関係に従って実行するための、Spark SQL向けの軽量なELT/DAG実行基盤です。

大きな特徴は以下です。

- SQLファイル名をジョブ名として扱う
- 1つのSQLファイル内に複数SQL文を書ける
- SQLファイル内のSQL文は上から順番に直列実行する
- ジョブ間の依存関係は `jobs.yaml` の `depends_on` で管理する
- 依存関係のないジョブは同一ステージ内で並列実行する
- 依存元ジョブが失敗またはスキップされた場合、後続ジョブは `SKIPPED` になる
- 実際のSQL実行は Spark SQL によって行う
- DB名、スキーマ名、カタログ名などは設定ファイルではなくSQL内に明示する設計

---

## 2. 全体構成

### 2.1 想定ディレクトリ構成

```text
project_root/
├── main.py
├── executor.py
├── scheduler.py
├── config/
│   └── jobs.yaml
├── sql/
│   ├── raw_to_stg_customer.sql
│   ├── raw_to_stg_sales.sql
│   ├── stg_to_mart_customer.sql
│   └── stg_to_mart_sales.sql
└── utils/
    ├── spark_session.py      # 任意
    └── sql_parser.py         # 任意
```

### 2.2 各ファイルの役割

| ファイル | 役割 |
|---|---|
| `main.py` | エントリポイント。SQLファイル検出、設定読込、実行計画作成、ステージ単位の並列実行、結果集計を行う |
| `executor.py` | 1つのSQLファイルを読み込み、SQL文に分割し、Spark SQLで順番に実行する |
| `scheduler.py` | `jobs.yaml` を読み込み、ジョブの有効/無効、依存関係、実行ステージを解決する |
| `config/jobs.yaml` | ジョブ設定ファイル。並列数、enabled、depends_on を定義する |
| `sql/*.sql` | 実行対象のSQLファイル。ファイル名がジョブ名になる |
| `utils/spark_session.py` | 任意。SparkSession生成処理をプロジェクト固有に差し替えるための拡張ポイント |
| `utils/sql_parser.py` | 任意。SQL分割処理をプロジェクト固有に差し替えるための拡張ポイント |

---

## 3. 処理全体の流れ

```mermaid
flowchart TD
    A[main.py 起動] --> B[コマンドライン引数を解析]
    B --> C[jobs.yaml を読み込み]
    C --> D[sql/ 配下の .sql ファイルを検出]
    D --> E[SQLファイル名からジョブ定義を作成]
    E --> F[--job 指定があれば対象ジョブを絞り込み]
    F --> G[scheduler.py で実行対象ジョブを解決]
    G --> H[depends_on をもとに実行ステージを作成]
    H --> I[実行計画を表示]
    I --> J{ステージが存在するか}
    J -- No --> K[終了コード0で終了]
    J -- Yes --> L[ステージ単位で処理]
    L --> M[依存元の失敗/スキップを確認]
    M --> N[実行可能ジョブを並列実行]
    N --> O[executor.py がSQLファイルを実行]
    O --> P[結果を SUCCESS / FAILED / SKIPPED として集計]
    P --> Q{全ステージ完了?}
    Q -- No --> L
    Q -- Yes --> R[実行結果サマリを表示]
    R --> S{失敗またはスキップあり?}
    S -- Yes --> T[終了コード1]
    S -- No --> U[終了コード0]
```

---

## 4. 実行単位の考え方

### 4.1 SQLファイル = ジョブ

本プログラムでは、1つの `.sql` ファイルを1つのジョブとして扱います。

例:

```text
sql/raw_to_stg_customer.sql
```

この場合、ジョブ名は以下になります。

```text
raw_to_stg_customer
```

拡張子 `.sql` を除いたファイル名が、そのままジョブ名になります。

### 4.2 SQLファイル内の複数SQL文

1つのSQLファイル内には、複数のSQL文を書けます。

例:

```sql
DROP TABLE IF EXISTS mart.sales_summary;

CREATE TABLE mart.sales_summary AS
SELECT
    customer_id,
    SUM(amount) AS total_amount
FROM stg.sales
GROUP BY customer_id;
```

この場合、`executor.py` はSQL文を2つに分割し、ファイル内の順番どおりに以下の順で実行します。

```text
1. DROP TABLE IF EXISTS mart.sales_summary
2. CREATE TABLE mart.sales_summary AS SELECT ...
```

### 4.3 ジョブ間の依存関係

ジョブ間の依存関係は `config/jobs.yaml` の `depends_on` で定義します。

例:

```yaml
default:
  enabled: true
  parallelism: 4

jobs:
  raw_to_stg_customer:
    enabled: true
    depends_on: []

  raw_to_stg_sales:
    enabled: true
    depends_on: []

  stg_to_mart_sales:
    enabled: true
    depends_on:
      - raw_to_stg_customer
      - raw_to_stg_sales
```

この場合、`raw_to_stg_customer` と `raw_to_stg_sales` は依存関係がないため並列実行可能です。  
`stg_to_mart_sales` は2つの依存元が完了してから実行されます。

---

## 5. `main.py` 仕様

`main.py` は、プログラム全体のエントリポイントです。

主な責務は以下です。

- CLI引数の解析
- SQLディレクトリの解決
- 設定ファイルの解決
- SQLファイルの検出
- ジョブ定義の作成
- 実行対象ジョブの絞り込み
- 並列数の決定
- 実行ステージの作成
- ステージ単位のジョブ実行
- 依存失敗時のスキップ制御
- 実行結果サマリの出力
- 終了コードの返却

### 5.1 デフォルトパス

`main.py` では、以下のデフォルトパスが定義されています。

| 項目 | デフォルト |
|---|---|
| SQLディレクトリ | `./sql` |
| 設定ファイル | `./config/jobs.yaml` |

実際には、`main.py` が配置されているディレクトリを基準に解決されます。

### 5.2 コマンドライン引数

| 引数 | 型 | デフォルト | 説明 |
|---|---:|---|---|
| `--sql-dir` | string | `./sql` | SQLファイル格納ディレクトリ |
| `--config` | string | `./config/jobs.yaml` | ジョブ設定YAMLファイル |
| `--parallelism` | int | `None` | 並列実行数。未指定時は `jobs.yaml` の `default.parallelism` を使用 |
| `--job` | string / multiple | `[]` | 実行対象ジョブ名を限定。複数指定可能 |
| `--include-disabled` | flag | `False` | `enabled: false` のジョブも強制的に実行対象へ含める |

### 5.3 実行例

#### デフォルト実行

```bash
python main.py
```

#### SQLディレクトリを指定して実行

```bash
python main.py --sql-dir ./sql/prod
```

#### 設定ファイルを指定して実行

```bash
python main.py --config ./config/prod_jobs.yaml
```

#### 並列数を指定して実行

```bash
python main.py --parallelism 8
```

#### 特定ジョブのみ実行

```bash
python main.py --job stg_to_mart_sales
```

#### 複数ジョブを指定して実行

```bash
python main.py \
  --job raw_to_stg_customer \
  --job raw_to_stg_sales \
  --job stg_to_mart_sales
```

#### disabledジョブも含めて実行

```bash
python main.py --include-disabled
```

### 5.4 並列数の決定ルール

並列実行数は以下の優先順位で決定されます。

```text
1. CLI引数 --parallelism
2. jobs.yaml の default.parallelism
3. デフォルト値 4
```

`--parallelism` に `1` 未満の値が指定された場合はエラーになります。

### 5.5 実行結果と終了コード

`main.py` は、全ジョブの実行結果を集計し、以下のルールで終了コードを返します。

| 状態 | 終了コード |
|---|---:|
| すべて `SUCCESS` | `0` |
| 1件でも `FAILED` または `SKIPPED` がある | `1` |
| 致命的な例外で処理中断 | `1` |

`SKIPPED` も異常終了扱いになる点に注意してください。

---

## 6. `executor.py` 仕様

`executor.py` は、1つのSQLファイルを実行するためのモジュールです。

`main.py` から以下の関数が呼び出されます。

```python
execute_sql_file(job_name, sql_file_path)
```

### 6.1 処理フロー

```mermaid
flowchart TD
    A[execute_sql_file開始] --> B[SparkSession取得]
    B --> C[SQLファイルをUTF-8で読み込み]
    C --> D[SQLコメントを除去]
    D --> E[SQL文をセミコロンで分割]
    E --> F{SQL文が存在するか}
    F -- No --> G[FAILEDを返却]
    F -- Yes --> H[SQL文を先頭から順番に実行]
    H --> I{全SQL文成功?}
    I -- Yes --> J[SUCCESSを返却]
    I -- No --> K[FAILEDを返却]
```

### 6.2 SparkSession取得

SparkSessionの取得は `get_spark_session()` で行われます。

優先順位は以下です。

```text
1. utils.spark_session.get_spark_session()
2. executor.py 内のフォールバック実装
```

プロジェクト側で `utils/spark_session.py` を用意している場合は、その中の `get_spark_session()` が利用されます。

用意されていない場合、以下のフォールバック実装でSparkSessionが生成されます。

```python
SparkSession.builder \
    .appName("data-transformation") \
    .enableHiveSupport() \
    .getOrCreate()
```

### 6.3 スレッドローカル管理

`executor.py` は、`threading.local()` を使ってスレッドごとにSparkSessionを保持します。

これは `main.py` が `ThreadPoolExecutor` でジョブを並列実行するためです。

ただし、SparkSession自体はJVM側でsingletonに近い挙動をするため、実際の並列性はSparkクラスタやスケジューラ設定に依存します。

### 6.4 SQLファイル読み込み

SQLファイルはUTF-8で読み込まれます。

以下の場合はエラーになります。

| 条件 | エラー |
|---|---|
| ファイルが存在しない | `FileNotFoundError` |
| 指定パスがファイルではない | `FileNotFoundError` |

### 6.5 SQLコメント除去

実行前に、SQLコメントが除去されます。

対応しているコメント形式は以下です。

```sql
-- 行コメント
```

```sql
/* ブロックコメント */
```

注意点として、文字列リテラル内の `--` や `/* ... */` を厳密には考慮していません。

以下のようなSQLは、意図せず壊れる可能性があります。

```sql
SELECT 'this is not -- comment' AS text_col;
SELECT 'this is not /* comment */' AS text_col;
```

### 6.6 SQL文の分割

SQL文の分割は `split_sql_statements()` で行われます。

優先順位は以下です。

```text
1. utils.sql_parser.split_sql_statements()
2. executor.py 内のフォールバック分割処理
```

フォールバック分割処理では、基本的にセミコロン `;` でSQL文を分割します。

ただし、以下の中にあるセミコロンは分割対象外です。

```sql
SELECT 'A;B;C' AS text_col;
SELECT "A;B;C" AS text_col;
```

非対応または注意が必要な構文は以下です。

- `$$ ... $$` のような特殊ブロック
- ストアドプロシージャ
- 複雑なUDF定義
- 方言固有のスクリプトSQL
- 完全なSQLパーサが必要な複雑SQL

### 6.7 SQL実行

単一SQL文は以下で実行されます。

```python
spark.sql(statement)
```

主に以下のようなSQLを想定しています。

- `CREATE TABLE AS SELECT`
- `CREATE OR REPLACE TABLE`
- `CREATE OR REPLACE VIEW`
- `INSERT INTO`
- `INSERT OVERWRITE`
- `DROP TABLE`
- `TRUNCATE TABLE`
- Spark SQL / Iceberg 用のDDL・DML

### 6.8 SELECT単体SQLの注意

Sparkでは、通常の `SELECT` はDataFrameを返すだけで、アクションを伴わない場合は遅延評価になる可能性があります。

そのため、この基盤では以下のようなSQLを中心に書くことを推奨します。

```sql
CREATE OR REPLACE TABLE mart.sales_summary AS
SELECT ...;
```

または、

```sql
INSERT OVERWRITE TABLE mart.sales_summary
SELECT ...;
```

検証目的の `SELECT` のみをSQLファイルに書く場合、意図した実行が行われない可能性があります。

### 6.9 返却値

`execute_sql_file()` は、以下の辞書を返します。

```python
{
    "job_name": "stg_to_mart_sales",
    "sql_file": "/absolute/path/to/sql/stg_to_mart_sales.sql",
    "status": "SUCCESS",
    "elapsed_seconds": 12.34,
    "error": None,
}
```

失敗時は以下のようになります。

```python
{
    "job_name": "stg_to_mart_sales",
    "sql_file": "/absolute/path/to/sql/stg_to_mart_sales.sql",
    "status": "FAILED",
    "elapsed_seconds": 5.67,
    "error": "AnalysisException: ...",
}
```

---

## 7. `scheduler.py` 仕様

`scheduler.py` は、`jobs.yaml` を読み込み、ジョブの実行対象判定と依存関係解決を行います。

主な関数は以下です。

| 関数 | 役割 |
|---|---|
| `load_job_config()` | `jobs.yaml` を読み込み、デフォルト設定を補完する |
| `_normalize_depends_on()` | `depends_on` を `list[str]` に正規化する |
| `resolve_runnable_jobs()` | SQLファイル一覧と設定を突き合わせ、実行対象ジョブを作る |
| `build_execution_stages()` | 依存関係を解決し、ステージ単位に分割する |

### 7.1 `jobs.yaml` が存在しない場合

設定ファイルが存在しない場合、エラーにはならず、以下のデフォルト設定が使われます。

```python
{
    "default": {
        "enabled": True,
        "parallelism": 4,
    },
    "jobs": {},
}
```

この場合、`sql/` 配下のすべてのSQLファイルが、依存関係なし・enabled扱いで実行対象になります。

### 7.2 `jobs.yaml` の基本フォーマット

```yaml
default:
  enabled: true
  parallelism: 4

jobs:
  raw_to_stg_customer:
    enabled: true
    depends_on: []

  raw_to_stg_sales:
    enabled: true
    depends_on: []

  stg_to_mart_sales:
    enabled: true
    depends_on:
      - raw_to_stg_customer
      - raw_to_stg_sales
```

### 7.3 `default` 設定

| 項目 | 型 | デフォルト | 説明 |
|---|---:|---|---|
| `enabled` | bool | `true` | ジョブごとの `enabled` が未指定の場合のデフォルト |
| `parallelism` | int | `4` | CLIで `--parallelism` が未指定の場合の並列数 |

### 7.4 `jobs` 設定

| 項目 | 型 | 必須 | 説明 |
|---|---:|---:|---|
| `enabled` | bool | 任意 | ジョブを実行対象にするかどうか |
| `depends_on` | list[string] | 任意 | 依存先ジョブ名のリスト |

### 7.5 `depends_on` のルール

`depends_on` は必ずリストで指定します。

OK:

```yaml
jobs:
  mart_sales:
    depends_on:
      - stg_sales
```

NG:

```yaml
jobs:
  mart_sales:
    depends_on: stg_sales
```

依存先が1つでも、文字列単体ではなくリストで書く必要があります。

### 7.6 ステージ分割

`build_execution_stages()` は、依存関係をもとに、同時実行可能なジョブを同じステージにまとめます。

例:

```yaml
jobs:
  job_a:
    depends_on: []

  job_b:
    depends_on: []

  job_c:
    depends_on:
      - job_a
      - job_b

  job_d:
    depends_on:
      - job_c
```

この場合、ステージは以下になります。

```text
Stage 1:
  - job_a
  - job_b

Stage 2:
  - job_c

Stage 3:
  - job_d
```

### 7.7 検出される設定エラー

`scheduler.py` は以下の設定ミスを検出します。

| エラー | 説明 |
|---|---|
| YAMLルートが辞書ではない | `jobs.yaml` 全体がmappingでない |
| `default` が辞書ではない | `default:` 配下の形式不正 |
| `jobs` が辞書ではない | `jobs:` 配下の形式不正 |
| `enabled` がboolではない | `true` / `false` 以外が指定されている |
| `depends_on` が文字列単体 | list形式でない |
| `depends_on` の要素が文字列ではない | 数値などが含まれている |
| `depends_on` の要素が空文字 | 空の依存先が指定されている |
| 重複ジョブ名 | 同じジョブ名が複数存在する |
| 未定義ジョブへの依存 | 依存先ジョブが実行対象に存在しない |
| 自己依存 | 自分自身を `depends_on` に指定している |
| 循環依存 | `A -> B -> A` のような依存関係 |

---

## 8. 実行ステージと失敗時の挙動

### 8.1 通常時の実行例

依存関係が以下の場合:

```text
raw_to_stg_customer ┐
                    ├─ stg_to_mart_sales ── mart_to_report_sales
raw_to_stg_sales    ┘
```

ステージは以下になります。

```text
Stage 1:
  - raw_to_stg_customer
  - raw_to_stg_sales

Stage 2:
  - stg_to_mart_sales

Stage 3:
  - mart_to_report_sales
```

Stage 1の2ジョブは並列実行されます。  
Stage 2はStage 1の完了後に実行されます。  
Stage 3はStage 2の完了後に実行されます。

### 8.2 失敗時のスキップ挙動

以下の依存関係があるとします。

```text
job_a -> job_b -> job_c
```

`job_a` が失敗した場合、後続は以下のようになります。

| ジョブ | 結果 |
|---|---|
| `job_a` | `FAILED` |
| `job_b` | `SKIPPED` |
| `job_c` | `SKIPPED` |

`main.py` では、依存先が `FAILED` または `SKIPPED` になっているジョブを実行せず、`SKIPPED` として扱います。

### 8.3 `SKIPPED` の意味

`SKIPPED` は、ジョブ自体のSQLを実行して失敗したのではなく、依存元が正常に完了していないため実行対象から除外された状態です。

例:

```text
[SKIPPED] mart_sales reason=blocked by upstream jobs: ['stg_sales']
```

---

## 9. ログ出力仕様

本プログラムは、標準出力および標準エラーにログを出力します。

### 9.1 実行計画ログ

`main.py` は実行前に以下を表示します。

- 設定ファイルパス
- SQLディレクトリ
- 並列数
- ステージ数
- 対象ジョブ数
- ステージごとのジョブ一覧
- 各ジョブの依存関係

例:

```text
[INFO] Data Transformation Job Started
[INFO] Config file : /path/to/config/jobs.yaml
[INFO] SQL dir      : /path/to/sql
[INFO] Parallelism  : 4
[INFO] Stage count  : 2
[INFO] Target jobs  : 3
```

### 9.2 SQL実行ログ

`executor.py` はSQLファイルごとに以下を表示します。

- SQLファイル実行開始
- SQLファイルパス
- SQL文数
- SQL文プレビュー
- SQL文ごとの実行開始
- SQL文ごとの成功と実行時間
- SQLファイル全体の成功と実行時間
- 失敗時のエラー内容
- 失敗時のtraceback

### 9.3 実行結果サマリ

最後に以下のサマリが表示されます。

```text
[INFO] Execution Summary
[INFO] Total jobs      : 3
[INFO] Success count   : 3
[INFO] Failure count   : 0
[INFO] Skipped count   : 0
[INFO] Total elapsed   : 12.34 sec
```

各ジョブの詳細も表示されます。

```text
[SUCCESS] raw_to_stg_customer                 3.21 sec
[SUCCESS] raw_to_stg_sales                    4.56 sec
[SUCCESS] stg_to_mart_sales                   2.34 sec
```

---

## 10. 代表的な利用シナリオ

### 10.1 RAW -> STG -> MART のSQL変換

```text
raw_to_stg_customer.sql
raw_to_stg_sales.sql
stg_to_mart_customer.sql
stg_to_mart_sales.sql
mart_to_report_sales.sql
```

`jobs.yaml`:

```yaml
default:
  enabled: true
  parallelism: 4

jobs:
  raw_to_stg_customer:
    depends_on: []

  raw_to_stg_sales:
    depends_on: []

  stg_to_mart_customer:
    depends_on:
      - raw_to_stg_customer

  stg_to_mart_sales:
    depends_on:
      - raw_to_stg_sales
      - raw_to_stg_customer

  mart_to_report_sales:
    depends_on:
      - stg_to_mart_sales
      - stg_to_mart_customer
```

### 10.2 一部ジョブだけ無効化

```yaml
jobs:
  old_sales_mart:
    enabled: false
```

通常実行では `old_sales_mart` は実行されません。

強制的に含める場合:

```bash
python main.py --include-disabled
```

### 10.3 開発中の特定ジョブだけ実行

```bash
python main.py --job stg_to_mart_sales
```

ただし、依存元ジョブも実行対象に含まれていない場合、`depends_on` 解決時にエラーになる可能性があります。

必要に応じて、依存元も明示的に指定します。

```bash
python main.py \
  --job raw_to_stg_customer \
  --job raw_to_stg_sales \
  --job stg_to_mart_sales
```

---

## 11. 設計上の重要ポイント

### 11.1 DB / スキーマ指定はSQL内で完結させる

この実行基盤では、設定ファイル側にDB名やスキーマ名を持たせません。

そのため、SQL内で明示的に指定します。

例:

```sql
CREATE OR REPLACE TABLE mart.sales_summary AS
SELECT ...
FROM stg.sales;
```

または、必要に応じてSQL内で以下のような指定を行います。

```sql
USE CATALOG dev_catalog;
USE SCHEMA mart;
```

### 11.2 SQLファイル名とジョブ名を一致させる

`jobs.yaml` のジョブ名は、SQLファイル名の拡張子を除いた名前と一致させる必要があります。

例:

```text
sql/stg_to_mart_sales.sql
```

対応する `jobs.yaml`:

```yaml
jobs:
  stg_to_mart_sales:
    depends_on:
      - raw_to_stg_sales
```

### 11.3 SQLファイルがないジョブは実行されない

`jobs.yaml` にジョブ定義が存在していても、対応する `.sql` ファイルが `sql/` 配下に存在しなければ、実行対象にはなりません。

### 11.4 SQLファイルがあり、jobs.yamlに設定がないジョブは実行される

`jobs.yaml` にジョブ定義がなくても、SQLファイルが存在すれば、デフォルト設定で実行対象になります。

つまり、明示的に除外したい場合は `enabled: false` を設定します。

---

## 12. 制約・注意点

### 12.1 トランザクション制御はない

1つのSQLファイル内に複数SQL文がある場合、途中まで成功してから失敗すると、成功済みSQLの変更は自動では戻りません。

例:

```sql
DROP TABLE mart.sales_summary;

CREATE TABLE mart.sales_summary AS
SELECT ...;
```

この場合、`DROP TABLE` が成功し、`CREATE TABLE` が失敗すると、テーブルが消えた状態になる可能性があります。

重要テーブルでは、以下のような安全な差し替え設計を推奨します。

```text
1. 一時テーブルを作成
2. 件数チェック・品質チェック
3. 問題なければ本番テーブルへ差し替え
4. 一時テーブルを削除
```

### 12.2 SQL分割は完全なSQLパーサではない

フォールバックのSQL分割処理は、一般的なDDL/DMLには対応できますが、完全なSQLパーサではありません。

複雑なSQLを扱う場合は、`utils/sql_parser.py` を実装して差し替えることを推奨します。

### 12.3 SELECT単体SQLは推奨しない

Sparkの遅延評価により、`SELECT` 単体では意図した処理が実行されない可能性があります。

この基盤では、以下のような副作用を持つSQLを推奨します。

- `CREATE TABLE AS SELECT`
- `CREATE OR REPLACE TABLE AS SELECT`
- `INSERT INTO SELECT`
- `INSERT OVERWRITE SELECT`
- `CREATE OR REPLACE VIEW`

### 12.4 同一テーブルへの並列書き込みに注意

依存関係がないジョブは同一ステージ内で並列実行されます。

そのため、複数ジョブが同じテーブルへ書き込む場合、競合やデータ不整合が発生する可能性があります。

同一テーブルに書き込むジョブ同士は、`depends_on` で順序を明示してください。

### 12.5 Spark側の並列実行性能は環境依存

Python側では `ThreadPoolExecutor` により並列実行されますが、実際の並列性は以下に依存します。

- Sparkクラスタのリソース
- Executor数
- Queue設定
- `spark.scheduler.mode`
- Hive Metastore / Iceberg Catalog のロック
- 同時書き込み先の競合

---

## 13. 推奨運用ルール

### 13.1 SQLファイル命名規則

以下のように、レイヤーと処理内容がわかる名前を推奨します。

```text
raw_to_stg_customer.sql
raw_to_stg_sales.sql
stg_to_mart_customer.sql
stg_to_mart_sales.sql
mart_to_report_sales.sql
```

### 13.2 レイヤー順の依存関係

基本的には以下の順序を依存関係で表現します。

```text
RAW -> STG -> MART -> REPORT
```

### 13.3 1ファイル1責務

1つのSQLファイルには、なるべく1つの成果物を作る処理をまとめます。

推奨:

```text
stg_to_mart_sales.sql
```

非推奨:

```text
create_all_marts.sql
```

大きすぎるSQLファイルは、失敗時の影響範囲が広くなり、再実行もしづらくなります。

### 13.4 依存関係は明示する

同じテーブルや同じ入力データに関係するジョブは、暗黙の順序に頼らず、`depends_on` で明示します。

### 13.5 本番用SparkSessionは `utils.spark_session` に切り出す

本番環境では、フォールバックのSparkSessionではなく、`utils/spark_session.py` を用意して環境固有の設定を明示することを推奨します。

例:

```python
from pyspark.sql import SparkSession


def get_spark_session() -> SparkSession:
    return (
        SparkSession.builder
        .appName("data-transformation-prod")
        .enableHiveSupport()
        .config("spark.sql.shuffle.partitions", "400")
        .getOrCreate()
    )
```

---

## 14. トラブルシューティング

### 14.1 SQLディレクトリが存在しない

エラー例:

```text
SQL directory does not exist: /path/to/sql
```

確認事項:

- `--sql-dir` の指定が正しいか
- `sql/` ディレクトリが存在するか
- 実行カレントディレクトリが想定通りか

### 14.2 `jobs.yaml` の構造が不正

エラー例:

```text
jobs.yaml root must be a mapping (dictionary).
```

確認事項:

- YAMLのルートが辞書になっているか
- `default:` と `jobs:` のインデントが正しいか

### 14.3 `depends_on` を文字列で書いている

NG:

```yaml
jobs:
  mart_sales:
    depends_on: stg_sales
```

OK:

```yaml
jobs:
  mart_sales:
    depends_on:
      - stg_sales
```

### 14.4 依存先ジョブが存在しない

エラー例:

```text
Job 'mart_sales' depends on undefined or non-runnable jobs: ['stg_sales']
```

確認事項:

- `sql/stg_sales.sql` が存在するか
- SQLファイル名と `jobs.yaml` のジョブ名が一致しているか
- 依存先ジョブが `enabled: false` になっていないか
- `--job` で依存先ジョブを除外していないか

### 14.5 循環依存がある

NG例:

```yaml
jobs:
  job_a:
    depends_on:
      - job_b

  job_b:
    depends_on:
      - job_a
```

この場合、どちらも先に実行できないためエラーになります。

### 14.6 SQLファイル内に実行可能なSQLがない

エラー例:

```text
No executable SQL statements found in file
```

確認事項:

- SQLファイルが空ではないか
- コメントだけになっていないか
- セミコロンやSQL本文が正しく書かれているか

---

## 15. 改善候補

現状でも小〜中規模のSQLバッチ実行基盤として利用できますが、本番運用を強化するなら以下の改善が考えられます。

### 15.1 `--with-upstream` オプションの追加

`--job` で後続ジョブを指定した場合に、依存元ジョブも自動で含めるオプションです。

例:

```bash
python main.py --job mart_sales --with-upstream
```

### 15.2 リトライ機能

一時的なSparkエラーやメタストア接続エラーに備えて、ジョブ単位のリトライ回数を設定できるようにします。

例:

```yaml
jobs:
  mart_sales:
    retry: 2
```

### 15.3 タイムアウト制御

長時間終了しないSQLに対して、ジョブ単位でタイムアウトを設定できるようにします。

```yaml
jobs:
  mart_sales:
    timeout_seconds: 1800
```

### 15.4 実行履歴テーブルへの保存

標準出力だけでなく、実行結果をテーブルやログ基盤に保存すると運用しやすくなります。

保存候補:

- job_name
- sql_file
- status
- started_at
- finished_at
- elapsed_seconds
- error
- run_id

### 15.5 ドライラン機能

SQLを実行せず、実行計画だけ表示する `--dry-run` があると安全です。

```bash
python main.py --dry-run
```

### 15.6 ジョブタグ

ジョブにタグを付与し、特定タグのジョブだけ実行できるようにします。

```yaml
jobs:
  mart_sales:
    tags:
      - mart
      - sales
```

```bash
python main.py --tag mart
```

### 15.7 SQLファイルとjobs.yamlの差分チェック

以下のような差分を検出できると、本番運用で安全です。

- SQLファイルはあるが `jobs.yaml` に定義がない
- `jobs.yaml` に定義があるがSQLファイルがない
- `depends_on` が存在しないジョブを参照している

---

## 16. この基盤が向いている用途・向いていない用途

### 16.1 向いている用途

- Spark SQLによるデータ変換
- Iceberg / Hive Metastore を使ったテーブル作成
- RAW -> STG -> MART のELT処理
- SQLファイル単位のシンプルなジョブ管理
- 小〜中規模のDAG型バッチ処理
- AirflowやDagsterを入れるほどではない軽量な依存実行
- ローカル検証用のSQL実行基盤
- PoC / MVP段階のデータ変換基盤

### 16.2 向いていない用途

- 複雑なワークフロー管理
- GUIでのDAG管理
- 高度なスケジューリング
- SLA管理
- ジョブリトライ、アラート、監視を強く求める本番運用
- 複雑なトランザクション保証が必要な処理
- ストアドプロシージャや方言固有の複雑SQLスクリプト実行

このような用途では、Airflow、Dagster、Prefect、Databricks Workflows などの利用も検討してください。

---

## 17. まとめ

このプログラム群は、Spark SQLを使ったデータ変換処理を、SQLファイル単位で管理・実行するための軽量なDAG実行基盤です。

全体の責務は以下のように分かれています。

```text
main.py
  - 全体制御
  - CLI引数解析
  - SQLファイル検出
  - ステージ単位の並列実行
  - 失敗/スキップ管理
  - 実行結果サマリ出力

executor.py
  - SQLファイル読み込み
  - SQLコメント除去
  - SQL文分割
  - SparkSession取得
  - Spark SQL実行
  - SQLファイル単位のSUCCESS/FAILED返却

scheduler.py
  - jobs.yaml読込
  - default/jobs設定の正規化
  - enabled判定
  - depends_on検証
  - 実行対象ジョブ抽出
  - 実行ステージ作成
```

本基盤は、データエンジニアリングにおける `RAW -> STG -> MART` のようなSQL中心のELT処理を、最小構成で管理する用途に適しています。

一方で、本格的な本番運用では、リトライ、監視、実行履歴保存、ドライラン、依存元自動追加、SQLパーサ強化などを追加すると、より安全で運用しやすい基盤になります。

-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi003002
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi003008
select
	--ソート順
	v3002.mj_sortjyun as`ソート順`,
	--販社コード
	v3002.cd_hansya as `販社コード`,
	--会社コード
	v3002.cd_kaisya as `会社コード`,
	--店舗コード
	v3002.cd_tenpo as `店舗コード`,
	--販社会社店舗コード
	concat(v3002.cd_hansya, v3002.cd_kaisya, v3002.cd_tenpo) as `販社会社店舗コード`,
	--エリアコード
	v3002.cd_zon as `エリアコード`,
	--エリア名
	v3002.kj_zonmei as `エリア名`,
	--店舗名
	v3002.kj_tenpomei as `店舗名`
-- ストールマスタ_充足率対象ＤＢ
from gold.vbi003002 v3002
group by v3002.cd_hansya, v3002.cd_kaisya, v3002.cd_tenpo, v3002.kj_zonmei,v3002.cd_zon, v3002.kj_tenpomei, v3002.mj_sortjyun
;

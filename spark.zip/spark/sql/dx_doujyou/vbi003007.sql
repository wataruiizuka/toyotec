-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 3
-- Internal Gold dependencies: gold.vbi003003, gold.vbi003006_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi003007
select
	--ソート順
	v3003.mj_sortjyun as `ソート順`,
	--販社コード
	v3003.cd_hansya as `販社コード`,
	--会社コード
	v3003.cd_kaisya as `会社コード`,
	--店舗コード
	v3003.cd_tenpo as `店舗コード`,
	--販社会社店舗コード
	concat(v3003.cd_hansya, v3003.cd_kaisya, v3003.cd_tenpo) as `販社会社店舗コード`,
	--エリアード
	v3003.cd_zon as `エリアコード`,
	--エリア名
	v3003.kj_zonmei as `エリア名`,
	--店舗名
	v3003.kj_tenpomei as `店舗名`,
	--ストール番号
	v3003.no_stall as `ストール番号`,
	--ストール名称
	v3003.mj_stallmei as `ストール名称`,
	--販社会社店舗ストール番号日付
	v3003.cd_hansyakaisyatenpostalldate as `販社会社店舗ストール番号日付`,
	--ストール選択
	v3003.kb_stallsentaku as `ストール選択`,
	--日付
	v3003.dd_date as `日付`,
	--定内規定
	v3003.kb_teinaikitei as `定内規定`,
	--予約
	nvl(v3006.mj_yoyaku, 0) as `予約`
-- ストールマスタ_充足率対象ＤＢ_14日
from gold.vbi003003 v3003
-- ストール予約明細_分析対象ＤＢ_14日_group
left join (
	select
		v3006.cd_hansya,
		v3006.cd_kaisya,
		v3006.cd_tenpo,
		v3006.no_stall,
		v3006.dd_nyuukoyt,
		sum(v3006.mj_yoyaku) as mj_yoyaku
	-- ストール予約明細_分析対象ＤＢ_14日
	from gold.vbi003006_en v3006
	group by v3006.cd_hansya, v3006.cd_kaisya, v3006.cd_tenpo, v3006.no_stall, v3006.dd_nyuukoyt
) v3006 on v3006.cd_hansya = v3003.cd_hansya
and v3006.cd_kaisya = v3003.cd_kaisya
and v3006.cd_tenpo = v3003.cd_tenpo
and v3006.no_stall = v3003.no_stall
and v3006.dd_nyuukoyt = v3003.dd_date
;

-- Source file: 011_メンテナンスパック契約客ステータス一覧/メンテナンスパック契約客ステータス一覧.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi011004
SELECT 
	--販社コード
	t005g.cd_hansya,
	--会社コード
	t005g.cd_kaisya,
	--お客様コード
	ta001g.cd_okyaku,
	--登録ＮＯ陸支コード
	ta001g.cd_norikusi,
	--登録ＮＯ車種区分
	ta001g.kb_nosyasyu,
	--登録ＮＯ業態コード
	ta001g.cd_nogyotai,
	--登録ＮＯ整理番号
	ta001g.no_noseiri,
	--入庫予定日時
	ta001g.dt_nyuukoyt,
	--入庫区分
	t005g.kb_nyuuko
--ストール予約明細DB
FROM ai21rep_ve_dx.tbsa005g t005g
--ストール予約ＤＢ
LEFT JOIN ai21rep_ve_dx.tbsa001g ta001g 
ON t005g.cd_hansya = ta001g.cd_hansya 
AND t005g.cd_kaisya = ta001g.cd_kaisya
AND t005g.cd_tenpo = ta001g.cd_tenpo
--予約ＩＤ
AND t005g.no_yoyakuid = ta001g.no_yoyakuid
--= Table.SelectRows(フィルターされた行, each ([予約ＩＤ] <> null and [予約ＩＤ] <> "") and ([登録ＮＯ陸支コード] <> ""))
AND ta001g.no_yoyakuid IS NOT NULL
--登録ＮＯ陸支コード != '' 
AND ta001g.cd_norikusi != '' 
--= Table.SelectRows(chgColName, each ([ＳＭＢ削除フラグ] = "0"))
AND ta001g.mj_sakujyo = '0'
WHERE 
--= Table.SelectRows(条件付き制限された初期行数, each ([ＳＭＢ削除フラグ] = "0") and ([入庫区分] <> "" and [入庫区分] <> "0" and [入庫区分] <> "8" and [入庫区分] <> "9"))
t005g.mj_sakujyo = '0'
AND t005g.kb_nyuuko != ''
AND t005g.kb_nyuuko != '0'
AND t005g.kb_nyuuko != '8'
AND t005g.kb_nyuuko != '9'
;

-- Source file: 001_新車車両日報/新車車両日報.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi001002
SELECT
	--販社コード
    cd_hansya,
    --会社コード
    cd_kaisya,
    --店舗コード
    cd_tenpo,
    --車名コード
    cd_ncsyamei,
    --車名
    kn_syame,
    --日付
    CAST(to_date(dd_date) AS DATE) AS dd_date,
    --新車販売実績
    nullif(SUM(su_sinsya_hanbai), 0) AS su_sinsya_hanbai,
    --新車販売取消
    nullif(SUM(su_sinsya_torikesi), 0) AS su_sinsya_hanbai_torikesi,
    --新車販売合計
    nullif(SUM(su_sinsya_hanbai) - SUM(su_sinsya_torikesi), 0) AS su_sinsya_hanbai_goukei
FROM (
    SELECT 
    	--販社コード
        tg.cd_hansya,
        --会社コード
        tg.cd_kaisya,
        --店舗コード
        tg.cd_tenpo,
        --車名コード
        tbbf001m.cd_ncsyamei,
        --車名
        UPPER(NVL(tbbf001m.kn_syame, '')) AS kn_syame,
        --日付
        (CASE 
            WHEN ft168g.dd_torokei IS NULL THEN tg.dd_uriagekj 
            ELSE ft168g.dd_torokei 
         END) AS dd_date,
        --新車販売実績
        COUNT(*) AS su_sinsya_hanbai,
        --新車販売取消
        0 AS su_sinsya_torikesi
    FROM ai21rep_ve_dx.tbba001g tg  -- 新車受注基本情報ＤＢ
    LEFT JOIN ai21rep_ve_dx.tbbf008m tbbf008m  -- 車両スペック２ＤＢ
        ON tg.cd_kaisya = tbbf008m.cd_kaisya 
        AND tg.cd_hansya = tbbf008m.cd_hansya 
        AND tg.mj_sinkysed = tbbf008m.mj_sinkysed 
        AND tg.mj_gaihansy = tbbf008m.cd_spec 
        AND tg.mj_hantenkt = tbbf008m.mj_hantenkt
        -- スペック区分が 「G」 である
        AND tbbf008m.kb_spec = 'G'
    LEFT JOIN ai21rep_ve_dx.tbbf001m tbbf001m  -- 車名ＤＢ
        ON tbbf001m.cd_kaisya = tbbf008m.cd_kaisya 
        AND tbbf001m.cd_hansya = tbbf008m.cd_hansya 
        AND tbbf001m.cd_ncsyamei = tbbf008m.mj_syamei
    LEFT JOIN (
        SELECT 
            t168g.cd_hansya,
            t168g.cd_kaisya,
            t168g.no_cyumon,
            MIN(t168g.dd_torokei) AS dd_torokei
        FROM ai21rep_ve_dx.tbbg168g t168g  -- 履歴登録ＤＢ
        WHERE 
            -- 業務ＮＯが 07 である
            t168g.no_gyomu = '07' 
            -- 処理ＮＯが 01 である
            AND t168g.no_syori = '01'
        GROUP BY 
            t168g.cd_hansya,
            t168g.cd_kaisya,
            t168g.no_cyumon
    ) ft168g 
        ON ft168g.cd_kaisya = tg.cd_kaisya 
        AND ft168g.cd_hansya = tg.cd_hansya 
        AND ft168g.no_cyumon = tg.no_cyumon
    WHERE
        -- 払出区分が　「00」　「40」　以外である 
        tg.kb_haraidas NOT IN ('00', '40') 
        -- 受注計上日が空ではない
        AND tg.dd_jucyuke IS NOT NULL 
        AND (
            (-- 登録計上日が空である
            ft168g.dd_torokei IS NULL
            -- 売上計上日が前月1日より大きい
                AND date_format(tg.dd_uriagekj, 'yyyyMM') >= date_format(add_months(current_timestamp(), -1), 'yyyyMM')
            ) 
            OR ( -- 登録計上日が空ではない
            ft168g.dd_torokei IS NOT NULL 
             -- 登録計上日が前月1日より大きい
                AND date_format(ft168g.dd_torokei, 'yyyyMM') >= date_format(add_months(current_timestamp(), -1), 'yyyyMM')
            )
        )
    GROUP BY 
        tg.cd_hansya,
        tg.cd_kaisya,
        tg.cd_tenpo,
        dd_date,
        tbbf001m.cd_ncsyamei,
        NVL(tbbf001m.kn_syame, '')
    UNION ALL
    SELECT
    	--販社コード
        tg.cd_hansya,
        --会社コード
        tg.cd_kaisya,
        --店舗コード
        tg.cd_tenpo,
        --車名コード
        tbbf001m.cd_ncsyamei,
        --車名
        UPPER(NVL(tbbf001m.kn_syame, '')) AS kn_syame,
        --日付
        tg.dd_uritrkkj AS dd_date,
        --新車販売実績
        0 AS su_sinsya_hanbai,
        --新車販売取消
        COUNT(*) AS su_sinsya_torikesi
    FROM ai21rep_ve_dx.tbba001g tg  -- 新車受注基本情報ＤＢ
    LEFT JOIN ai21rep_ve_dx.tbbf008m tbbf008m   -- 車両スペック２ＤＢ
        ON tg.cd_kaisya = tbbf008m.cd_kaisya 
        AND tg.cd_hansya = tbbf008m.cd_hansya 
        AND tg.mj_sinkysed = tbbf008m.mj_sinkysed 
        AND tg.mj_gaihansy = tbbf008m.cd_spec 
        AND tg.mj_hantenkt = tbbf008m.mj_hantenkt
        -- スペック区分が 「G」 である
        AND tbbf008m.kb_spec = 'G'
    LEFT JOIN ai21rep_ve_dx.tbbf001m tbbf001m  -- 車名ＤＢ
        ON tbbf001m.cd_kaisya = tbbf008m.cd_kaisya 
        AND tbbf001m.cd_hansya = tbbf008m.cd_hansya 
        AND tbbf001m.cd_ncsyamei = tbbf008m.mj_syamei
    WHERE 
        -- 払出区分が　「00」　「40」　以外である 
        tg.kb_haraidas NOT IN ('00', '40') 
         -- 受注計上日が空ではない
        AND tg.dd_jucyuke IS NOT NULL 
        -- 売上取消計上日が前月1日より大きい
        AND date_format(tg.dd_uritrkkj, 'yyyyMM') >= date_format(add_months(current_timestamp(), -1), 'yyyyMM')
    GROUP BY 
        tg.cd_hansya,
        tg.cd_kaisya,
        tg.cd_tenpo,
        tbbf001m.cd_ncsyamei,
        NVL(tbbf001m.kn_syame, ''),
        tg.dd_uritrkkj
) combined
GROUP BY 
    cd_hansya,
    cd_kaisya,
    cd_tenpo,
    to_date(dd_date),
    cd_ncsyamei,
    kn_syame
;

-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi000001_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000001
select
	--ソート順
	mj_sortjyun as `ソート順`,
	--販社コード
	cd_hansya as `販社コード`,
	--会社コード
	cd_kaisya as `会社コード`,
	--店舗コード
	cd_tenpo as `店舗コード`,
	--店舗名称
	kj_tenpomei as `店舗名称`
from gold.vbi000001_en
;

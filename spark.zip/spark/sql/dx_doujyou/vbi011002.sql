-- Source file: 011_メンテナンスパック契約客ステータス一覧/メンテナンスパック契約客ステータス一覧.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi011002
SELECT 
	--販社コード
	t0201m.cd_hansya,  
	--会社コード
	t0201m.cd_kaisya, 
	--店舗コード
	t0201m.cd_tenpo,  
	--店舗名称
	t0201m.kj_tenpomei,
	--ゾーンコード
	 IF(
    	t0033m.kj_zonmei IS NULL OR regexp_replace(t0033m.kj_zonmei, '[ 　]+', '') = '',
    	'999999',
    	IF(
        	t0033m.cd_zon IS NULL OR regexp_replace(t0033m.cd_zon, '[ 　]+', '') = '',
        	'999998',
        	t0033m.cd_zon
    	)
	) AS cd_zon, 
	--ゾーン名称 
	t0033m.kj_zonmei,
	--ソート順
	t9003m.mj_sortjyun
FROM
	--共通店舗DB
    ai21rep_ve_dx.tbv0201m t0201m
    --M車両店舗DB
LEFT JOIN ai21rep_ve_dx.tbv0047m t0047m
    ON t0047m.cd_hansya = t0201m.cd_hansya
    AND t0047m.cd_kaisya = t0201m.cd_kaisya
    AND t0047m.cd_tenpo = t0201m.cd_tenpo
    --MゾーンコードDB
LEFT JOIN ai21rep_ve_dx.tbv0033m t0033m
    ON t0033m.cd_hansya = t0047m.cd_hansya
    AND t0033m.cd_kaisya = t0047m.cd_kaisya
    AND t0033m.cd_zon = t0047m.CD_NCZON
	--商品区分 = '3'（サービス）
	AND t0033m.kb_syohin = '3'
	--店舗展示設定
INNER JOIN dx_ve.tbi999003m t9003m
	ON t9003m.cd_hansya = t0201m.cd_hansya
    AND t9003m.cd_kaisya = t0201m.cd_kaisya
    AND t9003m.cd_tenpo = t0201m.cd_tenpo
    AND t9003m.mj_cyohyoid = '011'
    AND t9003m.kb_tenji = 1
;

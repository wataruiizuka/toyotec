-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi000004_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000004
select
	cd_hansya as `販社コード`,
	cd_kaisya as `会社コード`,
	no_seiri as `整理ＮＯ`,
	kj_recallme as `リコール名称`
from gold.vbi000004_en
;

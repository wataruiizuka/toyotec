-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000001_en
select
	--ソート順
	row_number() over(order by t201m.cd_hansya, t201m.cd_kaisya, t9003m.mj_sortjyun, t201m.cd_tenpo) as mj_sortjyun,
	--販社コード
	t201m.cd_hansya,
	--会社コード
	t201m.cd_kaisya,
	--店舗コード
	t201m.cd_tenpo,
	--店舗名称
	regexp_replace(t201m.kj_tenpomei, '　+$', '') as kj_tenpomei
--共通店舗DB
from ai21rep_ve_dx.tbv0201m t201m
-- 店舗表示設定
inner join dx_ve.tbi999003m t9003m on t9003m.cd_hansya = t201m.cd_hansya
and t9003m.cd_kaisya = t201m.cd_kaisya
and t9003m.cd_tenpo = t201m.cd_tenpo
and t9003m.mj_cyohyoid = '000'
and t9003m.kb_tenji = 1
;

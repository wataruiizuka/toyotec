-- Source file: 002_新車売掛金/VBI002008_新車売掛金回転日数_売上金額.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi002001_en
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.VBI002008
SELECT
    tbg7005m_3.cd_hansya AS `販社コード`, --販社コード
    tbg7005m_3.cd_kaisya AS `会社コード`, --会社コード
    tbg7005m_3.cd_tenpo AS `店舗コード`, --店舗コード
    tbg7005m_3.cd_hansya || tbg7005m_3.cd_kaisya || tbg7005m_3.cd_tenpo AS `販社会社店舗コード`, --販社会社店舗コード
    SUM(tbg7005m_3.ki_toykar01) AS `当年借方金額０１`, --当年借方金額０１
    SUM(tbg7005m_3.ki_toykar02) AS `当年借方金額０２`, --当年借方金額０２
    SUM(tbg7005m_3.ki_toykar03) AS `当年借方金額０３`, --当年借方金額０３
    SUM(tbg7005m_3.ki_toykar04) AS `当年借方金額０４`, --当年借方金額０４
    SUM(tbg7005m_3.ki_toykar05) AS `当年借方金額０５`, --当年借方金額０５
    SUM(tbg7005m_3.ki_toykar06) AS `当年借方金額０６`, --当年借方金額０６
    SUM(tbg7005m_3.ki_toykar07) AS `当年借方金額０７`, --当年借方金額０７
    SUM(tbg7005m_3.ki_toykar08) AS `当年借方金額０８`, --当年借方金額０８
    SUM(tbg7005m_3.ki_toykar09) AS `当年借方金額０９`, --当年借方金額０９
    SUM(tbg7005m_3.ki_toykar10) AS `当年借方金額１０`, --当年借方金額１０
    SUM(tbg7005m_3.ki_toykar11) AS `当年借方金額１１`, --当年借方金額１１
    SUM(tbg7005m_3.ki_toykar12) AS `当年借方金額１２`, --当年借方金額１２
    SUM(tbg7005m_3.ki_toykas01) AS `当年貸方金額０１`, --当年貸方金額０１
    SUM(tbg7005m_3.ki_toykas02) AS `当年貸方金額０２`, --当年貸方金額０２
    SUM(tbg7005m_3.ki_toykas03) AS `当年貸方金額０３`, --当年貸方金額０３
    SUM(tbg7005m_3.ki_toykas04) AS `当年貸方金額０４`, --当年貸方金額０４
    SUM(tbg7005m_3.ki_toykas05) AS `当年貸方金額０５`, --当年貸方金額０５
    SUM(tbg7005m_3.ki_toykas06) AS `当年貸方金額０６`, --当年貸方金額０６
    SUM(tbg7005m_3.ki_toykas07) AS `当年貸方金額０７`, --当年貸方金額０７
    SUM(tbg7005m_3.ki_toykas08) AS `当年貸方金額０８`, --当年貸方金額０８
    SUM(tbg7005m_3.ki_toykas09) AS `当年貸方金額０９`, --当年貸方金額０９
    SUM(tbg7005m_3.ki_toykas10) AS `当年貸方金額１０`, --当年貸方金額１０
    SUM(tbg7005m_3.ki_toykas11) AS `当年貸方金額１１`, --当年貸方金額１１
    SUM(tbg7005m_3.ki_toykas12) AS `当年貸方金額１２`  --当年貸方金額１２
FROM
    ai21rep_ve_dx.tbg7005m tbg7005m_3 --総勘定ＤＢ
INNER JOIN gold.vbi002001_en v2001 --新車売掛金店舗別_en
    ON v2001.cd_hansya = tbg7005m_3.cd_hansya
    AND v2001.cd_kaisya = tbg7005m_3.cd_kaisya
    AND v2001.cd_tenpo = tbg7005m_3.cd_tenpo
WHERE (tbg7005m_3.cd_hansya <> '03601' OR tbg7005m_3.cd_kaisya <> '01' OR tbg7005m_3.cd_tenpo <> 'ZZZ') --店舗コード制限
    AND tbg7005m_3.nu_yyyy = YEAR(add_months(current_timestamp(), -(4))) --日付選択で4ヶ月前に対応する年を選択する
    AND tbg7005m_3.cd_kanjyou BETWEEN '5010101' AND '5019999' --勘定科目コード制限
GROUP BY
    tbg7005m_3.cd_hansya,
    tbg7005m_3.cd_kaisya,
    tbg7005m_3.cd_tenpo
;

-- Source file: 022_中古車車両日報/中古車車両日報.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi022001
SELECT
	--販社コード
	cd_hansya,
	--会社コード
	cd_kaisya,
	--受注店舗コード
	cd_jytyuten AS cd_tenpo,
	--日付
    CAST(to_date(dd_date) AS DATE) AS dd_date,
	--車名コード
	cd_ncsyamei,
	--車名
	kn_syame,
	--中古車受注実績
	nullif(SUM(su_jusya_jucyu), 0) AS su_jusya_jucyu,
	--中古車受注取消
	nullif(SUM(su_jusya_jucyu_torikesi), 0) AS su_jusya_jucyu_torikesi,
	--中古車受注合計
	nullif(SUM(su_jusya_jucyu) - SUM(su_jusya_jucyu_torikesi), 0) AS su_jusya_jucyu_goukei,
	--中古車受注残
	nullif(SUM(su_jusya_jucyucan), 0) AS su_jusya_jucyucan
FROM
	(
	SELECT
		--販社コード
		tg.cd_hansya,
		--会社コード
		tg.cd_kaisya,
		--受注店舗コード
		tg.cd_jytyuten,
		--車名コード
		CONCAT(NVL(tbbc001g.mj_21syamek, ''), 
               NVL(tbbc001g.mj_21syasyu, ''), 
               NVL(tbbc001g.mj_21syamak, ''), 
               NVL(tbbc001g.no_21syaren, ''), 
               NVL(tbbc001g.mj_21syanin, '')) AS cd_ncsyamei,
		--車名
		UPPER(NVL(tbv0232m.mj_syamei, '')) AS kn_syame,
		--日付
		tg.dd_jucyuke AS dd_date,
		--中古車受注実績
        CASE
			WHEN tg.dd_jucyuke IS NOT NULL THEN 1
			ELSE NULL
		END AS su_jusya_jucyu,
		--中古車受注取消
		0 AS su_jusya_jucyu_torikesi,
		--中古車受注残
		CASE
			WHEN tg.dd_jucyuke IS NOT NULL
			AND tg.dd_touroku IS NULL THEN 1
			ELSE NULL
		END AS su_jusya_jucyucan
	FROM
		ai21rep_ve_dx.tbbc017g tg	-- 中古車受注基本情報ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbc001g tbbc001g	-- 中古車在庫基本情報ＤＢ
        ON
		tbbc001g.cd_kaisya = tg.cd_kaisya
		AND tbbc001g.cd_hansya = tg.cd_hansya
		AND tbbc001g.no_syaryou = tg.no_syaryou
	LEFT JOIN ai21rep_ve_dx.tbv0232m tbv0232m	-- ａｉ２１車名コードＤＢ
        ON
		tbv0232m.cd_hansya = tbbc001g.cd_hansya
		AND tbv0232m.cd_kaisya = tbbc001g.cd_kaisya
		-- 車名コード = ａｉ２１車名コードメーカー & ａｉ２１車名コード車種  &  ａｉ２１車名コード市場  &  ａｉ２１車名コード連番  &  ａｉ２１車名コード任意
		AND tbv0232m.cd_syamei = CONCAT(NVL(tbbc001g.mj_21syamek, ''), 
                                        NVL(tbbc001g.mj_21syasyu, ''), 
                                        NVL(tbbc001g.mj_21syamak, ''), 
                                        NVL(tbbc001g.no_21syaren, ''), 
                                        NVL(tbbc001g.mj_21syanin, ''))
	WHERE
		--受注計上日が空ではない
		tg.dd_jucyuke IS NOT NULL
		--受注計上日が前月1日より大きい
		AND date_format(tg.dd_jucyuke, 'yyyyMM') >= date_format(add_months(CAST(current_timestamp() AS DATE), -1), 'yyyyMM')
UNION ALL
	SELECT
		--販社コード
		tg.cd_hansya,
		--会社コード
		tg.cd_kaisya,
		--受注店舗コード
		tg.cd_jytyuten,
		--車名コード
		CONCAT(NVL(tbbc001g.mj_21syamek, ''), 
               NVL(tbbc001g.mj_21syasyu, ''), 
               NVL(tbbc001g.mj_21syamak, ''), 
               NVL(tbbc001g.no_21syaren, ''), 
               NVL(tbbc001g.mj_21syanin, '')) AS cd_ncsyamei,
        --車名
		UPPER(NVL(tbv0232m.mj_syamei, '')) AS kn_syame,
		--日付
		tg.dd_torikesi AS dd_date,
		--中古車受注実績
		0 AS su_jusya_jucyu,
		--中古車受注取消
		CASE
			WHEN tg.dd_torikesi IS NOT NULL THEN 1
			ELSE NULL
		END AS su_jusya_jucyu_torikesi,
		--中古車受注残
		0 AS su_jusya_jucyucan
	FROM
		ai21rep_ve_dx.tbbc017g tg	--中古車受注基本情報ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbc001g tbbc001g	--中古車在庫基本情報ＤＢ
        ON
		tbbc001g.cd_kaisya = tg.cd_kaisya
		AND tbbc001g.cd_hansya = tg.cd_hansya
		AND tbbc001g.no_syaryou = tg.no_syaryou
	LEFT JOIN ai21rep_ve_dx.tbv0232m tbv0232m	--ａｉ２１車名コードＤＢ
        ON
		tbv0232m.cd_hansya = tbbc001g.cd_hansya
		AND tbv0232m.cd_kaisya = tbbc001g.cd_kaisya
		--車名コード = ａｉ２１車名コードメーカー & ａｉ２１車名コード車種  &  ａｉ２１車名コード市場  &  ａｉ２１車名コード連番  &  ａｉ２１車名コード任意
		AND tbv0232m.cd_syamei = CONCAT(NVL(tbbc001g.mj_21syamek, ''), 
                                        NVL(tbbc001g.mj_21syasyu, ''), 
                                        NVL(tbbc001g.mj_21syamak, ''), 
                                        NVL(tbbc001g.no_21syaren, ''), 
                                        NVL(tbbc001g.mj_21syanin, ''))
	WHERE
		--受注計上日が空ではない
		tg.dd_jucyuke IS NOT NULL
		--取消日が前月1日より大きい
		AND date_format(tg.dd_torikesi, 'yyyyMM') >= date_format(add_months(CAST(current_timestamp() AS DATE), -1), 'yyyyMM')
) combined
GROUP BY
	cd_hansya,
	cd_kaisya,
	cd_jytyuten,
	to_date(dd_date),
	cd_ncsyamei,
	kn_syame
;

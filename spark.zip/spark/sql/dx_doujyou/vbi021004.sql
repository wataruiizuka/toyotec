-- Source file: 021_Bz4x買換え報奨金照会/報奨金_view_ve_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

WITH
-- 受注下取ＤＢ+抹消済受注下取ＤＢ+保存用受注下取ＤＢ
a003g AS (
  SELECT *
  FROM (
    SELECT
      cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,NO_SYADAIBA,DD_SITATORI,KB_SINCYU,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, no_cyumon, no_cyumoned, NO_SYADAIBA ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,NO_SYADAIBA,DD_SITATORI,KB_SINCYU,1 AS sortn
      -- 受注下取ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBA003G TBBA003G where cd_hansya is null
      UNION ALL
      SELECT
        cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,NO_SYADAIBA,DD_SITATORI,KB_SINCYU,2 AS sortn
      -- 抹消済受注下取ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBA095G TBBA095G where cd_hansya is null
      UNION ALL
      SELECT
        cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,NO_SYADAIBA,DD_SITATORI,KB_SINCYU,3 AS sortn
      -- 保存用受注下取ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBA117G TBBA117G where cd_hansya is null
    ) jucyushitatr1
  ) jucyushitatr2
  WHERE rnk = 1
),
-- 新車受注顧客情報ＤＢ+抹消済+保存用
a051g AS (
  SELECT *
  FROM (
    SELECT
      cd_hansya,cd_kaisya,CD_KOKYAKU,KB_KOKYAKU,NO_CYUMON,NO_CYUMONED,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, no_cyumon, no_cyumoned,KB_KOKYAKU ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        cd_hansya,cd_kaisya,CD_KOKYAKU,KB_KOKYAKU,NO_CYUMON,NO_CYUMONED,1 AS sortn
      -- 新車受注顧客情報ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBA051G TBBA051G
      UNION ALL
      SELECT
        cd_hansya,cd_kaisya,CD_KOKYAKU,KB_KOKYAKU,NO_CYUMON,NO_CYUMONED,2 AS sortn
      -- 抹消済新車顧客情報ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBA087G TBBA087G
      UNION ALL
      SELECT
        cd_hansya,cd_kaisya,CD_KOKYAKU,KB_KOKYAKU,NO_CYUMON,NO_CYUMONED,3 AS sortn
      -- 保存用受注下取ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBA130G TBBA130G
    ) jucyushitatr1
  ) jucyushitatr2
  WHERE rnk = 1
),
-- 新車受注基本情報ＤＢ+抹消済+保存用
a001g AS (
  SELECT *
  FROM (
    SELECT
      NO_SYADAIBA,KJ_MEIGIME1,DD_JUCYU,DD_TOUROKU,MJ_HANTENKT,DD_TORIKESI,cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,MJ_SINKYSED,MJ_GAIHANSY,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, no_cyumon, no_cyumoned ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        NO_SYADAIBA,KJ_MEIGIME1,DD_JUCYU,DD_TOUROKU,MJ_HANTENKT,DD_TORIKESI,cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,MJ_SINKYSED,MJ_GAIHANSY,1 AS sortn
      -- 新車受注基本情報ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBA001G TBBA001G where (DD_TOUROKU >= '2025-8-27' and DD_TOUROKU < '2028-4-1' or DD_TOUROKU is null)
      UNION ALL
      SELECT
        NO_SYADAIBA,KJ_MEIGIME1,DD_JUCYU,DD_TOUROKU,MJ_HANTENKT,DD_TORIKESI,cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,MJ_SINKYSED,MJ_GAIHANSY,2 AS sortn
      -- 抹消済新車受注基本情報ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBA085G TBBA085G where (DD_TOUROKU >= '2025-8-27' and DD_TOUROKU < '2028-4-1' or DD_TOUROKU is null)
      UNION ALL
      SELECT
        NO_SYADAIBA,KJ_MEIGIME1,DD_JUCYU,DD_TOUROKU,MJ_HANTENKT,DD_TORIKESI,cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,MJ_SINKYSED,MJ_GAIHANSY,3 AS sortn
      -- 保存用新車受注基本情報ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBA108G TBBA108G where (DD_TOUROKU >= '2025-8-27' and DD_TOUROKU < '2028-4-1' or DD_TOUROKU is null)
    ) shinsha1
  ) shinsha2
  WHERE rnk = 1
),
-- 中古車在庫基本情報ＤＢ+抹消済+保存用
c001g AS (
  SELECT *
  FROM (
    SELECT
      MJ_SIRENORI,KB_SIRETOSY,CD_SIRETOGY,NO_SIRETOSE,DD_SIIRE,DT_SAISINUP,DD_KEIRIKEI,NO_SYADAIBA,MJ_KATASIKI,KJ_SITAMEIG,MJ_FURUSYAM,KB_SIIRE,DD_SIREJYTY,DD_SIRETORO,CD_SYOYUSYA,KJ_SAISSYYU,cd_hansya,cd_kaisya,DD_TORIKESI,cd_sitadote,NO_SIRETYUM,no_syaryou,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, NO_SYADAIBA ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        MJ_SIRENORI,KB_SIRETOSY,CD_SIRETOGY,NO_SIRETOSE,DD_SIIRE,DT_SAISINUP,DD_KEIRIKEI,NO_SYADAIBA,MJ_KATASIKI,KJ_SITAMEIG,MJ_FURUSYAM,KB_SIIRE,DD_SIREJYTY,DD_SIRETORO,CD_SYOYUSYA,KJ_SAISSYYU,cd_hansya,cd_kaisya,DD_TORIKESI,cd_sitadote,NO_SIRETYUM,no_syaryou,1 AS sortn
      -- 中古車在庫基本情報ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBC001G TBBC001G
      where (lOWER(MJ_KATASIKI) like '%xeam10%' or lOWER(MJ_KATASIKI) like '%yeam15%')
		AND DD_TORIKESI IS NULL
		and KB_SIIRE like '3%'
      UNION ALL
      SELECT
        MJ_SIRENORI,KB_SIRETOSY,CD_SIRETOGY,NO_SIRETOSE,DD_SIIRE,DT_SAISINUP,DD_KEIRIKEI,NO_SYADAIBA,MJ_KATASIKI,KJ_SITAMEIG,MJ_FURUSYAM,KB_SIIRE,DD_SIREJYTY,DD_SIRETORO,CD_SYOYUSYA,KJ_SAISSYYU,cd_hansya,cd_kaisya,DD_TORIKESI,cd_sitadote,NO_SIRETYUM,no_syaryou,2 AS sortn
      -- 抹消済中古車在庫基本情報ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBC050G TBBC050G
      where (lOWER(MJ_KATASIKI) like '%xeam10%' or lOWER(MJ_KATASIKI) like '%yeam15%')
		AND DD_TORIKESI IS NULL
		and KB_SIIRE like '3%'
      UNION ALL
      SELECT
        MJ_SIRENORI,KB_SIRETOSY,CD_SIRETOGY,NO_SIRETOSE,DD_SIIRE,DT_SAISINUP,DD_KEIRIKEI,NO_SYADAIBA,MJ_KATASIKI,KJ_SITAMEIG,MJ_FURUSYAM,KB_SIIRE,DD_SIREJYTY,DD_SIRETORO,CD_SYOYUSYA,KJ_SAISSYYU,cd_hansya,cd_kaisya,DD_TORIKESI,cd_sitadote,NO_SIRETYUM,no_syaryou,3 AS sortn
      -- 保存用中古車在庫基本情報ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBC065G TBBC065G
      where (lOWER(MJ_KATASIKI) like '%xeam10%' or lOWER(MJ_KATASIKI) like '%yeam15%')
		AND DD_TORIKESI IS NULL
		and KB_SIIRE like '3%'
    ) cyukokh1
  ) cyukokh2
  WHERE rnk = 1
),
-- 中古車在庫登録情報ＤＢ+抹消済+保存用
c006g AS (
  SELECT *
  FROM (
    SELECT
      DD_1JTOROKU,cd_hansya,cd_kaisya,NO_SYARYOU,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, NO_SYARYOU ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        DD_1JTOROKU,cd_hansya,cd_kaisya,NO_SYARYOU,1 AS sortn
      -- 中古車在庫登録情報ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBC006G TBBC006G
      UNION ALL
      SELECT
        DD_1JTOROKU,cd_hansya,cd_kaisya,NO_SYARYOU,2 AS sortn
      -- 抹消済中古車在庫登録情報ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBC052G TBBC052G
      UNION ALL
      SELECT
        max(DD_1JTOROKU) as DD_1JTOROKU,cd_hansya,cd_kaisya,NO_SYARYOU,3 AS sortn
      -- 保存用中古車在庫登録情報ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBC064G TBBC064G
      group by cd_hansya,cd_kaisya,NO_SYARYOU
    ) cyukotr1
  ) cyukotr2
  WHERE rnk = 1
)
INSERT OVERWRITE TABLE gold.vbi021004
select 
t.cd_hansya,
t200m.kj_kaisyatn ,
t200m.cd_hanbaitn,
t.cd_kaisya , 
t201m.kj_tenpomei,
t.NO_SYADAIBA,
t.MJ_KATASIKI,
t.KJ_SITAMEIG,
t.MJ_FURUSYAM,
t.KB_SIIRE,
t.DD_KEIRIKEI,
t.DD_SIRETORO,
t.DD_SIREJYTY,
t.CD_SYOYUSYA,
t.KJ_SAISSYYU,
NULLIF(
  LEAST(
    -- 仕入日
    COALESCE(t.DD_SIIRE, DATE '9999-12-31'),
    -- 経理計上日
    COALESCE(t.DD_KEIRIKEI, DATE '9999-12-31'),
    -- 仕入受注日
    COALESCE(t.DD_SIREJYTY, DATE '9999-12-31'),
    -- 仕入登録日
    COALESCE(t.DD_SIRETORO, DATE '9999-12-31'),
    -- 最新更新日時
    COALESCE(t.DT_SAISINUP, DATE '9999-12-31')
  ),
  DATE '9999-12-31'
) AS min_non_null_date_zaiko,
-- 新車受注基本情報ＤＢ
a001g.NO_SYADAIBA as NO_SYADAIBA_shinsya,
a001g.KJ_MEIGIME1 as kj_meigime1_shinsya,
a001g.DD_JUCYU as dd_jucyu_shinsya,
a001g.DD_TOUROKU as dd_touroku_shinsya,
a001g.MJ_HANTENKT as mj_katasiki_shinsya,
a001g.NO_CYUMON as no_cyumon_shinsya,
f001m.KJ_KURUMAME as kj_kurumame_shinsya,
-- 仕入予定基本情報ＤＢ
c003g.KB_SIREHANB,
-- 中古車在庫登録情報ＤＢ
c006g.DD_1JTOROKU
-- 中古車在庫基本情報ＤＢ+抹消済+保存用
from c001g t
-- 車両管理ＤＢ 
inner join ai21rep_ve_dx.TBTEC05G c05g
on c05g.cd_hansya = t.cd_hansya
and c05g.cd_kaisya = t.cd_kaisya
and RTRIM(c05g.NO_SYADAI) = rtrim(t.NO_SYADAIBA)
and c05g.CD_NORIKUSI = t.MJ_SIRENORI
and c05g.KB_NOSYASYU = t.KB_SIRETOSY
and c05g.CD_NOGYOTAI = t.CD_SIRETOGY
and c05g.NO_NOSEIRI = t.NO_SIRETOSE
left join ai21rep_ve_dx.tbv0200m t200m
on t200m.cd_hansya = t.cd_hansya
and t200m.cd_kaisya = t.cd_kaisya
left join ai21rep_ve_dx.tbv0201m t201m
on t201m.cd_hansya = t.cd_hansya
and t201m.cd_kaisya = t.cd_kaisya
and t201m.cd_tenpo = t.CD_SITADOTE
-- 新車受注顧客情報ＤＢ+抹消済+保存用
inner join a051g
on a051g.cd_hansya = t.cd_hansya
and a051g.cd_kaisya = t.cd_kaisya
and a051g.CD_KOKYAKU = c05g.CD_OKYAKU
and a051g.KB_KOKYAKU = '2'
-- 新車受注基本情報ＤＢ+抹消済+保存用
inner join a001g
on a001g.cd_hansya = t.cd_hansya
and a001g.cd_kaisya = t.cd_kaisya
-- and RTRIM(a001g.KJ_MEIGIME1) =RTRIM(t.KJ_SITAMEIG)
and a001g.NO_CYUMON = a051g.NO_CYUMON
and a001g.NO_CYUMONED = a051g.NO_CYUMONED
and a001g.DD_TORIKESI IS NULL
-- 車両スペック２ＤＢ
inner join ai21rep_ve_dx.TBBF008M f008m
on f008m.cd_hansya = a001g.cd_hansya
and f008m.cd_kaisya = a001g.cd_kaisya
and f008m.MJ_SINKYSED = a001g.MJ_SINKYSED
and f008m.CD_SPEC = a001g.MJ_GAIHANSY
and f008m.MJ_HANTENKT = a001g.MJ_HANTENKT
AND f008m.kb_spec = 'G'
-- 車名ＤＢ
inner join ai21rep_ve_dx.Tbbf001m f001m
on f001m.cd_hansya = f008m.cd_hansya
and f001m.cd_kaisya = f008m.cd_kaisya
and f001m.cd_ncsyamei = f008m.mj_syamei
-- 仕入予定基本情報ＤＢ
left join ai21rep_ve_dx.TBBC003G c003g
on c003g.cd_hansya = a001g.cd_hansya
and c003g.cd_kaisya = a001g.cd_kaisya
and c003g.NO_SIRETYUM = CONCAT(a001g.NO_CYUMON, a001g.NO_CYUMONED)
-- 受注下取ＤＢ+抹消済+保存用
left join a003g
on a003g.cd_hansya = t.cd_hansya
and a003g.cd_kaisya = t.cd_kaisya
and a003g.NO_CYUMON = a001g.NO_CYUMON
and a003g.NO_CYUMONED = a001g.NO_CYUMONED
AND RTRIM(a003g.NO_SYADAIBA) = RTRIM(a001g.NO_SYADAIBA)
AND a003g.DD_SITATORI IS NULL
AND a003g.KB_SINCYU ='1'
-- 中古車在庫登録情報ＤＢ+抹消済+保存用
LEFT JOIN c006g
ON c006g.cd_hansya = t.cd_hansya
AND c006g.cd_kaisya = t.cd_kaisya
and c006g.NO_SYARYOU = t.NO_SYARYOU
where (lOWER(t.MJ_KATASIKI) like '%xeam10%' or lOWER(t.MJ_KATASIKI) like '%yeam15%')
AND t.DD_TORIKESI IS NULL
and t.KB_SIIRE like '3%'
and a003g.cd_hansya is null
and (c003g.KB_SIREHANB not in ('1', '2', '4') or c003g.KB_SIREHANB is null)
and ( ((f001m.KJ_KURUMAME like '%bZ4X%' or  f001m.KJ_KURUMAME LIKE '%ｂＺ４Ｘ%') and (a001g.MJ_HANTENKT like '%XEAM11%' or a001g.MJ_HANTENKT like '%XEAM15%'))
 or f001m.KJ_KURUMAME like '%bZ4Xツーリング%'
 OR f001m.KJ_KURUMAME LIKE '%ｂＺ４Ｘツーリング%'
 or f001m.KJ_KURUMAME like '%プリウス%'
 or f001m.KJ_KURUMAME like '%RAV4%'
 OR f001m.KJ_KURUMAME LIKE '%ＲＡＶ４%'
 or f001m.KJ_KURUMAME like '%ハリアー%'
 or f001m.KJ_KURUMAME like '%アルファード%'
 or f001m.KJ_KURUMAME like '%ヴェルファイア%'
 or f001m.KJ_KURUMAME like '%クラウンスポーツ%'
 or f001m.KJ_KURUMAME like '%クラウンエステート%'
)
;

-- Source file: 016_新車受注分析/vbi016001-vbi016011.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.VBI016003
SELECT
	main.cd_hansya AS `販社コード`, --販社コード
	main.cd_kaisya AS `会社コード`, --会社コード
	main.kj_tentanms AS `店舗短縮名称`, --店舗短縮名称
	main.kj_kurumame AS `新車車名` , --新車車名
	main.cd_tenpo AS `店舗コード`, --店舗コード
	CONCAT(kj_kurumame, date_format(dd_jucyuke, 'yyyyMMdd')) AS `車名受注日`, --車名受注日
	RANK() OVER (PARTITION BY cd_hansya, cd_kaisya ORDER BY mj_sortjyun , cd_tenpo) AS `ソート順`, --ソート順
	daisu AS `台数`
FROM
	(
	SELECT
		main1.cd_hansya, --販社コード
		main1.cd_kaisya, --会社コード
		main1.cd_tenpo, --店舗コード
		main1.kj_tentanms, --店舗短縮名称
		main1.dd_jucyuke, --受注計上日
		main1.kj_kurumame, --新車車名
		sort_sub.mj_sortjyun, --ソート順
		SUM(daisu) AS daisu --台数
	FROM
		(
		SELECT
			t201m.cd_hansya, --販社コード
			t201m.cd_kaisya, --会社コード
			t201m.cd_tenpo, --店舗コード
			t201m.kj_tenpomei, --店舗名称
			t201m.kj_tentanms, --店舗短縮名称
			CAST(tbba001g.dd_jucyuke AS DATE) AS dd_jucyuke, --受注計上日
			TBBF001M.kj_kurumame AS kj_kurumame, --新車車名
			COUNT(tbba001g.cd_hansya) AS daisu --台数
		FROM
			 ai21rep_ve_dx.tbv0201m t201m  --共通店舗ＤＢ
		LEFT SEMI JOIN dx_ve.tbi999003m tbi999003m  --店舗展示設定
			ON
			t201m.cd_hansya = tbi999003m.cd_hansya
			AND t201m.cd_kaisya = tbi999003m.cd_kaisya
			AND t201m.cd_tenpo = tbi999003m.cd_tenpo
			AND tbi999003m.mj_cyohyoid = '016'
			AND tbi999003m.kb_tenji = 1
		LEFT JOIN ai21rep_ve_dx.tbba001g tbba001g			--新車受注基本情報ＤＢ
		ON
			t201m.cd_hansya = tbba001g.cd_hansya
			AND t201m.cd_kaisya = tbba001g.cd_kaisya
			AND t201m.cd_tenpo = tbba001g.cd_tenpo
		LEFT JOIN ai21rep_ve_dx.tbbf008m TBBF008M			--車両スペック２ＤＢ
		    ON
			tbba001g.cd_kaisya = TBBF008M.cd_kaisya
			AND tbba001g.cd_hansya = TBBF008M.cd_hansya
			AND tbba001g.mj_sinkysed = TBBF008M.mj_sinkysed
			AND tbba001g.mj_gaihansy = TBBF008M.cd_spec
			AND tbba001g.mj_hantenkt = TBBF008M.mj_hantenkt
			AND TBBF008M.kb_spec = 'G'
		LEFT JOIN ai21rep_ve_dx.tbbf001m TBBF001M			--車名ＤＢ 
	    	ON
			TBBF001M.cd_kaisya = TBBF008M.cd_kaisya
			AND TBBF001M.cd_hansya = TBBF008M.cd_hansya
			AND TBBF001M.cd_ncsyamei = TBBF008M.mj_syamei
		LEFT SEMI JOIN dx_ve.tbi999008m tbi999008m			--車種展示設定
			ON
			TBBF001M.cd_hansya = tbi999008m.cd_hansya
			AND TBBF001M.cd_kaisya = tbi999008m.cd_kaisya
			AND TBBF001M.cd_ncsyamei = tbi999008m.cd_ncsyamei
			AND tbi999008m.kb_tenji = 1
		WHERE
			--売上取消計上日と取消日=NULL
			tbba001g.dd_uritrkkj IS NULL
			AND tbba001g.dd_torikesi IS NULL
			AND tbba001g.dd_jucyuke IS NOT NULL
		GROUP BY
			t201m.cd_hansya,
			t201m.cd_kaisya,
			t201m.cd_tenpo,
			kj_tenpomei,
			kj_tentanms,
			CAST(tbba001g.dd_jucyuke AS DATE),
			kj_kurumame
		HAVING NOT (NVL(t201m.kj_tenpomei, '') LIKE '%廃）%'
				AND COUNT(tbba001g.cd_hansya)= 0)
	) main1
	LEFT JOIN (
		SELECT
			kj_tentanms, --店舗短縮名称
			t201m_2.cd_hansya, --販社コード
			t201m_2.cd_kaisya, --会社コード
			MIN(tbi999003m.mj_sortjyun) AS mj_sortjyun --ソート順
		FROM
			ai21rep_ve_dx.tbv0201m t201m_2
		INNER JOIN dx_ve.tbi999003m tbi999003m --店舗展示設定
			ON
			t201m_2.cd_hansya = tbi999003m.cd_hansya
			AND t201m_2.cd_kaisya = tbi999003m.cd_kaisya
			AND t201m_2.cd_tenpo = tbi999003m.cd_tenpo
			AND tbi999003m.mj_cyohyoid = '016'
			AND tbi999003m.kb_tenji = 1
		GROUP BY 
			t201m_2.cd_hansya,
			t201m_2.cd_kaisya,
			kj_tentanms		
	) sort_sub
	ON
		main1.cd_hansya = sort_sub.cd_hansya
		AND main1.cd_kaisya = sort_sub.cd_kaisya
		AND main1.kj_tentanms = sort_sub.kj_tentanms
	GROUP BY
		main1.cd_hansya,
		main1.cd_kaisya,
		main1.cd_tenpo,
		main1.kj_tentanms,
		main1.dd_jucyuke,
		sort_sub.mj_sortjyun,
		main1.kj_kurumame
 ) main
;

-- Source file: 011_メンテナンスパック契約客ステータス一覧/メンテナンスパック契約客ステータス一覧.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi011001
SELECT 
    --販社コード
    t0021m.cd_hansya,  
    --会社コード
    t0021m.cd_kaisya, 
    --契約区分
    t0021m.kb_keiyaku, 
    --枝番
    t0021m.no_edaban,   
    --想定税率 
    t0021m.nu_sotezert, 
    --連番
    t0021m.no_renban, 
    --利用整備名称
    t0021m.kj_riyoseim,
    --加入商品名
    t0020m.kj_kanyusyu,
    --税込金額 = 合計金額 + 消費税
    t0021m.ki_goukei + t0021m.ki_syohizei AS `totalcount`
FROM 
    --Ｍパック料金ＤＢ
    ai21rep_ve_dx.tbv0021m t0021m   
LEFT JOIN
    --Ｍパック商品ＤＢ
    ai21rep_ve_dx.tbv0020m t0020m   
ON 
    t0021m.cd_hansya = t0020m.cd_hansya
    AND t0021m.cd_kaisya = t0020m.cd_kaisya
    AND t0021m.kb_keiyaku = t0020m.kb_keiyaku
    AND t0021m.no_edaban = t0020m.no_edaban
    AND t0021m.nu_sotezert = t0020m.nu_sotezert
;

-- Source file: 013_中古車売掛金/VBI013006_中古車売掛金明細_アラート判断.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

WITH kb_genkin_table AS(
    SELECT
        tbi999013m.cd_hansya, --販社コード
        tbi999013m.cd_kaisya, --会社コード
        CASE WHEN count(tbi999013m.kb_nyuukin) = 0 THEN NULL ELSE concat_ws(',', collect_list(tbi999013m.kb_nyuukin)) END AS kb_nyuukin_list --入金区分list
    FROM dx_ve.tbi999013m tbi999013m --販売店入金区分設定
    WHERE tbi999013m.kb_genkin = '1'
    GROUP BY tbi999013m.cd_hansya
            ,tbi999013m.cd_kaisya
),
kb_crejcard_table AS(
    SELECT
        tbi999013m.cd_hansya, --販社コード
        tbi999013m.cd_kaisya, --会社コード
        CASE WHEN count(tbi999013m.kb_nyuukin) = 0 THEN NULL ELSE concat_ws(',', collect_list(tbi999013m.kb_nyuukin)) END AS kb_nyuukin_list --入金区分list
    FROM dx_ve.tbi999013m tbi999013m --販売店入金区分設定
    WHERE tbi999013m.kb_crejcard = '1'
    GROUP BY tbi999013m.cd_hansya
            ,tbi999013m.cd_kaisya
),
nt8014m AS(
    SELECT
        t014m.cd_hansya, --販社コード
        t014m.cd_kaisya, --会社コード
        t014m.no_cyumon, --注文ＮＯ
        MAX(IF(t014m.kb_nyukkanr = '01',t014m.dd_keijyou,NULL)) AS dd_keijyou1, --計上日1
        MAX(IF(t014m.kb_nyukkanr = '02',t014m.dd_keijyou,NULL)) AS dd_keijyou2 --計上日2
    FROM ai21rep_ve_dx.tbg8014m t014m --TBG8014M_売掛金履歴ＤＢ
    GROUP BY t014m.cd_hansya, t014m.cd_kaisya, t014m.no_cyumon
),
base_data AS (
  SELECT
    CAST(current_timestamp() AS DATE) AS jp_today, --現在の時刻
    DATE_TRUNC('MONTH', current_timestamp()) AS current_month_start, --月初
    LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AS last_month_end, --先月末
    tbbc017g.cd_hansya || tbbc017g.cd_kaisya || tbbc017g.no_cyumon || trim(tbbc017g.no_cyumoned) AS cd_pk, --pk
    IF(LEFT(tbbc017g.no_cyumon, 3) = 'TAD' AND LENGTH(tbbc017g_2.no_min_denpyo) > 0,tbbc017g.cd_hansya || tbbc017g.cd_kaisya || LEFT(tbbc017g_2.no_min_denpyo, 3),tbbc017g.cd_hansya || tbbc017g.cd_kaisya || tbbc017g.cd_jytyuten) AS cd_hankaisya_tenpo, --PK_販社会社店舗コード
    tbbc017g.cd_hansya, --販社コード
    tbbc017g.cd_kaisya, --会社コード
    IF(LEFT(tbbc017g.no_cyumon, 3) = 'TAD' AND LENGTH(tbbc017g_2.no_min_denpyo) > 0,LEFT(tbbc017g_2.no_min_denpyo, 3),tbbc017g.cd_jytyuten) AS cd_jytyuten, --店舗コード
    tbbc017g.no_cyumon, --注文ＮＯ
    tbbc017g.no_cyumoned, --注文ＮＯ枝番
    tbbc017g.dd_touroku, --登録日
    tbbc017g.dd_nosya, --納車日
    tbbc017g.dd_urikzumi, --売掛金完済日
    tbbc017g.dd_jucyu, --受注日
    tbbc017g.dd_torikesi, --取消日
    tbbc017g.dd_torotrkk, --登録取消計上日
    tbbc020g.dd_minasksy, --見直し回収予定日
    tbbc020g.dd_kaisyuyo, --回収予定日
    tbbc020g.ki_haseirui, --発生累計
    tbbc020g.ki_genknykg, --現金入金額
    tbbc020g.ki_sitanykg, --下取車入金額
    tbbc020g.ki_fuharnyk, --賦払金入金額
    tbbc020g.ki_genkhasg, --現金発生額
    tbbc020g.ki_fuharhsk, --賦払金発生額
    CASE tbbc020g.mj_keiykeit
        WHEN '1' THEN '現金'
        WHEN '2' THEN '後払い'
        WHEN '3' THEN '自社割賦'
        WHEN '4' THEN '信用購入斡旋'
        WHEN '5' THEN '債権譲渡'
        WHEN '' THEN 'その他'
    END AS mj_keiykeit, --契約形態
    TO_TIMESTAMP(CAST(nt8014m1.dd_keijyou1 AS STRING), 'yyyyMMdd') AS dd_keijyou1, --最終入金日（現金）
    TO_TIMESTAMP(CAST(nt8014m1.dd_keijyou2 AS STRING), 'yyyyMMdd') AS dd_keijyou2, --最終入金日（割賦）
    COALESCE(tbi002001m.su_minosya, 14) AS su_minosya, --未納車経過日
    COALESCE(tbi002001m.su_touroku, 30) AS su_touroku, --登録経過日
    COALESCE(tbi002001m.su_jucyu, 30) AS su_jucyu --受注経過日
  FROM 
    ai21rep_ve_dx.tbbc017g tbbc017g --TBBC017G_中古車受注基本情報DB
  LEFT JOIN ai21rep_ve_dx.tbbc020g tbbc020g --TBBC020G_中古車受注販売条件情報DB
    ON tbbc017g.cd_hansya = tbbc020g.cd_hansya
   AND tbbc017g.cd_kaisya = tbbc020g.cd_kaisya
   AND tbbc017g.no_cyumon = tbbc020g.no_cyumon
   AND TRIM(tbbc017g.no_cyumoned) = TRIM(tbbc020g.no_cyumoned)
LEFT JOIN (
    SELECT
         tbbc017g.cd_hansya --販社コード
        ,tbbc017g.cd_kaisya--会社コード
        ,tbbc017g.no_cyumon --注文ＮＯ
        ,tbbc017g.no_cyumoned --注文ＮＯ枝番
        ,MIN(tbg8014m.no_denpyo) AS no_min_denpyo --伝票番号
    FROM ai21rep_ve_dx.tbg8014m tbg8014m --TBG8014M_売掛金履歴ＤＢ
    RIGHT JOIN ai21rep_ve_dx.tbbc017g tbbc017g --TBBC017G_中古車受注基本情報DB
    ON tbg8014m.cd_hansya = tbbc017g.cd_hansya
   AND tbg8014m.cd_kaisya = tbbc017g.cd_kaisya
   AND TRIM(tbg8014m.no_cyumon) = (TRIM(tbbc017g.no_cyumon) || TRIM(tbbc017g.no_cyumoned))
   AND tbg8014m.kb_urinyuki = '2' --売上入金区分が2
   AND tbg8014m.kb_nyukkanr = '01' --入金管理区分 が01
    GROUP BY
         tbbc017g.cd_hansya
        ,tbbc017g.cd_kaisya
        ,tbbc017g.no_cyumon
        ,tbbc017g.no_cyumoned
) tbbc017g_2
ON tbbc017g_2.cd_hansya = tbbc017g.cd_hansya
AND tbbc017g_2.cd_kaisya = tbbc017g.cd_kaisya
AND tbbc017g_2.no_cyumon = tbbc017g.no_cyumon
AND tbbc017g_2.no_cyumoned = tbbc017g.no_cyumoned
    LEFT JOIN dx_ve.tbi013001m tbi002001m --店舗アラート項目設定
    ON tbbc017g.cd_hansya = tbi002001m.cd_hansya
   AND tbbc017g.cd_kaisya = tbi002001m.cd_kaisya
LEFT JOIN nt8014m nt8014m1 --TBG8014M_売掛金履歴ＤＢ
    ON nt8014m1.cd_hansya = tbbc017g.cd_hansya
   AND nt8014m1.cd_kaisya = tbbc017g.cd_kaisya
   AND nt8014m1.no_cyumon = TRIM(CONCAT(tbbc017g.no_cyumon, tbbc017g.no_cyumoned))
  WHERE (NOT coalesce((NVL(tbbc020g.ki_haseirui ,0) - NVL(tbbc020g.ki_genknykg ,0) - NVL(tbbc020g.ki_sitanykg ,0) - NVL(tbbc020g.ki_fuharnyk ,0)) = 0 --値があると残高がある
    AND((tbbc017g.dd_touroku IS NOT NULL --登録日がNULLではない
      AND tbbc017g.dd_nosya < DATE '2023-03-01' --納車日が2023-03-01以前
      AND (tbbc017g.dd_urikzumi IS NULL OR tbbc017g.dd_urikzumi < DATE '2024-03-01')) --売掛金完済日がNULLであるまたは売掛金完済日が2024-03-01以前
    OR (tbbc017g.dd_nosya IS NULL AND tbbc017g.dd_touroku < DATE '2023-03-01') --納車日がNULLであるそして登録日が2023-03-01以前
      OR tbbc017g.dd_urikzumi < DATE '2024-03-01' --納車日が2024-03-01以前
      OR (tbbc017g.dd_touroku IS NULL AND tbbc017g.dd_jucyu < DATE '2020-12-01')), false)) --ゴミデータ除外
    AND (tbbc017g.dd_torotrkk IS NULL OR (tbbc017g.dd_torotrkk IS NOT NULL AND (NVL(tbbc020g.ki_haseirui ,0) - NVL(tbbc020g.ki_genknykg ,0) - NVL(tbbc020g.ki_sitanykg ,0) - NVL(tbbc020g.ki_fuharnyk ,0)) <> 0)) --登録取消計上日がNULLである or 値があると残高がある
    AND (
        LEFT(tbbc017g.kb_uriage, 1) = '1' --払出区分のために1
        OR (
        LEFT(tbbc017g.kb_uriage, 1) = '3' --払出区分のために3
        AND
        NOT((NVL(tbbc020g.ki_haseirui ,0) - NVL(tbbc020g.ki_genknykg ,0) - NVL(tbbc020g.ki_sitanykg ,0) - NVL(tbbc020g.ki_fuharnyk ,0)) = 0 --値があると残高がある
        AND (NVL(tbbc020g.ki_genkhasg ,0) - NVL(tbbc020g.ki_genknykg ,0)) = 0 --現金発生額から現金入金額を引いた値が0である
        AND (NVL(tbbc020g.ki_fuharhsk ,0) - NVL(tbbc020g.ki_fuharnyk ,0)) = 0 --賦払金発生額から下取車入金額を引いた値が0である
        AND (NVL(tbbc020g.ki_sitahasg ,0) - NVL(tbbc020g.ki_sitanykg ,0)) = 0))) --下取車発生額から下取車入金額を引いた値が0である
)--ゴミデータ除外
INSERT OVERWRITE TABLE gold.VBI013006
SELECT
  cd_pk AS `PK_販社会社注文NO枝番`, --PK_販社会社注文NO枝番
  cd_hankaisya_tenpo AS `PK_販社会社店舗コード`, --PK_販社会社店舗コード
  cd_hansya AS `販社コード`, --販社コード
  cd_kaisya AS `会社コード`, --会社コード
  IF(CONCAT_WS('',flg_1, flg_2, flg_3, flg_4, flg_5, flg_6, flg_a, flg_b, flg_c, flg_d, flg_e, flg_f) = '','99',CONCAT_WS('',flg_1, flg_2, flg_3, flg_4, flg_5, flg_6, flg_a, flg_b, flg_c, flg_d, flg_e, flg_f)) AS `アラート判断` --アラート判断
  ,no_cyumon AS `注文no` --注文no
  ,cd_jytyuten AS `店舗コード` --店舗コード
  ,dd_nosya AS `納車日` --納車日
  ,dd_touroku AS `登録日` --登録日
  ,dd_jucyu AS `受注日` --受注日
  ,flg_1
  ,flg_2
  ,flg_3
  ,flg_4
  ,flg_5
  ,flg_6
  ,flg_a
  ,flg_b
  ,flg_c
  ,flg_d
  ,flg_e
  ,flg_f
  ,flg
  ,dd_minasksy AS `見直し回収予定日` --見直し回収予定日
  ,dd_kaisyuyo AS `回収予定日` --回収予定日
  ,su_minosya AS `未納車経過日` --未納車経過日
  ,su_touroku AS `登録経過日` --登録経過日
  ,su_jucyu AS `受注経過日` --受注経過日
  FROM(
  SELECT
    cd_pk, --PK_販社会社注文NO枝番
    cd_hankaisya_tenpo, --PK_販社会社店舗コード
    cd_hansya, --販社コード
    cd_kaisya, --会社コード
    no_cyumon, --注文no
    cd_jytyuten, --店舗コード
    dd_nosya, --納車日
    dd_touroku, --登録日
    dd_jucyu, --受注日
    dd_minasksy, --見直し回収予定日
    dd_kaisyuyo, --回収予定日
    su_minosya, --未納車経過日
    su_touroku, --登録経過日
    su_jucyu, --受注経過日
    IF(COALESCE(dd_minasksy ,dd_kaisyuyo) IS NOT NULL AND COALESCE(dd_minasksy ,dd_kaisyuyo) < jp_today AND ((NVL(ki_genkhasg ,0) - NVL(ki_genknykg ,0) ) <> 0 OR (NVL(ki_fuharhsk ,0) - NVL(ki_fuharnyk ,0)) <> 0),'1','') AS flg_1,
    IF(dd_touroku IS NOT NULL AND (NVL(ki_haseirui ,0) - NVL(ki_genknykg ,0) - NVL(ki_sitanykg ,0) - NVL(ki_fuharnyk ,0)) < 0,'2','') AS flg_2,
    IF(dd_touroku IS NOT NULL AND dd_nosya IS NULL,'3','') AS flg_3,
    IF(dd_nosya IS NOT NULL AND ((NVL(ki_genkhasg ,0) - NVL(ki_genknykg ,0) ) <> 0 OR (NVL(ki_fuharhsk ,0) - NVL(ki_fuharnyk ,0)) <> 0) AND mj_keiykeit <> '後払い','4','') AS flg_4,
    IF(dd_nosya IS NOT NULL AND mj_keiykeit <> '後払い' AND (dd_keijyou1 > dd_nosya || dd_keijyou2 > dd_nosya),'5','') AS flg_5,
    IF(NVL(tbg8014m_2.ki_nyukinur2 - tbg8014m_2.ki_nyukinur3, 0) + NVL(tbg8014m_2.positive_count - tbg8014m_2.negative_count, 0) >= 3,'6','') AS flg_6,
    IF((dd_touroku < current_month_start AND dd_touroku IS NOT NULL) AND (dd_urikzumi > last_month_end OR dd_urikzumi IS NULL),'a','') AS flg_a,
    IF((dd_touroku < current_month_start AND dd_touroku IS NOT NULL) AND (dd_urikzumi > last_month_end OR dd_urikzumi IS NULL) AND DATEDIFF(last_month_end, dd_touroku) >= su_minosya AND (dd_nosya IS NULL OR TRUNC(dd_nosya, 'month') >= TRUNC(last_month_end, 'month')),'b','') AS flg_b,
    IF((dd_touroku < current_month_start AND dd_touroku IS NOT NULL) AND (dd_urikzumi > last_month_end OR dd_urikzumi IS NULL) AND DATEDIFF(last_month_end, dd_touroku) >= su_touroku,'c','') AS flg_c,
    IF(dd_jucyu IS NOT NULL AND dd_touroku IS NULL AND DATEDIFF(last_month_end, dd_jucyu) >= su_jucyu,'d','') AS flg_d,
    '' AS flg_e,
    '' AS flg_f,
   CASE
       WHEN dd_nosya IS NOT NULL AND mj_keiykeit <> '後払い' AND (dd_keijyou1 > dd_nosya || dd_keijyou2 > dd_nosya)
       THEN
           CASE
               WHEN dd_keijyou1 > dd_nosya AND dd_keijyou2 > dd_nosya
               THEN '1'
               WHEN dd_keijyou1 > dd_nosya
               THEN '2'
               ELSE '3'
           END
       ELSE ''
   END AS flg
  FROM base_data
  LEFT JOIN (
      SELECT
        tbg8014m.cd_hansya AS cd_hansya_1, --販社コード
        tbg8014m.cd_kaisya AS cd_kaisya_1, --会社コード
        TRIM(tbg8014m.no_cyumon) AS no_cyumon_1, --注文ＮＯ
        SUM(IF(tbg8014m.kb_nyukkanr = '01',1,0)) AS cash_receipt, --現金入金回数を取得
        SUM(IF(FIND_IN_SET(LEFT(tbg8014m.kb_nyuukin, 2),kb_genkin_table.kb_nyuukin_list) > 0 AND tbg8014m.kb_urinyuki = '2' AND tbg8014m.ki_nyukinur >= 1,1,0)) AS positive_count, --カード入金金額が1円以上の回数を取得
        SUM(IF(FIND_IN_SET(LEFT(tbg8014m.kb_nyuukin, 2),kb_genkin_table.kb_nyuukin_list) > 0 AND tbg8014m.kb_urinyuki = '2' AND tbg8014m.ki_nyukinur <= -1,1,0)) AS negative_count, --カード入金金額がｰ1円以下の回数を取得
        SUM(IF(FIND_IN_SET(LEFT(tbg8014m.kb_nyuukin, 2),kb_crejcard_table.kb_nyuukin_list) > 0 AND tbg8014m.kb_urinyuki = '2' AND tbg8014m.ki_nyukinur >= 1,1,0)) AS ki_nyukinur2, --カード入金の回数（カード入金金額が1円以上の回数）
        SUM(IF(FIND_IN_SET(LEFT(tbg8014m.kb_nyuukin, 2),kb_crejcard_table.kb_nyuukin_list) > 0 AND tbg8014m.kb_urinyuki = '2' AND tbg8014m.ki_nyukinur <= -1,1,0)) AS ki_nyukinur3 --カード入金の回数（カード入金金額がｰ1円以下の回数）
      FROM
        ai21rep_ve_dx.tbg8014m tbg8014m --売掛金履歴ＤＢ
      RIGHT JOIN ai21rep_ve_dx.tbbc020g tbbc020g --TBBC020G_中古車受注販売条件情報DB
        ON tbg8014m.cd_hansya = tbbc020g.cd_hansya
       AND tbg8014m.cd_kaisya = tbbc020g.cd_kaisya
       AND TRIM(tbg8014m.no_cyumon) = (TRIM(tbbc020g.no_cyumon) || TRIM(tbbc020g.no_cyumoned))
       LEFT JOIN kb_genkin_table
        ON kb_genkin_table.cd_hansya = tbg8014m.cd_hansya
       AND kb_genkin_table.cd_kaisya = tbg8014m.cd_kaisya
       LEFT JOIN kb_crejcard_table
        ON kb_crejcard_table.cd_hansya = tbg8014m.cd_hansya
       AND kb_crejcard_table.cd_kaisya = tbg8014m.cd_kaisya
      GROUP BY
        tbg8014m.cd_hansya,
        tbg8014m.cd_kaisya,
        TRIM(tbg8014m.no_cyumon)
  )tbg8014m_2
    ON base_data.cd_hansya = tbg8014m_2.cd_hansya_1
   AND base_data.cd_kaisya = tbg8014m_2.cd_kaisya_1
   AND (TRIM(base_data.no_cyumon) ||  TRIM(base_data.no_cyumoned)) = tbg8014m_2.no_cyumon_1
  ) maintable
;

-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi000004_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000005
select
	--販社コード
 	t001g.cd_hansya as `販社コード`,
 	--会社コード
 	t001g.cd_kaisya as `会社コード`,
 	--フォロー店舗コード
 	t001g.cd_flwtenp as `フォロー店舗コード`,
 	--入庫予定店舗
 	t001g.cd_nyuukoyt as `入庫予定店舗 `,
 	--整理ＮＯ
	t001g.no_seiri as `整理ＮＯ`,
	--フレーム型式
	t001g.mj_framekat as `フレーム型式`,
	--リコール名称
	v0004.kj_recallme as `リコール名称`,
	--適用期間始期
	t205m.dd_tekkikst as `適用期間始期`,
	--一時抹消: [抹消区分]="1" && [実施区分]="0"
	sum(t001g.kb_massyo = '1' and t001g.kb_jissi= '0') as `一時抹消`
--リコールメインＤＢ
from ai21rep_ve_dx.tbfj001g t001g
-- 店舗表示設定
left semi join dx_ve.tbi999003m t9003m on (t9003m.cd_hansya = t001g.cd_hansya
and t9003m.cd_kaisya = t001g.cd_kaisya
and t9003m.cd_tenpo = t001g.cd_nyuukoyt
and t9003m.mj_cyohyoid = '000'
and t9003m.kb_tenji = 1) or trim(t001g.cd_nyuukoyt) = ''
--リコール展開明細ＤＢ
--left semi join ai21rep_ve_dx.tbfy206m t206m on t206m.cd_hansya = t001g.cd_hansya
--and t206m.cd_kaisya = t001g.cd_kaisya
--and t206m.no_seiri = t001g.no_seiri
--リコール名称
left join gold.vbi000004_en v0004 on v0004.cd_hansya = t001g.cd_hansya
and v0004.cd_kaisya = t001g.cd_kaisya
and v0004.no_seiri = t001g.no_seiri
left join (
	select
		t205m.cd_hansya,
		t205m.cd_kaisya,
		t205m.no_seiri,
		trim(t205m.mj_framekat) as mj_framekat,
		max(t205m.dd_tekkikst) as dd_tekkikst
	--リコール展開名称ＤＢ
	from ai21rep_ve_dx.tbfy205m t205m
	group by t205m.cd_hansya, t205m.cd_kaisya, t205m.no_seiri, trim(t205m.mj_framekat)
) t205m on t205m.cd_hansya = t001g.cd_hansya
and t205m.cd_kaisya = t001g.cd_kaisya
and t205m.no_seiri = t001g.no_seiri
and trim(t205m.mj_framekat) = trim(t001g.mj_framekat)
group by t001g.cd_hansya, t001g.cd_kaisya, t001g.cd_flwtenp, t001g.cd_nyuukoyt, t001g.no_seiri, t001g.mj_framekat, v0004.kj_recallme, t205m.dd_tekkikst
;

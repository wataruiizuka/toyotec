-- Source file: 012_SMB空き枠カレンダー（ストール軸管理向け）/smbcalendar.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi012001_en
select
	--日付
	bt.dd_date,
	--日付_月
	trunc(bt.dd_date, 'MM') as dd_month,
	--日付_yyyy/MM/dd
	date_format(bt.dd_date, 'yyyy/MM/dd') as `dd_yyyy/MM/dd`,
	--日付_yyyyMMdd
	date_format(bt.dd_date, 'yyyyMMdd') as `dd_yyyyMMdd`,
	--日付_曜日
	concat(date_format(bt.dd_date, 'MM/dd'), CHR(10), '(',
		case dayofweek(bt.dd_date)
			when 1 then '日'
			when 2 then '月'
			when 3 then '火'
			when 4 then '水'
			when 5 then '木'
			when 6 then '金'
			when 7 then '土'
		end,
	')') as dd_week,
	--先週/来週
	bt.kb_senshuraishu
from (
	select
		date_add(cast(current_timestamp() as date), i) as dd_date,
		if (i < 7, '先週', '来週') as kb_senshuraishu
	from(
		VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13)
	) AS dd(i)
) bt
;

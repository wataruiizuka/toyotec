-- Source file: 101_マスタメンテナンス/vbi999001-VBI999010.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi999001
SELECT
	t200m.cd_hanbaitn AS `販売店コード`, --販売店コード
	t200m.cd_hansya AS `販社コード`, --販社コード
	t200m.cd_kaisya AS `会社コード`, --会社コード
	CONCAT(t200m.cd_hanbaitn, '_', regexp_replace(t200m.kj_kaisya, '　| +$', '')) AS `会社名`,  --会社名
    CASE WHEN count(v9001m.mj_account) = 0 THEN NULL ELSE concat_ws(';', collect_list(v9001m.mj_account)) END AS `メール`, --メール
	CASE WHEN count(IF(
		v9001m.mj_account LIKE '%toyotecdap.onmicrosoft.com',
		v9001m.mj_account,
		CONCAT(REPLACE(v9001m.mj_account, '@', '_'), '#EXT#@toyotecdap.onmicrosoft.com')
	)) = 0 THEN NULL ELSE concat_ws(';', collect_list(IF(
		v9001m.mj_account LIKE '%toyotecdap.onmicrosoft.com',
		v9001m.mj_account,
		CONCAT(REPLACE(v9001m.mj_account, '@', '_'), '#EXT#@toyotecdap.onmicrosoft.com')
	))) END AS `メールSP`  --メールSP
FROM ai21rep_ve_dx.tbv0200m t200m --会社コードＤＢ 
INNER JOIN dx_ve.tbi999001m v9001m --ユーザ情報  
ON v9001m.cd_hanbaitn = t200m.cd_hanbaitn
AND v9001m.kb_masterkengen = '1'
GROUP BY t200m.cd_hansya, t200m.cd_kaisya, t200m.cd_hanbaitn, regexp_replace(t200m.kj_kaisya, '　| +$', '')
;

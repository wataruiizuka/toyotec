-- Source file: 999_入口/vbi999006.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi999006
SELECT
         tbi999002m.cd_hanbaitn AS `販売店コード` --販売店コード
        ,tbi999002m.mj_cyohyoid AS `帳票ID` --帳票ID
        ,tbi999002m.mj_url AS URL --URL
        ,CONCAT(COALESCE(tbv0200m.kj_kaisyatn, ''), '(', tbi999002m.cd_hanbaitn, ')') AS `販売店名` --販売店名
        ,tbi999006m.mj_url AS `マスタメンテナンスURL` --マスタメンテナンスURL
        ,tbi999002m.kb_sakujo AS `削除フラグ` --削除フラグ
    FROM dx_ve.tbi999002m tbi999002m --帳票情報
    LEFT JOIN (
        SELECT
             tbv0200m.cd_hanbaitn --販売店コード
            ,tbv0200m.kj_kaisyatn --販売店名
            ,ROW_NUMBER() OVER (PARTITION BY tbv0200m.cd_hanbaitn ORDER BY tbv0200m.dd_saisinup DESC) AS rn --選別
      FROM ai21rep_ve_dx.tbv0200m tbv0200m --tbv0200m
    ) tbv0200m
    ON tbi999002m.cd_hanbaitn = tbv0200m.cd_hanbaitn
    AND tbv0200m.rn = 1 --選別 = 0
    LEFT JOIN dx_ve.tbi999006m tbi999006m --マスタメンテナンス情報
    ON tbi999002m.`cd_hanbaitn` = tbi999006m.cd_hanbaitn
    AND tbi999006m.kb_sakujo = 0 --いいえ削除フラグ
    --WHERE tbi999002m.削除フラグ = 0
;

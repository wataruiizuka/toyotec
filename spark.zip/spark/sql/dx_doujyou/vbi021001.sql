-- Source file: 021_Bz4x買換え報奨金照会/報奨金_view_ve_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi021001
select t.cd_hansya , 
		t200m.kj_kaisyatn, 
		t200m.cd_hanbaitn,
		t.cd_kaisya, 
		t.CD_OKYAKU, 
		t.KB_SINCYU, 
		t.NO_SYADAI, 
		t.MJ_KATASIKI,
		t.MJ_SYAMEI,
		t006m.CD_STAFFTEN, 
		t201m.kj_tenpomei,
		t000m.KJ_OKYAKUM1
-- 車両管理ＤＢ
from ai21rep_ve_dx.TBTEC05G t
-- 顧客担当ＤＢ
left join ai21rep_ve_dx.TBAZ006M t006m
on t006m.cd_hansya = t.cd_hansya
and t006m.cd_kaisya = t.cd_kaisya
and t006m.CD_OKYAKU = t.CD_OKYAKU
-- 会社コードＤＢ
left join ai21rep_ve_dx.tbv0200m t200m
on t200m.cd_hansya = t.cd_hansya
and t200m.cd_kaisya = t.cd_kaisya
-- 共通店舗ＤＢ 
left join ai21rep_ve_dx.tbv0201m t201m
on t201m.cd_hansya = t.cd_hansya
and t201m.cd_kaisya = t.cd_kaisya
and t201m.cd_tenpo = t006m.CD_STAFFTEN
-- 顧客基本ＤＢ
left join ai21rep_ve_dx.TBAZ000M t000m					
on t000m.cd_hansya = t.cd_hansya					
and t000m.cd_kaisya = t.cd_kaisya					
and t000m.CD_OKYAKU = t.CD_OKYAKU	
where (lOWER(t.MJ_KATASIKI) like '%xeam10%' or lOWER(t.MJ_KATASIKI) like '%yeam15%')
and t006m.KB_TANTOBUN = '1'
and t.KB_SYAMASSY  <> '1'
;

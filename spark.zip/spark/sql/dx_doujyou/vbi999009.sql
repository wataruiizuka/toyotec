-- Source file: 101_マスタメンテナンス/vbi999001-VBI999010.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi999009
SELECT
	ROW_NUMBER() OVER(PARTITION BY tf001m.cd_hansya, tf001m.cd_kaisya order by CAST(tf001m.nu_symenarb AS int), tf001m.cd_ncsyamei) AS `No.`, --No
	tf001m.cd_hansya AS `販社コード`, --販社コード
	tf001m.cd_kaisya AS `会社コード`, --会社コード
	tf001m.cd_ncsyamei AS `車名コード`, --車名コード
	CONCAT(tf001m.kn_syame, '##', CAST(ROW_NUMBER() OVER(PARTITION BY tf001m.cd_hansya, tf001m.cd_kaisya order by CAST(tf001m.nu_symenarb AS int), tf001m.cd_ncsyamei) AS string), '##') AS `カナ車名`, --カナ車名
	CONCAT(tf001m.kj_kurumame, '##', CAST(ROW_NUMBER() OVER(PARTITION BY tf001m.cd_hansya, tf001m.cd_kaisya order by CAST(tf001m.nu_symenarb AS int), tf001m.cd_ncsyamei) AS string), '##') AS `漢字車名`, --漢字車名
	IF(t9008m.kb_tenji = 0, '×', IF(tf001m.kb_oem in('0', '3', '6'), '○', '×')) AS `表示可否`, --表示可否
	CAST(tf001m.nu_symenarb AS int) AS `車名並び順` --車名並び順
FROM ai21rep_ve_dx.tbbf001m tf001m --車名ＤＢ
LEFT JOIN dx_ve.tbi999008m t9008m --新車車種表示設定
ON t9008m.cd_hansya = tf001m.cd_hansya
AND t9008m.cd_kaisya = tf001m.cd_kaisya
AND t9008m.cd_ncsyamei = tf001m.cd_ncsyamei
WHERE tf001m.kn_syame IS NOT NULL
GROUP BY tf001m.cd_hansya, tf001m.cd_kaisya, tf001m.kn_syame, tf001m.cd_ncsyamei, tf001m.kj_kurumame, t9008m.kb_tenji, tf001m.kb_oem, tf001m.nu_symenarb
;

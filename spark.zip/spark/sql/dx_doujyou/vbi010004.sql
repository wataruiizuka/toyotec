-- Source file: 010_経営主要項目実績/VBI010001-VBI010006.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.VBI010004
SELECT  
	t201m.cd_hansya AS `販社コード`, --販社コード
	t201m.cd_kaisya AS `会社コード`, --会社コード
	t201m.cd_tenpo AS `店舗コード`, --店舗コード
	CONCAT(t201m.cd_hansya, t201m.cd_kaisya, t201m.cd_tenpo) AS `販社会社店舗`, --販社会社店舗
	NVL(ucar.`TAD販売実績`, 0) AS `TAD販売実績`, --TAD販売実績
	NVL(ucar.`TAD下取数`, 0) AS `TAD下取数`, --TAD下取数
	NVL(ucar.`TAD入会数`, 0) AS `TAD入会数`, --TAD入会数
	NVL(ucar.`Ucar下取数`, 0) AS `Ucar下取数`, --Ucar下取数
	NVL(ucar.`UCar買取数`, 0) AS `UCar買取数`, --UCar買取数
	NVL(ucar.`UCar入会数`, 0) AS `UCar入会数`, --UCar入会数
	NVL(ucar.`UCar小売`, 0) AS `UCar小売`, --UCar小売
	NVL(ucar.`UCar卸`, 0) AS `UCar卸` --UCar卸
FROM
	ai21rep_ve_dx.tbv0201m t201m --共通店舗ＤＢ
LEFT JOIN 
(--中古車販売
	SELECT
		cd_hansya, --販社コード
		cd_kaisya,  --会社コード
		cd_jytyuten, --受注店舗コード
		SUM(CASE WHEN `売上区分` = '11' THEN `Ucar下取数` ELSE 0 END) AS `Ucar下取数`, --Ucar下取数
		SUM(CASE WHEN `売上区分` = '11' THEN `UCar入会数` ELSE 0 END) AS `UCar入会数`, --UCar入会数
		SUM(`UCar買取数`) AS `UCar買取数`, --UCar買取数	
		SUM(CASE WHEN `売上区分` = '11' THEN `Ucar販売数` ELSE 0 END) AS `UCar小売`, --UCar小売
		SUM(CASE WHEN `売上区分` = '20' THEN `Ucar販売数` ELSE 0 END) AS `UCar卸`, --UCar卸
		SUM(CASE WHEN `売上区分` = '14' THEN `Ucar販売数` ELSE 0 END) AS `TAD販売実績`, --TAD販売実績
		SUM(CASE WHEN `売上区分` = '14' THEN `Ucar下取数` ELSE 0 END) AS `TAD下取数`, --TAD下取数
		SUM(CASE WHEN `売上区分` = '14' THEN `UCar入会数` ELSE 0 END) AS `TAD入会数` --TAD入会数
	FROM
		(
		SELECT
			tbbc017g.cd_hansya, --販社コード
			tbbc017g.cd_kaisya, --会社コード
			tbbc017g.cd_jytyuten, --受注店舗コード
			tbbc017g.kb_uriage AS `売上区分`, --売上区分
			SUM(calflg) AS `Ucar販売数`, --Ucar販売数
     		(SUM(CASE WHEN tbba003g_1.`Ucar下取数` > 0  THEN calflg ELSE 0 END) ) AS `Ucar下取数`, --Ucar下取数
			SUM(CASE WHEN TBBC001G.kb_siire LIKE '3%' THEN calflg ELSE 0 END) AS `UCar買取数` , --UCar買取数
			SUM(CASE WHEN NVL(REPLACE(REPLACE(tbbc020g.kb_mntpkkei, '　', ''), ' ', ''),'') <> '' THEN calflg ELSE 0 END)  AS `UCar入会数`  --UCar入会数
		FROM
			(
			SELECT
				tbbc017g.cd_hansya, --販社コード
				tbbc017g.cd_kaisya, --会社コード
				tbbc017g.cd_jytyuten, --受注店舗コード
				tbbc017g.no_cyumon, --注文ＮＯ
				tbbc017g.no_cyumoned, --注文ＮＯ枝番
				tbbc017g.no_syaryou, --車両ＮＯ
				tbbc017g.kb_uriage, --売上区分
				1 AS calflg --計算フラグ
			FROM
				ai21rep_ve_dx.tbbc017g tbbc017g --中古車受注基本情報ＤＢ
			LEFT JOIN 
	   		(
				SELECT
					t8006.cd_hansya, --販社コード
					t8006.cd_kaisya, --会社コード
					t8006.no_cyumon,  --注文ＮＯ
					MIN(t8006.dd_uriage) AS dd_uriage --売上日
				FROM
					ai21rep_ve_dx.tbg8006m t8006 --中古車小売売上トランＤＢ 
				GROUP BY
					t8006.cd_hansya,
					t8006.cd_kaisya,
					t8006.no_cyumon
	    		)ft8006 ON
				tbbc017g.cd_kaisya = ft8006.cd_kaisya
				AND tbbc017g.cd_kaisya = ft8006.cd_kaisya
				AND tbbc017g.no_cyumon = ft8006.no_cyumon
				AND tbbc017g.dd_uritorik IS NULL
			WHERE -- 受注計上日に値があり、取消日がNULL、かつ中古車小売売上トランＤＢ の売上日がNULLと中古車受注基本情報ＤＢの売上計上日が当月、
				--或いは中古車小売売上トランＤＢの売上日が当月
				tbbc017g.dd_uriagekj IS NOT NULL
				AND tbbc017g.dd_torikesi IS NULL
				AND ( (ft8006.dd_uriage IS NULL
					AND tbbc017g.dd_uriagekj >= TRUNC(ADD_MONTHS(CAST(current_timestamp() AS DATE), 0), 'MM'))
					OR 
	            		(ft8006.dd_uriage IS NOT NULL
					AND date_format(to_timestamp(CAST(ft8006.dd_uriage AS STRING), 'yyyyMM'), 'yyyyMM') >= TRUNC(ADD_MONTHS(CAST(current_timestamp() AS DATE), 0), 'MM')
	        ))
		UNION ALL
			SELECT
				tbbc017g.cd_hansya, --販社コード
				tbbc017g.cd_kaisya, --会社コード
				tbbc017g.cd_jytyuten, --受注店舗コード
				tbbc017g.no_cyumon, --注文ＮＯ
				tbbc017g.no_cyumoned, --注文ＮＯ枝番
				tbbc017g.no_syaryou,  --車両ＮＯ
				tbbc017g.kb_uriage, --売上区分
				-1 AS calflg --計算フラグ
			FROM
				ai21rep_ve_dx.tbbc017g tbbc017g --中古車受注基本情報ＤＢ
			WHERE -- 中古車受注基本情報ＤＢの受注計上日に値があり、取消日が当月
				tbbc017g.dd_jucyuke IS NOT NULL
				AND tbbc017g.dd_uritorik >= TRUNC(ADD_MONTHS(CAST(current_timestamp() AS DATE), 0), 'MM')
		) tbbc017g
		LEFT JOIN ai21rep_ve_dx.tbbc001g TBBC001G --中古車在庫基本情報ＤＢ
		ON TBBC001G.cd_kaisya = tbbc017g.cd_kaisya
		AND TBBC001G.cd_hansya = tbbc017g.cd_hansya
		AND TBBC001G.no_syaryou = tbbc017g.no_syaryou
		LEFT JOIN (
			SELECT
				tbba003g.cd_hansya, --販社コード
				tbba003g.cd_kaisya, --会社コード
				tbba003g.no_cyumon, --注文ＮＯ
				tbba003g.no_cyumoned, --注文ＮＯ枝番
				COUNT(1) AS `Ucar下取数` --Ucar下取数
			FROM
				ai21rep_ve_dx.tbba003g tbba003g --受注下取DB
			WHERE --新中区分='2'
				tbba003g.kb_sincyu = '2'
			GROUP BY
				tbba003g.cd_hansya,
				tbba003g.cd_kaisya,
				tbba003g.no_cyumon,
				tbba003g.no_cyumoned
		   ) tbba003g_1
		   ON tbbc017g.cd_hansya = tbba003g_1.cd_hansya
			AND tbbc017g.cd_kaisya = tbba003g_1.cd_kaisya
			AND tbbc017g.no_cyumon = tbba003g_1.no_cyumon
			AND TRIM(tbbc017g.no_cyumoned) = TRIM(tbba003g_1.no_cyumoned)
		LEFT JOIN ai21rep_ve_dx.tbbc020g tbbc020g --中古車受注販売条件情報ＤＢ
			ON tbbc017g.cd_hansya = tbbc020g.cd_hansya
			AND tbbc017g.cd_kaisya = tbbc020g.cd_kaisya
			AND tbbc017g.no_cyumon = tbbc020g.no_cyumon
			AND TRIM(tbbc017g.no_cyumoned) = TRIM(tbbc020g.no_cyumoned)
		--売上区分 = '11', '14', '20'
		WHERE tbbc017g.kb_uriage IN ('11', '14', '20')
			GROUP BY
				tbbc017g.cd_hansya,
				tbbc017g.cd_kaisya,
				tbbc017g.cd_jytyuten,
				tbbc017g.kb_uriage
) combined
	GROUP BY
		cd_hansya,
		cd_kaisya,
		cd_jytyuten
) ucar ON
	t201m.cd_hansya = ucar.cd_hansya
	AND t201m.cd_kaisya = ucar.cd_kaisya
	AND t201m.cd_tenpo = ucar.cd_jytyuten
;

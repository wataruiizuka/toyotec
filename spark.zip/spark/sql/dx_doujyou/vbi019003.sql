-- Source file: 019_中古車実績一覧(スタッフ別・店舗別)/中古車実績一覧（スタッフ別・店舗別）_iceberg.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi019001, gold.vbi019002
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi019003
SELECT 
	--販社コード
	t.cd_hansya AS `販社コード`,
	--会社コード
	t.cd_kaisya AS `会社コード`,
	--店舗コード
	t.cd_tenpo AS `店舗コード`,
	--店舗名称
	t.kj_tenpomei AS `店舗名称`,
	--販売スタッフコード
	t.cd_hanstaff AS `販売スタッフコード`,
	--社員名
	t.kj_syainmei AS `社員名`,
	--月
	t.month AS `月`,
	--受注
	t.su_jucyu AS `受注`,
	--受注キャンセル反映
	t.su_jucyucancelhane AS `受注キャンセル反映`,
	--受注除軽
	t.su_jucyujyokei AS `受注除軽`,
	--受注除軽キャンセル反映
	t.su_jucyucanceljyokeihane AS `受注除軽キャンセル反映`,
	--販売
	t.su_hanbai AS `販売`,
	--販売キャンセル反映
	t.su_hanbaicancelhane AS `販売キャンセル反映`,
	--販売除軽
	t.su_hanbaijyokei AS `販売除軽`,
	--販売除軽キャンセル反映
	t.su_hanbaicanceljyokeihene AS `販売除軽キャンセル反映`,
	--割賦
	t.su_kap AS `割賦`,
	--メンテナンスパック
	t.su_maintenancepack AS `メンテナンスパック`,
	--ソート順
	rank() over (partition by t.cd_hansya,t.cd_kaisya order by tbi999003m.mj_sortjyun , t.cd_tenpo) as `ソート順`
FROM 
(
	SELECT 
		--販社コード
		cd_hansya,
		--会社コード
		cd_kaisya,
		--店舗コード
		cd_tenpo,
		--店舗名称
		kj_tenpomei,
		--販売スタッフコード
		cd_hanstaff,
		--社員名
		kj_syainmei,
		--月
		month,
		--受注
		SUM(su_jucyu) AS `su_jucyu`,
		--受注キャンセル反映
		SUM(su_jucyucancelhane) AS `su_jucyucancelhane`,
		--受注除軽
		SUM(su_jucyujyokei) AS `su_jucyujyokei`,
		--受注除軽キャンセル反映
		SUM(su_jucyucanceljyokeihane) AS `su_jucyucanceljyokeihane`,
		--販売
		SUM(su_hanbai) AS `su_hanbai`,
		--販売キャンセル反映
		SUM(su_hanbaicancelhane) AS `su_hanbaicancelhane`,
		--販売除軽
		SUM(su_hanbaijyokei) AS `su_hanbaijyokei`,
		--販売除軽キャンセル反映
		SUM(su_hanbaicanceljyokeihene) AS `su_hanbaicanceljyokeihene`,
		--割賦
		SUM(su_kap) AS `su_kap`,
		--メンテナンスパック
		SUM(su_maintenancepack) AS `su_maintenancepack`
	FROM
	(
		SELECT 
			--販社コード
			cd_hansya,
			--会社コード
			cd_kaisya,
			--店舗コード
			cd_tenpo,
			--店舗名称
			kj_tenpomei,
			--販売スタッフコード
			cd_hanstaff,
			--社員名
			kj_syainmei,
			--月
			month,
			--受注
			su_jucyu,
			--受注キャンセル反映
			su_jucyucancelhane,
			--受注除軽
			su_jucyujyokei,
			--受注除軽キャンセル反映
			su_jucyucanceljyokeihane,
			--販売
			0 AS `su_hanbai`,
			--販売キャンセル反映
			0 AS `su_hanbaicancelhane`,
			--販売除軽
			0 AS `su_hanbaijyokei`,
			--販売除軽キャンセル反映
			0 AS `su_hanbaicanceljyokeihene`,
			--割賦
			su_kap,
			--メンテナンスパック
			su_maintenancepack
		FROM gold.vbi019001
		UNION ALL
		SELECT 
			--販社コード
			cd_hansya,
			--会社コード
			cd_kaisya,
			--店舗コード
			cd_tenpo,
			--店舗名称
			kj_tenpomei,
			--販売スタッフコード
			cd_hanstaff,
			--社員名
			kj_syainmei,
			--月
			month,
			--受注
			0 AS `su_jucyu`,
			--受注キャンセル反映
			0 AS `su_jucyucancelhane`,
			--受注除軽
			0 AS `su_jucyujyokei`,
			--受注除軽キャンセル反映
			0 AS `su_jucyucanceljyokeihane`,
			--販売
			su_hanbai,
			--販売キャンセル反映
			su_hanbaicancelhane,
			--販売除軽
			su_hanbaijyokei,
			--販売除軽キャンセル反映
			su_hanbaicanceljyokeihene,
			--割賦
			0 AS `su_kap`,
			--メンテナンスパック
			0 AS `su_maintenancepack`
		FROM gold.vbi019002
	)combined
	GROUP BY
		--販社コード
		cd_hansya,
		--会社コード
		cd_kaisya,
		--店舗コード
		cd_tenpo,
		--店舗名称
		kj_tenpomei,
		--販売スタッフコード
		cd_hanstaff,
		--社員名
		kj_syainmei,
		--月
		month
)t
-- 店舗表示設定
INNER JOIN dx_ve.tbi999003m
	ON tbi999003m.cd_kaisya = t.cd_kaisya
	AND tbi999003m.cd_hansya = t.cd_hansya
	AND tbi999003m.cd_tenpo = t.cd_tenpo
	AND tbi999003m.mj_cyohyoid = '019'
	AND tbi999003m.kb_tenji = 1
;

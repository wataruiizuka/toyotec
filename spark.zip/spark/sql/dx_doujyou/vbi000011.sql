-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi000002_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000011
select
	--販社コード
 	t206m.cd_hansya as `販社コード`,
 	--会社コード
 	t206m.cd_kaisya as `会社コード`,
 	--店舗コード
 	ta001g.cd_tenpo as `店舗コード`,
 	--取替部品品番
 	trim(t206m.mj_toribhhn) as `取替部品品番`,
 	--整理ＮＯ
	t206m.no_seiri as `整理ＮＯ`,
	--フレーム型式
 	t206m.mj_framekat as `フレーム型式`,
 	--支払区分
	right(trim(t008g.cd_seibi), 1) as `支払区分`,
	--販社会社整理ＮＯフレーム型式支払区分
	concat(t206m.cd_hansya, t206m.cd_kaisya, t206m.no_seiri, trim(t206m.mj_framekat), right(trim(t008g.cd_seibi), 1)) as `販社会社整理ＮＯフレーム型式支払区分`,
	--取替部品個数
	t206m.su_toribhsu as `取替部品個数`,
	--取替部品品名
	v0002.mj_torihnme as `取替部品品名`
--リコールメインＤＢ
from ai21rep_ve_dx.tbfj001g t001g
--ストール予約ＤＢ
inner join ai21rep_ve_dx.tbsa001g ta001g on ta001g.cd_hansya = t001g.cd_hansya
and ta001g.cd_kaisya = t001g.cd_kaisya
and ta001g.no_aijutyu = t001g.no_jucyu
-- 店舗表示設定
left semi join dx_ve.tbi999003m t9003m on t9003m.cd_hansya = ta001g.cd_hansya
and t9003m.cd_kaisya = ta001g.cd_kaisya
and t9003m.cd_tenpo = ta001g.cd_tenpo
and t9003m.mj_cyohyoid = '000'
and t9003m.kb_tenji = 1
--受注明細ＤＢ
inner join ai21rep_ve_dx.tbfa008g t008g on t008g.cd_hansya = t001g.cd_hansya
and t008g.cd_kaisya = t001g.cd_kaisya
and t008g.cd_tenpo = ta001g.cd_tenpo
and left(t008g.cd_seibi, 5) = t001g.no_seiri
and t008g.no_jucyu = t001g.no_jucyu
--リコール展開明細ＤＢ
inner join ai21rep_ve_dx.tbfy206m t206m on t206m.cd_hansya = t001g.cd_hansya
and t206m.cd_kaisya = t001g.cd_kaisya
and t206m.no_seiri = t001g.no_seiri
and trim(t206m.mj_framekat) = (t001g.mj_framekat)
and t206m.kb_siharai = right(trim(t008g.cd_seibi), 1)
and left(t206m.mj_toribhhn, 3) = '040'
--部品品名マスタ
left join gold.vbi000002_en v0002 on v0002.cd_hansya = t206m.cd_hansya
and v0002.cd_kaisya = t206m.cd_kaisya
and v0002.mj_toribhhn = trim(t206m.mj_toribhhn)
group by t206m.cd_hansya, t206m.cd_kaisya, ta001g.cd_tenpo, trim(t206m.mj_toribhhn), t206m.no_seiri, t206m.mj_framekat, right(trim(t008g.cd_seibi), 1), t206m.su_toribhsu, v0002.mj_torihnme
;

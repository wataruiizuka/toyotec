-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi000001_en, gold.vbi000002_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000008
select
	--販社コード
 	t001g.cd_hansya as `販社コード`,
 	--会社コード
 	t001g.cd_kaisya as `会社コード`,
 	--店舗コード
 	t001g.cd_tenpo as `店舗コード`,
 	--品番
	trim(t001g.mj_hinban) as `品番`,
	--在庫数
	sum(t001g.su_zaikosu) as `在庫数`,
	--発注数
	sum(t001g.su_hacyusu) as `発注数`
--部品在庫ＤＢ
from ai21rep_ve_dx.tbfb001g t001g
-- 店舗表示設定
left semi join dx_ve.tbi999003m t9003m on t9003m.cd_hansya = t001g.cd_hansya
and t9003m.cd_kaisya = t001g.cd_kaisya
and t9003m.cd_tenpo = t001g.cd_tenpo
and t9003m.mj_cyohyoid = '000'
and t9003m.kb_tenji = 1
--部品品名マスタ
left semi join gold.vbi000002_en v0002 on v0002.cd_hansya = t001g.cd_hansya
and v0002.cd_kaisya = t001g.cd_kaisya
and v0002.mj_toribhhn = trim(t001g.mj_hinban)
--店舗
left semi join gold.vbi000001_en v0001 on v0001.cd_hansya = t001g.cd_hansya
and v0001.cd_kaisya = t001g.cd_kaisya
and v0001.cd_tenpo = t001g.cd_tenpo
group by t001g.cd_hansya, t001g.cd_kaisya, t001g.cd_tenpo, trim(t001g.mj_hinban)
;

-- Source file: 016_新車受注分析/vbi016001-vbi016011.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.VBI016001
SELECT
	`販社コード`, --販社コード
	`会社コード`, --会社コード
	`新車車名`, --新車車名
	`受注計上日`, --受注計上日
	CASE
		WHEN date_format(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'yyyyMM') = date_format(`受注計上日`, 'yyyyMM')
		THEN '前月'
		WHEN date_format(CAST(current_timestamp() AS DATE), 'yyyyMM') = date_format(`受注計上日`, 'yyyyMM')
		THEN '当月'
		ELSE
		' '
	END AS `月別`, --月別
	CONCAT(`新車車名`, date_format(`受注計上日`, 'yyyyMMdd')) AS `車名受注日`,  --車名受注日
	DENSE_RANK() OVER (PARTITION BY `販社コード`, `会社コード` ORDER BY `ソート順`, `新車車名コード` ) AS `ソート順`, --ソート順
	`台数` --台数
FROM
	(
	SELECT
		tbba001g.cd_hansya AS `販社コード`,  --販社コード
		tbba001g.cd_kaisya AS `会社コード`,  --会社コード
		CAST(tbba001g.dd_jucyuke AS DATE) AS `受注計上日`,  --受注計上日
		tbbf001m.kj_kurumame AS `新車車名`, --新車車名
		MIN(sort_car.mj_sortjyun) AS `ソート順`, --ソート順
		MIN(sort_car.cd_ncsyamei) AS `新車車名コード`, --新車車名コード
		COUNT(1) AS `台数`  --台数
	FROM
		ai21rep_ve_dx.tbba001g tbba001g --新車受注基本情報ＤＢ
	LEFT SEMI JOIN dx_ve.tbi999003m tbi999003m --店舗展示設定
	ON
		tbba001g.cd_hansya = tbi999003m.cd_hansya
		AND tbba001g.cd_kaisya = tbi999003m.cd_kaisya
		AND tbba001g.cd_tenpo = tbi999003m.cd_tenpo
		AND tbi999003m.mj_cyohyoid = '016'
		AND tbi999003m.kb_tenji = 1
	LEFT JOIN ai21rep_ve_dx.tbbf008m tbbf008m --車両スペック２ＤＢ
    ON
		tbba001g.cd_hansya = tbbf008m.cd_hansya
		AND tbba001g.cd_kaisya = tbbf008m.cd_kaisya
		AND tbba001g.mj_sinkysed = tbbf008m.mj_sinkysed
		AND tbba001g.mj_gaihansy = tbbf008m.cd_spec
		AND tbba001g.mj_hantenkt = tbbf008m.mj_hantenkt
		AND tbbf008m.kb_spec = 'G'
	LEFT JOIN ai21rep_ve_dx.tbbf001m tbbf001m --車名ＤＢ 
    ON
		tbbf001m.cd_kaisya = tbbf008m.cd_kaisya
		AND tbbf001m.cd_hansya = tbbf008m.cd_hansya
		AND tbbf001m.cd_ncsyamei = tbbf008m.mj_syamei
	INNER JOIN dx_ve.tbi999008m tbi999008m --車種展示設定
	ON
		tbbf001m.cd_hansya = tbi999008m.cd_hansya
		AND tbbf001m.cd_kaisya = tbi999008m.cd_kaisya
		AND tbbf001m.cd_ncsyamei = tbi999008m.cd_ncsyamei
		AND tbi999008m.kb_tenji = 1
	LEFT JOIN (
		SELECT	
				 tbi999008m.cd_hansya, --販社コード
				 tbi999008m.cd_kaisya, --会社コード
				 TRIM(tbi999008m.kj_kurumame) AS kj_kurumame, --漢字車名
				 MIN(tbi999008m.mj_sortjyun) AS mj_sortjyun, --ソート順
				 MIN(tbi999008m.cd_ncsyamei) AS cd_ncsyamei --新車車名コード
		FROM
			dx_ve.tbi999008m tbi999008m --車種展示設定
		WHERE
			tbi999008m.kb_tenji = 1
		GROUP BY 
			tbi999008m.cd_hansya,
			tbi999008m.cd_kaisya,
			TRIM(tbi999008m.kj_kurumame)
		) sort_car
	ON
		tbbf001m.cd_hansya = sort_car.cd_hansya
		AND tbbf001m.cd_kaisya = sort_car.cd_kaisya
		AND TRIM(tbbf001m.kj_kurumame) = TRIM(sort_car.kj_kurumame)
		--売上取消計上日と取消日=NULL、受注計上日!=NULL
	WHERE
		tbba001g.dd_uritrkkj IS NULL
		AND tbba001g.dd_torikesi IS NULL
		AND tbba001g.dd_jucyuke IS NOT NULL
	GROUP BY
		tbba001g.cd_hansya,
		tbba001g.cd_kaisya,
		CAST(tbba001g.dd_jucyuke AS DATE),
		`新車車名`
) t
UNION ALL
SELECT
	'固定' AS `販社コード`, --販社コード
	'' AS `会社コード`, --会社コード
	'合計' AS `新車車名`, --新車車名
	NULL AS `受注計上日`, --受注計上日
	NULL AS `月別`, --月別
	NULL AS `車名受注日`, --車名受注日
	-1 AS `ソート順`, --ソート順
	0 AS `台数` --台数
;

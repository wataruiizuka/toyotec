-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 3
-- Internal Gold dependencies: gold.vbi003006_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi003006
select
	--販社コード
	cd_hansya as `販社コード`,
	--会社コード
	cd_kaisya as `会社コード`,
	--店舗コード
	cd_tenpo as `店舗コード`,
	--予約ＩＤ
	no_yoyakuid as `予約ＩＤ`,
	--予約明細ＩＤ
	cd_yoykmsai as `予約明細ＩＤ`,
	--ストール番号
	no_stall as `ストール番号`,
	--ご用
	mj_gyme as `ご用命`,
	--工程区分
	kb_koutei as `工程区分`,
	--入庫予定日時
	dt_nyuukoyt as `入庫予定日時`,
	--出庫予定日時
	dt_shukkoyt as `出庫予定日時`,
	--使用所要時間
	tm_siyotime as `使用所要時間`,
	--入庫区分
	kb_nyuuko as `入庫区分`,
	--実績ステータス
	cd_jisekist as `実績ステータス`,
	--実績ステータス名
	mj_jisekist as `実績ステータス名`,
	--休憩跨ぎ区分
	cd_restcros as `休憩跨ぎ区分`,
	--ＳＭＢ削除フラグ
	mj_sakujyo as `ＳＭＢ削除フラグ`,
	--販社会社店舗ストール番号日付
	cd_hansyakaisyatenpostalldate as `販社会社店舗ストール番号日付`,
	--入庫予定日
	dd_nyuukoyt as `入庫予定日`,
	--予約
	mj_yoyaku as `予約`,
	--出勤時間
	tm_shukkin as `出勤時間`,
	--退勤時間
	tm_taikin as `退勤時間`,
	--残業時間
	tm_zangyo as `残業時間`
from
	gold.vbi003006_en
;

-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi003005
select
	--販社コード
	t021m.cd_hansya,
	--会社コード
	t021m.cd_kaisya,
	--店舗コード
	t021m.cd_tenpo,
	--ストール番号
	t021m.no_stall,
	--ストール休憩番号
	t021m.no_stlkyuke,
	--休憩有効フラグ
	t021m.mj_kyukeyko,
	--休憩開始時間
	t021m.tm_kyukest,
	--休憩開始時間_秒
	unix_timestamp(concat('1970-01-01 ', t021m.tm_kyukest)) as tm_kyukestsecond,
	--休憩終了時間
	t021m.tm_kyukeen,
	--休憩終了時間_秒
	unix_timestamp(concat('1970-01-01 ', t021m.tm_kyukeen)) as tm_kyukeensecond
-- ストール休憩マスタＤＢ
from ai21rep_ve_dx.tbsa021m t021m
-- 店舗表示設定
left semi join dx_ve.tbi999003m t9003m on t9003m.cd_hansya = t021m.cd_hansya
and t9003m.cd_kaisya = t021m.cd_kaisya
and t9003m.cd_tenpo = t021m.cd_tenpo
and t9003m.mj_cyohyoid = '003'
and t9003m.kb_tenji = 1
-- SMB異常管理ボード集計対象店舗一覧
left semi join dx_ve.tbi003001m t3001m on t3001m.cd_hansya = t021m.cd_hansya
and t3001m.cd_kaisya = t021m.cd_kaisya
and t3001m.cd_tenpo = t021m.cd_tenpo
and t3001m.tm_kaiten < t021m.tm_kyukest
and t3001m.tm_heiten > t021m.tm_kyukeen
-- [ＳＭＢ削除フラグ] = "0"
where t021m.mj_sakujyo = '0'
-- [休憩有効フラグ] = 1
and t021m.mj_kyukeyko = '1'
;

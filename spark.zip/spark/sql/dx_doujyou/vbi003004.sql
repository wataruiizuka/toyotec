-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi003002
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi003004
select
	--販社コード
	t005g.cd_hansya,
	--会社コード
	t005g.cd_kaisya,
	--店舗コード
	t005g.cd_tenpo,
	--予約ＩＤ
	t005g.no_yoyakuid,
	--予約明細ＩＤ
	t005g.cd_yoykmsai,
	--明細枝番最大番号
	t005g.no_msaiedmx,
	--ストール番号
	t005g.no_stall,
	--ストール番号_文字列
	cast(t005g.no_stall as string) as mj_stallno,
	--ご用命
	t005g.mj_gyme,
	--工程区分
	t005g.kb_koutei,
	--使用開始日時
	t005g.dt_siyost,
	--入庫予定日
	trunc(t005g.dt_siyost, 'J') as dd_nyuukoyt,
	--入庫予定時間_秒
	unix_timestamp(concat('1970-01-01 ', date_format(t005g.dt_siyost, 'HH:mm:ss'))) as tm_nyuukoytsecond,
	--使用終了日時
	t005g.dt_siyoed,
	--出庫予定日
	trunc(t005g.dt_siyoed, 'J') as dd_shukkoyt,
	--出庫予定時間_秒
	unix_timestamp(concat('1970-01-01 ', date_format(t005g.dt_siyoed, 'HH:mm:ss'))) as tm_shukkoytsecond,
	--使用所要時間
	t005g.tm_siyotime,
	--入庫区分
	t005g.kb_nyuuko,
	--実績ステータス
	t005g.cd_jisekist,
	--休憩跨ぎ区分
	t005g.cd_restcros,
	--作業人数
	t005g.su_sgyninz,
	--入庫実績日時
	t005g.dt_nyukjisk,
	--精算実績日時
	t005g.dt_sesnjisk,
	--ＳＭＢ削除フラグ
	t005g.mj_sakujyo
-- ストール予約明細ＤＢ
from ai21rep_ve_dx.tbsa005g t005g
-- ストールマスタ_充足率対象ＤＢ
left semi join gold.vbi003002 v3002 on v3002.cd_hansya = t005g.cd_hansya
and v3002.cd_kaisya = t005g.cd_kaisya
and v3002.cd_tenpo = t005g.cd_tenpo
and v3002.no_stall = t005g.no_stall
-- [ＳＭＢ削除フラグ] = "0"
where t005g.mj_sakujyo = '0'
-- [実績ステータス] <> "00" and [実績ステータス] <> "01" and [実績ステータス] <> "02"
and (NOT coalesce(t005g.cd_jisekist in('00', '01', '02'), false))
and t005g.dt_siyost >= cast(current_timestamp() as date)
and t005g.dt_siyost < date_add(cast(current_timestamp() as date), 14)
union all
select
	tb05s.cd_hansya,
	tb05s.cd_kaisya,
	tb05s.cd_tenpo,
	tb05s.no_yoyakuid,
	tb05s.cd_yoykmsai,
	tb05s.no_msaiedmx,
	tb05s.no_stall,
	cast(tb05s.no_stall as string) as mj_stallno,
	tb05s.mj_gyme,
	tb05s.kb_koutei,
	tb05s.dt_siyost,
	trunc(tb05s.dt_siyost, 'J') as dd_nyuukoyt,
	-- 入庫予定時間
	unix_timestamp(concat('1970-01-01 ', date_format(tb05s.dt_siyost, 'HH:mm:ss'))) as tm_nyuukoytsecond,
	tb05s.dt_siyoed,
	trunc(tb05s.dt_siyoed, 'J') as dd_shukkoyt,
	-- 出庫予定時間
	unix_timestamp(concat('1970-01-01 ', date_format(tb05s.dt_siyoed, 'HH:mm:ss'))) as tm_shukkoytsecond,
	tb05s.tm_siyotime,
	tb05s.kb_nyuuko,
	tb05s.cd_jisekist,
	tb05s.cd_restcros,
	tb05s.su_sgyninz,
	tb05s.dt_nyukjisk,
	tb05s.dt_sesnjisk,
	tb05s.mj_sakujyo
	-- ストール予約明細退避ＤＢ
from ai21rep_ve_dx.tbsab05s tb05s
-- ストールマスタ_充足率対象ＤＢ
left semi join gold.vbi003002 v3002 on v3002.cd_hansya = tb05s.cd_hansya
and v3002.cd_kaisya = tb05s.cd_kaisya
and v3002.cd_tenpo = tb05s.cd_tenpo
and v3002.no_stall = tb05s.no_stall
-- ストール予約明細ＤＢ
left anti join ai21rep_ve_dx.tbsa005g t005g on t005g.cd_hansya = tb05s.cd_hansya
and t005g.cd_kaisya = tb05s.cd_kaisya
and t005g.cd_tenpo = tb05s.cd_tenpo
and t005g.no_yoyakuid = tb05s.no_yoyakuid
and t005g.no_stall = tb05s.no_stall
and t005g.mj_sakujyo = '0'
and (NOT coalesce(t005g.cd_jisekist in('00', '01', '02'), false))
-- ストール予約明細退避ＤＢ，重複判別
left anti join ai21rep_ve_dx.tbsab05s tb05s2 on tb05s2.cd_hansya = tb05s.cd_hansya
and tb05s2.cd_kaisya = tb05s.cd_kaisya
and tb05s2.cd_tenpo = tb05s.cd_tenpo
and tb05s2.no_yoyakuid = tb05s.no_yoyakuid
and tb05s2.cd_yoykmsai = tb05s.cd_yoykmsai
and tb05s2.no_stall = tb05s.no_stall
and tb05s2.mj_sakujyo = '0'
and (NOT coalesce(tb05s2.cd_jisekist in('00', '01', '02'), false))
and tb05s2.no_msaiedmx <> tb05s.no_msaiedmx
-- [ＳＭＢ削除フラグ] = "0"
where tb05s.mj_sakujyo = '0'
-- [実績ステータス] <> "00" and [実績ステータス] <> "01" and [実績ステータス] <> "02"
and (NOT coalesce(tb05s.cd_jisekist in('00', '01', '02'), false))
and tb05s.dt_siyost >= cast(current_timestamp() as date)
and tb05s.dt_siyost < date_add(cast(current_timestamp() as date), 14)
;

-- Source file: 002_新車売掛金/VBI002005_新車売掛金残高.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi002001_en
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.VBI002005
SELECT
	tbba001g.cd_hansya AS `販社コード`, --販社コード
	tbba001g.cd_kaisya AS `会社コード`, --会社コード
    tbba001g.cd_hansya || tbba001g.cd_kaisya || tbba001g.cd_tenpo AS `販社会社店舗コード`,
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(),-1)) AND (tbba001g.dd_urikzumi >= TRUNC(current_timestamp(),'MM') OR tbba001g.dd_urikzumi IS NULL),1,0) AS `登録済件数`,--登録済件数
    IF(COALESCE(tbba052g.su_sitadori, 0) = 0 AND tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND (tbba001g.dd_urikzumi >= TRUNC(current_timestamp(), 'MM') OR tbba001g.dd_urikzumi IS NULL),1,0) AS `下取車なし総件数`, --下取車なし総件数
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbba001g.dd_urikzumi IS NULL AND (tbba052g.ki_haseirui - tbba052g.ki_genknykg - tbba052g.ki_sitanykg - tbba052g.ki_fuharnyk) != 0,1,0) AS `未回収総件数`, --未回収総件数
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbba001g.dd_urikzumi IS NULL AND (tbba052g.ki_haseirui - tbba052g.ki_genknykg - tbba052g.ki_sitanykg - tbba052g.ki_fuharnyk) != 0,tbba052g.ki_haseirui - tbba052g.ki_genknykg - tbba052g.ki_sitanykg - tbba052g.ki_fuharnyk,0) AS `未回収総金額`, --未回収総金額
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbba001g.dd_urikzumi IS NULL AND (tbba052g.ki_genkhasg - tbba052g.ki_genknykg) != 0,1,0) AS `未回収現金総件数`, --未回収現金総件数
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbba001g.dd_urikzumi IS NULL AND (tbba052g.ki_genkhasg - tbba052g.ki_genknykg) != 0,tbba052g.ki_genkhasg - tbba052g.ki_genknykg,0) AS `未回収現金総金額`, --未回収現金総金額
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbba001g.dd_urikzumi IS NULL AND (tbba052g.ki_fuharhsk - tbba052g.ki_fuharnyk) != 0,1,0) AS `未回収割賦総総件数`, --未回収割賦総総件数
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbba001g.dd_urikzumi IS NULL AND (tbba052g.ki_fuharhsk - tbba052g.ki_fuharnyk) != 0,tbba052g.ki_fuharhsk - tbba052g.ki_fuharnyk,0) AS `未回収割賦総総金額`, --未回収割賦総総金額
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbba001g.dd_urikzumi IS NULL AND (tbba052g.ki_sitahasg - tbba052g.ki_sitanykg) != 0,1,0) AS `未回収下取総件数`, --未回収下取総件数
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbba001g.dd_urikzumi IS NULL AND (tbba052g.ki_sitahasg - tbba052g.ki_sitanykg) != 0,tbba052g.ki_sitahasg - tbba052g.ki_sitanykg,0) AS `未回収下取総金額`, --未回収下取総金額
    IF(tbba001g.dd_touroku IS NOT NULL AND tbba001g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND (tbba001g.dd_urikzumi >= TRUNC(current_timestamp(), 'MM') OR tbba001g.dd_urikzumi IS NULL) AND tbba001g.dd_nosya IS NULL,1,0) AS `登録済未納車件数` --登録済未納車件数
FROM 
	ai21rep_ve_dx.tbba001g tbba001g --新車受注基本DB
INNER JOIN gold.vbi002001_en v2001 --新車売掛金店舗別_en
    ON v2001.cd_hansya = tbba001g.cd_hansya
    AND v2001.cd_kaisya = tbba001g.cd_kaisya
    AND v2001.cd_tenpo = tbba001g.cd_tenpo
LEFT JOIN ai21rep_ve_dx.tbba052g tbba052g --新車受注販売条件情報DB
	ON tbba001g.cd_hansya = tbba052g.cd_hansya
	AND tbba001g.cd_kaisya = tbba052g.cd_kaisya
	AND tbba001g.no_cyumon = tbba052g.no_cyumon
	AND TRIM(tbba001g.no_cyumoned) = TRIM(tbba052g.no_cyumoned)
WHERE
tbba001g.dd_torikesi IS NULL --取消日がNULLである
AND (dd_torotrkk IS NULL
      OR (dd_torotrkk IS NOT NULL
        AND (tbba052g.ki_haseirui - tbba052g.ki_genknykg - tbba052g.ki_sitanykg - tbba052g.ki_fuharnyk) != 0
        )
    )--登録取消計上日がNULLではない　or　残高がある
AND LEFT(CAST (tbba001g.kb_haraidas AS STRING), 1) = '1' --払出区分の第一位が1
AND (NOT coalesce((tbba052g.ki_haseirui - tbba052g.ki_genknykg - tbba052g.ki_sitanykg - tbba052g.ki_fuharnyk) = 0 --値があると残高がある
        AND(
    	    (
    	        tbba001g.dd_touroku IS NOT NULL --登録日がNULLではないではありません
    	        and tbba001g.dd_nosya < DATE '2023-03-01' --納車日が2023-03-01以前
    	        and (tbba001g.dd_urikzumi IS NULL OR tbba001g.dd_urikzumi < DATE '2024-03-01') --売掛金完済日がNULLであるまたは売掛金完済日が2024-03-01以前
    	    )
    	    OR (tbba001g.dd_nosya IS NULL AND tbba001g.dd_touroku < DATE '2023-03-01') --納車日がNULLであるそして登録日が2023-03-01以前
    	    OR tbba001g.dd_urikzumi < DATE '2024-03-01' --納車日が2024-03-01以前
    	    OR (tbba001g.dd_touroku IS NULL AND tbba001g.dd_jucyu < DATE '2020-12-01') --登録日がNULLであるまたは受注日が2020-12-01以前
            ), false))--ゴミデータ除外
;

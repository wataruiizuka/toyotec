-- Source file: 018_NEO/enoreport_full_fixed.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

WITH base AS (
SELECT
     tbba001g.cd_hansya    AS `販社コード`
    ,tbba001g.cd_kaisya    AS `会社コード`
    ,tbba001g.no_cyumon    AS `注文ＮＯ`
    ,tbba001g.no_cyumoned  AS `注文ＮＯ枝番`
    ,tbba001g.dd_haisoyot  AS `配送予定日`
    ,tbba001g.dd_nosya     AS `納車日`
    ,COALESCE(REGEXP_REPLACE(tbba001g.kj_kainmei1, '^[ 　]+|[ 　]+$', ''),'') || COALESCE(REGEXP_REPLACE(tbba001g.kj_kainmei2, '^[ 　]+|[ 　]+$', ''),'') AS `買主名漢字`
    ,COALESCE(REGEXP_REPLACE(tbba001g.KJ_MEIGIME1, '^[ 　]+|[ 　]+$', ''),'') || COALESCE(REGEXP_REPLACE(tbba001g.KJ_MEIGIME2, '^[ 　]+|[ 　]+$', ''),'') AS `名義人名漢字`
    ,tbba001g.mj_hantenkt  AS `販売店型式`
    ,tbba001g.mj_gaihansy  AS `外鈑色`
    ,tbba001g.dd_jucyuke   AS `受注計上日`
    --,tbba001g.dd_fr        AS 振当日
    ,tbba008g.kb_zaikojyo AS `tbba008g.在庫状態区分`
    ,CAST(TO_TIMESTAMP(CAST(tbba008g.dd_karinoki AS STRING), 'yyyyMMdd') AS DATE)  AS `tbba008g.仮納期`
    ,CAST(TO_TIMESTAMP(CAST(tbba008g.dd_kansei AS STRING), 'yyyyMMdd') AS DATE) AS `tbba008g.完成予定日`
    ,CAST(TO_TIMESTAMP(CAST(tbba008g.dd_haisyyo AS STRING), 'yyyyMMdd') AS DATE) AS `tbba008g.配車予定日`
    ,tbba008g.dd_orderjur AS `tbba008g.オーダー受理日`
    ,tbba035g.su_nokikasn  AS `tbba035g.仮納期加算日数`
    ,tbba035g.su_kanseiks  AS `tbba035g.完成予定日加算日数`
    ,tbba035g.su_kakunoki  AS `tbba035g.確定納期加算日数`
    ,tbz0002c.dd_job  AS `tbz0002c.ジョブ日付`
    ,TRUNC(ADD_MONTHS(tbz0002c.dd_job, -1), 'MM') AS `前月1日`
    ,'' AS `振当日`
    ,CASE WHEN tbba001g.dd_zjfryote IS NOT NULL THEN '予' ELSE NULL END AS `振当予定`
    ,tbv0200m.kj_kaisyatn  AS `販売店名`
    ,tbv0014m.kj_syainmei  AS `社員名`
    ,tbbf001m.kj_kurumame  AS `車名`
    ,tbba001g.no_syadaiba      AS `車台番号`
    ,tbba001g.dd_touroku       AS `登録日`
    ,tbba001g.no_palkanri      AS   `tbba001g.ＰＡＬ管理ＮＯ`
    ,tbba001g.no_kanri         AS   `tbba001g.管理ＮＯ`
    ,tbba001g.no_yoyaku        AS   `tbba001g.予約ＮＯ`
    ,tbba001g.su_juchudai      AS   `tbba001g.受注台数`
    ,tbba001g.cd_zon           AS   `tbba001g.ゾーンコード`
    ,tbba001g.cd_tenpo         AS   `tbba001g.店舗コード`
    ,tbba001g.cd_ka            AS   `tbba001g.課コード`
    ,tbba001g.cd_kakari        AS   `tbba001g.係コード`
    ,tbba001g.kb_yoyaku        AS   `tbba001g.予約区分`
    ,tbba001g.cd_hanstaff      AS   `tbba001g.販売スタッフコード`
    ,tbba001g.mj_hantenkt      AS   `tbba001g.販売店型式`
    ,tbba001g.mj_sinkysed      AS   `tbba001g.新旧世代`
    ,tbba001g.no_syadaiba      AS   `tbba001g.車台番号`
    ,tbba001g.no_siteruib      AS   `tbba001g.指定類別番号`
    ,tbba001g.mj_gaihansy      AS   `tbba001g.外鈑色`
    ,tbba001g.mj_iropadng      AS   `tbba001g.色パディング`
    ,tbba001g.cd_utihari       AS   `tbba001g.内張コード`
    ,tbba001g.cd_taiya         AS   `tbba001g.タイヤコード`
    ,tbba001g.mj_taiyacom      AS   `tbba001g.タイヤコメント`
    ,tbba001g.mj_makeop1       AS   `tbba001g.メーカーＯＰＴ１`
    ,tbba001g.mj_makeop2       AS   `tbba001g.メーカーＯＰＴ２`
    ,tbba001g.mj_makeop3       AS   `tbba001g.メーカーＯＰＴ３`
    ,tbba001g.mj_makeop4       AS   `tbba001g.メーカーＯＰＴ４`
    ,tbba001g.mj_makeop5       AS   `tbba001g.メーカーＯＰＴ５`
    ,tbba001g.mj_makeop6       AS   `tbba001g.メーカーＯＰＴ６`
    ,tbba001g.mj_makeop7       AS   `tbba001g.メーカーＯＰＴ７`
    ,tbba001g.mj_makeop8       AS   `tbba001g.メーカーＯＰＴ８`
    ,tbba001g.mj_makeop9       AS   `tbba001g.メーカーＯＰＴ９`
    ,tbba001g.mj_makeop10      AS   `tbba001g.メーカーＯＰＴ１０`
    ,tbba001g.mj_makeop11      AS   `tbba001g.メーカーＯＰＴ１１`
    ,tbba001g.mj_makeop12      AS   `tbba001g.メーカーＯＰＴ１２`
    ,tbba001g.mj_makeop13      AS   `tbba001g.メーカーＯＰＴ１３`
    ,tbba001g.mj_makeop14      AS   `tbba001g.メーカーＯＰＴ１４`
    ,tbba001g.mj_makeop15      AS   `tbba001g.メーカーＯＰＴ１５`
    ,tbba001g.mj_makeop16      AS   `tbba001g.メーカーＯＰＴ１６`
    ,tbba001g.kb_haraidas      AS   `tbba001g.払出区分`
    ,tbba001g.kb_yoto          AS   `tbba001g.用途区分`
    ,tbba001g.kb_toroku        AS   `tbba001g.登録区分`
    ,tbba001g.kb_genmen        AS   `tbba001g.減免区分`
    ,tbba001g.kb_jcsinpo       AS   `tbba001g.受注進捗区分`
    ,tbba001g.kb_torokkah      AS   `tbba001g.登録可否区分`
    ,tbba001g.kb_jibaeigy      AS   `tbba001g.自賠営業用区分`
    ,tbba001g.no_tysenkib      AS   `tbba001g.抽選希望ＮＯ`
    ,tbba001g.no_ipankibo      AS   `tbba001g.一般希望ＮＯ`
    ,tbba001g.mj_jikosiki      AS   `tbba001g.字光式`
    ,tbba001g.mj_nosybas       AS   `tbba001g.納車場所`
    ,tbba001g.mj_syateira      AS   `tbba001g.車両手配依頼`
    ,tbba001g.dd_syrythir      AS   `tbba001g.車両手配依頼日`
    ,tbba001g.cd_kainusig      AS   `tbba001g.買主業者コード`
    ,tbba001g.kb_gyosynys      AS   `tbba001g.業者名寄せ区分`
    ,tbba001g.kj_kainmei1      AS   `tbba001g.買主名漢字１`
    ,tbba001g.kj_kainmei2      AS   `tbba001g.買主名漢字２`
    ,tbba001g.kj_meigime1      AS   `tbba001g.名義人名漢字１`
    ,tbba001g.kj_meigime2      AS   `tbba001g.名義人名漢字２`
    ,tbba001g.mj_kainmgka      AS   `tbba001g.買主名義人関係`
    ,tbba001g.mj_siyohonk      AS   `tbba001g.使用本拠地`
    ,tbba001g.mj_siyohnkk      AS   `tbba001g.使用本拠地小字`
    ,tbba001g.kj_siyohonk      AS   `tbba001g.使用本拠地名`
    ,tbba001g.kb_syokenry      AS   `tbba001g.所有権留保区分`
    ,tbba001g.kb_tasnowko      AS   `tbba001g.多降雪控除区分`
    ,tbba001g.kb_ritojiba      AS   `tbba001g.離島自賠責区分`
    ,tbba001g.mj_cymonm1       AS   `tbba001g.注文メモ１`
    ,tbba001g.mj_cymonm2       AS   `tbba001g.注文メモ２`
    ,tbba001g.mj_cymonnin      AS   `tbba001g.注文任意メモ`
    ,tbba001g.cd_teritbsy      AS   `tbba001g.テリトリ部署コード`
    ,tbba001g.kb_tyonou        AS   `tbba001g.直納区分`
    ,tbba001g.mj_tntbusen      AS   `tbba001g.担当物流センター`
    ,tbba001g.kj_tuikomem      AS   `tbba001g.追工メモ`
    ,tbba001g.mj_freeto        AS   `tbba001g.フリート`
    ,tbba001g.mj_reigai        AS   `tbba001g.例外`
    ,tbba001g.mj_jucyhkok      AS   `tbba001g.受注報告一覧出力済ＦＬＧ`
    ,tbba001g.kb_yudamhab      AS   `tbba001g.有玉販売区分`
    ,tbba001g.dd_frjknkab      AS   `tbba001g.振当条件完備日`
    ,tbba001g.dd_paltymsk      AS   `tbba001g.ＰＡＬ注文書作成日`
    ,tbba001g.dd_jucyuhas      AS   `tbba001g.受注発生日`
    ,tbba001g.dd_jucyuke       AS   `tbba001g.受注計上日`
    ,tbba001g.dd_jucyu         AS   `tbba001g.受注日`
    ,tbba001g.dd_jokenhen      AS   `tbba001g.条件変更日`
    ,tbba001g.mj_simuksak      AS   `tbba001g.仕向先`
    ,tbba001g.no_order         AS   `tbba001g.オーダーＮＯ`
    ,tbba001g.mj_katahima      AS   `tbba001g.型式ハイフン前`
    ,tbba001g.no_frame         AS   `tbba001g.フレームＮＯ`
    ,tbba001g.dd_siire         AS   `tbba001g.仕入日`
    ,tbba001g.dd_frkanou       AS   `tbba001g.振当可能日`
    ,tbba001g.dd_frkej         AS   `tbba001g.振当計上日`
    ,tbba001g.dd_krhuri        AS   `tbba001g.仮振当日`
    ,tbba001g.dd_fr            AS   `tbba001g.振当日`
    ,tbba001g.dd_frtoriks      AS   `tbba001g.振当取消日`
    ,tbba001g.mj_frtorikr      AS   `tbba001g.振当取消理由`
    ,tbba001g.dd_kibonoki      AS   `tbba001g.希望納期`
    ,tbba001g.dd_torokibo      AS   `tbba001g.登録希望日`
    ,tbba001g.dd_touroku       AS   `tbba001g.登録日`
    ,tbba001g.dd_honbsyok      AS   `tbba001g.本部書類全完日`
    ,tbba001g.dd_tenpsyok      AS   `tbba001g.店舗書類全完日`
    ,tbba001g.cd_toroirai      AS   `tbba001g.登録代行依頼元販売店コード`
    ,tbba001g.dd_torodaik      AS   `tbba001g.登録代行受付日`
    ,tbba001g.dd_torotrkk      AS   `tbba001g.登録取消計上日`
    ,tbba001g.dd_uritrkkj      AS   `tbba001g.売上取消計上日`
    ,tbba001g.dd_modurikj      AS   `tbba001g.戻し売上計上日`
    ,tbba001g.dd_uriagekj      AS   `tbba001g.売上計上日`
    ,tbba001g.dd_uritorik      AS   `tbba001g.売上取消日`
    ,tbba001g.dd_moduriag      AS   `tbba001g.戻し売上日`
    ,tbba001g.dd_uriage        AS   `tbba001g.売上日`
    ,tbba001g.dd_urikzumi      AS   `tbba001g.売掛金完済日`
    ,tbba001g.dd_nosya         AS   `tbba001g.納車日`
    ,tbba001g.nu_nosysokm      AS   `tbba001g.納車時走行キロ`
    ,tbba001g.dd_haiskibo      AS   `tbba001g.配送希望日`
    ,tbba001g.dd_haisou        AS   `tbba001g.配送日`
    ,tbba001g.tm_haisotai      AS   `tbba001g.配送時間帯`
    ,tbba001g.cd_haisskdr      AS   `tbba001g.配送先ディーラーコード`
    ,tbba001g.dd_joknhkhk      AS   `tbba001g.条件変更不可日付`
    ,tbba001g.dd_haisoyot      AS   `tbba001g.配送予定日`
    ,tbba001g.mj_haisosak      AS   `tbba001g.配送先`
    ,tbba001g.kj_naisomem      AS   `tbba001g.配送メモ`
    ,tbba001g.nu_sagyjyn       AS   `tbba001g.作業順位`
    ,tbba001g.dd_sagtyyo       AS   `tbba001g.作業着手予定日`
    ,tbba001g.kb_daihynai      AS   `tbba001g.代表作業難易度区分`
    ,tbba001g.tm_totutmke      AS   `tbba001g.取付時間計`
    ,tbba001g.kb_tokuso        AS   `tbba001g.特装区分`
    ,tbba001g.kb_tokusouk      AS   `tbba001g.特装受付区分`
    ,tbba001g.dd_tokusosg      AS   `tbba001g.特装作業日数`
    ,tbba001g.dd_toksokry      AS   `tbba001g.特装完了予定日`
    ,tbba001g.dd_sagtyak       AS   `tbba001g.作業着手日`
    ,tbba001g.dd_sagyokan      AS   `tbba001g.作業完了日`
    ,tbba001g.mj_iraibumo      AS   `tbba001g.依頼部門`
    ,tbba001g.dd_totyakuy      AS   `tbba001g.到着予定日`
    ,tbba001g.dd_totykykg      AS   `tbba001g.到着予定日加算後`
    ,tbba001g.dd_haisosru      AS   `tbba001g.配送車両受取日`
    ,tbba001g.dd_syakihka      AS   `tbba001g.車両基本確定日`
    ,tbba001g.no_syakihjo      AS   `tbba001g.車両基本条件変更枝番`
    ,tbba001g.mj_syssiym       AS   `tbba001g.最終仕様無ＦＬＧ`
    ,tbba001g.mj_nysjkk        AS   `tbba001g.名寄せ実行ＦＬＧ買主`
    ,tbba001g.mj_nysjkksy      AS   `tbba001g.名寄せ実行ＦＬＧ買主車両`
    ,tbba001g.mj_nysjkm        AS   `tbba001g.名寄せ実行ＦＬＧ名義人`
    ,tbba001g.dd_fuzkspsi      AS   `tbba001g.付属品特別仕様確定日`
    ,tbba001g.dd_hanbkaku      AS   `tbba001g.販売条件確定日`
    ,tbba001g.dd_sitajkak      AS   `tbba001g.下取車情報確定日`
    ,tbba001g.dd_sykajoka      AS   `tbba001g.紹介者情報確定日`
    ,tbba001g.dd_kyakkaku      AS   `tbba001g.お客様詳細確定日`
    ,tbba001g.dd_sonknkak      AS   `tbba001g.損金残益確定日`
    ,tbba001g.dd_cynyukan      AS   `tbba001g.注文書入力完全完了日`
    ,tbba001g.dd_seikysak      AS   `tbba001g.請求書作成日`
    ,tbba001g.dd_jibsysak      AS   `tbba001g.自賠責証明書作成日`
    ,tbba001g.no_nohinsek      AS   `tbba001g.納品請求書ＮＯ`
    ,tbba001g.no_gosnseky      AS   `tbba001g.合算請求書ＮＯ`
    ,tbba001g.su_hokenkim      AS   `tbba001g.保険期間月数`
    ,tbba001g.dd_hokenkij      AS   `tbba001g.保険期間至`
    ,tbba001g.dd_hokenkii      AS   `tbba001g.保険期間自`
    ,tbba001g.mj_oyaari        AS   `tbba001g.親有ＦＬＧ`
    ,tbba001g.mj_joknhkhy      AS   `tbba001g.条件変更表示フラグ`
    ,tbba001g.dd_torikesi      AS   `tbba001g.取消日`
    ,tbba001g.cd_toririyu      AS   `tbba001g.取消理由コード`
    ,tbba001g.cd_toristaf      AS   `tbba001g.取消スタッフコード`
    ,tbba001g.mj_copynofl      AS   `tbba001g.コピーＮＯＦＬＧ`
    ,tbba001g.kb_hisenkan      AS   `tbba001g.品番選択完了区分`
    ,tbba001g.mj_dfsckanr      AS   `tbba001g.ＤＦＳＣ寒冷地`
    ,tbba001g.kb_tuiksjin      AS   `tbba001g.追工指示票印刷区分`
    ,tbba001g.no_kytyumon      AS   `tbba001g.旧注文ＮＯ`
    ,tbba001g.no_kytymoed      AS   `tbba001g.旧注文ＮＯ枝番`
    ,tbba001g.cd_kyhabstf      AS   `tbba001g.旧販売スタッフコード`
    ,tbba001g.no_sintymon      AS   `tbba001g.新注文ＮＯ`
    ,tbba001g.no_sintymed      AS   `tbba001g.新注文ＮＯ枝番`
    ,tbba001g.cd_sihabstf      AS   `tbba001g.新販売スタッフコード`
    ,tbba001g.no_skycymon      AS   `tbba001g.送信旧注文ＮＯ`
    ,tbba001g.no_skycymed      AS   `tbba001g.送信旧注文ＮＯ枝番`
    ,tbba001g.kb_8no           AS   `tbba001g.８ＮＯ区分`
    ,tbba001g.mj_listoutf      AS   `tbba001g.リスト出力フラグ`
    ,tbba001g.mj_sosinerf      AS   `tbba001g.送信エラーフラグ`
    ,tbba001g.mj_kaktshrp      AS   `tbba001g.確定お支払いプラン`
    ,tbba001g.kb_busiji        AS   `tbba001g.物流指示区分`
    ,tbba001g.kb_buhtejot      AS   `tbba001g.部品手配状態区分`
    ,tbba001g.kb_zekomiin      AS   `tbba001g.税込入力区分`
    ,tbba001g.kb_yotaku        AS   `tbba001g.預託区分`
    ,tbba001g.dd_yotakuyt      AS   `tbba001g.預託予定日`
    ,tbba001g.nu_syrdstjr      AS   `tbba001g.シュレッダーダスト重量増減`
    ,tbba001g.mj_arcnscum      AS   `tbba001g.エアコン装着有無`
    ,tbba001g.kb_tokusyu       AS   `tbba001g.特殊区分`
    ,tbba001g.kb_houtaksh      AS   `tbba001g.法対象架装物区分変更値`
    ,tbba001g.kb_sekydtss      AS   `tbba001g.請求データ送信区分`
    ,tbba001g.kb_yohndtss      AS   `tbba001g.用品品番データ送信区分`
    ,tbba001g.kb_osssin        AS   `tbba001g.ＯＳＳ申請区分`
    ,tbba001g.kb_siyozkis      AS   `tbba001g.使用済記載区分`
    ,tbba001g.kb_stjizeso      AS   `tbba001g.下取自動車税相当額表示区分`
    ,tbba001g.dd_hosysyhk      AS   `tbba001g.保証書発行日`
    ,tbba001g.kb_kamitjis      AS   `tbba001g.保険かんたん見積実施区分`
    ,tbba001g.kb_symitjis      AS   `tbba001g.保険詳細見積実施区分`
    ,tbba001g.mj_junknorn      AS   `tbba001g.旬間オーダー連番`
    ,tbba001g.kb_iko           AS   `tbba001g.移行区分`
    ,tbba001g.mj_gbkprint      AS   `tbba001g.ＧＢＯＯＫ申込書印刷済フラグ`
    ,tbba001g.kb_telmnavi      AS   `tbba001g.テレマナビ区分`
    ,tbba001g.mj_telmnavs      AS   `tbba001g.テレマナビ種別`
    ,tbba001g.cd_telmnavi      AS   `tbba001g.テレマナビコード`
    ,tbba001g.cd_telnavsy      AS   `tbba001g.テレマ車名コード`
    ,tbba001g.kb_espotai       AS   `tbba001g.ＥＳＰＯ対象区分`
    ,tbba001g.kb_ptlmnavi      AS   `tbba001g.ＰＡＬテレマナビ区分`
    ,tbba001g.mj_ptlmnavs      AS   `tbba001g.ＰＡＬテレマナビ種別`
    ,tbba001g.cd_ptlmnavi      AS   `tbba001g.ＰＡＬテレマナビコード`
    ,tbba001g.cd_ptlnavsy      AS   `tbba001g.ＰＡＬテレマ車名コード`
    ,tbba001g.kb_pespotai      AS   `tbba001g.ＰＡＬＥＳＰＯ対象区分`
    ,tbba001g.mj_znfratjt      AS   `tbba001g.前回振当状態`
    ,tbba001g.dd_znfratmd      AS   `tbba001g.前回振当月日`
    ,tbba001g.kb_znfurate      AS   `tbba001g.前回振当区分`
    ,tbba001g.dd_znhaisou      AS   `tbba001g.前回配送日`
    ,tbba001g.kj_znhaisoj      AS   `tbba001g.前回配送状況`
    ,tbba001g.dt_znsyokai      AS   `tbba001g.前回照会日時`
    ,tbba001g.kb_zjsyori       AS   `tbba001g.前日処理ＦＬＧ`
    ,tbba001g.kb_zjzaikoj      AS   `tbba001g.前日在庫状態区分`
    ,tbba001g.dd_zjfryote      AS   `tbba001g.前日振当予定日`
    ,tbba001g.dd_zjkrhuri      AS   `tbba001g.前日仮振当日`
    ,tbba001g.dd_zjfr          AS   `tbba001g.前日振当日`
    ,tbba001g.dd_zjhaisou      AS   `tbba001g.前日配送表示日`
    ,tbba001g.mj_zjhaist       AS   `tbba001g.前日配送ステータス`
    ,tbba001g.kb_zzsyori       AS   `tbba001g.前々日処理ＦＬＧ`
    ,tbba001g.kb_zzzaikoj      AS   `tbba001g.前々日在庫状態区分`
    ,tbba001g.dd_zzfryote      AS   `tbba001g.前々日振当予定日`
    ,tbba001g.dd_zzkrhuri      AS   `tbba001g.前々日仮振当日`
    ,tbba001g.dd_zzfr          AS   `tbba001g.前々日振当日`
    ,tbba001g.dd_zzhaisou      AS   `tbba001g.前々日配送表示日`
    ,tbba001g.mj_zzhaist       AS   `tbba001g.前々日配送ステータス`
    ,tbba001g.kb_sysnhosy      AS   `tbba001g.小損害保証区分`
    ,tbba001g.dd_sysnhshk      AS   `tbba001g.小損害保証書発行日`
    ,tbba001g.kb_rtnsyry       AS   `tbba001g.Ｒ店車両区分`
    ,tbba001g.no_rtnhaty       AS   `tbba001g.Ｒ店車両発注ＮＯ`
    ,tbba001g.no_rtnhaed       AS   `tbba001g.Ｒ店車両発注ＮＯ枝番`
    ,tbba001g.mj_syatkid       AS   `tbba001g.車両特定ＩＤ`
    ,tbba001g.dd_rtntry        AS   `tbba001g.Ｒ店登録予定日`
    /*
    ,CAST(
        CONCAT(
            SUBSTR(CAST(tbba001g.dd_rtntry AS STRING), 1, 4), '-',
            SUBSTR(CAST(tbba001g.dd_rtntry AS STRING), 5, 2), '-',
            SUBSTR(CAST(tbba001g.dd_rtntry AS STRING), 7, 2)
        ) AS TIMESTAMP
     ) AS 'Ｒ店登録予定日'
     */
    ,tbba031g.dd_toroyote    AS   `Ｒ店登録予定日`
    ,tbba001g.dd_rtnnsy      AS   `tbba001g.Ｒ店納車予定日`
    ,tbba001g.dd_rtntsh      AS   `tbba001g.Ｒ店登録書類必着日`
    ,tbba001g.dd_rtnfri      AS   `tbba001g.Ｒ店振当結果送付日`
    ,tbba001g.kb_icjrnkum    AS   `tbba001g.ＩＣＲＯＰＪ連携有無`
    ,tbba001g.kb_kinto       AS   `tbba001g.ＫＩＮＴＯ区分`
    ,tbba001g.dt_saisinup    AS   `tbba001g.最新更新日時`
    ,tbba001g.mj_sasintan    AS   `tbba001g.最新更新端末ＩＤ`
    ,tbv0014m.cd_syain       AS   `tbv0014m.社員コード`
    ,tbv0014m.kj_syainmei      AS   `tbv0014m.社員名`
    ,tbv0014m.kb_syainzok      AS   `tbv0014m.社員属性`
    ,tbv0014m.cd_syozoten      AS   `tbv0014m.所属店舗`
    ,tbv0014m.cd_syozoka      AS   `tbv0014m.所属課`
    ,tbv0014m.cd_syozokak      AS   `tbv0014m.所属係`
    ,tbv0014m.cd_syozobum      AS   `tbv0014m.所属部門`
    ,tbv0014m.mj_syanenji      AS   `tbv0014m.車両年次`
    ,tbv0014m.mj_syarank      AS   `tbv0014m.車両ランク`
    ,tbv0014m.kb_staffsin      AS   `tbv0014m.スタッフ新車`
    ,tbv0014m.kb_stafftyu      AS   `tbv0014m.スタッフ中古車`
    ,tbv0014m.kb_okyakuta      AS   `tbv0014m.お客様担当`
    ,tbv0014m.kb_staffduo      AS   `tbv0014m.スタッフＤＵＯ`
    ,tbv0014m.mj_staffsv      AS   `tbv0014m.スタッフサービス`
    ,tbv0014m.dd_taisyoku      AS   `tbv0014m.退職日`
    ,tbv0014m.kb_gyomkeng      AS   `tbv0014m.業務権限区分`
    ,tbv0014m.kb_tyokan      AS   `tbv0014m.直間区分`
    ,tbv0014m.kb_frestaff      AS   `tbv0014m.フリースタッフ区分`
    ,tbv0014m.dd_ido      AS   `tbv0014m.移動日`
    ,tbv0014m.mj_kysyztnp      AS   `tbv0014m.旧所属店舗`
    ,tbv0014m.mj_kysyzka      AS   `tbv0014m.旧所属課`
    ,tbv0014m.mj_kysyzkak      AS   `tbv0014m.旧所属係`
    ,tbv0014m.mj_kysyzbum      AS   `tbv0014m.旧所属部門`
    ,tbv0014m.kb_tasyskos      AS   `tbv0014m.他システム更新区分`
    ,tbv0014m.dd_todoke      AS   `tbv0014m.届出日`
    ,tbv0014m.dd_haisi      AS   `tbv0014m.廃止日`
    ,tbv0014m.kb_kyugyokn      AS   `tbv0014m.旧業務権限区分`
    ,tbv0014m.kb_usekbn      AS   `tbv0014m.ＡＴＳＣ利用区分`
    ,tbv0014m.mj_syainmei      AS   `tbv0014m.ＡＴＳＣ社員英名`
    ,tbv0014m.kb_honkbn      AS   `tbv0014m.ＡＴＳＣ本部店舗区分`
    ,tbv0014m.mj_login1      AS   `tbv0014m.ログインＩＤ１`
    ,tbv0014m.mj_login2      AS   `tbv0014m.ログインＩＤ２`
    ,tbv0014m.mj_login3      AS   `tbv0014m.ログインＩＤ３`
    ,tbv0014m.mj_login4      AS   `tbv0014m.ログインＩＤ４`
    ,tbv0014m.mj_login5      AS   `tbv0014m.ログインＩＤ５`
    ,tbv0014m.mj_login6      AS   `tbv0014m.ログインＩＤ６`
    ,tbv0014m.mj_login7      AS   `tbv0014m.ログインＩＤ７`
    ,tbv0014m.mj_login8      AS   `tbv0014m.ログインＩＤ８`
    ,tbv0014m.mj_login9      AS   `tbv0014m.ログインＩＤ９`
    ,tbv0014m.mj_login10      AS   `tbv0014m.ログインＩＤ１０`
    ,tbv0014m.mj_keisyo      AS   `tbv0014m.継承有無`
    ,tbv0014m.cd_kirkaisy      AS   `tbv0014m.切替可能会社`
    ,tbv0014m.cd_kirtenpo      AS   `tbv0014m.切替可能店舗`

    ,tbbf008m.mj_hantenkt     AS   `tbbf008m.販売店型式`
    ,tbbf008m.mj_sinkysed     AS   `tbbf008m.新旧世代`
    ,tbbf008m.kb_spec     AS   `tbbf008m.スペック区分`
    ,tbbf008m.cd_spec     AS   `tbbf008m.スペックコード`
    ,tbbf008m.no_hinmei     AS   `tbbf008m.品名連番`
    ,tbbf008m.mj_syamei     AS   `tbbf008m.車名`
    ,tbbf008m.ki_baika     AS   `tbbf008m.売価`
    ,tbbf008m.nu_kazejyry     AS   `tbbf008m.課税重量`
    ,tbbf008m.ki_jikasyzg     AS   `tbbf008m.自家用取得税額`
    ,tbbf008m.ki_eigysyga     AS   `tbbf008m.営業用取得税額`
    ,tbbf008m.ki_kanrigen     AS   `tbbf008m.管理原価`
    ,tbbf008m.nu_kanrgen     AS   `tbbf008m.管理原価率`
    ,tbbf008m.ki_yotegen     AS   `tbbf008m.予定原価`
    ,tbbf008m.nu_yotegnr     AS   `tbbf008m.予定原価率`
    ,tbbf008m.no_hyojsobh     AS   `tbbf008m.標準装備品ＮＯ`
    ,tbbf008m.mj_setkaumu     AS   `tbbf008m.セット価格有無`
    ,tbbf008m.mj_padhing     AS   `tbbf008m.パディング`
    ,tbbf008m.mj_hyojnais     AS   `tbbf008m.標準内装`
    ,tbbf008m.kb_siyohuka     AS   `tbbf008m.使用不可区分`
    ,tbbf008m.kb_kkkmhane     AS   `tbbf008m.価格未反映区分`
    ,tbbf008m.kb_modrst     AS   `tbbf008m.モデリスタ区分`
    ,tbbf008m.kb_palrenra     AS   `tbbf008m.ＰＡＬ連絡区分`
    ,tbbf008m.dd_jcutikri     AS   `tbbf008m.受注打切日`
    ,tbbf001m.cd_ncsyamei     AS   `tbbf001m.新車車名コード`
    ,tbbf001m.kn_syame     AS   `tbbf001m.カナ車名`
    ,tbbf001m.kj_kurumame     AS   `tbbf001m.漢字車名`
    ,tbbf001m.nu_symenarb     AS   `tbbf001m.車名並び順`
    ,tbbf001m.kb_oem     AS   `tbbf001m.ＯＥＭ区分`
    ,tbbf001m.kb_recycmks     AS   `tbbf001m.リサイクルメーカー識別区分`
    ,tbbf001m.kb_syasyu     AS   `tbbf001m.車種区分`
    ,tbbf001m.kb_jikajidz     AS   `tbbf001m.自家用自動車税区分`
    ,tbbf001m.kb_eigyjdsy     AS   `tbbf001m.営業用自動車税区分`
    ,tbbf001m.kb_jyuuzei     AS   `tbbf001m.重量税区分`
    ,tbbf001m.ki_yusohi     AS   `tbbf001m.輸送費`
    ,tbbf001m.kb_syohize     AS   `tbbf001m.消費税区分`
    ,tbbf001m.mj_haigasu     AS   `tbbf001m.排ガス記号`
    ,tbbf001m.kb_yoykkah     AS   `tbbf001m.予約可否区分`
    ,tbbf001m.su_yoykkano     AS   `tbbf001m.予約可能台数`
    ,tbbf001m.su_yoyayuko     AS   `tbbf001m.予約有効日数`
    ,tbbf001m.su_nokikasn     AS   `tbbf001m.仮納期加算日数`
    ,tbbf001m.su_kanseiks     AS   `tbbf001m.完成予定日加算日数`
    ,tbbf001m.su_kakunoki     AS   `tbbf001m.確定納期加算日数`
    ,tbbf001m.su_totyakuy     AS   `tbbf001m.到着予定日加算日数`
    ,tbbf001m.ki_nebkeiko     AS   `tbbf001m.値引き警告額`
    ,tbbf001m.nu_nebkeiko     AS   `tbbf001m.値引き警告率`
    ,tbbf001m.ki_nebjogen     AS   `tbbf001m.値引き上限額`
    ,tbbf001m.nu_nebjogen     AS   `tbbf001m.値引き上限率`
    ,tbbf001m.cd_21syamei     AS   `tbbf001m.ａｉ２１車名コード`
    ,tbbf001m.cd_yohinsya     AS   `tbbf001m.用品車名コード`
    ,tbbf001m.mj_farkanrg     AS   `tbbf001m.ファーム管理グループ`
    ,tbbf001m.kb_sobetu     AS   `tbbf001m.層別区分`
    ,tbbf001m.mj_zenjd     AS   `tbbf001m.全自動振当有無`
    ,tbbf001m.mj_zenjdkar     AS   `tbbf001m.全自動仮振当有無`
    ,tbbf001m.kb_orderkah     AS   `tbbf001m.オーダー可否区分`
    ,tbbf001m.ki_toksyne1     AS   `tbbf001m.特殊値引き警告額１`
    ,tbbf001m.nu_toksyne1     AS   `tbbf001m.特殊値引き警告率１`
    ,tbbf001m.ki_toksynj1     AS   `tbbf001m.特殊値引き上限額１`
    ,tbbf001m.nu_toksynj1     AS   `tbbf001m.特殊値引き上限率１`
    ,tbbf001m.ki_toksyne2     AS   `tbbf001m.特殊値引き警告額２`
    ,tbbf001m.nu_toksyne2     AS   `tbbf001m.特殊値引き警告率２`
    ,tbbf001m.ki_toksynj2     AS   `tbbf001m.特殊値引き上限額２`
    ,tbbf001m.nu_toksynj2     AS   `tbbf001m.特殊値引き上限率２`
    ,tbbf001m.ki_toksyne3     AS   `tbbf001m.特殊値引き警告額３`
    ,tbbf001m.nu_toksyne3     AS   `tbbf001m.特殊値引き警告率３`
    ,tbbf001m.ki_toksynj3     AS   `tbbf001m.特殊値引き上限額３`
    ,tbbf001m.nu_toksynj3     AS   `tbbf001m.特殊値引き上限率３`
    ,tbbf001m.nu_toksyby     AS   `tbbf001m.特殊売価率`
    ,tbbf001m.cd_busent     AS   `tbbf001m.物流センタコード`
    ,tbbf001m.cd_syuyaksy     AS   `tbbf001m.集約車名コード`
    ,tbbf001m.nu_risoptkz     AS   `tbbf001m.リースＯＰＴ加算係数`
    ,tbbf001m.kb_palrenra     AS   `tbbf001m.ＰＡＬ連絡区分`
    ,tbbf001m.mj_siki     AS   `tbbf001m.始期`
    ,tbbf001m.mj_syuuki     AS   `tbbf001m.終期`
    ,tbbf001m.kb_syasikib     AS   `tbbf001m.車名識別区分`
    ,tbbf001m.kb_seisansy     AS   `tbbf001m.生産車区分`
    ,tbbf001m.ki_honbkanr     AS   `tbbf001m.本部管理費`
    ,tbbf001m.kb_syatehai     AS   `tbbf001m.車両手配区分`
    ,tbbf001m.dd_syatehai     AS   `tbbf001m.車両手配日数`
    ,tbbf001m.dd_kankenkik     AS   `tbbf001m.完検切期間`
    ,tbbf001m.ki_afutas     AS   `tbbf001m.アフターサービス料`
    ,tbbf001m.cd_sinttuik     AS   `tbbf001m.新点追工コード`
    ,tbbf001m.nu_kanrgen     AS   `tbbf001m.管理原価率`
    ,tbbf001m.kb_kanrhas     AS   `tbbf001m.管理端数処理区分`
    ,tbbf001m.kb_nebset     AS   `tbbf001m.値引設定区分`
    ,tbbf001m.nu_yotegnr     AS   `tbbf001m.予定原価率`
    ,tbbf001m.kb_yotehssy     AS   `tbbf001m.予定端数処理区分`
    ,tbbf001m.kb_toksyhss     AS   `tbbf001m.特殊端数処理区分`
    ,tbbf001m.kb_zekmkths     AS   `tbbf001m.税込型式端数区分`
    ,tbbf001m.kb_zekmspch     AS   `tbbf001m.税込スペック端数区分`
    ,tbbf001m.kb_szekmkth     AS   `tbbf001m.新税込型式端数区分`
    ,tbbf001m.nu_zkmkkemz     AS   `tbbf001m.税込価格計算元税率`
    ,tbbf001m.cd_kairisya     AS   `tbbf001m.経理車名コード`
    ,tbbf001m.dd_jcutikri     AS   `tbbf001m.受注打切日`
    ,tbbf001m.ki_hyojrie     AS   `tbbf001m.標準利益`
    ,tbbf001m.su_hyojrisi     AS   `tbbf001m.標準利益使用台数`
    ,tbbf001m.cd_kykeirsy     AS   `tbbf001m.旧経理車名コード`
    ,tbbf001m.dd_kirikae     AS   `tbbf001m.切替日`
    ,tbbf001m.kb_siyofskh     AS   `tbbf001m.仕様振当照会可否区分`
    ,tbbf001m.kb_dfscjdst     AS   `tbbf001m.ＤＦＳＣ自動設定区分`
    ,tbbf001m.mj_sinkyhug     AS   `tbbf001m.新旧符号`
    ,tbbf001m.kb_toksyns1     AS   `tbbf001m.特殊値引設定区分１`
    ,tbbf001m.kb_toksyns2     AS   `tbbf001m.特殊値引設定区分２`
    ,tbbf001m.kb_toksyns3     AS   `tbbf001m.特殊値引設定区分３`
    ,tbbf001m.kn_kei     AS   `tbbf001m.軽区分`
    ,tbbf001m.kb_hyojnkai     AS   `tbbf001m.標準解除区分`
    ,tbbf001m.kb_tachasya     AS   `tbbf001m.他チャネル車両区分`
    ,tbbf001m.kb_pc10hisu     AS   `tbbf001m.ＰＣ１０非推奨区分`

    ,tltl2001.lskykno      AS `リース契約Ｎｏ`
    ,tltl2001.kata         AS `型式`
    ,tltl2001.toshokcd     AS `塗色`
    ,tltl2031.hchymd       AS `発注年月日`
    ,tltl2031.noshakiboymd AS `納車希望年月日`
    ,tltl2031.trkkiboymd AS `登録希望日`

    ,tltl2001.RTENID AS `tltl2001.Ｒ店ＩＤ`
    ,tltl2001.LSKYKNO AS `tltl2001.リース契約Ｎｏ`
    ,tltl2001.SHDNNO AS `tltl2001.商談Ｎｏ`
    ,tltl2001.SHDNNOSC AS `tltl2001.商談Ｎｏ枝番`
    ,tltl2001.ANKENGRPNO AS `tltl2001.案件グループＮｏ`
    ,tltl2001.ANKENGRPSC AS `tltl2001.案件グループ枝番`
    ,tltl2001.ZNLSKYKNO AS `tltl2001.前リース契約Ｎｏ`
    ,tltl2001.NXTLSKYKNO AS `tltl2001.次リース契約Ｎｏ`
    ,tltl2001.KYKSKCD AS `tltl2001.契約先コード`
    ,tltl2001.SKYSKCD AS `tltl2001.請求先コード`
    ,tltl2001.USESKCD AS `tltl2001.使用先コード`
    ,tltl2001.TKSKCD AS `tltl2001.点検先コード`
    ,tltl2001.SCNKYKSKCD AS `tltl2001.２次契約先コード`
    ,tltl2001.SCNKYKSKNM1 AS `tltl2001.２次契約先名称１`
    ,tltl2001.SCNKYKSKNM2 AS `tltl2001.２次契約先名称２`
    ,tltl2001.TNTSHOPCD AS `tltl2001.担当ショップコード`
    ,tltl2001.TNTSHOPNM1 AS `tltl2001.担当ショップ名１`
    ,tltl2001.TNTSHOPNM2 AS `tltl2001.担当ショップ名２`
    ,tltl2001.EXPRANNAISFSCD AS `tltl2001.満了案内送付先コード`
    ,tltl2001.LSKTAI AS `tltl2001.リース形態`
    ,tltl2001.LSKIKN AS `tltl2001.リース期間`
    ,tltl2001.LSSYMD AS `tltl2001.リース開始年月日`
    ,tltl2001.LSEYMD AS `tltl2001.リース終了年月日`
    ,tltl2001.LSKISU AS `tltl2001.リース回数`
    ,tltl2001.LSURISUMIKISU AS `tltl2001.リース売上済回数`
    ,tltl2001.LSHOSK AS `tltl2001.リース方式`
    ,tltl2001.FLEETMNTKBN AS `tltl2001.フリートメンテナンス区分`
    ,tltl2001.NUKBN AS `tltl2001.新中区分`
    ,tltl2001.KYKKTAICD AS `tltl2001.契約形態コード`
    ,tltl2001.RELSKBN AS `tltl2001.再リース区分`
    ,tltl2001.TKEILSHOSK AS `tltl2001.提携リース方式`
    ,tltl2001.TKEISKCD AS `tltl2001.提携先コード`
    ,tltl2001.LSSSNBNR AS `tltl2001.リース資産分類`
    ,tltl2001.CARNMCD AS `tltl2001.車名コード`
    ,tltl2001.REFCARNMCD AS `tltl2001.参照車名コード`
    ,tltl2001.SHDNCARNM AS `tltl2001.商談車名`
    ,tltl2001.GRDNM AS `tltl2001.グレード名`
    ,tltl2001.BDYNM AS `tltl2001.ボディ名`
    ,tltl2001.ENGINNM AS `tltl2001.エンジン名`
    ,tltl2001.MISSIONNM AS `tltl2001.ミッション名`
    ,tltl2001.MKRCARNMCD AS `tltl2001.メーカー車名コード`
    ,tltl2001.SHGNGEN AS `tltl2001.諸元世代`
    ,tltl2001.MKRKATA AS `tltl2001.メーカー型式`
    ,tltl2001.SNGYSHRKBN AS `tltl2001.産業車両区分`
    ,tltl2001.TRKNOPLTNO AS `tltl2001.登録ＮｏプレートＮｏ`
    ,tltl2001.TRKNORKSCD AS `tltl2001.登録Ｎｏ陸支コード`
    ,tltl2001.TRKNOSHSHKBN AS `tltl2001.登録Ｎｏ車種区分`
    ,tltl2001.TRKNONK AS `tltl2001.登録Ｎｏカナ`
    ,tltl2001.SHADINO AS `tltl2001.車台番号`
    ,tltl2001.KATA AS `tltl2001.型式`
    ,tltl2001.TOSHOKCD AS `tltl2001.塗色コード`
    ,tltl2001.NAISOSHOKCD AS `tltl2001.内装色コード`
    ,tltl2001.NENRYOKBN AS `tltl2001.燃料区分`
    ,tltl2001.SNGYSHRKYKSHFLG AS `tltl2001.産業車両契約書フラグ`
    ,tltl2001.NOZEISHSHKBN AS `tltl2001.納税車種区分`
    ,tltl2001.SHKNYOHIFLG AS `tltl2001.車検要否フラグ`
    ,tltl2001.HTNYOHIFLG AS `tltl2001.法点要否フラグ`
    ,tltl2001.SHKNCYCLSHKAI AS `tltl2001.車検サイクル初回`
    ,tltl2001.SHKNCYCLSCNIKO AS `tltl2001.車検サイクル２回目以降`
    ,tltl2001.NOSHABASHOCD AS `tltl2001.納車場所コード`
    ,tltl2001.MSOKOKYORI AS `tltl2001.月走行距離`
    ,tltl2001.OVRSOKORYO AS `tltl2001.超過走行料`
    ,tltl2001.SHRHONTAINCARJIKK AS `tltl2001.車両本体新車時価格`
    ,tltl2001.SHRHONTAIZNKYKKK AS `tltl2001.車両本体前契約価格`
    ,tltl2001.SHRHONTAIGKAKK AS `tltl2001.車両本体原価価格`
    ,tltl2001.SHRHONTAISIRKK AS `tltl2001.車両本体仕入価格`
    ,tltl2001.TRKNOSHAHYOUMFLG AS `tltl2001.登録納車費用有無フラグ`
    ,tltl2001.TRKNOSHAHYO AS `tltl2001.登録納車費用`
    ,tltl2001.SHTKTXUMFLG AS `tltl2001.取得税有無フラグ`
    ,tltl2001.SHTKTX AS `tltl2001.取得税`
    ,tltl2001.JURYOTXUMKBN AS `tltl2001.重量税有無区分`
    ,tltl2001.JURYOTX1NENMEKNGK AS `tltl2001.重量税１年目金額`
    ,tltl2001.JURYOTX2NENMEKNGK AS `tltl2001.重量税２年目金額`
    ,tltl2001.JURYOTX3NENMEKNGK AS `tltl2001.重量税３年目金額`
    ,tltl2001.JURYOTX4NENMEKNGK AS `tltl2001.重量税４年目金額`
    ,tltl2001.JURYOTX5NENMEKNGK AS `tltl2001.重量税５年目金額`
    ,tltl2001.JURYOTX6NENMEKNGK AS `tltl2001.重量税６年目金額`
    ,tltl2001.JURYOTX7NENMEKNGK AS `tltl2001.重量税７年目金額`
    ,tltl2001.JURYOTX8NENMEKNGK AS `tltl2001.重量税８年目金額`
    ,tltl2001.JURYOTXGOKKNGK AS `tltl2001.重量税合計金額`
    ,tltl2001.JURYOTXKISU AS `tltl2001.重量税回数`
    ,tltl2001.JBSKUMKBN AS `tltl2001.自賠責有無区分`
    ,tltl2001.JBSKKISU AS `tltl2001.自賠責回数`
    ,tltl2001.JBSK1NENMEKNGK AS `tltl2001.自賠責１年目金額`
    ,tltl2001.JBSK2NENMEKNGK AS `tltl2001.自賠責２年目金額`
    ,tltl2001.JBSK3NENMEKNGK AS `tltl2001.自賠責３年目金額`
    ,tltl2001.JBSK4NENMEKNGK AS `tltl2001.自賠責４年目金額`
    ,tltl2001.JBSK5NENMEKNGK AS `tltl2001.自賠責５年目金額`
    ,tltl2001.JBSK6NENMEKNGK AS `tltl2001.自賠責６年目金額`
    ,tltl2001.JBSK7NENMEKNGK AS `tltl2001.自賠責７年目金額`
    ,tltl2001.JBSK8NENMEKNGK AS `tltl2001.自賠責８年目金額`
    ,tltl2001.JBSKGOKKNGK AS `tltl2001.自賠責合計金額`
    ,tltl2001.JBSKKANYUKBN AS `tltl2001.自賠責加入区分`
    ,tltl2001.JBSKSNPSTEIFLG AS `tltl2001.自賠責損保指定フラグ`
    ,tltl2001.JBSKSNPKSHCD AS `tltl2001.自賠責損保会社コード`
    ,tltl2001.JBSKDIRTNSTEIFLG AS `tltl2001.自賠責代理店指定フラグ`
    ,tltl2001.JBSKDIRTNNM AS `tltl2001.自賠責代理店名`
    ,tltl2001.CARTXUMKBN AS `tltl2001.自動車税有無区分`
    ,tltl2001.CARTXKISU AS `tltl2001.自動車税回数`
    ,tltl2001.CARTXCHIKBTKBN AS `tltl2001.自動車税地区別区分`
    ,tltl2001.CARTXSHNENDKNGK AS `tltl2001.自動車税初年度金額`
    ,tltl2001.CARTX2NENDKNGK AS `tltl2001.自動車税２年度金額`
    ,tltl2001.CARTX3NENDKNGK AS `tltl2001.自動車税３年度金額`
    ,tltl2001.CARTX4NENDKNGK AS `tltl2001.自動車税４年度金額`
    ,tltl2001.CARTX5NENDKNGK AS `tltl2001.自動車税５年度金額`
    ,tltl2001.CARTX6NENDKNGK AS `tltl2001.自動車税６年度金額`
    ,tltl2001.CARTX7NENDKNGK AS `tltl2001.自動車税７年度金額`
    ,tltl2001.CARTX8NENDKNGK AS `tltl2001.自動車税８年度金額`
    ,tltl2001.CARTXGOKKNGK AS `tltl2001.自動車税合計金額`
    ,tltl2001.SHKIRYOUMFLG AS `tltl2001.紹介料有無フラグ`
    ,tltl2001.SHKIRYO AS `tltl2001.紹介料`
    ,tltl2001.HOJOKNUMFLG AS `tltl2001.補助金有無フラグ`
    ,tltl2001.HOJOKN AS `tltl2001.補助金`
    ,tltl2001.HOJOKNHNKYAKKBN AS `tltl2001.補助金返却区分`
    ,tltl2001.STAFINCEJKNUMFLG AS `tltl2001.その他ファイナンス条件有無フラグ`
    ,tltl2001.STAFINCEHYO AS `tltl2001.その他ファイナンス費用`
    ,tltl2001.NHKNUMFLG AS `tltl2001.任意保険有無フラグ`
    ,tltl2001.NHKNKISU AS `tltl2001.任意保険回数`
    ,tltl2001.NHKNMSKDITOSHFTNUMFLG AS `tltl2001.任意保険免責代当社負担有無フラグ`
    ,tltl2001.NHKNMSKDITOSHFTNKYKKISU AS `tltl2001.任意保険免責代当社負担契約回数`
    ,tltl2001.NHKNMSKDITOSHFTNKYKGKA AS `tltl2001.任意保険免責代当社負担契約原価`
    ,tltl2001.JIKOHSOUMFLG AS `tltl2001.事故補償有無フラグ`
    ,tltl2001.JAFUMFLG AS `tltl2001.ＪＡＦ有無フラグ`
    ,tltl2001.JAFHYO AS `tltl2001.ＪＡＦ費用`
    ,tltl2001.SPOTDIALUMFLG AS `tltl2001.サポートダイヤル有無フラグ`
    ,tltl2001.KYUYUCARDUMFLG AS `tltl2001.給油カード有無フラグ`
    ,tltl2001.KYUYUCARDSBT AS `tltl2001.給油カード種別`
    ,tltl2001.G_BOOKUMFLG AS `tltl2001.Ｇ－ＢＯＯＫ有無フラグ`
    ,tltl2001.G_BOOKHYO AS `tltl2001.Ｇ－ＢＯＯＫ費用`
    ,tltl2001.MNTKBN AS `tltl2001.メンテナンス区分`
    ,tltl2001.SVREKBN AS `tltl2001.シビア区分`
    ,tltl2001.SFMKYKUMFLG AS `tltl2001.ＳＦＭ契約有無フラグ`
    ,tltl2001.SFMSHSHTYP AS `tltl2001.ＳＦＭ車種タイプ`
    ,tltl2001.SFMNOUHIKIUMFLG AS `tltl2001.ＳＦＭ納引有無フラグ`
    ,tltl2001.SFMHOMONTKUMFLG AS `tltl2001.ＳＦＭ訪問点検有無フラグ`
    ,tltl2001.SFMHOMONTKCYCL AS `tltl2001.ＳＦＭ訪問点検サイクル`
    ,tltl2001.SFMSHSHCLS AS `tltl2001.ＳＦＭ車種クラス`
    ,tltl2001.SFMSOKOKYORICLS AS `tltl2001.ＳＦＭ走行距離クラス`
    ,tltl2001.SHKNUMFLG AS `tltl2001.車検有無フラグ`
    ,tltl2001.SHKNKISU AS `tltl2001.車検回数`
    ,tltl2001.SHKNTEIKA AS `tltl2001.車検定価`
    ,tltl2001.SHKNGKA AS `tltl2001.車検原価`
    ,tltl2001.SHKNHNKUMFLG AS `tltl2001.車検変更有無フラグ`
    ,tltl2001.SHKNFUTAITEIKA AS `tltl2001.車検付帯定価`
    ,tltl2001.SHKNFUTAIGKA AS `tltl2001.車検付帯原価`
    ,tltl2001.SHKNFUTAIHNKUMFLG AS `tltl2001.車検付帯変更有無フラグ`
    ,tltl2001.HTENUMFLG AS `tltl2001.法点有無フラグ`
    ,tltl2001.HTNCYCL AS `tltl2001.法点サイクル`
    ,tltl2001.HTENKISU AS `tltl2001.法点回数`
    ,tltl2001.HTENTEIKA AS `tltl2001.法点定価`
    ,tltl2001.HTENGKA AS `tltl2001.法点原価`
    ,tltl2001.HTENHNKUMFLG AS `tltl2001.法点変更有無フラグ`
    ,tltl2001.HTENFUTAITEIKA AS `tltl2001.法点付帯定価`
    ,tltl2001.HTENFUTAIGKA AS `tltl2001.法点付帯原価`
    ,tltl2001.HTENFUTAIHNKUMFLG AS `tltl2001.法点付帯変更有無フラグ`
    ,tltl2001.PRO10UMFLG AS `tltl2001.プロケア１０有無フラグ`
    ,tltl2001.PRO10KISU AS `tltl2001.プロケア１０回数`
    ,tltl2001.PRO10TEIKA AS `tltl2001.プロケア１０定価`
    ,tltl2001.PRO10GKA AS `tltl2001.プロケア１０原価`
    ,tltl2001.PRO10HNKUMFLG AS `tltl2001.プロケア１０変更有無フラグ`
    ,tltl2001.PRO10FUTAITEIKA AS `tltl2001.プロケア１０付帯定価`
    ,tltl2001.PRO10FUTAIGKA AS `tltl2001.プロケア１０付帯原価`
    ,tltl2001.PRO10FUTAIHNKUMFLG AS `tltl2001.プロケア１０付帯変更有無フラグ`
    ,tltl2001.IPNSEIBIUMFLG AS `tltl2001.一般整備有無フラグ`
    ,tltl2001.IPNSEIBITEIKA AS `tltl2001.一般整備定価`
    ,tltl2001.IPNSEIBIGKA AS `tltl2001.一般整備原価`
    ,tltl2001.IPNSEIBIHNKUMFLG AS `tltl2001.一般整備変更有無フラグ`
    ,tltl2001.JIKOREPAIRUMFLG AS `tltl2001.事故修理有無フラグ`
    ,tltl2001.OILUMFLG AS `tltl2001.オイル有無フラグ`
    ,tltl2001.OILKISU AS `tltl2001.オイル回数`
    ,tltl2001.OILTEIKA AS `tltl2001.オイル定価`
    ,tltl2001.OILGKA AS `tltl2001.オイル原価`
    ,tltl2001.OILHNKUMFLG AS `tltl2001.オイル変更有無フラグ`
    ,tltl2001.BTTRYUMFLG AS `tltl2001.バッテリー有無フラグ`
    ,tltl2001.BTTRYKOSU AS `tltl2001.バッテリー個数`
    ,tltl2001.BTTRYNM1 AS `tltl2001.バッテリー名称１`
    ,tltl2001.BTTRYNM2 AS `tltl2001.バッテリー名称２`
    ,tltl2001.BTTRYTEIKA AS `tltl2001.バッテリー定価`
    ,tltl2001.BTTRYGKA AS `tltl2001.バッテリー原価`
    ,tltl2001.BTTRYHNKUMFLG AS `tltl2001.バッテリー変更有無フラグ`
    ,tltl2001.BTTRYMUSEIGENKBN AS `tltl2001.バッテリー無制限区分`
    ,tltl2001.JNKISVCUMFLG AS `tltl2001.巡回サービス有無フラグ`
    ,tltl2001.JNKISVCKISU AS `tltl2001.巡回サービス回数`
    ,tltl2001.JNKISVCCYCL AS `tltl2001.巡回サービスサイクル`
    ,tltl2001.JNKISVCTEIKA AS `tltl2001.巡回サービス定価`
    ,tltl2001.JNKISVCGKA AS `tltl2001.巡回サービス原価`
    ,tltl2001.JNKISVCHNKUMFLG AS `tltl2001.巡回サービス変更有無フラグ`
    ,tltl2001.JNKISVCTRKFLG AS `tltl2001.巡回サービス登録フラグ`
    ,tltl2001.TIREUMFLG AS `tltl2001.タイヤ有無フラグ`
    ,tltl2001.TIRECD01 AS `tltl2001.タイヤコード０１`
    ,tltl2001.TIRECD02 AS `tltl2001.タイヤコード０２`
    ,tltl2001.TIRECD03 AS `tltl2001.タイヤコード０３`
    ,tltl2001.TIRECD04 AS `tltl2001.タイヤコード０４`
    ,tltl2001.TIRECD05 AS `tltl2001.タイヤコード０５`
    ,tltl2001.TIRECD06 AS `tltl2001.タイヤコード０６`
    ,tltl2001.TIRESZ01 AS `tltl2001.タイヤサイズ０１`
    ,tltl2001.TIRESZ02 AS `tltl2001.タイヤサイズ０２`
    ,tltl2001.TIRESZ03 AS `tltl2001.タイヤサイズ０３`
    ,tltl2001.TIRESZ04 AS `tltl2001.タイヤサイズ０４`
    ,tltl2001.TIRESZ05 AS `tltl2001.タイヤサイズ０５`
    ,tltl2001.TIRESZ06 AS `tltl2001.タイヤサイズ０６`
    ,tltl2001.TIREHONSU01 AS `tltl2001.タイヤ本数０１`
    ,tltl2001.TIREHONSU02 AS `tltl2001.タイヤ本数０２`
    ,tltl2001.TIREHONSU03 AS `tltl2001.タイヤ本数０３`
    ,tltl2001.TIREHONSU04 AS `tltl2001.タイヤ本数０４`
    ,tltl2001.TIREHONSU05 AS `tltl2001.タイヤ本数０５`
    ,tltl2001.TIREHONSU06 AS `tltl2001.タイヤ本数０６`
    ,tltl2001.TIRETEIKA01 AS `tltl2001.タイヤ定価０１`
    ,tltl2001.TIRETEIKA02 AS `tltl2001.タイヤ定価０２`
    ,tltl2001.TIRETEIKA03 AS `tltl2001.タイヤ定価０３`
    ,tltl2001.TIRETEIKA04 AS `tltl2001.タイヤ定価０４`
    ,tltl2001.TIRETEIKA05 AS `tltl2001.タイヤ定価０５`
    ,tltl2001.TIRETEIKA06 AS `tltl2001.タイヤ定価０６`
    ,tltl2001.TIREGKA01 AS `tltl2001.タイヤ原価０１`
    ,tltl2001.TIREGKA02 AS `tltl2001.タイヤ原価０２`
    ,tltl2001.TIREGKA03 AS `tltl2001.タイヤ原価０３`
    ,tltl2001.TIREGKA04 AS `tltl2001.タイヤ原価０４`
    ,tltl2001.TIREGKA05 AS `tltl2001.タイヤ原価０５`
    ,tltl2001.TIREGKA06 AS `tltl2001.タイヤ原価０６`
    ,tltl2001.TIREHNKUMFLG01 AS `tltl2001.タイヤ変更有無フラグ０１`
    ,tltl2001.TIREHNKUMFLG02 AS `tltl2001.タイヤ変更有無フラグ０２`
    ,tltl2001.TIREHNKUMFLG03 AS `tltl2001.タイヤ変更有無フラグ０３`
    ,tltl2001.TIREHNKUMFLG04 AS `tltl2001.タイヤ変更有無フラグ０４`
    ,tltl2001.TIREHNKUMFLG05 AS `tltl2001.タイヤ変更有無フラグ０５`
    ,tltl2001.TIREHNKUMFLG06 AS `tltl2001.タイヤ変更有無フラグ０６`
    ,tltl2001.TIREMUSEIGENFLG01 AS `tltl2001.タイヤ無制限フラグ０１`
    ,tltl2001.TIREMUSEIGENFLG02 AS `tltl2001.タイヤ無制限フラグ０２`
    ,tltl2001.TIREMUSEIGENFLG03 AS `tltl2001.タイヤ無制限フラグ０３`
    ,tltl2001.TIREMUSEIGENFLG04 AS `tltl2001.タイヤ無制限フラグ０４`
    ,tltl2001.TIREMUSEIGENFLG05 AS `tltl2001.タイヤ無制限フラグ０５`
    ,tltl2001.TIREMUSEIGENFLG06 AS `tltl2001.タイヤ無制限フラグ０６`
    ,tltl2001.TIREHOKANUMFLG AS `tltl2001.タイヤ保管有無フラグ`
    ,tltl2001.TIREHOKANGKA AS `tltl2001.タイヤ保管原価`
    ,tltl2001.TIREHOKANTEIKA AS `tltl2001.タイヤ保管定価`
    ,tltl2001.TIREHOKANHNKUMFLG AS `tltl2001.タイヤ保管変更有無フラグ`
    ,tltl2001.DISHAUMFLG AS `tltl2001.代車有無フラグ`
    ,tltl2001.DISHASHKNJIDSU AS `tltl2001.代車車検時日数`
    ,tltl2001.DISHASHKNJITEIKA AS `tltl2001.代車車検時定価`
    ,tltl2001.DISHASHKNJIGKA AS `tltl2001.代車車検時原価`
    ,tltl2001.DISHASHKNJIHNKUMFLG AS `tltl2001.代車車検時変更有無フラグ`
    ,tltl2001.DISHASHKNJIMUSEIGENFLG AS `tltl2001.代車車検時無制限フラグ`
    ,tltl2001.DISHAHTENJIDSU AS `tltl2001.代車法点時日数`
    ,tltl2001.DISHAHTENJITEIKA AS `tltl2001.代車法点時定価`
    ,tltl2001.DISHAHTENJIGKA AS `tltl2001.代車法点時原価`
    ,tltl2001.DISHAHTENJIHNKUMFLG AS `tltl2001.代車法点時変更有無フラグ`
    ,tltl2001.DISHAHTENJIMUSEIGENFLG AS `tltl2001.代車法点時無制限フラグ`
    ,tltl2001.DISHAJIKOJIDSU AS `tltl2001.代車事故時日数`
    ,tltl2001.DISHAJIKOJITEIKA AS `tltl2001.代車事故時定価`
    ,tltl2001.DISHAJIKOJIGKA AS `tltl2001.代車事故時原価`
    ,tltl2001.DISHAJIKOJIHNKUMFLG AS `tltl2001.代車事故時変更有無フラグ`
    ,tltl2001.DISHAJIKOJIMUSEIGENFLG AS `tltl2001.代車事故時無制限フラグ`
    ,tltl2001.DISHAIPNDSU AS `tltl2001.代車一般日数`
    ,tltl2001.DISHAIPNTEIKA AS `tltl2001.代車一般定価`
    ,tltl2001.DISHAIPNGKA AS `tltl2001.代車一般原価`
    ,tltl2001.DISHAIPNHNKUMFLG AS `tltl2001.代車一般変更有無フラグ`
    ,tltl2001.DISHAIPNMUSEIGENFLG AS `tltl2001.代車一般無制限フラグ`
    ,tltl2001.DISHATKYJKN AS `tltl2001.代車提供条件`
    ,tltl2001.FGOKTEIKA AS `tltl2001.Ｆ合計定価`
    ,tltl2001.FGOKGKA AS `tltl2001.Ｆ合計原価`
    ,tltl2001.MGOKTEIKA AS `tltl2001.Ｍ合計定価`
    ,tltl2001.MGOKGKA AS `tltl2001.Ｍ合計原価`
    ,tltl2001.FMGOKTEIKA AS `tltl2001.ＦＭ合計定価`
    ,tltl2001.FMGOKGKA AS `tltl2001.ＦＭ合計原価`
    ,tltl2001.ZNKSESNKBN AS `tltl2001.残価精算区分`
    ,tltl2001.ZNKKSKBN AS `tltl2001.残価係数区分`
    ,tltl2001.ZNKTEIKA AS `tltl2001.残価定価`
    ,tltl2001.ZNKGKA AS `tltl2001.残価原価`
    ,tltl2001.ZNKHGK AS `tltl2001.残価表示額`
    ,tltl2001.ZNKRT AS `tltl2001.残価率`
    ,tltl2001.ARARRRT AS `tltl2001.細利率`
    ,tltl2001.ARARIGK AS `tltl2001.粗利額`
    ,tltl2001.LSRYOSOGKTEIKA AS `tltl2001.リース料総額定価`
    ,tltl2001.LSRYOSOGKGKA AS `tltl2001.リース料総額原価`
    ,tltl2001.CHSGOARARRRT AS `tltl2001.調整後粗利率`
    ,tltl2001.CHSGOARARIGK AS `tltl2001.調整後粗利額`
    ,tltl2001.CHSGK AS `tltl2001.調整額`
    ,tltl2001.CHSGOLSRYOSOGK AS `tltl2001.調整後リース料総額`
    ,tltl2001.KITSNGIKNKHNRYO AS `tltl2001.規定損害金基本料`
    ,tltl2001.KITSNGIKNTGNMGK AS `tltl2001.規定損害金逓減月額`
    ,tltl2001.KITSNGIKNTGNMGKRK AS `tltl2001.規定損害金逓減月額累計`
    ,tltl2001.KITSNGIKNKKAMSU AS `tltl2001.規定損害金経過月数`
    ,tltl2001.KAZEIKBN AS `tltl2001.課税区分`
    ,tltl2001.KAZEITAISGAIKBN AS `tltl2001.課税対象外区分`
    ,tltl2001.MITUKLSKISU AS `tltl2001.毎月リース回数`
    ,tltl2001.MITUKLSGK AS `tltl2001.毎月リース額`
    ,tltl2001.MITUKSHHTXGK AS `tltl2001.毎月消費税額`
    ,tltl2001.BNSM1 AS `tltl2001.ボーナス月１`
    ,tltl2001.BNSM2 AS `tltl2001.ボーナス月２`
    ,tltl2001.BNSMLSGK AS `tltl2001.ボーナス月リース額`
    ,tltl2001.BNSMSHHTXGK AS `tltl2001.ボーナス月消費税額`
    ,tltl2001.NAKANUKEMS AS `tltl2001.中抜け月開始`
    ,tltl2001.NAKANUKEME AS `tltl2001.中抜け月終了`
    ,tltl2001.NAKANUKEMLSGK AS `tltl2001.中抜け月リース額`
    ,tltl2001.NAKANUKEMSHHTXGK AS `tltl2001.中抜け月消費税額`
    ,tltl2001.DWSHKAI AS `tltl2001.日割初回`
    ,tltl2001.DWSHKAILSGK AS `tltl2001.日割初回リース額`
    ,tltl2001.DWSHKAISHHTXGK AS `tltl2001.日割初回消費税額`
    ,tltl2001.DWLASTKAI AS `tltl2001.日割最終回`
    ,tltl2001.DWLASTKAILSGK AS `tltl2001.日割最終回リース額`
    ,tltl2001.DWLASTKAISHHTXGK AS `tltl2001.日割最終回消費税額`
    ,tltl2001.MBKN AS `tltl2001.前払金`
    ,tltl2001.MBKNPAYYMD AS `tltl2001.前払金支払年月日`
    ,tltl2001.MBKNSHKAISKYKBN AS `tltl2001.前払金初回請求区分`
    ,tltl2001.MBKN1KISU AS `tltl2001.前払金１回数`
    ,tltl2001.MBKN1 AS `tltl2001.前払金１`
    ,tltl2001.MBKN2KISUJI AS `tltl2001.前払金２回数自`
    ,tltl2001.MBKN2KISUITR AS `tltl2001.前払金２回数至`
    ,tltl2001.MBKN2KAIAT AS `tltl2001.前払金２回当`
    ,tltl2001.MBKN3KISUJI AS `tltl2001.前払金３回数自`
    ,tltl2001.MBKN3KISUITR AS `tltl2001.前払金３回数至`
    ,tltl2001.MBKN3KAIAT AS `tltl2001.前払金３回当`
    ,tltl2001.HOSHOKNGK AS `tltl2001.保証金額`
    ,tltl2001.HOSHOKNPAYYMD AS `tltl2001.保証金支払年月日`
    ,tltl2001.HOSHOKNSHKAISKYKBN AS `tltl2001.保証金初回請求区分`
    ,tltl2001.LSPAYKISUJI1 AS `tltl2001.リース支払回数自１`
    ,tltl2001.LSPAYKISUITR1 AS `tltl2001.リース支払回数至１`
    ,tltl2001.LSPAYYMD1 AS `tltl2001.リース支払年月日１`
    ,tltl2001.SHKAISKYKBN1KAIME AS `tltl2001.初回請求区分１回目`
    ,tltl2001.LSPAYKISUJI2 AS `tltl2001.リース支払回数自２`
    ,tltl2001.LSPAYKISUITR2 AS `tltl2001.リース支払回数至２`
    ,tltl2001.LSPAYYMD2 AS `tltl2001.リース支払年月日２`
    ,tltl2001.SHKAISKYKBNSCN AS `tltl2001.初回請求区分２回目`
    ,tltl2001.LSPAYKISUJI3 AS `tltl2001.リース支払回数自３`
    ,tltl2001.LSPAYKISUITR3 AS `tltl2001.リース支払回数至３`
    ,tltl2001.LSPAYKISUJI4 AS `tltl2001.リース支払回数自４`
    ,tltl2001.LSPAYKISUITR4 AS `tltl2001.リース支払回数至４`
    ,tltl2001.TCDTNO AS `tltl2001.トヨタクレジットＮｏ`
    ,tltl2001.HNBITENKNRNO AS `tltl2001.販売店管理番号`
    ,tltl2001.SHKNHOSHOSHNINNO AS `tltl2001.集金保証承認番号`
    ,tltl2001.JAFNO AS `tltl2001.ＪＡＦＮｏ`
    ,tltl2001.JCHKTRY AS `tltl2001.受注獲得理由`
    ,tltl2001.JCHKTRY5KT AS `tltl2001.受注獲得理由（５桁）`
    ,tltl2001.DTRKRY AS `tltl2001.脱落理由`
    ,tltl2001.KIYKSHRIKBN AS `tltl2001.解約処理区分`
    ,tltl2001.KIYKRYKBN AS `tltl2001.解約理由区分`
    ,tltl2001.KIYKRYOSKYKBN AS `tltl2001.解約料請求区分`
    ,tltl2001.KIYKRYOPAYYMD AS `tltl2001.解約料支払年月日`
    ,tltl2001.KMDSKISU AS `tltl2001.組戻回数`
    ,tltl2001.KMDSSYMD AS `tltl2001.組戻開始年月日`
    ,tltl2001.KMDSEYMD AS `tltl2001.組戻終了年月日`
    ,tltl2001.KMDSGOKGK AS `tltl2001.組戻合計額`
    ,tltl2001.KMDSSCS AS `tltl2001.組戻枝番始`
    ,tltl2001.KMDSSCE AS `tltl2001.組戻枝番終`
    ,tltl2001.JCHYMD AS `tltl2001.受注年月日`
    ,tltl2001.KYKYMD AS `tltl2001.契約年月日`
    ,tltl2001.CTKYKYMD AS `tltl2001.中途解約年月日`
    ,tltl2001.CNCLYMD AS `tltl2001.キャンセル年月日`
    ,tltl2001.MSHYMD AS `tltl2001.抹消年月日`
    ,tltl2001.NOSHAYMD AS `tltl2001.納車年月日`
    ,tltl2001.LSSYTIYMD AS `tltl2001.リース開始予定年月日`
    ,tltl2001.MGKHNKSGK AS `tltl2001.月額変更差額`
    ,tltl2001.TRKKJOYMD AS `tltl2001.登録計上年月日`
    ,tltl2001.TRKSHRIYMD AS `tltl2001.登録処理年月日`
    ,tltl2001.JCHKJOYMD AS `tltl2001.受注計上年月日`
    ,tltl2001.CNCLKJOYMD AS `tltl2001.キャンセル計上年月日`
    ,tltl2001.CTKYKKJOYMD AS `tltl2001.中途解約計上年月日`
    ,tltl2001.IKTPAYMSU AS `tltl2001.一括払月数`
    ,tltl2001.SETKNRJSSITSUP AS `tltl2001.設定金利実質％`
    ,tltl2001.SETKNRGKA AS `tltl2001.設定金利原価`
    ,tltl2001.CHOKIKNRJSSITSUP AS `tltl2001.長期金利実質％`
    ,tltl2001.CHOKIKNRGKA AS `tltl2001.長期金利原価`
    ,tltl2001.ATMKIN AS `tltl2001.頭金`
    ,tltl2001.SETATMKINKNRP AS `tltl2001.設定頭金金利％`
    ,tltl2001.CHOKIATMKINKNRP AS `tltl2001.長期頭金金利％`
    ,tltl2001.TTLARARRRT AS `tltl2001.トータル粗利率`
    ,tltl2001.SHRFEE AS `tltl2001.車両手数料`
    ,tltl2001.HKNFEE AS `tltl2001.保険手数料`
    ,tltl2001.HKNFEEBTNRT AS `tltl2001.保険手数料分担率`
    ,tltl2001.STAICM AS `tltl2001.その他収入`
    ,tltl2001.SITADORICARKAITRIKK AS `tltl2001.下取車買取価格`
    ,tltl2001.SITADORICARBAIKYAKYTIKK AS `tltl2001.下取車売却予定価格`
    ,tltl2001.SKYSHBIKO1 AS `tltl2001.請求書備考１`
    ,tltl2001.SKYSHBIKO2 AS `tltl2001.請求書備考２`
    ,tltl2001.SHKNINFTRIKMSUMIFLG AS `tltl2001.車検情報取込済フラグ`
    ,tltl2001.MBKNSKYSHNO AS `tltl2001.前払金請求書Ｎｏ`
    ,tltl2001.MBKNSKYSHOUTFLG AS `tltl2001.前払金請求書出力フラグ`
    ,tltl2001.MBKNSKYSHSHHTXRT AS `tltl2001.前払金請求書消費税率`
    ,tltl2001.MNTCARDOUTJOKYO AS `tltl2001.メンテナンスカード出力状況`
    ,tltl2001.MNTCARDOUTFLG AS `tltl2001.メンテナンスカード出力フラグ`
    ,tltl2001.SFMNTCARDFKHYOOUTJOKYO AS `tltl2001.ＳＦメンテナンスカード副表出力状況`
    ,tltl2001.SFMNTCARDFKHYOOUTFLG AS `tltl2001.ＳＦメンテナンスカード副表出力フラグ`
    ,tltl2001.SHKNFLTRIKMFLG AS `tltl2001.車検ファイル取込フラグ`
    ,tltl2001.TKYAK1 AS `tltl2001.特約１`
    ,tltl2001.TKYAK2 AS `tltl2001.特約２`
    ,tltl2001.TKYAK3 AS `tltl2001.特約３`
    ,tltl2001.TKYAK4 AS `tltl2001.特約４`
    ,tltl2001.TKYAK5 AS `tltl2001.特約５`
    ,tltl2001.TKYAK6 AS `tltl2001.特約６`
    ,tltl2001.MEMO1 AS `tltl2001.メモ１`
    ,tltl2001.MEMO2 AS `tltl2001.メモ２`
    ,tltl2001.MEMO3 AS `tltl2001.メモ３`
    ,tltl2001.MEMO4 AS `tltl2001.メモ４`
    ,tltl2001.MEMO5 AS `tltl2001.メモ５`
    ,tltl2001.MEMOA AS `tltl2001.メモＡ`
    ,tltl2001.MEMOB AS `tltl2001.メモＢ`
    ,tltl2001.MEMOC AS `tltl2001.メモＣ`
    ,tltl2001.MEMOD AS `tltl2001.メモＤ`
    ,tltl2001.MEMOE AS `tltl2001.メモＥ`
    ,tltl2001.MEMOF AS `tltl2001.メモＦ`
    ,tltl2001.HKNMOSHIKOMRENKEISUMIFLG AS `tltl2001.保険申込連携済フラグ`
    ,tltl2001.MBKNSKYD AS `tltl2001.前払金請求日`
    ,tltl2001.ZNKHOSHOKBN AS `tltl2001.残価保証区分`
    ,tltl2001.SHYUKITNKBN AS `tltl2001.所有権移転区分`
    ,tltl2001.LSTRIHKKBN AS `tltl2001.リース取引区分`
    ,tltl2001.LSTRIHKKBNKST AS `tltl2001.リース取引区分（貸手）`
    ,tltl2001.MITUKLSRYOHNKFLG AS `tltl2001.毎月リース料変更フラグ`
    ,tltl2001.LSTRIHKKBNZIMB AS `tltl2001.リース取引区分（税務Ｂ）`
    ,tltl2001.SHYUKITNKBNZIMB AS `tltl2001.所有権移転区分（税務Ｂ）`
    ,tltl2001.MNTCARDSKSED AS `tltl2001.メンテナンスカード作成日`
    ,tltl2001.MNTCARDZNKSKSED AS `tltl2001.メンテナンスカード前回作成日`
    ,tltl2001.MNTCARDFKHYOSKSED AS `tltl2001.メンテナンスカード副表作成日`
    ,tltl2001.MNTCARDFKHYOZNKSKSED AS `tltl2001.メンテナンスカード副表前回作成日`
    ,tltl2001.SHSHCLS AS `tltl2001.車種クラス`
    ,tltl2001.DNKYKKBN AS `tltl2001.ＤＮ契約区分`
    ,tltl2001.DNSESNNOSC AS `tltl2001.ＤＮ精算Ｎｏ枝番`
    ,tltl2001.SCHTKKBN AS `tltl2001.スケジュール点検区分`
    ,tltl2001.MPBKBN AS `tltl2001.ＭＰＢ区分`
    ,tltl2001.SHHTXKKASOTIKBN AS `tltl2001.消費税経過措置区分`
    ,tltl2001.SYSUPDCLIENTID AS `tltl2001.システム更新クライアントＩＤ`
    ,tltl2001.SYSUPDPRGID AS `tltl2001.システム更新プログラムＩＤ`
    ,tltl2001.SYSUPDYMDHMS AS `tltl2001.システム更新年月日時分秒`
    ,tltl2001.TCKYKUMFLG AS `tltl2001.ＴＣ契約有無フラグ`
    ,tltl2001.TCKYKKBN AS `tltl2001.ＴＣ契約区分`
    ,tltl2001.TCKYKHYO AS `tltl2001.ＴＣ契約費用`
    ,tltl2001.MNTTKTSFLG AS `tltl2001.メンテ統括フラグ`
    ,tltl2001.DNCENFLG AS `tltl2001.ＤＮセンターフラグ`

    ,jslimorderstatus.sim_kndate_dt AS `納期情報_納期シミュレーション結果(日付型)`
    --,jslimorderstatus.toroyote      AS 登録予定日
    ,tbba001g.no_order              AS `オーダーNo`
    ,tbba051g_sel.kn_kinmumei       AS `名義人勤務先名`

    -- 塗色差異：不同就〇
    ,CASE
        WHEN COALESCE(REPLACE(TRIM(tltl2001.toshokcd), '　', ''), '') <>
             COALESCE(REPLACE(TRIM(tbba001g.mj_gaihansy), '　', ''), '')
        THEN '〇' ELSE NULL
     END AS `塗色差異`

    -- 型式差異：不同就〇
    ,CASE
        WHEN COALESCE(REPLACE(TRIM(tbba001g.mj_hantenkt), '　', ''), '') <>
             COALESCE(REPLACE(TRIM(tltl2001.kata),       '　', ''), '')
        THEN '〇' ELSE NULL
     END AS `型式差異`

    -- 型式色差異：任一组有差异就〇
    ,CASE
        WHEN COALESCE(REPLACE(TRIM(tltl2001.toshokcd), '　', ''), '') <>
             COALESCE(REPLACE(TRIM(tbba001g.mj_gaihansy), '　', ''), '')
          OR COALESCE(REPLACE(TRIM(tbba001g.mj_hantenkt), '　', ''), '') <>
             COALESCE(REPLACE(TRIM(tltl2001.kata),       '　', ''), '')
        THEN '〇' ELSE NULL
     END AS `型式色差異`

    -- メーカーOPT４５桁：有任一项则〇
    ,CASE
        WHEN COALESCE(TRIM(tbba001g.mj_makeop1),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop2),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop3),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop4),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop5),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop6),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop7),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop8),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop9),  '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop10), '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop11), '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop12), '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop13), '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop14), '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop15), '') <> '' OR
             COALESCE(TRIM(tbba001g.mj_makeop16), '') <> ''
        THEN '〇' ELSE NULL
     END AS `メーカーOPT４５桁`
    ,houjinhankatsu.dt_nifi_kosin AS `houjinhankatsu.nifi更新日`
    ,'D11' || tbv0200m.cd_hanbaitn || tbba001g.no_cyumon AS `車両特定番号`
    ,CAST(tltl2001.lskykno AS STRING) || trim(houjinhankatsu.no_cyumon_fk) AS `契約ＮＯのSort`
    -- 内装差異：不同就〇
    ,CASE
        WHEN COALESCE(REPLACE(TRIM(tltl2001.NAISOSHOKCD), '　', ''), '') <>
             COALESCE(REPLACE(TRIM(tbba001g.cd_utihari), '　', ''), '')
        THEN '〇' ELSE NULL
     END AS `内装差異`

FROM neo1rep_ve.tltl2001 tltl2001 --契約情報

    -- ★ 1) tltl2001 ⇔ houjinhankatsu（最新行）【INNER JOIN】
    INNER JOIN (
        SELECT
             h.no_cyumon
            ,h.no_cyumon_fk
            ,h.dt_nifi_kosin
            ,COALESCE(h.mj_risukaisyasyaryokeiyakuno, h.mj_risukaisyasyaryokeiyakunoyobi) AS mj_risukaisyasyaryokeiyakuno
        FROM dx_ve.houjinhankatsu h --中間ファイルデータ
    ) houjinhankatsu
      --リース会社車両契約NO/リース会社車両契約NO(予備) = リース契約Ｎｏ
      ON CAST(houjinhankatsu.mj_risukaisyasyaryokeiyakuno AS INT) = tltl2001.lskykno

    -- ★ 2) houjinhankatsu ⇔ tbba001g（受注番号(枝番付)）【INNER JOIN】
    --INNER JOIN tbba001g tbba001g
      INNER JOIN ai21rep_ve_dx.tbba001g tbba001g --新車受注基本情報ＤＢ
      --ON TRIM(tbba001g.no_cyumon || tbba001g.no_cyumoned) = TRIM(houjinhankatsu.no_cyumon)
      --'T_'+[注文ＮＯ]+[注文ＮＯ枝番]+'_'+[受注発生日] = [注文No(外部キー)]
      ON CAST('T_' || tbba001g.no_cyumon || tbba001g.no_cyumoned || '_' || COALESCE(from_unixtime(unix_timestamp(tbba001g.dd_jucyuhas), 'yyyyMMdd'), '') AS String)  = houjinhankatsu.no_cyumon_fk
    LEFT JOIN ai21rep_ve_dx.tbba031g tbba031g --登録ＤＢ
      ON tbba031g.cd_hansya = tbba001g.cd_hansya
     AND tbba031g.cd_kaisya = tbba001g.cd_kaisya
     AND tbba031g.no_cyumon = tbba001g.no_cyumon
     AND tbba031g.no_cyumoned = tbba001g.no_cyumoned
    LEFT JOIN ai21rep_ve_dx.tbba008g tbba008g --新車車両情報ＤＢ
      --販社コード、会社コード、注文ＮＯ、注文ＮＯ枝番、仕向先、オーダーＮＯ、型式ハイフン前、フレームＮＯ、仕入日
      ON tbba008g.cd_hansya = tbba001g.cd_hansya
     AND tbba008g.cd_kaisya = tbba001g.cd_kaisya
     AND tbba008g.no_cyumon = tbba001g.no_cyumon
     AND tbba008g.no_cyumoned = tbba001g.no_cyumoned
     AND tbba008g.mj_simuksak = tbba001g.mj_simuksak
     AND tbba008g.no_order = tbba001g.no_order
     AND tbba008g.mj_katahima = tbba001g.mj_katahima
     AND tbba008g.no_frame = tbba001g.no_frame
     AND tbba008g.dd_siire  = tbba001g.dd_siire
    LEFT JOIN ai21rep_ve_dx.tbba035g tbba035g --最終仕様ＤＢ
      --販社コード、会社コード、販売店型式、新旧世代、外鈑色、メーカーＯＰＴ１～メーカーＯＰＴ１６
      ON tbba035g.cd_hansya = tbba008g.cd_hansya
     AND tbba035g.cd_kaisya = tbba008g.cd_kaisya
     AND tbba035g.mj_hantenkt = tbba008g.mj_hantenkt
     AND tbba035g.mj_sinkysed = tbba008g.mj_sinkysed
     AND tbba035g.mj_gaihansy = tbba008g.mj_gaihansy
     AND tbba035g.mj_makeop1 = tbba008g.mj_makeop1
     AND tbba035g.mj_makeop2 = tbba008g.mj_makeop2
     AND tbba035g.mj_makeop3 = tbba008g.mj_makeop3
     AND tbba035g.mj_makeop4 = tbba008g.mj_makeop4
     AND tbba035g.mj_makeop5 = tbba008g.mj_makeop5
     AND tbba035g.mj_makeop6 = tbba008g.mj_makeop6
     AND tbba035g.mj_makeop7 = tbba008g.mj_makeop7
     AND tbba035g.mj_makeop8 = tbba008g.mj_makeop8
     AND tbba035g.mj_makeop9 = tbba008g.mj_makeop9
     AND tbba035g.mj_makeop10 = tbba008g.mj_makeop10
     AND tbba035g.mj_makeop11 = tbba008g.mj_makeop11
     AND tbba035g.mj_makeop12 = tbba008g.mj_makeop12
     AND tbba035g.mj_makeop13 = tbba008g.mj_makeop13
     AND tbba035g.mj_makeop14 = tbba008g.mj_makeop14
     AND tbba035g.mj_makeop15 = tbba008g.mj_makeop15
     AND tbba035g.mj_makeop16 = tbba008g.mj_makeop16
    LEFT JOIN ai21rep_ve_dx.tbz0002c tbz0002c --システム情報ＤＢ
      ON tbz0002c.cd_hansya = tbba001g.cd_hansya
     AND tbz0002c.cd_kaisya = tbba001g.cd_kaisya
    LEFT JOIN neo1rep_ve.tltl2031 tltl2031 --車両発注情報
      --Ｒ店ＩＤ、リース契約Ｎｏ
      ON tltl2001.rtenid = tltl2031.rtenid
     AND tltl2001.lskykno = tltl2031.lskykno
    -- マスタ系：保持 LEFT JOIN
    LEFT JOIN ai21rep_ve_dx.tbv0200m tbv0200m --会社コードＤＢ
      ON tbba001g.cd_hansya = tbv0200m.cd_hansya
     AND tbba001g.cd_kaisya = tbv0200m.cd_kaisya

    LEFT JOIN ai21rep_ve_dx.tbv0014m tbv0014m --Ｍ社員ＤＢ
      ON tbba001g.cd_hansya   = tbv0014m.cd_hansya
     AND tbba001g.cd_kaisya   = tbv0014m.cd_kaisya
     AND tbba001g.cd_hanstaff = tbv0014m.cd_syain

    LEFT JOIN ai21rep_ve_dx.tbbf008m tbbf008m --車両スペック２ＤＢ
      --販社コード、会社コード、販売店型式、新旧世代、スペック区分
      ON tbba001g.cd_hansya   = tbbf008m.cd_hansya
     AND tbba001g.cd_kaisya   = tbbf008m.cd_kaisya
     AND tbba001g.mj_gaihansy = tbbf008m.cd_spec
     AND tbba001g.mj_sinkysed = tbbf008m.mj_sinkysed
     AND tbba001g.mj_hantenkt = tbbf008m.mj_hantenkt
     AND tbbf008m.kb_spec = 'G' --Ｇ：外鈑色

    LEFT JOIN ai21rep_ve_dx.tbbf001m tbbf001m --車名ＤＢ
      ON tbbf008m.cd_hansya = tbbf001m.cd_hansya
     AND tbbf008m.cd_kaisya = tbbf001m.cd_kaisya
     --車名 = 新車車名コード
     AND tbbf008m.mj_syamei = tbbf001m.cd_ncsyamei

    LEFT JOIN datalib_ve.V_JSLIM_STS jslimorderstatus
      ON TRIM(tbba001g.no_cyumon || tbba001g.no_cyumoned)
       = TRIM(jslimorderstatus.no_cyumon || jslimorderstatus.no_cyumoned)
     AND tbba001g.cd_hansya = jslimorderstatus.dlrcd
    LEFT JOIN (
        SELECT
             g.cd_hansya
            ,g.cd_kaisya
            ,g.no_cyumon
            ,g.no_cyumoned
            ,g.kn_kinmumei
            ,ROW_NUMBER() OVER (
                PARTITION BY g.cd_hansya, g.cd_kaisya, g.no_cyumon, g.no_cyumoned
                ORDER BY g.no_cyumon
            ) AS rn
        FROM ai21rep_ve_dx.tbba051g g --新車受注顧客情報ＤＢ
        WHERE g.kb_kokyaku = '2' --顧客区分 = 2:名義人
    ) tbba051g_sel
      ON tbba001g.cd_hansya   = tbba051g_sel.cd_hansya
     AND tbba001g.cd_kaisya   = tbba051g_sel.cd_kaisya
     AND tbba001g.no_cyumon   = tbba051g_sel.no_cyumon
     AND tbba001g.no_cyumoned = tbba051g_sel.no_cyumoned
     AND tbba051g_sel.rn = 1
--WHERE
    -- Ｒ店ＩＤ
    --tltl2001.RTENID = '122';
)

INSERT OVERWRITE TABLE gold.enoreport_full_fixed
SELECT
    b.*
FROM (
    SELECT
        base.*,
        ROW_NUMBER() OVER (
            PARTITION BY base.`契約ＮＯのSort`
            ORDER BY base.`tbba001g.受注発生日` DESC, base.`注文ＮＯ`, base.`注文ＮＯ枝番`
        ) AS rn
    FROM base
) b
WHERE b.rn = 1
;

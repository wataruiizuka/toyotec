-- Source file: 013_中古車売掛金/VBI013004_中古車売掛金回収状況_en.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi013001_en
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.VBI013004_en
SELECT
	tbbc017g.cd_hansya, --販社コード
	tbbc017g.cd_kaisya, --会社コード
	IF(LEFT(tbbc017g.no_cyumon, 3) = 'TAD' AND LENGTH(tbbc017g_2.no_min_denpyo) > 0,LEFT(tbbc017g_2.no_min_denpyo, 3),tbbc017g.cd_jytyuten) AS cd_jytyuten, --店舗コード
	IF(LEFT(tbbc017g.no_cyumon, 3) = 'TAD' AND LENGTH(tbbc017g_2.no_min_denpyo) > 0,tbbc017g.cd_hansya || tbbc017g.cd_kaisya || LEFT(tbbc017g_2.no_min_denpyo, 3),tbbc017g.cd_hansya || tbbc017g.cd_kaisya || tbbc017g.cd_jytyuten) AS cd_hansya_kaisya_jytyuten, --販社会社店舗コード
    IF(MONTH(tbbc017g.dd_jucyu) = MONTH(current_timestamp()),1,0) AS su_jucyu, --受注台数
    IF(MONTH(tbbc017g.dd_touroku) = MONTH(current_timestamp()),1,0) AS su_touroku, --登録台数
    IF(MONTH(tbbc017g.dd_touroku) = MONTH(current_timestamp()) AND tbbc020g.su_sitadori = 0,1,0) AS no_trade_in_vehicles_registered_this_month, --当月登録内下取車なし
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_urikzumi IS NULL,1,0) AS currently_registered_but_uncollected_cases, --現在登録済未回収件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_urikzumi IS NULL,tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk,0) AS currently_registered_uncollected_amount, --現在登録済未回収金額
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_urikzumi IS NULL AND TRUNC(tbbc017g.dd_touroku, 'month') = TRUNC(ADD_MONTHS(current_timestamp(), -1), 'month'),1,0) AS registered_but_uncollected_items_from_the_previous_month, --前月登録済未回収件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_urikzumi IS NULL AND TRUNC(tbbc017g.dd_touroku, 'month') = TRUNC(ADD_MONTHS(current_timestamp(), -1), 'month'),tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk,0) AS uncollected_amount_registered_in_the_previous_month, --前月登録済未回収金額
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_urikzumi IS NULL AND (TRUNC(tbbc017g.dd_touroku, 'year') < TRUNC(ADD_MONTHS(current_timestamp(), -1), 'year') OR (TRUNC(tbbc017g.dd_touroku, 'year') = TRUNC(ADD_MONTHS(current_timestamp(), -1), 'year') AND TRUNC(tbbc017g.dd_touroku, 'month') < TRUNC(ADD_MONTHS(current_timestamp(), -1), 'month'))),1,0) AS uncollected_cases_registered_two_months_prior, --前々月以前登録済未回収件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_urikzumi IS NULL AND (TRUNC(tbbc017g.dd_touroku, 'year') < TRUNC(ADD_MONTHS(current_timestamp(), -1), 'year') OR (TRUNC(tbbc017g.dd_touroku, 'year') = TRUNC(ADD_MONTHS(current_timestamp(), -1), 'year') AND TRUNC(tbbc017g.dd_touroku, 'month') < TRUNC(ADD_MONTHS(current_timestamp(), -1), 'month'))),tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk,0) AS uncollected_amount_registered_two_months_prior, --前々月以前登録済未回収金額
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_urikzumi IS NULL,1,NULL) AS su_pieces, --件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_urikzumi IS NULL,(tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk) / 1000,NULL) AS su_amount, --金額
	vbi013001.mj_sortjyun --ソート順
FROM ai21rep_ve_dx.tbbc017g tbbc017g --TBBC017G_中古車受注基本情報DB
LEFT JOIN ai21rep_ve_dx.tbbc020g tbbc020g --TBBC020G_中古車受注販売条件情報DB
    ON tbbc017g.cd_hansya = tbbc020g.cd_hansya
   AND tbbc017g.cd_kaisya = tbbc020g.cd_kaisya
   AND tbbc017g.no_cyumon = tbbc020g.no_cyumon
   AND TRIM(tbbc017g.no_cyumoned) = TRIM(tbbc020g.no_cyumoned)
LEFT JOIN (--当月回収完了分平均リードタイム取得
	SELECT
        tbbc017g.cd_hansya, --販社コード
		tbbc017g.cd_kaisya, --会社コード
		tbbc017g.cd_jytyuten --店舗コード
	FROM
		ai21rep_ve_dx.tbbc017g tbbc017g --TBBC017G_中古車受注基本情報DB
	LEFT JOIN ai21rep_ve_dx.tbbc020g tbbc020g --TBBC020G_中古車受注販売条件情報DB
         ON tbbc017g.cd_hansya = tbbc020g.cd_hansya
		AND tbbc017g.cd_kaisya = tbbc020g.cd_kaisya
		AND tbbc017g.no_cyumon = tbbc020g.no_cyumon
		AND TRIM(tbbc017g.no_cyumoned) = TRIM(tbbc020g.no_cyumoned)
	WHERE tbbc017g.dd_touroku IS NOT NULL --登録取消計上日がNULLではない
		AND (tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk) = 0 --未回収額が0
        AND TRUNC(tbbc017g.dd_urikzumi, 'month') = TRUNC(current_timestamp(), 'month') --販売日が今月である
	GROUP BY
        tbbc017g.cd_hansya,
		tbbc017g.cd_kaisya,
		tbbc017g.cd_jytyuten) tbbc017g_1
	ON tbbc017g.cd_hansya = tbbc017g_1.cd_hansya
    AND tbbc017g.cd_kaisya = tbbc017g_1.cd_kaisya
	AND tbbc017g.cd_jytyuten = tbbc017g_1.cd_jytyuten
    LEFT JOIN (
    SELECT
         tbbc017g.cd_hansya --販社コード
        ,tbbc017g.cd_kaisya --会社コード
        ,tbbc017g.no_cyumon --注文ＮＯ
        ,tbbc017g.no_cyumoned --注文ＮＯ枝番
        ,MIN(tbg8014m.no_denpyo) AS no_min_denpyo --伝票番号
    FROM ai21rep_ve_dx.tbg8014m tbg8014m --TBG8014M_売掛金履歴ＤＢ
    RIGHT JOIN ai21rep_ve_dx.tbbc017g tbbc017g --TBBC017G_中古車受注基本情報DB
    ON tbg8014m.cd_hansya = tbbc017g.cd_hansya
    AND tbg8014m.cd_kaisya = tbbc017g.cd_kaisya
    AND TRIM(tbg8014m.no_cyumon) = (TRIM(tbbc017g.no_cyumon) || TRIM(tbbc017g.no_cyumoned))
    AND tbg8014m.kb_urinyuki = '2' --売上入金区分が2
    AND tbg8014m.kb_nyukkanr = '01' --入金管理区分 が01
    GROUP BY
         tbbc017g.cd_hansya
        ,tbbc017g.cd_kaisya
        ,tbbc017g.no_cyumon
        ,tbbc017g.no_cyumoned
) tbbc017g_2
ON tbbc017g_2.cd_hansya = tbbc017g.cd_hansya
AND tbbc017g_2.cd_kaisya = tbbc017g.cd_kaisya
AND tbbc017g_2.no_cyumon = tbbc017g.no_cyumon
AND tbbc017g_2.no_cyumoned = tbbc017g.no_cyumoned
INNER JOIN gold.vbi013001_en vbi013001
    ON vbi013001.cd_hansya = tbbc017g.cd_hansya
    AND vbi013001.cd_kaisya = tbbc017g.cd_kaisya
    AND vbi013001.cd_tenpo = IF(LEFT(tbbc017g.no_cyumon, 3) = 'TAD' AND LENGTH(tbbc017g_2.no_min_denpyo) > 0,LEFT(tbbc017g_2.no_min_denpyo, 3),tbbc017g.cd_jytyuten) --ショップフィルタリング
WHERE tbbc017g.dd_torikesi IS NULL --取消日がNULLである
    AND (dd_torotrkk IS NULL OR (dd_torotrkk IS NOT NULL AND (tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk) != 0)) --登録取消計上日がNULLである or 値があると残高がある
    AND LEFT(CAST (tbbc017g.kb_uriage AS STRING), 1) = '1' --払出区分の第一位が1
    AND (NOT coalesce((tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk) = 0 --値があると残高がある
        AND((tbbc017g.dd_touroku IS NOT NULL --登録日がNULLではないではありません
    	    AND tbbc017g.dd_nosya < DATE '2023-03-01' --納車日が2023-03-01以前
    	    AND (tbbc017g.dd_urikzumi IS NULL OR tbbc017g.dd_urikzumi < DATE '2024-03-01')) --売掛金完済日がNULLであるまたは売掛金完済日が2024-03-01以前
    	OR (tbbc017g.dd_nosya IS NULL AND tbbc017g.dd_touroku < DATE '2023-03-01') --納車日がNULLであるそして登録日が2023-03-01以前
    	    OR tbbc017g.dd_urikzumi < DATE '2024-03-01' --納車日が2024-03-01以前
    	    OR (tbbc017g.dd_touroku IS NULL AND tbbc017g.dd_jucyu < DATE '2020-12-01')), false)) --ゴミデータ除外
;

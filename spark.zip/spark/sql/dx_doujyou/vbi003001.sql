-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi003001_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi003001
select
	--日付
	dd_date as `日付`,
	--日付_月
	dd_month as `日付_月`,
	--日付_yyyy/MM/dd
	`dd_yyyy/MM/dd` as `日付_yyyy/MM/dd`,
	--日付_yyyyMMdd
	`dd_yyyyMMdd` as `日付_yyyyMMdd`,
	--週末判定
	kb_week as `週末判定`
from gold.vbi003001_en
;

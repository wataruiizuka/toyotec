-- Source file: 011_メンテナンスパック契約客ステータス一覧/メンテナンスパック契約客ステータス一覧.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi011002
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi011005
SELECT 
	--販社コード
	tz006m.cd_hansya,
	--会社コード
	tz006m.cd_kaisya,
	--お客様コード
	tz006m.cd_okyaku,
	--スタッフ店舗コード
	tz006m.cd_stafften,
	--スタッフコード
	tz006m.cd_staff,
	--エリアコード
	vbi011002.cd_zon,
	--エリア名
	vbi011002.kj_zonmei,
	--店舗名
	vbi011002.kj_tenpomei,
	--ソート順
	vbi011002.mj_sortjyun,
	--社員名
	t0014m.kj_syainmei
--顧客担当ＤＢ
FROM ai21rep_ve_dx.tbaz006m tz006m
INNER JOIN gold.vbi011002 vbi011002
	ON tz006m.cd_hansya = vbi011002.cd_hansya
	AND tz006m.cd_kaisya = vbi011002.cd_kaisya
	AND tz006m.cd_stafften = vbi011002.cd_tenpo
--M社員DB
LEFT JOIN ai21rep_ve_dx.tbv0014m t0014m
	ON tz006m.cd_hansya = t0014m.cd_hansya
	AND tz006m.cd_kaisya = t0014m.cd_kaisya
	AND tz006m.cd_staff = t0014m.cd_syain
--Table.SelectRows(#"名前が変更された列 ", each ([会社コード] = "01") and ([#"担当分類区分 "] = "1"))
WHERE tz006m.kb_tantobun = '1'
;

-- Source file: 013_中古車売掛金/VBI013001_中古車売掛金店舗別.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi013001_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.VBI013001
--販社コードがTMTの店舗
SELECT
    su_store AS `店舗数`, --店舗数
	cd_hansya_kaisya_tenpo AS `販社会社店舗コード`, --販社会社店舗コード
	cd_hansya_kaisya_zon_tenpo AS `販社会社ゾーン店舗コード`, --販社会社ゾーン店舗コード
	cd_hansya AS `販社コード`, --販社コード
	cd_kaisya AS `会社コード`, --会社コード
	cd_tenpo AS `店舗コード`, --店舗コード
	kj_tenpomei AS `店舗名称`, --店舗名称
	kj_tentanms AS `店舗短縮名称`, --店舗短縮名称
    cd_zon AS `ゾーンコード`, --ゾーンコード
    cd_nczon AS `ゾーンコード1`, --ゾーンコード1
    kj_zonmei AS `ゾーン名`, --ゾーン名
	zone_name AS `ゾーン名(略)`, --ゾーン名(略)
    mj_sortjyun AS `ソート順` --ソート順
FROM gold.vbi013001_en vbi013001 --売掛金店舗別_en
;

-- Source file: 012_SMB空き枠カレンダー（ストール軸管理向け）/smbcalendar.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi012001_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi012001
select
	--日付
	dd_date as `日付`,
	--日付_月
	dd_month as `日付_月`,
	--日付_yyyy/MM/dd
	`dd_yyyy/MM/dd` as `日付_yyyy/MM/dd`,
	--日付_yyyyMMdd
	`dd_yyyyMMdd` as `日付_yyyyMMdd`,
	--日付_曜日
	dd_week as `日付_曜日`,
	--先週/来週
	kb_senshuraishu as `先週/来週`
from gold.vbi012001_en
;

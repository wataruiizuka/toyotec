-- Source file: 013_中古車売掛金/VBI013005_中古車売掛金残高.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi013001_en
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.VBI013005
SELECT
	tbbc017g.cd_hansya AS `販社コード`, --販社コード
	tbbc017g.cd_kaisya AS `会社コード`, --会社コード
	IF(LEFT(tbbc017g.no_cyumon, 3) = 'TAD' AND LENGTH(tbbc017g_1.no_min_denpyo) > 0,tbbc017g.cd_hansya || tbbc017g.cd_kaisya || LEFT(tbbc017g_1.no_min_denpyo, 3),tbbc017g.cd_hansya || tbbc017g.cd_kaisya || tbbc017g.cd_jytyuten) AS `販社会社店舗コード`, --販社会社店舗コード
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND (tbbc017g.dd_urikzumi >= TRUNC(current_timestamp(), 'MM') OR tbbc017g.dd_urikzumi IS NULL),1,0) AS `登録済件数`, --登録済件数
    IF(COALESCE(tbbc020g.su_sitadori, 0) = 0 AND tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND (tbbc017g.dd_urikzumi >= TRUNC(current_timestamp(), 'MM') OR tbbc017g.dd_urikzumi IS NULL),1,0) AS `下取車なし総件数`, --下取車なし総件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbbc017g.dd_urikzumi IS NULL AND (tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk) != 0,1,0) AS `未回収総件数`, --未回収総件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbbc017g.dd_urikzumi IS NULL AND (tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk) != 0,tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk,0) AS `未回収総金額`, --未回収総金額
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbbc017g.dd_urikzumi IS NULL AND (tbbc020g.ki_genkhasg - tbbc020g.ki_genknykg) != 0,1,0) AS `未回収現金総件数`, --未回収現金総件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbbc017g.dd_urikzumi IS NULL AND (tbbc020g.ki_genkhasg - tbbc020g.ki_genknykg) != 0,tbbc020g.ki_genkhasg - tbbc020g.ki_genknykg,0) AS `未回収現金総金額`, --未回収現金総金額
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbbc017g.dd_urikzumi IS NULL AND (tbbc020g.ki_fuharhsk - tbbc020g.ki_fuharnyk) != 0,1,0) AS `未回収割賦総総件数`, --未回収割賦総総件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbbc017g.dd_urikzumi IS NULL AND (tbbc020g.ki_fuharhsk - tbbc020g.ki_fuharnyk) != 0,tbbc020g.ki_fuharhsk - tbbc020g.ki_fuharnyk,0) AS `未回収割賦総総金額`, --未回収割賦総総金額
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbbc017g.dd_urikzumi IS NULL AND (tbbc020g.ki_sitahasg - tbbc020g.ki_sitanykg) != 0,1,0) AS `未回収下取総件数`, --未回収下取総件数
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND tbbc017g.dd_urikzumi IS NULL AND (tbbc020g.ki_sitahasg - tbbc020g.ki_sitanykg) != 0,tbbc020g.ki_sitahasg - tbbc020g.ki_sitanykg,0) AS `未回収下取総金額`, --未回収下取総金額
    IF(tbbc017g.dd_touroku IS NOT NULL AND tbbc017g.dd_touroku <= LAST_DAY(ADD_MONTHS(current_timestamp(), -1)) AND (tbbc017g.dd_urikzumi >= TRUNC(current_timestamp(), 'MM') OR tbbc017g.dd_urikzumi IS NULL) AND tbbc017g.dd_nosya IS NULL,1,0) AS `登録済未納車件数` --登録済未納車件数
FROM ai21rep_ve_dx.tbbc017g tbbc017g --TBBC017G_中古車受注基本情報DB
LEFT JOIN (
    SELECT
         tbbc017g.cd_hansya --販社コード
        ,tbbc017g.cd_kaisya --会社コード
        ,tbbc017g.no_cyumon --注文ＮＯ
        ,tbbc017g.no_cyumoned --注文ＮＯ枝番
        ,MIN(tbg8014m.no_denpyo) AS no_min_denpyo --伝票番号
    FROM ai21rep_ve_dx.tbg8014m tbg8014m --TBG8014M_売掛金履歴ＤＢ
    RIGHT JOIN ai21rep_ve_dx.tbbc017g tbbc017g --TBBC017G_中古車受注基本情報DB
    ON tbg8014m.cd_hansya = tbbc017g.cd_hansya
    AND tbg8014m.cd_kaisya = tbbc017g.cd_kaisya
    AND TRIM(tbg8014m.no_cyumon) = (TRIM(tbbc017g.no_cyumon) || TRIM(tbbc017g.no_cyumoned))
    AND tbg8014m.kb_urinyuki = '2' --売上入金区分が2
    AND tbg8014m.kb_nyukkanr = '01' --入金管理区分 が01
    GROUP BY
         tbbc017g.cd_hansya
        ,tbbc017g.cd_kaisya
        ,tbbc017g.no_cyumon
        ,tbbc017g.no_cyumoned
) tbbc017g_1
ON tbbc017g_1.cd_hansya = tbbc017g.cd_hansya
AND tbbc017g_1.cd_kaisya = tbbc017g.cd_kaisya
AND tbbc017g_1.no_cyumon = tbbc017g.no_cyumon
AND tbbc017g_1.no_cyumoned = tbbc017g.no_cyumoned
INNER JOIN gold.vbi013001_en vbi013001
    ON vbi013001.cd_hansya = tbbc017g.cd_hansya
    AND vbi013001.cd_kaisya = tbbc017g.cd_kaisya
    AND vbi013001.cd_tenpo = IF(LEFT(tbbc017g.no_cyumon, 3) = 'TAD' AND LENGTH(tbbc017g_1.no_min_denpyo) > 0,LEFT(tbbc017g_1.no_min_denpyo, 3),tbbc017g.cd_jytyuten) --ショップフィルタリング
LEFT JOIN ai21rep_ve_dx.tbbc020g tbbc020g  --TBBC020G_中古車受注販売条件情報DB
	ON tbbc017g.cd_hansya = tbbc020g.cd_hansya
	AND tbbc017g.cd_kaisya = tbbc020g.cd_kaisya
	AND tbbc017g.no_cyumon = tbbc020g.no_cyumon
	AND TRIM(tbbc017g.no_cyumoned) = TRIM(tbbc020g.no_cyumoned)
where tbbc017g.dd_torikesi IS NULL --取消日がNULLである
    AND (dd_torotrkk IS NULL OR (dd_torotrkk IS NOT NULL AND (tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk) != 0)) --登録取消計上日がNULLではない or 値があると残高がある
    AND LEFT(CAST (tbbc017g.kb_uriage AS STRING), 1) = '1' --払出区分の第一位が1
    AND (NOT coalesce((tbbc020g.ki_haseirui - tbbc020g.ki_genknykg - tbbc020g.ki_sitanykg - tbbc020g.ki_fuharnyk) = 0 --値があると残高がある
        AND((tbbc017g.dd_touroku IS NOT NULL --登録日がNULLではない
    	    AND tbbc017g.dd_nosya < DATE '2023-03-01' --納車日が2023-03-01以前
            AND (tbbc017g.dd_urikzumi IS NULL OR tbbc017g.dd_urikzumi < DATE '2024-03-01')) --売掛金完済日がNULLであるまたは売掛金完済日が2024-03-01以前
    	OR (tbbc017g.dd_nosya IS NULL AND tbbc017g.dd_touroku < DATE '2023-03-01') --納車日がNULLであるそして登録日が2023-03-01以前
    	    OR tbbc017g.dd_urikzumi < DATE '2024-03-01' --納車日が2024-03-01以前
    	    OR (tbbc017g.dd_touroku IS NULL AND tbbc017g.dd_jucyu < DATE '2020-12-01') --ゴミデータ除外
        ), false)) --ゴミデータ除外
;

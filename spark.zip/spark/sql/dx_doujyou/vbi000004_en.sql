-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000004_en
select
	--販社コード
	t022g.cd_hansya,
	--会社コード
	t022g.cd_kaisya,
	--整理ＮＯ
	t022g.no_seiri,
	--リコール名称
	max(t022g.kj_recallme) as kj_recallme
--市場処置部品集計ＤＢ
from ai21rep_ve_dx.tbfj022g t022g
group by t022g.cd_hansya, t022g.cd_kaisya, t022g.no_seiri
;

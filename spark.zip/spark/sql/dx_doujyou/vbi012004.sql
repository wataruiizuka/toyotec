-- Source file: 012_SMB空き枠カレンダー（ストール軸管理向け）/smbcalendar.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi012002
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi012004
select
	--販社コード
	t005g.cd_hansya,
	--会社コード
	t005g.cd_kaisya,
	--店舗コード
	t005g.cd_tenpo,
	--ストール番号
	t005g.no_stall,
	--使用開始日時
	t005g.dt_siyost,
	--使用終了日時
	t005g.dt_siyoed
-- ストール予約明細ＤＢ
from ai21rep_ve_stg_kudu.tbsa005g t005g
-- ストールマスタ_充足率対象ＤＢ
left semi join gold.vbi012002 v3002 on v3002.cd_hansya = t005g.cd_hansya
and v3002.cd_kaisya = t005g.cd_kaisya
and v3002.cd_tenpo = t005g.cd_tenpo
and v3002.no_stall = t005g.no_stall
-- [ＳＭＢ削除フラグ] = "0"
where t005g.mj_sakujyo = '0'
--使用開始日時が現在の日付から14日以内の範囲
and ((t005g.dt_siyost >= cast(current_timestamp() as date) and t005g.dt_siyost < date_add(cast(current_timestamp() as date), 14))
--使用終了日時が現在の日付から14日以内の範囲
or (t005g.dt_siyoed >= cast(current_timestamp() as date) and t005g.dt_siyoed < date_add(cast(current_timestamp() as date), 14)))
union all
select
	tb05s.cd_hansya,
	tb05s.cd_kaisya,
	tb05s.cd_tenpo,
	tb05s.no_stall,
	tb05s.dt_siyost,
	tb05s.dt_siyoed
-- ストール予約明細退避ＤＢ
from ai21rep_ve_stg_kudu.tbsab05s tb05s
-- ストールマスタ_充足率対象ＤＢ
left semi join gold.vbi012002 v3002 on v3002.cd_hansya = tb05s.cd_hansya
and v3002.cd_kaisya = tb05s.cd_kaisya
and v3002.cd_tenpo = tb05s.cd_tenpo
and v3002.no_stall = tb05s.no_stall
-- ストール予約明細ＤＢ
left anti join ai21rep_ve_stg_kudu.tbsa005g t005g on t005g.cd_hansya = tb05s.cd_hansya
and t005g.cd_kaisya = tb05s.cd_kaisya
and t005g.cd_tenpo = tb05s.cd_tenpo
and t005g.no_yoyakuid = tb05s.no_yoyakuid
and t005g.no_stall = tb05s.no_stall
and t005g.mj_sakujyo = '0'
-- ストール予約明細退避ＤＢ，重複判別
left anti join ai21rep_ve_stg_kudu.tbsab05s tb05s2 on tb05s2.cd_hansya = tb05s.cd_hansya
and tb05s2.cd_kaisya = tb05s.cd_kaisya
and tb05s2.cd_tenpo = tb05s.cd_tenpo
and tb05s2.no_yoyakuid = tb05s.no_yoyakuid
and tb05s2.cd_yoykmsai = tb05s.cd_yoykmsai
and tb05s2.no_stall = tb05s.no_stall
and tb05s2.mj_sakujyo = '0'
and tb05s2.no_msaiedmx <> tb05s.no_msaiedmx
-- [ＳＭＢ削除フラグ] = "0"
where tb05s.mj_sakujyo = '0'
--使用開始日時が現在の日付から14日以内の範囲
and ((tb05s.dt_siyost >= cast(current_timestamp() as date) and tb05s.dt_siyost < date_add(cast(current_timestamp() as date), 14))
--使用終了日時が現在の日付から14日以内の範囲
or (tb05s.dt_siyoed >= cast(current_timestamp() as date) and tb05s.dt_siyoed < date_add(cast(current_timestamp() as date), 14)))
;

-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000002_en
select
	--販社コード
	t206m.cd_hansya,
	--会社コード
	t206m.cd_kaisya,
	--取替部品品番
	trim(t206m.mj_toribhhn) as mj_toribhhn,
	--取替部品品名
	max(t022g.mj_torihnme) as mj_torihnme
--リコール展開明細ＤＢ
from ai21rep_ve_dx.tbfy206m t206m
--市場処置部品集計ＤＢ
left join ai21rep_ve_dx.tbfj022g t022g on t022g.cd_hansya = t206m.cd_hansya
and t022g.cd_kaisya = t206m.cd_kaisya
and trim(t022g.mj_toribhhn) = trim(t206m.mj_toribhhn)
and nvl(trim(t022g.mj_torihnme), '') <> ''
--取替部品品番の前三桁 = '040'： 市場処置部品
where left(t206m.mj_toribhhn, 3) = '040'
group by t206m.cd_hansya, t206m.cd_kaisya, trim(t206m.mj_toribhhn)
;

-- Source file: 022_中古車車両日報/中古車車両日報.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi022002
SELECT
	--販社コード
    cd_hansya,
    --会社コード
    cd_kaisya,
    --受注店舗コード
    cd_jytyuten AS cd_tenpo,
    --車名コード
    cd_ncsyamei,
    --車名
    kn_syame,
    --日付
    CAST(TO_DATE(dd_date) AS DATE) AS dd_date,
    --中古車販売実績
    nullif(SUM(su_jusya_hanbai), 0) AS su_jusya_hanbai,
    --中古車販売取消
    nullif(SUM(su_jusya_hanbai_torikesi), 0) AS su_jusya_hanbai_torikesi,
    --中古車販売合計
    nullif(SUM(su_jusya_hanbai) - SUM(su_jusya_hanbai_torikesi), 0) AS su_jusya_hanbai_goukei,
    --当月中古車販売
    nullif(SUM(
            CASE
                WHEN date_format(dd_date, 'yyyyMM') =
                     date_format(current_timestamp(), 'yyyyMM')
                THEN su_jusya_hanbai - su_jusya_hanbai_torikesi
                ELSE 0
            END
        ), 0) AS su_jusya_hanbai_current
FROM
(
    SELECT
    	--販社コード
        tg.cd_hansya,
        --会社コード
        tg.cd_kaisya,
        --受注店舗コード
        tg.cd_jytyuten,
        --車名コード
        CONCAT(
            NVL(tbbc001g.mj_21syamek, ''),
            NVL(tbbc001g.mj_21syasyu, ''),
            NVL(tbbc001g.mj_21syamak, ''),
            NVL(tbbc001g.no_21syaren, ''),
            NVL(tbbc001g.mj_21syanin, '')
        ) AS cd_ncsyamei,
        --車名
        UPPER(NVL(tbv0232m.mj_syamei, '')) AS kn_syame,
        --日付
        CASE
            WHEN ft8006.dd_uriage IS NULL THEN tg.dd_uriagekj
            ELSE TO_TIMESTAMP(CAST(ft8006.dd_uriage AS STRING), 'yyyyMMdd')
        END AS dd_date,
        --中古車販売実績
        COUNT(*) AS su_jusya_hanbai,
        --中古車販売取消
        0 AS su_jusya_hanbai_torikesi
    FROM ai21rep_ve_dx.tbbc017g tg  --中古車受注基本情報ＤＢ
    LEFT JOIN ai21rep_ve_dx.tbbc001g tbbc001g  --中古車在庫基本情報ＤＢ
        ON tbbc001g.cd_kaisya = tg.cd_kaisya
        AND tbbc001g.cd_hansya = tg.cd_hansya
        AND tbbc001g.no_syaryou = tg.no_syaryou
    LEFT JOIN
    (
        SELECT
        	--販社コード
            t8006.cd_hansya,
            --会社コード
            t8006.cd_kaisya,
            --注文NO
            t8006.no_cyumon,
            --売上日
            MIN(t8006.dd_uriage) AS dd_uriage
        FROM ai21rep_ve_dx.tbg8006m t8006  --中古車小売売上トランＤＢ
        GROUP BY
            t8006.cd_hansya,
            t8006.cd_kaisya,
            t8006.no_cyumon,
            t8006.dd_uriage
    ) ft8006
        ON tg.cd_kaisya = ft8006.cd_kaisya
        AND tg.cd_kaisya = ft8006.cd_kaisya
        AND tg.no_cyumon = ft8006.no_cyumon
        --売上取消日が空である
        AND tg.dd_uritorik IS NULL
    LEFT JOIN ai21rep_ve_dx.tbv0232m tbv0232m
        ON tbv0232m.cd_hansya = tbbc001g.cd_hansya
        AND tbv0232m.cd_kaisya = tbbc001g.cd_kaisya
        AND tbv0232m.cd_syamei = CONCAT(
            NVL(tbbc001g.mj_21syamek, ''),
            NVL(tbbc001g.mj_21syasyu, ''),
            NVL(tbbc001g.mj_21syamak, ''),
            NVL(tbbc001g.no_21syaren, ''),
            NVL(tbbc001g.mj_21syanin, '')
        )
    WHERE 
        --売上計上日が空ではない
        tg.dd_uriagekj IS NOT NULL
        --取消日が空である
        AND tg.dd_torikesi IS NULL
        AND (
            (--売上日が空である
            ft8006.dd_uriage IS NULL
            	--売上計上日が前月1日より大きい
                AND date_format(tg.dd_uriagekj, 'yyyyMM') >=
                    date_format(ADD_MONTHS(current_timestamp(), -1), 'yyyyMM'))
            OR
            (--売上日が空ではない
            ft8006.dd_uriage IS NOT NULL
            	--売上日が前月1日より大きい
                AND date_format(TO_TIMESTAMP(CAST(ft8006.dd_uriage AS STRING), 'yyyyMMdd'), 'yyyyMM') >=
                    date_format(ADD_MONTHS(current_timestamp(), -1), 'yyyyMM'))
        )
    GROUP BY
        tg.cd_hansya,
        tg.cd_kaisya,
        tg.cd_jytyuten,
        CONCAT(
            NVL(tbbc001g.mj_21syamek, ''),
            NVL(tbbc001g.mj_21syasyu, ''),
            NVL(tbbc001g.mj_21syamak, ''),
            NVL(tbbc001g.no_21syaren, ''),
            NVL(tbbc001g.mj_21syanin, '')
        ),
        kn_syame,
        dd_date,
        tbbc001g.no_syaryou
    UNION ALL
    SELECT
    	--販社コード
        tg.cd_hansya,
        --会社コード
        tg.cd_kaisya,
        --受注店舗コード
        tg.cd_jytyuten,
        --車名コード
        CONCAT(
            NVL(tbbc001g.mj_21syamek, ''),
            NVL(tbbc001g.mj_21syasyu, ''),
            NVL(tbbc001g.mj_21syamak, ''),
            NVL(tbbc001g.no_21syaren, ''),
            NVL(tbbc001g.mj_21syanin, '')
        ) AS cd_ncsyamei,
        --車名
        UPPER(NVL(tbv0232m.mj_syamei, '')) AS kn_syame,
        --日付
        tg.dd_uritorik AS dd_date,
        --中古車販売実績
        0 AS su_jusya_hanbai,
        --中古車販売取消
        COUNT(*) AS su_jusya_hanbai_torikesi
    FROM ai21rep_ve_dx.tbbc017g tg  -- 中古車受注基本情報ＤＢ
    LEFT JOIN ai21rep_ve_dx.tbbc001g tbbc001g  -- 中古車在庫基本情報ＤＢ
        ON tbbc001g.cd_kaisya = tg.cd_kaisya
        AND tbbc001g.cd_hansya = tg.cd_hansya
        AND tbbc001g.no_syaryou = tg.no_syaryou
    LEFT JOIN ai21rep_ve_dx.tbv0232m tbv0232m  -- ａｉ２１車名コードＤＢ
        ON tbv0232m.cd_hansya = tbbc001g.cd_hansya
        AND tbv0232m.cd_kaisya = tbbc001g.cd_kaisya
        -- 車名コード = ａｉ２１車名コードメーカー & ａｉ２１車名コード車種  &  ａｉ２１車名コード市場  &  ａｉ２１車名コード連番  &  ａｉ２１車名コード任意
        AND tbv0232m.cd_syamei = CONCAT(
            NVL(tbbc001g.mj_21syamek, ''),
            NVL(tbbc001g.mj_21syasyu, ''),
            NVL(tbbc001g.mj_21syamak, ''),
            NVL(tbbc001g.no_21syaren, ''),
            NVL(tbbc001g.mj_21syanin, '')
        )
    WHERE 
        -- 受注計上日が空ではない
        tg.dd_jucyuke IS NOT NULL
        -- 売上取消日が前月1日より大きい
        AND date_format(tg.dd_uritorik, 'yyyyMM') >=
            date_format(ADD_MONTHS(current_timestamp(), -1), 'yyyyMM')
    GROUP BY
        tg.cd_hansya,
        tg.cd_kaisya,
        tg.cd_jytyuten,
        CONCAT(
            NVL(tbbc001g.mj_21syamek, ''),
            NVL(tbbc001g.mj_21syasyu, ''),
            NVL(tbbc001g.mj_21syamak, ''),
            NVL(tbbc001g.no_21syaren, ''),
            NVL(tbbc001g.mj_21syanin, '')
        ),
        kn_syame,
        tg.dd_uritorik,
        tbbc001g.no_syaryou
) combined
GROUP BY
    cd_hansya,
    cd_kaisya,
    cd_jytyuten,
    cd_ncsyamei,
    kn_syame,
    TO_DATE(dd_date)
;

-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi000003
select
	--販社コード
 	t001g.cd_hansya as `販社コード`,
 	--会社コード
 	t001g.cd_kaisya as `会社コード`,
 	--整理ＮＯ
	t001g.no_seiri as `整理ＮＯ`,
	--フレーム型式
	t001g.mj_framekat as `フレーム型式`,
	--データ分類
	if (
		max(t205m.dd_tekkikst) >= add_months(cast(current_timestamp() as date), -(24)),
		'2年のみ',
		'過去全部'
	) as `データ分類`
--リコールメインＤＢ
from ai21rep_ve_dx.tbfj001g t001g
--ストール予約ＤＢ
left join ai21rep_ve_dx.tbsa001g ta001g on ta001g.cd_hansya = t001g.cd_hansya
and ta001g.cd_kaisya = t001g.cd_kaisya
and ta001g.no_aijutyu = t001g.no_jucyu
--リコール展開名称ＤＢ
left join ai21rep_ve_dx.tbfy205m t205m on t205m.cd_hansya = t001g.cd_hansya
and t205m.cd_kaisya = t001g.cd_kaisya
and t205m.no_seiri = t001g.no_seiri
and trim(t205m.mj_framekat) = trim(t001g.mj_framekat)
group by t001g.cd_hansya, t001g.cd_kaisya, t001g.no_seiri, t001g.mj_framekat
;

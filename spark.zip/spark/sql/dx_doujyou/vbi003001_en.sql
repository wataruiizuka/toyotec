-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi003001_en
select
	--日付
	bt.dd_date,
	--日付_月
	trunc(bt.dd_date, 'MM') as dd_month,
	--日付_yyyy/MM/dd
	date_format(bt.dd_date, 'yyyy/MM/dd') as `dd_yyyy/MM/dd`,
	--日付_yyyyMMdd
	date_format(bt.dd_date, 'yyyyMMdd') as `dd_yyyyMMdd`,
	--週末判定
	case dayofweek(bt.dd_date)
		when 1 then '2'
		when 7 then '2'
		else '1'
	end as kb_week
from (
	select
		date_add(cast(current_timestamp() as date), i) as dd_date
	from(
		VALUES (0),(1),(2),(3),(4),(5),(6),(7),(8),(9),(10),(11),(12),(13)
	) AS dd(i)
) bt
;

-- Source file: 101_マスタメンテナンス/vbi999001-VBI999010.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi999008
SELECT
	bt.cd_hansya AS `販社コード`, --販社コード
	bt.cd_kaisya AS `会社コード`, --会社コード
	CASE WHEN count(bt.mj_message) = 0 THEN NULL ELSE concat_ws('<br /><br />', collect_list(bt.mj_message)) END AS `メッセージ` --メッセージ
FROM (
	SELECT
		bt.cd_hansya, --販社コード
		bt.cd_kaisya, --会社コード
		CONCAT('※店舗情報が変更されましたため、マスタ情報の設定をお願い致します<br />下記が対象の店舗となります<br />※店舗コード_店舗名の順で記載しております<br />-------------<br />', CASE WHEN count(bt.mj_message) = 0 THEN NULL ELSE concat_ws('<br /><br />', collect_list(bt.mj_message)) END, '<br />-------------') AS mj_message  --メッセージ
	FROM (
		SELECT
			t201m.cd_hansya, --販社コード
			t201m.cd_kaisya, --会社コード
			CONCAT('■新規追加された店舗<br />', CASE WHEN count(CONCAT(t201m.cd_tenpo, '_', regexp_replace(t201m.kj_tenpomei, '　+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(t201m.cd_tenpo, '_', regexp_replace(t201m.kj_tenpomei, '　+$', '')))) END) AS mj_message   --メッセージ
		FROM ai21rep_ve_dx.tbv0201m t201m --共通店舗ＤＢ 
		LEFT anti JOIN dx_ve.tbi003001m v3001m --SMB異常管理ボード集計対象店舗一覧
		ON v3001m.cd_hansya = t201m.cd_hansya
		AND v3001m.cd_kaisya = t201m.cd_kaisya
		AND v3001m.cd_tenpo = t201m.cd_tenpo
		GROUP BY t201m.cd_hansya, t201m.cd_kaisya
		UNION ALL
		SELECT
			t201m.cd_hansya, --販社コード
			t201m.cd_kaisya, --会社コード
			CONCAT('■変更があった店舗<br />', CASE WHEN count(CONCAT(v3001m.cd_tenpo, '_', regexp_replace(v3001m.kj_tenpomei, '　+$', ''), '　→', t201m.cd_tenpo, '_', regexp_replace(t201m.kj_tenpomei, '　+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(v3001m.cd_tenpo, '_', regexp_replace(v3001m.kj_tenpomei, '　+$', ''), '　→', t201m.cd_tenpo, '_', regexp_replace(t201m.kj_tenpomei, '　+$', '')))) END) AS mj_message --メッセージ
		FROM ai21rep_ve_dx.tbv0201m t201m --共通店舗ＤＢ 
		INNER JOIN dx_ve.tbi003001m v3001m --SMB異常管理ボード集計対象店舗一覧
		ON v3001m.cd_hansya = t201m.cd_hansya
		AND v3001m.cd_kaisya = t201m.cd_kaisya
		AND v3001m.cd_tenpo = t201m.cd_tenpo
		AND CONCAT(v3001m.cd_tenpo, '_', regexp_replace(v3001m.kj_tenpomei, '　+$', '')) <> CONCAT(t201m.cd_tenpo, '_', regexp_replace(t201m.kj_tenpomei, '　+$', ''))
		GROUP BY t201m.cd_hansya, t201m.cd_kaisya
		UNION ALL
		SELECT
			v3001m.cd_hansya, --販社コード
			v3001m.cd_kaisya, --会社コード
			CONCAT('■削除された店舗<br />', CASE WHEN count(CONCAT(v3001m.cd_tenpo, '_', regexp_replace(v3001m.kj_tenpomei, '　+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(v3001m.cd_tenpo, '_', regexp_replace(v3001m.kj_tenpomei, '　+$', '')))) END)  --メッセージ
		FROM dx_ve.tbi003001m v3001m --SMB異常管理ボード集計対象店舗一覧
		LEFT anti JOIN ai21rep_ve_dx.tbv0201m t201m --共通店舗ＤＢ 
		ON t201m.cd_hansya = v3001m.cd_hansya
		AND t201m.cd_kaisya = v3001m.cd_kaisya
		AND t201m.cd_tenpo = v3001m.cd_tenpo
		GROUP BY v3001m.cd_hansya, v3001m.cd_kaisya
	) bt
	GROUP BY bt.cd_hansya, bt.cd_kaisya
	UNION ALL
	SELECT
		bt.cd_hansya, --販社コード
		bt.cd_kaisya, --会社コード
		CONCAT('※ストール情報が変更されましたため、マスタ情報の設定をお願い致します<br />下記が対象のストールとなります<br />※ストールコード_ストール名の順で記載しております<br />-------------<br />', CASE WHEN count(bt.mj_message) = 0 THEN NULL ELSE concat_ws('<br /><br />', collect_list(bt.mj_message)) END, '<br />-------------')  --メッセージ
	FROM (
		SELECT
			t001m.cd_hansya, --販社コード
			t001m.cd_kaisya, --会社コード
			CONCAT('■新規追加されたストール<br />', CASE WHEN count(CONCAT(CAST(t001m.no_stall AS string), '_', t001m.mj_stallmei)) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(CAST(t001m.no_stall AS string), '_', t001m.mj_stallmei))) END) AS mj_message --メッセージ
		FROM ai21rep_ve_dx.tbsa001m t001m --ストールマスタＤＢ
		LEFT semi JOIN ai21rep_ve_dx.tbv0201m t201m  --共通店舗ＤＢ
		ON t201m.cd_hansya = t001m.cd_hansya
		AND t201m.cd_kaisya = t001m.cd_kaisya
		AND t201m.cd_tenpo = t001m.cd_tenpo
		LEFT anti JOIN dx_ve.tbi003002m v3002m --ストール集計対象一覧
		ON v3002m.cd_hansya = t001m.cd_hansya
		AND v3002m.cd_kaisya = t001m.cd_kaisya
		AND v3002m.cd_tenpo = t001m.cd_tenpo
		AND v3002m.no_stall = t001m.no_stall
		GROUP BY t001m.cd_hansya, t001m.cd_kaisya
		UNION ALL
		SELECT
			t001m.cd_hansya, --販社コード
			t001m.cd_kaisya, --会社コード
			CONCAT('■変更があったストール<br />', CASE WHEN count(CONCAT(CAST(v3002m.no_stall AS string), '_', v3002m.mj_stallmei, '　→', CAST(t001m.no_stall AS string), '_', t001m.mj_stallmei)) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(CAST(v3002m.no_stall AS string), '_', v3002m.mj_stallmei, '　→', CAST(t001m.no_stall AS string), '_', t001m.mj_stallmei))) END) --メッセージ
		FROM ai21rep_ve_dx.tbsa001m t001m --ストールマスタＤＢ
		LEFT semi JOIN ai21rep_ve_dx.tbv0201m t201m  --共通店舗ＤＢ
		ON t201m.cd_hansya = t001m.cd_hansya
		AND t201m.cd_kaisya = t001m.cd_kaisya
		AND t201m.cd_tenpo = t001m.cd_tenpo
		INNER JOIN dx_ve.tbi003002m v3002m --ストール集計対象一覧
		ON v3002m.cd_hansya = t001m.cd_hansya
		AND v3002m.cd_kaisya = t001m.cd_kaisya
		AND v3002m.cd_tenpo = t001m.cd_tenpo
		AND v3002m.no_stall = t001m.no_stall
		AND CONCAT(CAST(v3002m.no_stall AS string), '_', v3002m.mj_stallmei) <> CONCAT(CAST(t001m.no_stall AS string), '_', t001m.mj_stallmei)
		GROUP BY t001m.cd_hansya, t001m.cd_kaisya
		UNION ALL
		SELECT
			v3002m.cd_hansya, --販社コード
			v3002m.cd_kaisya, --会社コード
			CONCAT('■削除されたストール<br />', CASE WHEN count(CONCAT(CAST(v3002m.no_stall AS string), '_', v3002m.mj_stallmei)) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(CAST(v3002m.no_stall AS string), '_', v3002m.mj_stallmei))) END) --メッセージ
		FROM dx_ve.tbi003002m v3002m --ストール集計対象一覧
		LEFT semi JOIN ai21rep_ve_dx.tbv0201m t201m  --共通店舗ＤＢ
		ON t201m.cd_hansya = v3002m.cd_hansya
		AND t201m.cd_kaisya = v3002m.cd_kaisya
		AND t201m.cd_tenpo = v3002m.cd_tenpo
		LEFT anti JOIN ai21rep_ve_dx.tbsa001m t001m --ストールマスタＤＢ 
		ON t001m.cd_hansya = v3002m.cd_hansya
		AND t001m.cd_kaisya = v3002m.cd_kaisya
		AND t001m.cd_tenpo = v3002m.cd_tenpo
		AND t001m.no_stall = v3002m.no_stall
		GROUP BY v3002m.cd_hansya, v3002m.cd_kaisya
	) bt
	GROUP BY bt.cd_hansya, bt.cd_kaisya
	UNION ALL
	SELECT
		bt.cd_hansya, --販社コード
		bt.cd_kaisya, --会社コード
		CONCAT('※新車車種情報が変更されましたため、マスタ情報の設定をお願い致します<br />下記が対象の車名となります<br />※車名コード_車名の順で記載しております<br />-------------<br />', CASE WHEN count(bt.mj_meaasge) = 0 THEN NULL ELSE concat_ws('<br /><br />', collect_list(bt.mj_meaasge)) END, '<br />-------------') --メッセージ
	FROM (
		SELECT
			tf001m.cd_hansya, --販社コード
			tf001m.cd_kaisya, --会社コード
			CONCAT('■新規追加された車種<br />',CASE WHEN count(CONCAT(tf001m.cd_ncsyamei, '_', regexp_replace(tf001m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(tf001m.kj_kurumame, '[　| ]+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(tf001m.cd_ncsyamei, '_', regexp_replace(tf001m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(tf001m.kj_kurumame, '[　| ]+$', '')))) END) AS mj_meaasge --メッセージ
		FROM ai21rep_ve_dx.tbbf001m tf001m --車名ＤＢ
		LEFT anti JOIN dx_ve.tbi999008m t9008m --新車車種表示設定
		ON t9008m.cd_hansya = tf001m.cd_hansya
		AND t9008m.cd_kaisya = tf001m.cd_kaisya
		AND t9008m.cd_ncsyamei = tf001m.cd_ncsyamei
		GROUP BY tf001m.cd_hansya, tf001m.cd_kaisya
		UNION ALL
		SELECT
			tf001m.cd_hansya, --販社コード
			tf001m.cd_kaisya, --会社コード
			CONCAT('■変更があった車種<br />',CASE WHEN count(CONCAT(t9008m.cd_ncsyamei, '_', regexp_replace(t9008m.kn_syamei, '[　| ]+$', ''), '_', regexp_replace(t9008m.kj_kurumame, '[　| ]+$', ''), '　→', tf001m.cd_ncsyamei, '_', regexp_replace(tf001m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(tf001m.kj_kurumame, '[　| ]+$', ''))) = 0 THEN NULL ELSE concat_ws('<br />', collect_list(CONCAT(t9008m.cd_ncsyamei, '_', regexp_replace(t9008m.kn_syamei, '[　| ]+$', ''), '_', regexp_replace(t9008m.kj_kurumame, '[　| ]+$', ''), '　→', tf001m.cd_ncsyamei, '_', regexp_replace(tf001m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(tf001m.kj_kurumame, '[　| ]+$', '')))) END) --メッセージ
		FROM ai21rep_ve_dx.tbbf001m tf001m --車名ＤＢ
		INNER JOIN dx_ve.tbi999008m t9008m --新車車種表示設定 
		ON t9008m.cd_hansya = tf001m.cd_hansya
		AND t9008m.cd_kaisya = tf001m.cd_kaisya
		AND t9008m.cd_ncsyamei = tf001m.cd_ncsyamei
		AND CONCAT(regexp_replace(t9008m.kn_syamei, '[　| ]+$', ''), '_', regexp_replace(t9008m.kj_kurumame, '[　| ]+$', '')) <> CONCAT(regexp_replace(tf001m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(tf001m.kj_kurumame, '[　| ]+$', ''))
		GROUP BY tf001m.cd_hansya, tf001m.cd_kaisya
		UNION ALL
		SELECT
			t9008m.cd_hansya, --販社コード
			t9008m.cd_kaisya, --会社コード
			CONCAT('■削除された車種<br />',CASE WHEN count(CONCAT(t9008m.cd_ncsyamei, '_', regexp_replace(t9008m.kn_syamei, '[　| ]+$', ''), '_', regexp_replace(t9008m.kj_kurumame, '[　| ]+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(t9008m.cd_ncsyamei, '_', regexp_replace(t9008m.kn_syamei, '[　| ]+$', ''), '_', regexp_replace(t9008m.kj_kurumame, '[　| ]+$', '')))) END)  --メッセージ
		FROM dx_ve.tbi999008m t9008m --新車車種表示設定 
		LEFT anti JOIN ai21rep_ve_dx.tbbf001m tf001m --車名ＤＢ 
		ON tf001m.cd_hansya = t9008m.cd_hansya
		AND tf001m.cd_kaisya = t9008m.cd_kaisya
		AND tf001m.cd_ncsyamei = t9008m.cd_ncsyamei
		GROUP BY t9008m.cd_hansya, t9008m.cd_kaisya
	) bt
	GROUP BY bt.cd_hansya, bt.cd_kaisya
	UNION ALL
	SELECT
		bt.cd_hansya, --販社コード
		bt.cd_kaisya, --会社コード
		CONCAT('※中古車車種情報が変更されましたため、マスタ情報の設定をお願い致します<br />下記が対象の車名となります<br />※車名コード_車名の順で記載しております<br />-------------<br />', CASE WHEN count(bt.mj_meaasge) = 0 THEN NULL ELSE concat_ws('<br /><br />', collect_list(bt.mj_meaasge)) END, '<br />-------------') --メッセージ
	FROM (
		SELECT
			t0232m.cd_hansya, --販社コード
			t0232m.cd_kaisya, --会社コード
			CONCAT('■新規追加された車種<br />',CASE WHEN count(CONCAT(t0232m.cd_syamei, '_', regexp_replace(t0232m.mj_syamei, '[　| ]+$', ''), '_', regexp_replace(t0232m.kj_syamei, '[　| ]+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(t0232m.cd_syamei, '_', regexp_replace(t0232m.mj_syamei, '[　| ]+$', ''), '_', regexp_replace(t0232m.kj_syamei, '[　| ]+$', '')))) END) AS mj_meaasge --メッセージ
		FROM ai21rep_ve_dx.tbv0232m t0232m --ａｉ２１車名コードＤＢ
		LEFT anti JOIN dx_ve.tbi999009m t9009m --中古車車種表示設定 
		ON t9009m.cd_hansya = t0232m.cd_hansya
		AND t9009m.cd_kaisya = t0232m.cd_kaisya
		AND t9009m.cd_ocsyamei = t0232m.cd_syamei
		WHERE t0232m.mj_syamei IS NOT NULL
		GROUP BY t0232m.cd_hansya, t0232m.cd_kaisya
		UNION ALL
		SELECT
			t0232m.cd_hansya, --販社コード
			t0232m.cd_kaisya, --会社コード
			CONCAT('■変更があった車種<br />',CASE WHEN count(CONCAT(t9009m.cd_ocsyamei, '_', regexp_replace(t9009m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(t9009m.kj_kurumame, '[　| ]+$', ''), '　→', t0232m.cd_syamei, '_', regexp_replace(t0232m.mj_syamei, '[　| ]+$', ''), '_', regexp_replace(t0232m.kj_syamei, '[　| ]+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(t9009m.cd_ocsyamei, '_', regexp_replace(t9009m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(t9009m.kj_kurumame, '[　| ]+$', ''), '　→', t0232m.cd_syamei, '_', regexp_replace(t0232m.mj_syamei, '[　| ]+$', ''), '_', regexp_replace(t0232m.kj_syamei, '[　| ]+$', '')))) END) --メッセージ
		FROM ai21rep_ve_dx.tbv0232m t0232m --ａｉ２１車名コードＤＢ
		INNER JOIN dx_ve.tbi999009m t9009m --中古車車種表示設定 
		ON t9009m.cd_hansya = t0232m.cd_hansya
		AND t9009m.cd_kaisya = t0232m.cd_kaisya
		AND t9009m.cd_ocsyamei = t0232m.cd_syamei
		AND CONCAT(t9009m.cd_ocsyamei, '_', regexp_replace(t9009m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(t9009m.kj_kurumame, '[　| ]+$', '')) <> CONCAT(t0232m.cd_syamei, '_', regexp_replace(t0232m.mj_syamei, '[　| ]+$', ''), '_', regexp_replace(t0232m.kj_syamei, '[　| ]+$', ''))
		WHERE t0232m.mj_syamei IS NOT NULL
		GROUP BY t0232m.cd_hansya, t0232m.cd_kaisya
		UNION ALL
		SELECT
			t9009m.cd_hansya, --販社コード
			t9009m.cd_kaisya, --会社コード
			CONCAT('■削除された車種<br />',CASE WHEN count(CONCAT(t9009m.cd_ocsyamei, '_', regexp_replace(t9009m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(t9009m.kj_kurumame, '[　| ]+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(t9009m.cd_ocsyamei, '_', regexp_replace(t9009m.kn_syame, '[　| ]+$', ''), '_', regexp_replace(t9009m.kj_kurumame, '[　| ]+$', '')))) END) --メッセージ
		FROM dx_ve.tbi999009m t9009m --中古車車種表示設定
		LEFT anti JOIN ai21rep_ve_dx.tbv0232m t0232m --ａｉ２１車名コードＤＢ 
		ON t0232m.cd_hansya = t9009m.cd_hansya
		AND t0232m.cd_kaisya = t9009m.cd_kaisya
		AND t0232m.cd_syamei = t9009m.cd_ocsyamei
		WHERE t9009m.kn_syame IS NOT NULL
		GROUP BY t9009m.cd_hansya, t9009m.cd_kaisya
	) bt
	GROUP BY bt.cd_hansya, bt.cd_kaisya
	UNION ALL
	SELECT
		bt.cd_hansya, --販社コード
		bt.cd_kaisya, --会社コード
		CONCAT('※入金区分情報が変更されましたため、マスタ情報の設定をお願い致します<br />下記が対象の入金区分となります<br />※入金区分コード_入金区分名の順で記載しております<br />-------------<br />', CASE WHEN count(bt.mj_message) = 0 THEN NULL ELSE concat_ws('<br /><br />', collect_list(bt.mj_message)) END, '<br />-------------') mj_message --メッセージ
	FROM
		(
		SELECT
			tbv0208m.cd_hansya, --販社コード
			tbv0208m.cd_kaisya, --会社コード
			CONCAT('■新規追加された入金区分<br />', CASE WHEN count(CONCAT(tbv0208m.kb_nyuukin, '_', regexp_replace(tbv0208m.kj_nyuukinm, '　+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(tbv0208m.kb_nyuukin, '_', regexp_replace(tbv0208m.kj_nyuukinm, '　+$', '')))) END) mj_message --メッセージ
		FROM
			ai21rep_ve_dx.tbv0208m tbv0208m --入金区分ＤＢ 
			LEFT ANTI
		JOIN dx_ve.tbi999013m tbi999013m --入金区分設定  
		ON
			tbv0208m.cd_hansya = tbi999013m.cd_hansya
			AND tbv0208m.cd_kaisya = tbi999013m.cd_kaisya
			AND tbv0208m.kb_nyuukin = tbi999013m.kb_nyuukin
		GROUP BY
			tbv0208m.cd_hansya,
			tbv0208m.cd_kaisya
	UNION ALL
	SELECT
			tbv0208m.cd_hansya, --販社コード
			tbv0208m.cd_kaisya, --会社コード
			CONCAT('■変更があった入金区分<br />', CASE WHEN count(CONCAT(regexp_replace(tbi999013m.kj_nyuukinm, '　+$', ''), '　→', regexp_replace(tbv0208m.kj_nyuukinm, '　+$', ''))) = 0 THEN NULL ELSE concat_ws('、', collect_list(CONCAT(regexp_replace(tbi999013m.kj_nyuukinm, '　+$', ''), '　→', regexp_replace(tbv0208m.kj_nyuukinm, '　+$', '')))) END) mj_message --メッセージ
		FROM
			ai21rep_ve_dx.tbv0208m tbv0208m --入金区分ＤＢ
		INNER JOIN dx_ve.tbi999013m tbi999013m --入金区分設定  
		ON
			tbv0208m.cd_hansya = tbi999013m.cd_hansya
			AND tbv0208m.cd_kaisya = tbi999013m.cd_kaisya
			AND tbv0208m.kb_nyuukin = tbi999013m.kb_nyuukin
			AND regexp_replace(tbv0208m.kj_nyuukinm, '　+$', '') != regexp_replace(tbi999013m.kj_nyuukinm, '　+$', '')
		GROUP BY
			tbv0208m.cd_hansya,
			tbv0208m.cd_kaisya
	UNION ALL
		SELECT
			tbi999013m.cd_hansya, --販社コード
			tbi999013m.cd_kaisya, --会社コード
			CONCAT('■削除された入金区分<br />', CASE WHEN count(regexp_replace(tbi999013m.kj_nyuukinm, '　+$', '')) = 0 THEN NULL ELSE concat_ws('、', collect_list(regexp_replace(tbi999013m.kj_nyuukinm, '　+$', ''))) END) --メッセージ
		FROM
			dx_ve.tbi999013m tbi999013m --入金区分設定  LEFT ANTI
		JOIN ai21rep_ve_dx.tbv0208m tbv0208m --入金区分ＤＢ 
		ON
			tbv0208m.cd_hansya = tbi999013m.cd_hansya
			AND tbv0208m.cd_kaisya = tbi999013m.cd_kaisya
			AND tbv0208m.kb_nyuukin = tbi999013m.kb_nyuukin
		GROUP BY
			tbi999013m.cd_hansya,
			tbi999013m.cd_kaisya) bt
	GROUP BY
		bt.cd_hansya,
		bt.cd_kaisya	
) bt
GROUP BY bt.cd_hansya, bt.cd_kaisya
;

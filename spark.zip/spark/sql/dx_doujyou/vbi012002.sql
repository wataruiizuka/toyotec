-- Source file: 012_SMB空き枠カレンダー（ストール軸管理向け）/smbcalendar.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi012002
select
	--販社コード
	t3002m.cd_hansya,
	--会社コード
	t3002m.cd_kaisya,
	--店舗コード
	t3002m.cd_tenpo,
	--ストール番号
	t3002m.no_stall,
	--ストール名称
	t3002m.mj_stallmei,
	--ストール選択
	concat(cast(t3002m.no_stall as string), '　', t3002m.mj_stallmei) as kb_stallsentaku,
	--販社会社店舗コード
	concat(t3002m.cd_hansya, t3002m.cd_kaisya, t3002m.cd_tenpo) as `cd_hansyakaisyatenpo`,
	--ソート順
	t9003m.mj_sortjyun
-- ストール集計対象一覧
from dx_ve.tbi003002m t3002m
-- SMB異常管理ボード集計対象店舗一覧
left semi join dx_ve.tbi003001m t3001m on t3001m.cd_hansya = t3002m.cd_hansya
and t3001m.cd_kaisya = t3002m.cd_kaisya
and t3001m.cd_tenpo = t3002m.cd_tenpo
-- 店舗表示設定
inner join dx_ve.tbi999003m t9003m on t9003m.cd_hansya = t3002m.cd_hansya
and t9003m.cd_kaisya = t3002m.cd_kaisya
and t9003m.cd_tenpo = t3002m.cd_tenpo
and t9003m.mj_cyohyoid = '012'
and t9003m.kb_tenji = 1
where t3002m.kb_shuukeitaishou = '1'
-- ISERROR(SEARCH("コント", [ストール名称], 1))
and instr(t3002m.mj_stallmei, 'コント') = 0
-- ISERROR(SEARCH("外注", [ストール名称], 1))
and instr(t3002m.mj_stallmei, '外注') = 0
;

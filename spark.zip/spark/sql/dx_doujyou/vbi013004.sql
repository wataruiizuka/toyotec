-- Source file: 013_中古車売掛金/VBI013004_中古車売掛金回収状況.sql
-- Dependency level: 2
-- Internal Gold dependencies: gold.vbi013004_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.VBI013004
SELECT
	cd_hansya AS `販社コード`, --販社コード
	cd_kaisya AS `会社コード`, --会社コード
	cd_jytyuten AS `店舗コード`, --店舗コード
	cd_hansya_kaisya_jytyuten AS `販社会社店舗コード`, --販社会社店舗コード
    su_jucyu AS `受注台数`, --受注台数
    su_touroku AS `登録台数`, --登録台数
    no_trade_in_vehicles_registered_this_month AS `当月登録内下取車なし`, --当月登録内下取車なし
	currently_registered_but_uncollected_cases AS `現在登録済未回収件数`, --現在登録済未回収件数
    currently_registered_uncollected_amount AS `現在登録済未回収金額`, --現在登録済未回収金額
    registered_but_uncollected_items_from_the_previous_month AS `前月登録済未回収件数`, --前月登録済未回収件数
    uncollected_amount_registered_in_the_previous_month AS `前月登録済未回収金額`, --前月登録済未回収金額
    uncollected_cases_registered_two_months_prior AS `前々月以前登録済未回収件数`, --前々月以前登録済未回収件数
    uncollected_amount_registered_two_months_prior AS `前々月以前登録済未回収金額`, --前々月以前登録済未回収金額
    su_pieces AS `件数`, --件数
    su_amount AS `金額`, --金額
	mj_sortjyun AS `ソート順` --ソート順
FROM gold.vbi013004_en vbi013004 --中古車売掛金回収状況_en
;

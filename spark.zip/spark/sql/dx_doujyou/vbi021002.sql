-- Source file: 021_Bz4x買換え報奨金照会/報奨金_view_ve_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

WITH
-- 受注下取ＤＢ+抹消済受注下取ＤＢ+保存用受注下取ＤＢ
a003g AS (
  SELECT *
  FROM (
    SELECT
      cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,NO_SYADAIBA,DD_SITATORI,KB_SINCYU,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, no_cyumon, no_cyumoned, NO_SYADAIBA ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,NO_SYADAIBA,DD_SITATORI,KB_SINCYU,1 AS sortn
      -- 受注下取ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBA003G TBBA003G
      UNION ALL
      SELECT
        cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,NO_SYADAIBA,DD_SITATORI,KB_SINCYU,2 AS sortn
      -- 抹消済受注下取ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBA095G TBBA095G
      UNION ALL
      SELECT
        cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,NO_SYADAIBA,DD_SITATORI,KB_SINCYU,3 AS sortn
      -- 保存用受注下取ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBA117G TBBA117G
    ) jucyushitatr1
  ) jucyushitatr2
  WHERE rnk = 1
),
-- 新車受注基本情報ＤＢ+抹消済+保存用
a001g AS (
  SELECT *
  FROM (
    SELECT
      NO_SYADAIBA,KJ_MEIGIME1,DD_JUCYU,DD_TOUROKU,MJ_HANTENKT,DD_TORIKESI,cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,MJ_SINKYSED,MJ_GAIHANSY,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, no_cyumon, no_cyumoned ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        NO_SYADAIBA,KJ_MEIGIME1,DD_JUCYU,DD_TOUROKU,MJ_HANTENKT,DD_TORIKESI,cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,MJ_SINKYSED,MJ_GAIHANSY,1 AS sortn
      -- 新車受注基本情報ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBA001G TBBA001G where (DD_TOUROKU >= '2025-8-27' and DD_TOUROKU < '2028-4-1' or DD_TOUROKU is null)
      UNION ALL
      SELECT
        NO_SYADAIBA,KJ_MEIGIME1,DD_JUCYU,DD_TOUROKU,MJ_HANTENKT,DD_TORIKESI,cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,MJ_SINKYSED,MJ_GAIHANSY,2 AS sortn
      -- 抹消済新車受注基本情報ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBA085G TBBA085G where (DD_TOUROKU >= '2025-8-27' and DD_TOUROKU < '2028-4-1' or DD_TOUROKU is null)
      UNION ALL
      SELECT
        NO_SYADAIBA,KJ_MEIGIME1,DD_JUCYU,DD_TOUROKU,MJ_HANTENKT,DD_TORIKESI,cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,MJ_SINKYSED,MJ_GAIHANSY,3 AS sortn
      -- 保存用新車受注基本情報ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBA108G TBBA108G where (DD_TOUROKU >= '2025-8-27' and DD_TOUROKU < '2028-4-1' or DD_TOUROKU is null)
    ) shinsha1
  ) shinsha2
  WHERE rnk = 1
),
-- 中古車在庫基本情報ＤＢ+抹消済+保存用
c001g AS (
  SELECT *
  FROM (
    SELECT
      DD_KEIRIKEI,NO_SYADAIBA,MJ_KATASIKI,KJ_SITAMEIG,MJ_FURUSYAM,KB_SIIRE,DD_SIREJYTY,DD_SIRETORO,CD_SYOYUSYA,KJ_SAISSYYU,cd_hansya,cd_kaisya,DD_TORIKESI,cd_sitadote,NO_SIRETYUM,no_syaryou,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, NO_SYADAIBA ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        DD_KEIRIKEI,NO_SYADAIBA,MJ_KATASIKI,KJ_SITAMEIG,MJ_FURUSYAM,KB_SIIRE,DD_SIREJYTY,DD_SIRETORO,CD_SYOYUSYA,KJ_SAISSYYU,cd_hansya,cd_kaisya,DD_TORIKESI,cd_sitadote,NO_SIRETYUM,no_syaryou,1 AS sortn
      -- 中古車在庫基本情報ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBC001G TBBC001G
      WHERE (LOWER(MJ_KATASIKI) LIKE '%xeam10%' OR LOWER(MJ_KATASIKI) LIKE '%yeam15%')
		AND KB_SIIRE LIKE '1%'
      UNION ALL
      SELECT
        DD_KEIRIKEI,NO_SYADAIBA,MJ_KATASIKI,KJ_SITAMEIG,MJ_FURUSYAM,KB_SIIRE,DD_SIREJYTY,DD_SIRETORO,CD_SYOYUSYA,KJ_SAISSYYU,cd_hansya,cd_kaisya,DD_TORIKESI,cd_sitadote,NO_SIRETYUM,no_syaryou,2 AS sortn
      -- 抹消済中古車在庫基本情報ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBC050G TBBC050G
      WHERE  (LOWER(MJ_KATASIKI) LIKE '%xeam10%' OR LOWER(MJ_KATASIKI) LIKE '%yeam15%')
		AND KB_SIIRE LIKE '1%'
      UNION ALL
      SELECT
        DD_KEIRIKEI,NO_SYADAIBA,MJ_KATASIKI,KJ_SITAMEIG,MJ_FURUSYAM,KB_SIIRE,DD_SIREJYTY,DD_SIRETORO,CD_SYOYUSYA,KJ_SAISSYYU,cd_hansya,cd_kaisya,DD_TORIKESI,cd_sitadote,NO_SIRETYUM,no_syaryou,3 AS sortn
      -- 保存用中古車在庫基本情報ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBC065G TBBC065G
      WHERE (LOWER(MJ_KATASIKI) LIKE '%xeam10%' OR LOWER(MJ_KATASIKI) LIKE '%yeam15%')
		AND KB_SIIRE LIKE '1%'
    ) cyukokh1
  ) cyukokh2
  WHERE rnk = 1
),
-- 中古車在庫登録情報ＤＢ+抹消済+保存用
c006g AS (
  SELECT *
  FROM (
    SELECT
      DD_1JTOROKU,cd_hansya,cd_kaisya,NO_SYARYOU,
      RANK() OVER (PARTITION BY cd_hansya, cd_kaisya, NO_SYARYOU ORDER BY sortn ASC) AS rnk
    FROM (
      SELECT
        DD_1JTOROKU,cd_hansya,cd_kaisya,NO_SYARYOU,1 AS sortn
      -- 中古車在庫登録情報ＤＢ（優先度=1）
      FROM ai21rep_ve_dx.TBBC006G TBBC006G
      UNION ALL
      SELECT
        DD_1JTOROKU,cd_hansya,cd_kaisya,NO_SYARYOU,2 AS sortn
      -- 抹消済中古車在庫登録情報ＤＢ（優先度=2）
      FROM ai21rep_ve_dx.TBBC052G TBBC052G
      UNION ALL
      SELECT
        max(DD_1JTOROKU) as DD_1JTOROKU,cd_hansya,cd_kaisya,NO_SYARYOU,3 AS sortn
      -- 保存用中古車在庫登録情報ＤＢ（優先度=3）
      FROM ai21rep_ve_dx.TBBC064G TBBC064G
      group by cd_hansya,cd_kaisya,NO_SYARYOU
    ) cyukotr1
  ) cyukotr2
  WHERE rnk = 1
)
-- ① 予定
INSERT OVERWRITE TABLE gold.vbi021002
SELECT
  t.cd_hansya,
  t200m.kj_kaisyatn,
  t200m.cd_hanbaitn,
  t.cd_kaisya,
  t201m.kj_tenpomei,
  t.NO_SYADAIBA,
  -- 予定
  t.NO_SYADAIBA AS NO_SYADAIBA_yotei,
  t.MJ_KATASIKI,
  t.KJ_SITAMEIG,
  t.MJ_FURUSYAM,
  t.KB_SIREHANB,
  -- 中古車在庫基本情報
  c001g.DD_KEIRIKEI AS DD_KEIRIKEI_zako,
  c001g.NO_SYADAIBA AS NO_SYADAIBA_zako,
  c001g.MJ_KATASIKI AS MJ_KATASIKI_zako,
  c001g.KJ_SITAMEIG AS KJ_SITAMEIG_zako,
  c001g.MJ_FURUSYAM AS MJ_FURUSYAM_zako,
  c001g.KB_SIIRE AS KB_SIIRE_zako,
  c001g.DD_SIREJYTY AS DD_SIREJYTY_zako,
  c001g.DD_SIRETORO AS DD_SIRETORO_zako,
  c001g.CD_SYOYUSYA AS CD_SYOYUSYA_zako,
  c001g.KJ_SAISSYYU AS KJ_SAISSYYU_zako,
  -- 新車受注基本情報
  a001g.NO_SYADAIBA AS NO_SYADAIBA_shinsya,
  a001g.KJ_MEIGIME1 AS kj_meigime1_shinsya,
  a001g.DD_JUCYU AS dd_jucyu_shinsya,
  a001g.DD_TOUROKU AS dd_touroku_shinsya,
  a001g.MJ_HANTENKT AS mj_katasiki_shinsya,
  a001g.NO_CYUMON AS no_cyumon_shinsya,
  f001m.KJ_KURUMAME AS kj_kurumame_shinsya,
  -- 中古車在庫登録情報ＤＢ
  c006g.DD_1JTOROKU
-- 仕入予定基本情報ＤＢ
FROM ai21rep_ve_dx.TBBC003G t
LEFT JOIN ai21rep_ve_dx.tbv0200m t200m
ON t200m.cd_hansya = t.cd_hansya
AND t200m.cd_kaisya = t.cd_kaisya
LEFT JOIN ai21rep_ve_dx.tbv0201m t201m
ON t201m.cd_hansya = t.cd_hansya
AND t201m.cd_kaisya = t.cd_kaisya
AND t201m.cd_tenpo  = t.CD_SITADOTE
-- 受注下取ＤＢ+抹消済+保存用
INNER JOIN a003g
ON a003g.cd_hansya = t.cd_hansya
AND a003g.cd_kaisya = t.cd_kaisya
AND CONCAT(COALESCE(a003g.NO_CYUMON,''), COALESCE(a003g.NO_CYUMONED,'')) = t.NO_SIRETYUM
AND TRIM(a003g.NO_SYADAIBA) = TRIM(t.NO_SYADAIBA)
AND a003g.DD_SITATORI IS NULL
AND a003g.KB_SINCYU = '1'
-- 新車受注基本情報ＤＢ+抹消済+保存用
INNER JOIN a001g
ON a001g.cd_hansya = t.cd_hansya
AND a001g.cd_kaisya = t.cd_kaisya
AND CONCAT(COALESCE(a001g.NO_CYUMON,''), COALESCE(a001g.NO_CYUMONED,'')) = t.NO_SIRETYUM
AND a001g.DD_TORIKESI IS NULL
-- 車両スペック２ＤＢ
INNER JOIN ai21rep_ve_dx.TBBF008M f008m
ON f008m.cd_hansya   = a001g.cd_hansya
AND f008m.cd_kaisya   = a001g.cd_kaisya
AND f008m.MJ_SINKYSED = a001g.MJ_SINKYSED
AND f008m.CD_SPEC     = a001g.MJ_GAIHANSY
AND f008m.MJ_HANTENKT = a001g.MJ_HANTENKT
AND f008m.kb_spec     = 'G'
-- 車名ＤＢ
INNER JOIN ai21rep_ve_dx.tbbf001m f001m
ON f001m.cd_hansya    = f008m.cd_hansya
AND f001m.cd_kaisya    = f008m.cd_kaisya
AND f001m.cd_ncsyamei  = f008m.mj_syamei
-- 中古車在庫基本情報ＤＢ+抹消済+保存用
left JOIN c001g
ON c001g.cd_hansya = t.cd_hansya
AND c001g.cd_kaisya = t.cd_kaisya
AND TRIM(c001g.NO_SYADAIBA) = TRIM(t.NO_SYADAIBA)
AND c001g.DD_TORIKESI IS NULL
LEFT JOIN c006g
ON c006g.cd_hansya = t.cd_hansya
AND c006g.cd_kaisya = t.cd_kaisya
AND c006g.NO_SYARYOU = t.NO_SYARYOU
WHERE (LOWER(t.MJ_KATASIKI) LIKE '%xeam10%' OR LOWER(t.MJ_KATASIKI) LIKE '%yeam15%')
AND t.KB_SIREHANB = '1'
AND (((f001m.KJ_KURUMAME LIKE '%bZ4X%' OR f001m.KJ_KURUMAME LIKE '%ｂＺ４Ｘ%')
    AND (a001g.MJ_HANTENKT LIKE '%XEAM11%' OR a001g.MJ_HANTENKT LIKE '%XEAM15%'))
    OR f001m.KJ_KURUMAME LIKE '%bZ4Xツーリング%'
    OR f001m.KJ_KURUMAME LIKE '%ｂＺ４Ｘツーリング%'
    OR f001m.KJ_KURUMAME LIKE '%プリウス%'
    OR f001m.KJ_KURUMAME LIKE '%RAV4%'
    OR f001m.KJ_KURUMAME LIKE '%ＲＡＶ４%'
    OR f001m.KJ_KURUMAME LIKE '%ハリアー%'
    OR f001m.KJ_KURUMAME LIKE '%アルファード%'
    OR f001m.KJ_KURUMAME LIKE '%ヴェルファイア%'
    OR f001m.KJ_KURUMAME LIKE '%クラウンスポーツ%'
    OR f001m.KJ_KURUMAME LIKE '%クラウンエステート%'
  )
UNION
-- ② 在庫
SELECT
  t.cd_hansya,
  t200m.kj_kaisyatn,
  t200m.cd_hanbaitn,
  t.cd_kaisya,
  t201m.kj_tenpomei,
  t.NO_SYADAIBA,
  -- 予定
  t.NO_SYADAIBA AS NO_SYADAIBA_yotei,
  t.MJ_KATASIKI AS MJ_KATASIKI,
  t.KJ_SITAMEIG AS KJ_SITAMEIG,
  t.MJ_FURUSYAM AS MJ_FURUSYAM,
  t.KB_SIIRE AS KB_SIREHANB,
  -- 中古車在庫基本情報
  t.DD_KEIRIKEI AS DD_KEIRIKEI_zako,
  t.NO_SYADAIBA AS NO_SYADAIBA_zako,
  t.MJ_KATASIKI AS MJ_KATASIKI_zako,
  t.KJ_SITAMEIG AS KJ_SITAMEIG_zako,
  t.MJ_FURUSYAM AS MJ_FURUSYAM_zako,
  t.KB_SIIRE AS KB_SIIRE_zako,
  t.DD_SIREJYTY AS DD_SIREJYTY_zako,
  t.DD_SIRETORO AS DD_SIRETORO_zako,
  t.CD_SYOYUSYA AS CD_SYOYUSYA_zako,
  t.KJ_SAISSYYU AS KJ_SAISSYYU_zako,
  -- 新車受注基本情報
  a001g.NO_SYADAIBA AS NO_SYADAIBA_shinsya,
  a001g.KJ_MEIGIME1 AS kj_meigime1_shinsya,
  a001g.DD_JUCYU AS dd_jucyu_shinsya,
  a001g.DD_TOUROKU AS dd_touroku_shinsya,
  a001g.MJ_HANTENKT AS mj_katasiki_shinsya,
  a001g.NO_CYUMON AS no_cyumon_shinsya,
  f001m.KJ_KURUMAME AS kj_kurumame_shinsya,
  -- 中古車在庫登録情報ＤＢ
  c006g.DD_1JTOROKU
-- 中古車在庫登録情報ＤＢ+抹消済+保存用
FROM c001g t
LEFT JOIN ai21rep_ve_dx.tbv0200m t200m
ON t200m.cd_hansya = t.cd_hansya
AND t200m.cd_kaisya = t.cd_kaisya
LEFT JOIN ai21rep_ve_dx.tbv0201m t201m
ON t201m.cd_hansya = t.cd_hansya
AND t201m.cd_kaisya = t.cd_kaisya
AND t201m.cd_tenpo  = t.CD_SITADOTE
-- 新車受注基本情報ＤＢ+抹消済+保存用
LEFT JOIN a001g
ON a001g.cd_hansya = t.cd_hansya
AND a001g.cd_kaisya = t.cd_kaisya
AND CONCAT(COALESCE(a001g.NO_CYUMON,''), COALESCE(a001g.NO_CYUMONED,'')) = t.NO_SIRETYUM
AND a001g.DD_TORIKESI IS NULL
-- 車両スペック２ＤＢ
INNER JOIN ai21rep_ve_dx.TBBF008M f008m
ON f008m.cd_hansya   = a001g.cd_hansya
AND f008m.cd_kaisya   = a001g.cd_kaisya
AND f008m.MJ_SINKYSED = a001g.MJ_SINKYSED
AND f008m.CD_SPEC     = a001g.MJ_GAIHANSY
AND f008m.MJ_HANTENKT = a001g.MJ_HANTENKT
AND f008m.kb_spec     = 'G'
-- 車名ＤＢ
INNER JOIN ai21rep_ve_dx.tbbf001m f001m
ON f001m.cd_hansya    = f008m.cd_hansya
AND f001m.cd_kaisya    = f008m.cd_kaisya
AND f001m.cd_ncsyamei  = f008m.mj_syamei
LEFT JOIN c006g
ON c006g.cd_hansya = t.cd_hansya
AND c006g.cd_kaisya = t.cd_kaisya
AND c006g.NO_SYARYOU = t.NO_SYARYOU
WHERE (LOWER(t.MJ_KATASIKI) LIKE '%xeam10%' OR LOWER(t.MJ_KATASIKI) LIKE '%yeam15%')
AND t.KB_SIIRE LIKE '1%'
AND (((f001m.KJ_KURUMAME LIKE '%bZ4X%' OR f001m.KJ_KURUMAME LIKE '%ｂＺ４Ｘ%')
    AND (a001g.MJ_HANTENKT LIKE '%XEAM11%' OR a001g.MJ_HANTENKT LIKE '%XEAM15%'))
    OR f001m.KJ_KURUMAME LIKE '%bZ4Xツーリング%'
    OR f001m.KJ_KURUMAME LIKE '%ｂＺ４Ｘツーリング%'
    OR f001m.KJ_KURUMAME LIKE '%プリウス%'
    OR f001m.KJ_KURUMAME LIKE '%RAV4%'
    OR f001m.KJ_KURUMAME LIKE '%ＲＡＶ４%'
    OR f001m.KJ_KURUMAME LIKE '%ハリアー%'
    OR f001m.KJ_KURUMAME LIKE '%アルファード%'
    OR f001m.KJ_KURUMAME LIKE '%ヴェルファイア%'
    OR f001m.KJ_KURUMAME LIKE '%クラウンスポーツ%'
    OR f001m.KJ_KURUMAME LIKE '%クラウンエステート%'
  )
;

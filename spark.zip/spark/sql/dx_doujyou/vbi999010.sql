-- Source file: 101_マスタメンテナンス/vbi999001-VBI999010.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.VBI999010
SELECT  
	ROW_NUMBER() OVER (PARTITION BY tbv0208m.cd_hansya, tbv0208m.cd_kaisya ORDER BY tbv0208m.kb_nyuukin ASC) AS `No.`, --番号
	tbv0208m.cd_hansya AS `販社コード`, --販社コード
	tbv0208m.cd_kaisya AS `会社コード`, --会社コード
	tbv0208m.kb_nyuukin AS `入金区分`, --入金区分
	tbv0208m.kj_nyuukinm AS `入金区分名`, --入金区分名
	IF(tbi999013m.cd_hansya IS NULL , IF(tbv0208m.kj_nyuukinm RLIKE '現金', '○', '×') ,IF(tbi999013m.kb_genkin='1', '○', '×')) AS `現金`, --現金
	IF(tbi999013m.cd_hansya IS NULL , IF(tbv0208m.kj_nyuukinm RLIKE 'クレジット', '○', '×'),IF(tbi999013m.kb_crejcard='1', '○', '×')) AS `クレジットカード` --クレジットカード
FROM
	ai21rep_ve_dx.tbv0208m tbv0208m --入金区分ＤＢ
LEFT JOIN dx_ve.tbi999013m tbi999013m --入金区分設定 
ON tbv0208m.cd_hansya = tbi999013m.cd_hansya
	AND tbv0208m.cd_kaisya = tbi999013m.cd_kaisya
	AND tbv0208m.kb_nyuukin = tbi999013m.kb_nyuukin
;

-- Source file: 011_メンテナンスパック契約客ステータス一覧/メンテナンスパック契約客ステータス一覧.sql
-- Dependency level: 2
-- Internal Gold dependencies: gold.vbi011005
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi011008
SELECT 
	--販社コード
	tz030m.cd_hansya AS `販社コード`,
	--会社コード
	tz030m.cd_kaisya AS `会社コード`,
	--お客様コード
	tz030m.cd_okyaku AS `お客様コード`,
	--ソート順
	dense_rank() over(partition by tz030m.cd_hansya, tz030m.cd_kaisya order by vbi011005.cd_zon,vbi011005.mj_sortjyun, vbi011005.cd_stafften) as `ソート順`,
	--テーブルソート順
	dense_rank() over(partition by tz030m.cd_hansya, tz030m.cd_kaisya order by vbi011005.cd_zon,vbi011005.mj_sortjyun, vbi011005.cd_stafften,vbi011005.cd_staff) as `テーブルソート順`,
	--車名
	tec05g.mj_syamei AS `車名`,
	--登録番号 = RELATED('TBV0013M_Ｍ陸支コードDB'[陸支名称])&[登録NO陸支除]
	CONCAT(t0013m.kj_rikusim, tz030m.kb_nosyasyu, tz030m.cd_nogyotai, tz030m.no_noseiri) AS `登録番号`,
	--登録ＮＯ
	CONCAT(
			tz030m.cd_hansya,
			tz030m.cd_kaisya,
			tz030m.cd_okyaku,
			tz030m.cd_norikusi,
			tz030m.kb_nosyasyu,
			tz030m.cd_nogyotai,
			tz030m.no_noseiri
			) AS `登録ＮＯ`
--メンテパック契約ＤＢ
FROM ai21rep_ve_dx.tbaz030m tz030m
INNER JOIN gold.vbi011005 vbi011005
	ON tz030m.cd_hansya = vbi011005.cd_hansya
	AND tz030m.cd_kaisya = vbi011005.cd_kaisya
	AND tz030m.cd_okyaku = vbi011005.cd_okyaku
--車両管理ＤＢ
LEFT JOIN ai21rep_ve_dx.tbtec05g tec05g
	ON tz030m.cd_hansya = tec05g.cd_hansya
	AND tz030m.cd_kaisya = tec05g.cd_kaisya
	AND tz030m.cd_okyaku = tec05g.cd_okyaku
	AND tz030m.cd_norikusi = tec05g.cd_norikusi
	AND tz030m.kb_nosyasyu = tec05g.kb_nosyasyu
	AND tz030m.cd_nogyotai = tec05g.cd_nogyotai
	AND tz030m.no_noseiri = tec05g.no_noseiri
--Ｍ陸支コードＤＢ
LEFT JOIN ai21rep_ve_dx.tbv0013m t0013m  
	ON tz030m.cd_hansya = t0013m.cd_hansya
	AND tz030m.cd_kaisya = t0013m.cd_kaisya
	AND REPLACE(REPLACE(tz030m.cd_norikusi, ' ', ''), '　', '') = t0013m.cd_rikusi
;

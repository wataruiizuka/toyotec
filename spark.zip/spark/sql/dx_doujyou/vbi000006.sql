-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000006
select
	--販社コード
 	t003g.cd_hansya as `販社コード`,
 	--会社コード
 	t003g.cd_kaisya as `会社コード`,
 	--店舗コード
 	t003g.cd_tenpo as `店舗コード`,
 	--整理ＮＯ
	t003g.no_seiri as `整理ＮＯ`,
	--対象車両台数
	sum(t003g.su_taisyasu) as `対象車両台数`,
	--自店実施台数
	sum(t003g.su_jitejida) as `自店実施台数`,
	--他店実施台数
	sum(t003g.su_tatenjis) as `他店実施台数`,
	--他社実施台数
	sum(t003g.su_tasyjiss) as `他社実施台数`
--リコール店舗実施ＤＢ
from ai21rep_ve_dx.tbfj003g t003g
-- 店舗表示設定
left semi join dx_ve.tbi999003m t9003m on t9003m.cd_hansya = t003g.cd_hansya
and t9003m.cd_kaisya = t003g.cd_kaisya
and t9003m.cd_tenpo = t003g.cd_tenpo
and t9003m.mj_cyohyoid = '000'
and t9003m.kb_tenji = 1
--where t003g.no_seiri = '5GT31'
group by t003g.cd_hansya, t003g.cd_kaisya, t003g.cd_tenpo, t003g.no_seiri
;

-- Source file: 019_中古車実績一覧(スタッフ別・店舗別)/中古車実績一覧（スタッフ別・店舗別）_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi019001
SELECT 
	--販社コード
	cd_hansya,
	--会社コード
	cd_kaisya,
	--店舗コード
	cd_tenpo,
	--店舗名称
	kj_tenpomei,
	--販売スタッフコード
	cd_hanstaff,
	--社員名
	kj_syainmei,
	--月
	month,
	--受注
	SUM(su_jucyu) AS `su_jucyu`,
	--受注キャンセル反映
	SUM(su_jucyu) - SUM(su_jucyucancel) AS `su_jucyucancelhane`,
	--受注除軽
	SUM(su_jucyujyokei) AS `su_jucyujyokei`,
	--受注除軽キャンセル反映
	SUM(su_jucyujyokei) - SUM(su_jucyucanceljyokei) AS `su_jucyucanceljyokeihane`,
	--割賦
	SUM(su_kap) AS `su_kap`,
	--メンテナンスパック
	SUM(su_maintenancepack) AS `su_maintenancepack`
FROM 
(
	SELECT
		--販社コード
		t.cd_hansya,
		--会社コード
		t.cd_kaisya,
		--受注店舗コード
		t.cd_jytyuten AS `cd_tenpo`,
		--店舗名称
		regexp_replace(t0201m.kj_tenpomei, '　+$', '') AS `kj_tenpomei`,
		--販売スタッフコード
		t.cd_hanstaff,
		--社員名
		regexp_replace(t014m.kj_syainmei, '　+$', '') AS `kj_syainmei`,
		--月
		IF(t.dd_jucyuke >= trunc(CAST(current_timestamp() AS DATE), 'MM'),'当月','前月') AS `month`,
		--受注
		1 AS `su_jucyu`,
		--受注取消
		0 AS `su_jucyucancel`,
		--受注除軽
		IF(t001g.kn_kei <> '1',1,0) AS `su_jucyujyokei`,
		--受注取消除軽
		0 AS `su_jucyucanceljyokei`,
		--割賦
		-- 中古車受注販売条件情報ＤＢ.支払区分 = 2(割賦)
		IF(t020g.kb_siharai = '2',1 ,0) AS `su_kap`,
		--メンテナンスパック
		-- 中古車受注販売条件情報ＤＢ.メンテナンスパック契約区分 <> 空
		IF(
			t020g.kb_mntpkkei IS NOT NULL
			AND REPLACE(REPLACE(t020g.kb_mntpkkei, '　', ''), ' ', '') != '',
			1 ,0
		) AS `su_maintenancepack`
	FROM 
	--抹消済中古車受注基本情報ＤＢ AND 中古車受注基本情報ＤＢ
	(
		SELECT cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,cd_jytyuten,cd_hanstaff,dd_jucyuke,no_syaryou FROM ai21rep_ve_dx.tbbc040g tbbc040g
		WHERE tbbc040g.dd_jucyuke >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM')
		UNION ALL
		SELECT cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,cd_jytyuten,cd_hanstaff,dd_jucyuke,no_syaryou FROM ai21rep_ve_dx.tbbc017g tbbc017g
		WHERE tbbc017g.dd_jucyuke >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM')
	) t
	-- 中古車受注販売条件情報ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbc020g t020g
		ON t.cd_kaisya = t020g.cd_kaisya
		AND t.cd_hansya = t020g.cd_hansya
		AND t.no_cyumon = t020g.no_cyumon
		AND TRIM(t.no_cyumoned) = TRIM(t020g.no_cyumoned)
	-- M社員ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0014m t014m
		ON t014m.cd_kaisya = t.cd_kaisya
		AND t014m.cd_hansya = t.cd_hansya
		AND t014m.cd_syain = t.cd_hanstaff
	-- 中古車在庫基本情報ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbc001g t001g 
    	ON t001g.cd_kaisya = t.cd_kaisya
	 	AND t001g.cd_hansya = t.cd_hansya
	 	AND t001g.no_syaryou = t.no_syaryou
	-- 共通店舗ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0201m t0201m
		ON t0201m.cd_kaisya = t.cd_kaisya
		AND t0201m.cd_hansya = t.cd_hansya
		AND t0201m.cd_tenpo = t.cd_jytyuten
	-- 店舗表示設定
	LEFT SEMI JOIN dx_ve.tbi999003m
		ON tbi999003m.cd_kaisya = t.cd_kaisya
	    AND tbi999003m.cd_hansya = t.cd_hansya
	    AND tbi999003m.cd_tenpo = t.cd_jytyuten
	    AND tbi999003m.mj_cyohyoid = '019'
	    AND tbi999003m.kb_tenji = 1
	UNION ALL
	SELECT
		--販社コード
		t.cd_hansya,
		--会社コード
		t.cd_kaisya,
		--受注店舗コード
		t.cd_jytyuten AS `cd_tenpo`,
		--店舗名称
		regexp_replace(t0201m.kj_tenpomei, '　+$', '') AS `kj_tenpomei`,
		--販売スタッフコード
		t.cd_hanstaff,
		--社員名
		regexp_replace(t014m.kj_syainmei, '　+$', '') AS `kj_syainmei`,
		--月
		IF(t.dd_torikesi >= trunc(CAST(current_timestamp() AS DATE), 'MM'),'当月','前月') AS `month`,
		--受注
		0 AS `su_jucyu`,
		--受注取消
		1 AS `su_jucyucancel`,
		--受注除軽
		0 AS `su_jucyujyokei`,
		--受注取消除軽
		IF(t001g.kn_kei <> '1',1,0) AS `su_jucyucanceljyokei`,
		0 AS `su_kap`,
		0 AS `su_maintenancepack`
	FROM 
	--抹消済中古車受注基本情報ＤＢ AND 中古車受注基本情報ＤＢ
	(
		SELECT cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,cd_jytyuten,cd_hanstaff,dd_jucyuke,dd_torikesi,no_syaryou 
		FROM ai21rep_ve_dx.tbbc040g
		WHERE tbbc040g.dd_torikesi >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM') AND tbbc040g.dd_jucyuke IS NOT NULL
		UNION ALL
		SELECT cd_hansya,cd_kaisya,no_cyumon,no_cyumoned,cd_jytyuten,cd_hanstaff,dd_jucyuke,dd_torikesi,no_syaryou 
		FROM ai21rep_ve_dx.tbbc017g
		WHERE tbbc017g.dd_torikesi >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM') AND tbbc017g.dd_jucyuke IS NOT NULL
	) t
	-- M社員ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0014m t014m
		ON t014m.cd_kaisya = t.cd_kaisya
		AND t014m.cd_hansya = t.cd_hansya
		AND t014m.cd_syain = t.cd_hanstaff
	-- 中古車在庫基本情報ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbc001g t001g 
    	ON t001g.cd_kaisya = t.cd_kaisya
	 	AND t001g.cd_hansya = t.cd_hansya
	 	AND t001g.no_syaryou = t.no_syaryou
	-- 共通店舗ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0201m t0201m
		ON t0201m.cd_kaisya = t.cd_kaisya
		AND t0201m.cd_hansya = t.cd_hansya
		AND t0201m.cd_tenpo = t.cd_jytyuten
	-- 店舗表示設定
	LEFT SEMI JOIN dx_ve.tbi999003m
		ON tbi999003m.cd_kaisya = t.cd_kaisya
	    AND tbi999003m.cd_hansya = t.cd_hansya
	    AND tbi999003m.cd_tenpo = t.cd_jytyuten
	    AND tbi999003m.mj_cyohyoid = '019'
	    AND tbi999003m.kb_tenji = 1
) t
GROUP BY
	cd_hansya,
	cd_kaisya,
	cd_tenpo,
	kj_tenpomei,
	cd_hanstaff,
	kj_syainmei,
	month
;

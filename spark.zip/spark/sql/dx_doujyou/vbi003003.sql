-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi003001_en, gold.vbi003002
-- Runtime requirements: Spark SQL 3.3+

with t275m as (
	select
		--販社コード
		t275m.cd_hansya,
		--会社コード
		t275m.cd_kaisya,
		--店舗コード
		t275m.cd_tenpo,
		--稼動日付
		v3001.dd_date as dd_kado,
		--稼動区分
		case day(v3001.dd_date)
			when 1 then t275m.kb_kado1
			when 2 then t275m.kb_kado2
			when 3 then t275m.kb_kado3
			when 4 then t275m.kb_kado4
			when 5 then t275m.kb_kado5
			when 6 then t275m.kb_kado6
			when 7 then t275m.kb_kado7
			when 8 then t275m.kb_kado8
			when 9 then t275m.kb_kado9
			when 10 then t275m.kb_kado10
			when 11 then t275m.kb_kado11
			when 12 then t275m.kb_kado12
			when 13 then t275m.kb_kado13
			when 14 then t275m.kb_kado14
			when 15 then t275m.kb_kado15
			when 16 then t275m.kb_kado16
			when 17 then t275m.kb_kado17
			when 18 then t275m.kb_kado18
			when 19 then t275m.kb_kado19
			when 20 then t275m.kb_kado20
			when 21 then t275m.kb_kado21
			when 22 then t275m.kb_kado22
			when 23 then t275m.kb_kado23
			when 24 then t275m.kb_kado24
			when 25 then t275m.kb_kado25
			when 26 then t275m.kb_kado26
			when 27 then t275m.kb_kado27
			when 28 then t275m.kb_kado28
			when 29 then t275m.kb_kado29
			when 30 then t275m.kb_kado30
			when 31 then t275m.kb_kado31
		end as kb_kado
	-- 店舗稼動日程ＤＢ
	from ai21rep_ve_dx.tbfy275m t275m
	-- 日付_14日
	inner join gold.vbi003001_en v3001 on v3001.dd_month = t275m.dd_kadoyymm
)
INSERT OVERWRITE TABLE gold.vbi003003
select
	--ソート順
	v3002.mj_sortjyun,
	--販社コード
	v3002.cd_hansya,
	--会社コード
	v3002.cd_kaisya,
	--店舗コード
	v3002.cd_tenpo,
	--店舗名
	v3002.kj_tenpomei,
	--販社会社店舗ストール番号
	v3002.cd_hansyakaisyatenpostall,
	--ストール番号
	v3002.no_stall,
	--ストール名称
	v3002.mj_stallmei,
	--ストール選択
	v3002.kb_stallsentaku,
	--エリアコード
	v3002.cd_zon,
	--エリア名
	v3002.kj_zonmei,
	--定外規定
	v3002.kb_teigaikitei,
	--定内規定
	if(
		-- 店舗休みの場合、休みとみなす
		t275m.kb_kado not in('1', '9')
		-- 店舗休みではない場合、ストールの[非稼動区分]が1でない場合、稼働とみなす
		or t002m.kb_hikado = '1',
		0,
		v3002.kb_teinaikitei
	) as kb_teinaikitei,
	-- 休憩区分
	if(
		-- 店舗休みの場合、休みとみなす
		t275m.kb_kado not in('1', '9')
		-- 店舗休みではない場合、ストールの[非稼動区分]が1でない場合、稼働とみなす
		or t002m.kb_hikado = '1',
		1,
		0
	) as kb_kyukei,
	--日付
	v3001.dd_date,
	--販社会社店舗ストール番号日付
	concat(v3002.cd_hansyakaisyatenpostall, v3001.`dd_yyyy/MM/dd`) as cd_hansyakaisyatenpostalldate,
	--週末判定
	v3001.kb_week
-- ストールマスタ_充足率対象ＤＢ
from gold.vbi003002 v3002
cross join gold.vbi003001_en v3001
-- 店舗稼動日程ＤＢ
left join t275m on t275m.cd_hansya = v3002.cd_hansya
and t275m.cd_kaisya = v3002.cd_kaisya
and t275m.cd_tenpo = v3002.cd_tenpo
and t275m.dd_kado = v3001.dd_date
and t275m.kb_kado <> 'Z'
-- ストール稼動予定マスタＤＢ
left join ai21rep_ve_dx.tbsa002m t002m on t002m.cd_hansya = v3002.cd_hansya
and t002m.cd_kaisya = v3002.cd_kaisya
and t002m.cd_tenpo = v3002.cd_tenpo
and t002m.no_stall = v3002.no_stall
and t002m.dd_hikado = v3001.`dd_yyyyMMdd`
;

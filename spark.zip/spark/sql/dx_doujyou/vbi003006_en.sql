-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 2
-- Internal Gold dependencies: gold.vbi003002, gold.vbi003003, gold.vbi003004, gold.vbi003005
-- Runtime requirements: Spark SQL 3.3+

with crs as(
	select
		--販社コード
		v3004.cd_hansya,
		--会社コード
		v3004.cd_kaisya,
		--店舗コード
		v3004.cd_tenpo,
		--予約ＩＤ
		v3004.no_yoyakuid,
		--予約明細ＩＤ
		v3004.cd_yoykmsai,
		--跨ぎ休憩時間_秒
		sum(nvl(v3005.tm_kyukeensecond - v3005.tm_kyukestsecond, 0)) as tm_mtgkyukesecond
	-- tbsa005g_ストール予約明細ＤＢ_退避含_14日
	from gold.vbi003004 v3004
	-- ストール休憩マスタＤＢ
	left join gold.vbi003005 v3005 on v3005.cd_hansya = v3004.cd_hansya
	and v3005.cd_kaisya = v3004.cd_kaisya
	and v3005.cd_tenpo = v3004.cd_tenpo
	and v3005.no_stall = v3004.no_stall
	and v3005.tm_kyukest > date_format(v3004.dt_siyost, 'HH:mm:ss')
	and v3005.tm_kyukeen < date_format(v3004.dt_siyoed, 'HH:mm:ss')
	group by v3004.cd_hansya, v3004.cd_kaisya, v3004.cd_tenpo, v3004.no_yoyakuid, v3004.cd_yoykmsai
)
INSERT OVERWRITE TABLE gold.vbi003006_en
select
	--販社コード
	bt.cd_hansya,
	--会社コード
	bt.cd_kaisya,
	--店舗コード
	bt.cd_tenpo,
	--予約ＩＤ
	bt.no_yoyakuid,
	--予約明細ＩＤ
	bt.cd_yoykmsai,
	--ストール番号
	bt.no_stall,
	--ご用命
	bt.mj_gyme,
	--工程区分
	bt.kb_koutei,
	--入庫予定日時
	bt.dt_siyost as dt_nyuukoyt,
	--出庫予定日時
	bt.dt_siyoed as dt_shukkoyt,
	--使用所要時間
	bt.tm_siyotime,
	--入庫区分
	bt.kb_nyuuko,
	--実績ステータス
	bt.cd_jisekist,
	--実績ステータス名
	t231m.mj_kubunnai as mj_jisekist,
	--休憩跨ぎ区分
	bt.cd_restcros,
	--ＳＭＢ削除フラグ
	bt.mj_sakujyo,
	--販社会社店舗ストール番号日付
	concat(bt.cd_hansyakaisyatenpostall, date_format(bt.dt_siyost, 'yyyy/MM/dd')) as cd_hansyakaisyatenpostalldate,
	--入庫予定日
	bt.dd_nyuukoyt,
	--予約
	if (
		bt.kb_shukkonyuko = 1,
		if (
			-- 入庫予定時間 < 退勤時間
			bt.tm_nyuukoytsecond < bt.tm_taikinsecond,
			bt.tm_siyotime,
			null
		),
		-- 入庫と出庫日一致
		if (
			-- 入庫予定時間<=出勤時間 && 出庫予定時間<=出勤時間
			bt.tm_nyuukoytsecond <= bt.tm_shukkinsecond and bt.tm_shukkoytsecond <= bt.tm_shukkinsecond,
			null,
			if (
				-- 入庫予定時間<=出勤時間 && 出庫予定時間 > 出勤時間 && 出庫予定時間<=退勤時間
				bt.tm_nyuukoytsecond <= bt.tm_shukkinsecond and bt.tm_shukkoytsecond > bt.tm_shukkinsecond and bt.tm_shukkoytsecond <= bt.tm_taikinsecond,
				-- 出庫予定時間 - 出勤時間
				(bt.tm_shukkoytsecond - bt.tm_shukkinsecond) / 60,
				if (
					-- 入庫予定時間<=出勤時間 && 出庫予定時間 > 退勤時間
					bt.tm_nyuukoytsecond <= bt.tm_shukkinsecond and bt.tm_shukkoytsecond > bt.tm_taikinsecond,
					(bt.tm_taikinsecond - bt.tm_shukkinsecond) / 60,
					if (
						-- 入庫予定時間 > 出勤時間  && 入庫予定時間<=退勤時間 && 出庫予定時間 > 出勤時間 && 出庫予定時間<=退勤時間
						bt.tm_nyuukoytsecond > bt.tm_shukkinsecond and bt.tm_nyuukoytsecond <= bt.tm_taikinsecond and bt.tm_shukkoytsecond > bt.tm_shukkinsecond and bt.tm_shukkoytsecond <= bt.tm_taikinsecond,
						-- 出庫予定時間 - 入庫予定時間
						(bt.tm_shukkoytsecond - bt.tm_nyuukoytsecond) / 60,
						if (
							-- 入庫予定時間 > 出勤時間 && 入庫予定時間<=退勤時間 && 出庫予定時間>退勤時間
							bt.tm_nyuukoytsecond > bt.tm_shukkinsecond and bt.tm_nyuukoytsecond <= bt.tm_taikinsecond and bt.tm_shukkoytsecond > bt.tm_taikinsecond,
							(bt.tm_taikinsecond - bt.tm_nyuukoytsecond) / 60,
							if (
								-- 入庫予定時間 > 退勤時間
								bt.tm_nyuukoytsecond > bt.tm_taikinsecond,
								0,
								null
							)
						)
					)
				)
			)
		)
	) - if (
		bt.cd_restcros = '0' or bt.cd_restcros = '2',
		0,
		if (
			bt.kb_shukkonyuko = 1,
			0,
			if (
				-- [入庫と出庫ストール休憩番号不一致FLG] = 0
				bt.kb_stall_syasumi_dif = 0,
				-- 出庫予定時間 - 入庫予定時間
				(bt.tm_shukkoytsecond - bt.tm_nyuukoytsecond) / 60,
				-- [入庫休憩時間] + [出庫休憩時間] + [跨ぎ休憩時間]
				(bt.tm_nyukoyukesecond + bt.tm_shukkoyukesecond + bt.tm_mtgkyukesecond) / 60
			)
		)
	) as mj_yoyaku,
	--出勤時間
	bt.tm_shukkin,
	--退勤時間
	bt.tm_taikin,
	--残業時間
	bt.tm_zangyo
from(
	select
		--販社コード
		v3004.cd_hansya,
		--会社コード
		v3004.cd_kaisya,
		--店舗コード
		v3004.cd_tenpo,
		--予約ＩＤ
		v3004.no_yoyakuid,
		--予約明細ＩＤ
		v3004.cd_yoykmsai,
		--ストール番号
		v3004.no_stall,
		--ご用命
		v3004.mj_gyme,
		--工程区分
		v3004.kb_koutei,
		--使用開始日時
		v3004.dt_siyost,
		--使用終了日時
		v3004.dt_siyoed,
		--使用所要時間
		v3004.tm_siyotime,
		--入庫区分
		v3004.kb_nyuuko,
		--実績ステータス
		v3004.cd_jisekist,
		--休憩跨ぎ区分
		v3004.cd_restcros,
		--ＳＭＢ削除フラグ
		v3004.mj_sakujyo,
		--販社会社店舗ストール番号
		concat(v3004.cd_hansya, v3004.cd_kaisya, v3004.cd_tenpo, v3004.mj_stallno) as cd_hansyakaisyatenpostall,
		--入庫予定日
		v3004.dd_nyuukoyt,
		--入庫と出庫日不一致
		if (v3004.dd_nyuukoyt <> v3004.dd_shukkoyt, 1, 0) as kb_shukkonyuko,
		--入庫と出庫ストール休憩番号不一致FLG
		if (v3005i.no_stlkyuke is null and v3005o.no_stlkyuke is null, 2, if (nvl(v3005i.no_stlkyuke, -1) <> nvl(v3005o.no_stlkyuke, -1), 1, 0)) as kb_stall_syasumi_dif,
		--入庫予定時間_秒
		v3004.tm_nyuukoytsecond,
		--出庫予定時間_秒
		v3004.tm_shukkoytsecond,
		--出勤時間
		v3002.tm_kaiten as tm_shukkin,
		--出勤時間_秒
		v3002.tm_shukkinsecond,
		--退勤時間
		v3002.tm_heiten as tm_taikin,
		--退勤時間_秒
		v3002.tm_taikinsecond,
		--残業時間
		v3002.tm_zangyo,
		--入庫休憩時間_秒
		nvl(v3005i.tm_kyukeensecond - v3004.tm_nyuukoytsecond, 0) as tm_nyukoyukesecond,
		--出庫休憩時間_秒
		nvl(v3004.tm_shukkoytsecond - v3005o.tm_kyukestsecond, 0) as tm_shukkoyukesecond,
		--跨ぎ休憩時間_秒
		nvl(crs.tm_mtgkyukesecond, 0) as tm_mtgkyukesecond
	-- tbsa005g_ストール予約明細ＤＢ_退避含_14日
	from gold.vbi003004 v3004
	-- ストールマスタ_充足率対象ＤＢ_14日
	left semi join gold.vbi003003 v3003 on v3003.cd_hansya = v3004.cd_hansya
	and v3003.cd_kaisya = v3004.cd_kaisya
	and v3003.cd_tenpo = v3004.cd_tenpo
	and v3003.no_stall = v3004.no_stall
	and v3003.dd_date = v3004.dd_nyuukoyt
	and v3003. kb_kyukei = 0
	-- ストールマスタ_充足率対象ＤＢ
	left join gold.vbi003002 v3002 on v3002.cd_hansya = v3004.cd_hansya
	and v3002.cd_kaisya = v3004.cd_kaisya
	and v3002.cd_tenpo = v3004.cd_tenpo
	and v3002.no_stall = v3004.no_stall
	-- ストール休憩マスタＤＢ，入庫
	left join gold.vbi003005 v3005i on v3005i.cd_hansya = v3004.cd_hansya
	and v3005i.cd_kaisya = v3004.cd_kaisya
	and v3005i.cd_tenpo = v3004.cd_tenpo
	and v3005i.no_stall = v3004.no_stall
	and v3005i.tm_kyukestsecond <= v3004.tm_nyuukoytsecond
	and v3005i.tm_kyukeensecond >= v3004.tm_nyuukoytsecond
	-- ストール休憩マスタＤＢ，出庫
	left join gold.vbi003005 v3005o on v3005o.cd_hansya = v3004.cd_hansya
	and v3005o.cd_kaisya = v3004.cd_kaisya
	and v3005o.cd_tenpo = v3004.cd_tenpo
	and v3005o.no_stall = v3004.no_stall
	and v3005o.tm_kyukestsecond <= v3004.tm_shukkoytsecond
	and v3005o.tm_kyukeensecond >= v3004.tm_shukkoytsecond
	-- ストール休憩マスタＤＢ， 跨ぎ
	left join crs on crs.cd_hansya = v3004.cd_hansya
	and crs.cd_kaisya = v3004.cd_kaisya
	and crs.cd_tenpo = v3004.cd_tenpo
	and	crs.no_yoyakuid = v3004.no_yoyakuid
	and	crs.cd_yoykmsai = v3004.cd_yoykmsai
) bt
--コード区分ＤＢ
left join ai21rep_ve_dx.tbv0231m t231m on t231m.cd_hansya = bt.cd_hansya
and t231m.cd_kaisya = bt.cd_kaisya
and t231m.mj_blockid = '09'
and t231m.mj_kubunid = '0016'
and t231m.cd_kubun = bt.cd_jisekist
;

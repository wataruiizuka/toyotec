-- Source file: 017_新車実績一覧(スタッフ別・店舗別)/新車実績一覧（スタッフ別・店舗別）_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi017001
SELECT
	--販社コード
	cd_hansya,
	--会社コード
	cd_kaisya,
	--店舗コード
	cd_tenpo,
	--店舗名称
	kj_tenpomei,
	--販売スタッフコード
	cd_hanstaff,
	--社員名
	kj_syainmei,
	--月
	month,
	--受注
	SUM(su_jucyu) AS `su_jucyu`,
	--受注キャンセル反映
	SUM(su_jucyu) - SUM(su_jucyucancel) AS `su_jucyucancelhane`,
	--受注除軽
	SUM(su_jucyujyokei) AS `su_jucyujyokei`,
	--受注除軽キャンセル反映
	SUM(su_jucyujyokei) - SUM(su_jucyucanceljyokei) AS `su_jucyucanceljyokeihane`,
	--割賦
	SUM(su_kap) AS `su_kap`,
	--メンテナンスパック
	SUM(su_maintenancepack) AS `su_maintenancepack`,
	--下取り
	SUM(su_sitadori) AS `su_sitadori`
FROM
(
	SELECT 
		--販社コード
		t001g.cd_hansya,
		--会社コード
		t001g.cd_kaisya,
		--店舗コード
		t001g.cd_tenpo,
		--店舗名称
		regexp_replace(t0201m.kj_tenpomei, '　+$', '') AS `kj_tenpomei`,
		--販売スタッフコード
		t001g.cd_hanstaff,
		--社員名
		regexp_replace(t014m.kj_syainmei, '　+$', '') AS `kj_syainmei`,
		--月
		IF(t001g.dd_jucyuke >= trunc(CAST(current_timestamp() AS DATE), 'MM'),'当月','前月') AS `month`,
		--受注
		1 AS `su_jucyu`,
		--受注取消
		0 AS `su_jucyucancel`,
		--受注除軽
		IF(t001m.kn_kei <> '1',1,0) AS `su_jucyujyokei`,
		--受注取消除軽
		0 AS `su_jucyucanceljyokei`,
		--割賦
		--新車受注販売条件情報ＤＢ.支払区分 = 2
		IF(t052g.kb_siharai = '2',1 ,0) AS `su_kap`,
		--メンテナンスパック
		--新車受注販売条件情報ＤＢ.メンテナンスパック契約区分 <> 空
		IF(t052g.kb_mntpkkei IS NOT NULL
			AND REPLACE(REPLACE(t052g.kb_mntpkkei, '　', ''), ' ', '') != '',1 ,0) AS `su_maintenancepack`,
		--下取り
		--新車受注販売条件情報ＤＢ.下取台数 > 0
		IF(t052g.su_sitadori > 0, 1, 0) AS `su_sitadori`
	-- 新車受注基本情報ＤＢ
	FROM ai21rep_ve_dx.tbba001g t001g
	--新車受注販売条件情報ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbba052g t052g
		ON t052g.cd_kaisya = t001g.cd_kaisya
	    AND t052g.cd_hansya = t001g.cd_hansya
	    AND t052g.no_cyumon = t001g.no_cyumon
	    AND TRIM(t052g.no_cyumoned) = TRIM(t001g.no_cyumoned)
	--M社員ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0014m t014m
		ON t014m.cd_kaisya = t001g.cd_kaisya
	    AND t014m.cd_hansya = t001g.cd_hansya
	    AND t014m.cd_syain = t001g.cd_hanstaff
	-- 車両スペック２ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf008m t008m
		ON t001g.cd_kaisya = t008m.cd_kaisya
		AND t001g.cd_hansya = t008m.cd_hansya
		AND t001g.mj_sinkysed = t008m.mj_sinkysed
		AND t001g.mj_gaihansy = t008m.cd_spec 
		AND t001g.mj_hantenkt  = t008m.mj_hantenkt 
		AND t008m.kb_spec = 'G'
	--車名ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf001m t001m
		ON t001m.cd_kaisya = t008m.cd_kaisya
		AND t001m.cd_hansya = t008m.cd_hansya
		AND t001m.cd_ncsyamei = t008m.mj_syamei 
	--共通店舗ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0201m t0201m
		ON t0201m.cd_kaisya = t001g.cd_kaisya
	    AND t0201m.cd_hansya = t001g.cd_hansya
	    AND t0201m.cd_tenpo = t001g.cd_tenpo
    -- 店舗表示設定
	LEFT SEMI JOIN dx_ve.tbi999003m
		ON tbi999003m.cd_kaisya = t001g.cd_kaisya
	    AND tbi999003m.cd_hansya = t001g.cd_hansya
	    AND tbi999003m.cd_tenpo = t001g.cd_tenpo
	    AND tbi999003m.mj_cyohyoid = '017'
	    AND tbi999003m.kb_tenji = 1
	WHERE 
	    -- [払出区分] <> "00" AND [払出区分] <> "40"
	    t001g.kb_haraidas NOT IN ('00', '40')
	    AND 
		-- 受注計上日 >= 先月
		t001g.dd_jucyuke >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM')
	UNION ALL
	SELECT
		--販社コード
		t001g.cd_hansya,
		--会社コード
		t001g.cd_kaisya,
		--店舗コード
		t001g.cd_tenpo,
		--店舗名称
		regexp_replace(t0201m.kj_tenpomei, '　+$', '') AS `kj_tenpomei`,
		--販売スタッフコード
		t001g.cd_hanstaff,
		--社員名
		regexp_replace(t014m.kj_syainmei, '　+$', '') AS `kj_syainmei`,
		--月
		IF(t001g.dd_torikesi >= trunc(CAST(current_timestamp() AS DATE), 'MM'),'当月','前月') AS `month`,
		--受注
		0 AS `su_jucyu`,
		--受注取消
		1 AS `su_jucyucancel`,
		--受注除軽
		0 AS `su_jucyujyokei`,
		--受注取消除軽
		IF(t001m.kn_kei <> '1',1,0) AS `su_jucyucanceljyokei`,
		--割賦
		0 AS `su_kap`,
		--メンテナンスパック
		0 AS `su_maintenancepack`,
		--下取り
		0 AS `su_sitadori`
	FROM
	--新車受注基本情報ＤＢ
	ai21rep_ve_dx.tbba001g t001g
	-- M社員ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0014m t014m
		ON t014m.cd_kaisya = t001g.cd_kaisya
	    AND t014m.cd_hansya = t001g.cd_hansya
	    AND t014m.cd_syain = t001g.cd_hanstaff
	-- 車両スペック２ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf008m t008m
		ON t001g.cd_kaisya = t008m.cd_kaisya
		AND t001g.cd_hansya = t008m.cd_hansya
		AND t001g.mj_sinkysed = t008m.mj_sinkysed
		AND t001g.mj_gaihansy = t008m.cd_spec 
		AND t001g.mj_hantenkt  = t008m.mj_hantenkt 
		AND t008m.kb_spec = 'G'
	--車名ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf001m t001m
		ON t001m.cd_kaisya = t008m.cd_kaisya
		AND t001m.cd_hansya = t008m.cd_hansya
		AND t001m.cd_ncsyamei = t008m.mj_syamei
	-- 共通店舗ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0201m t0201m
		ON t0201m.cd_kaisya = t001g.cd_kaisya
	    AND t0201m.cd_hansya = t001g.cd_hansya
	    AND t0201m.cd_tenpo = t001g.cd_tenpo
    -- 店舗表示設定
	LEFT SEMI JOIN dx_ve.tbi999003m
		ON tbi999003m.cd_kaisya = t001g.cd_kaisya
	    AND tbi999003m.cd_hansya = t001g.cd_hansya
	    AND tbi999003m.cd_tenpo = t001g.cd_tenpo
	    AND tbi999003m.mj_cyohyoid = '017'
	    AND tbi999003m.kb_tenji = 1
	WHERE 
	 	-- [払出区分] <> "00" AND [払出区分] <> "40"
	    t001g.kb_haraidas NOT IN ('00', '40')
	    -- 取消日 >= 先月
	    AND t001g.dd_torikesi >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM')
)combined
GROUP BY
	cd_hansya,
	cd_kaisya,
	cd_tenpo,
	kj_tenpomei,
	cd_hanstaff,
	kj_syainmei,
	month
;

-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi000007
select
	--販社コード
 	t001g.cd_hansya as `販社コード`,
 	--会社コード
 	t001g.cd_kaisya as `会社コード`,
 	--店舗コード
 	ta001g.cd_tenpo as `店舗コード`,
 	--整理ＮＯ
	t001g.no_seiri as `整理ＮＯ`,
	--入庫予定日0
	concat(date_format(ta001g.dt_nyuukoyt, 'yyyyMM'), '0') as `入庫予定日0`,
	--予約済台数
	count(*) as `予約済台数`
--リコールメインＤＢ
from ai21rep_ve_dx.tbfj001g t001g
inner join ai21rep_ve_dx.tbsa001g ta001g on ta001g.cd_hansya = t001g.cd_hansya
and ta001g.cd_kaisya = t001g.cd_kaisya
and ta001g.no_aijutyu = t001g.no_jucyu
-- 店舗表示設定
left semi join dx_ve.tbi999003m t9003m on t9003m.cd_hansya = ta001g.cd_hansya
and t9003m.cd_kaisya = ta001g.cd_kaisya
and t9003m.cd_tenpo = ta001g.cd_tenpo
and t9003m.mj_cyohyoid = '000'
and t9003m.kb_tenji = 1
--受注明細ＤＢ
inner join ai21rep_ve_dx.tbfa008g t008g on t008g.cd_hansya = t001g.cd_hansya
and t008g.cd_kaisya = t001g.cd_kaisya
and t008g.cd_tenpo = ta001g.cd_tenpo
and left(t008g.cd_seibi, 5) = t001g.no_seiri
and t008g.no_jucyu = t001g.no_jucyu
--リコール展開明細ＤＢ
left semi join ai21rep_ve_dx.tbfy206m t206m on t206m.cd_hansya = t001g.cd_hansya
and t206m.cd_kaisya = t001g.cd_kaisya
and t206m.no_seiri = t001g.no_seiri
and trim(t206m.mj_framekat) = trim(t001g.mj_framekat)
and t206m.kb_siharai = right(trim(t008g.cd_seibi), 1)
--入庫予定日が現在の日付から6ヶ月以内の範囲
where ta001g.dt_nyuukoyt > cast(current_timestamp() as date)
and ta001g.dt_nyuukoyt < add_months(cast(current_timestamp() as date), 6)
group by t001g.cd_hansya, t001g.cd_kaisya, ta001g.cd_tenpo, t001g.no_seiri, ta001g.dt_nyuukoyt
;

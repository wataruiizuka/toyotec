-- Source file: 017_新車実績一覧(スタッフ別・店舗別)/新車実績一覧（スタッフ別・店舗別）_iceberg.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi017002
SELECT 
	--販社コード
	cd_hansya,
	--会社コード
	cd_kaisya,
	--店舗コード
	cd_tenpo,
	--店舗名称
	kj_tenpomei,
	--販売スタッフコード
	cd_hanstaff,
	--社員名
	kj_syainmei,
	--月
	month,
	--販売
	SUM(su_hanbai) AS `su_hanbai`,
	--販売キャンセル反映
	SUM(su_hanbai) - SUM(su_hanbaicancel) AS `su_hanbaicancelhane`,
	--販売除軽
	SUM(su_hanbaijyokei) AS `su_hanbaijyokei`,
	--販売除軽キャンセル反映
	SUM(su_hanbaijyokei) - SUM(su_hanbaicanceljyokei) AS `su_hanbaicanceljyokeihene`
FROM
(
	SELECT
		--販社コード
		t001g.cd_hansya,
		--会社コード
		t001g.cd_kaisya,
		--店舗コード
		t001g.cd_tenpo,
		--店舗名称
		regexp_replace(t0201m.kj_tenpomei, '　+$', '') AS `kj_tenpomei`,
		--販売スタッフコード
		t001g.cd_hanstaff,
		--社員名
		regexp_replace(t014m.kj_syainmei, '　+$', '') AS `kj_syainmei`,
		--月
		IF(IF(ft168g.dd_torokei IS NULL, t001g.dd_uriagekj, ft168g.dd_torokei) >= trunc(CAST(current_timestamp() AS DATE), 'MM'),'当月','前月') AS `month`,
		--販売
		1 AS `su_hanbai`,
		--販売取消
		0 AS `su_hanbaicancel`,
		--販売除軽
		IF(t001m.kn_kei <> '1',1,0) AS `su_hanbaijyokei`,
		--販売取消除軽
		0 AS `su_hanbaicanceljyokei`
	FROM
	--新車受注基本情報ＤＢ
	ai21rep_ve_dx.tbba001g t001g
	-- 履歴登録ＤＢ
	LEFT JOIN 
		(
	        SELECT
				--販社コード
	            t168g.cd_hansya,
				--会社コード
	            t168g.cd_kaisya,
				--注文ＮＯ
	            t168g.no_cyumon,
				--注文ｎｏ枝番
				t168g.no_cyumoned,
				--登録計上日
	            min(t168g.dd_torokei) as dd_torokei
	        FROM ai21rep_ve_dx.tbbg168g t168g  
	        WHERE 
	            t168g.no_gyomu = '07'
	        AND t168g.no_syori = '01'
	        GROUP BY t168g.cd_hansya,t168g.cd_kaisya, t168g.no_cyumon, t168g.no_cyumoned
	    ) ft168g 
	    ON ft168g.cd_kaisya = t001g.cd_kaisya
	    AND ft168g.cd_hansya = t001g.cd_hansya
	    AND ft168g.no_cyumon = t001g.no_cyumon
	    AND TRIM(ft168g.no_cyumoned) = TRIM(t001g.no_cyumoned)
	-- 車両スペック２ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf008m t008m
		ON t001g.cd_kaisya = t008m.cd_kaisya
		AND t001g.cd_hansya = t008m.cd_hansya
		AND t001g.mj_sinkysed = t008m.mj_sinkysed
		AND t001g.mj_gaihansy = t008m.cd_spec 
		AND t001g.mj_hantenkt  = t008m.mj_hantenkt 
		AND t008m.kb_spec = 'G'
	--車名ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf001m t001m
		ON t001m.cd_kaisya = t008m.cd_kaisya
		AND t001m.cd_hansya = t008m.cd_hansya
		AND t001m.cd_ncsyamei = t008m.mj_syamei 
	-- M社員ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0014m t014m
		ON t014m.cd_kaisya = t001g.cd_kaisya
	    AND t014m.cd_hansya = t001g.cd_hansya
	    AND t014m.cd_syain = t001g.cd_hanstaff
	-- 共通店舗ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0201m t0201m
		ON t0201m.cd_kaisya = t001g.cd_kaisya
	    AND t0201m.cd_hansya = t001g.cd_hansya
	    AND t0201m.cd_tenpo = t001g.cd_tenpo
    -- 店舗表示設定
	LEFT SEMI JOIN dx_ve.tbi999003m
		ON tbi999003m.cd_kaisya = t001g.cd_kaisya
	    AND tbi999003m.cd_hansya = t001g.cd_hansya
	    AND tbi999003m.cd_tenpo = t001g.cd_tenpo
	    AND tbi999003m.mj_cyohyoid = '017'
	    AND tbi999003m.kb_tenji = 1
	WHERE 
	 	-- [払出区分] <> "00" AND [払出区分] <> "40"
	    t001g.kb_haraidas NOT IN ('00', '40')
	    --受注計上日≠NULL
	    AND t001g.dd_jucyuke IS NOT NULL
	    AND (
			(ft168g.dd_torokei >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM'))
			OR
			(ft168g.dd_torokei IS NULL AND t001g.dd_uriagekj >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM'))	
	    )
	UNION ALL
	SELECT
		--販社コード
		t001g.cd_hansya,
		--会社コード
		t001g.cd_kaisya,
		--店舗コード
		t001g.cd_tenpo,
		--店舗名称
		regexp_replace(t0201m.kj_tenpomei, '　+$', '') AS `kj_tenpomei`,
		--販売スタッフコード
		t001g.cd_hanstaff,
		--社員名
		regexp_replace(t014m.kj_syainmei, '　+$', '') AS `kj_syainmei`,
		--月
		IF(t001g.dd_uritrkkj >= trunc(CAST(current_timestamp() AS DATE), 'MM'),'当月','前月') AS `month`,
		--販売
		0 AS `su_hanbai`,
	    --販売取消
		1 AS `su_hanbaicancel`,
	    --販売除軽
		0 AS `su_hanbaijyokei`,
		--販売取消除軽
		IF(t001m.kn_kei <> '1',1,0) AS `su_hanbaicanceljyokei`
	FROM
	--新車受注基本情報ＤＢ
	ai21rep_ve_dx.tbba001g t001g
	-- M社員ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0014m t014m
		ON t014m.cd_kaisya = t001g.cd_kaisya
	    AND t014m.cd_hansya = t001g.cd_hansya
	    AND t014m.cd_syain = t001g.cd_hanstaff
	-- 車両スペック２ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf008m t008m
		ON t001g.cd_kaisya = t008m.cd_kaisya
		AND t001g.cd_hansya = t008m.cd_hansya
		AND t001g.mj_sinkysed = t008m.mj_sinkysed
		AND t001g.mj_gaihansy = t008m.cd_spec 
		AND t001g.mj_hantenkt  = t008m.mj_hantenkt 
		AND t008m.kb_spec = 'G'
	--車名ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf001m t001m
		ON t001m.cd_kaisya = t008m.cd_kaisya
		AND t001m.cd_hansya = t008m.cd_hansya
		AND t001m.cd_ncsyamei = t008m.mj_syamei 
	-- 共通店舗ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbv0201m t0201m
		ON t0201m.cd_kaisya = t001g.cd_kaisya
	    AND t0201m.cd_hansya = t001g.cd_hansya
	    AND t0201m.cd_tenpo = t001g.cd_tenpo
    -- 店舗表示設定
	LEFT SEMI JOIN dx_ve.tbi999003m
		ON tbi999003m.cd_kaisya = t001g.cd_kaisya
	    AND tbi999003m.cd_hansya = t001g.cd_hansya
	    AND tbi999003m.cd_tenpo = t001g.cd_tenpo
	    AND tbi999003m.mj_cyohyoid = '017'
	    AND tbi999003m.kb_tenji = 1
	WHERE 
	 	-- [払出区分] <> "00" AND [払出区分] <> "40"
	    t001g.kb_haraidas NOT IN ('00', '40')
	    --受注計上日≠NULL
	    AND t001g.dd_jucyuke IS NOT NULL
	    AND t001g.dd_uritrkkj >= trunc(ADD_MONTHS(CAST(current_timestamp() AS DATE), -1), 'MM')
)combined
GROUP BY
	--販社コード
	cd_hansya,
	--会社コード
	cd_kaisya,
	--店舗コード
	cd_tenpo,
	--店舗名称
	kj_tenpomei,
	--販売スタッフコード
	cd_hanstaff,
	--社員名
	kj_syainmei,
	--月
	month
;

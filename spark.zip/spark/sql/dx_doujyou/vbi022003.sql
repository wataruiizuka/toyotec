-- Source file: 022_中古車車両日報/中古車車両日報.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi022003
SELECT
	--販社コード
    tg.cd_hansya,
    --会社コード
    tg.cd_kaisya,
    --受注店舗コード
    tg.cd_jytyuten AS cd_tenpo,
    --車名
    UPPER(NVL(tbv0232m.mj_syamei, '')) AS kn_syame,
    --車名コード
    CONCAT(
        NVL(tbbc001g.mj_21syamek, ''),
        NVL(tbbc001g.mj_21syasyu, ''),
        NVL(tbbc001g.mj_21syamak, ''),
        NVL(tbbc001g.no_21syaren, ''),
        NVL(tbbc001g.mj_21syanin, '')
    ) AS cd_ncsyamei,
    --売上予定日
    CAST(TO_DATE(tg.dd_uriagyot) AS DATE) AS dd_uriagyot,
    --中古車販売見込み
    COUNT(*) AS su_jusya_hanbai_mikomi
FROM ai21rep_ve_dx.tbbc017g tg--中古車受注基本情報ＤＢ
    LEFT JOIN ai21rep_ve_dx.tbbc001g tbbc001g  --中古車在庫基本情報ＤＢ
        ON tbbc001g.cd_kaisya = tg.cd_kaisya
        AND tbbc001g.cd_hansya = tg.cd_hansya
        AND tbbc001g.no_syaryou = tg.no_syaryou
    LEFT JOIN ai21rep_ve_dx.tbv0232m tbv0232m  --ａｉ２１車名コードＤＢ
        ON tbv0232m.cd_hansya = tbbc001g.cd_hansya
        AND tbv0232m.cd_kaisya = tbbc001g.cd_kaisya
        --車名コード = ａｉ２１車名コードメーカー & ａｉ２１車名コード車種  &  ａｉ２１車名コード市場  &  ａｉ２１車名コード連番  &  ａｉ２１車名コード任意
        AND tbv0232m.cd_syamei = CONCAT(
            NVL(tbbc001g.mj_21syamek, ''),
            NVL(tbbc001g.mj_21syasyu, ''),
            NVL(tbbc001g.mj_21syamak, ''),
            NVL(tbbc001g.no_21syaren, ''),
            NVL(tbbc001g.mj_21syanin, '')
        )
WHERE 
    --売上計上日が空である
    tg.dd_uriagekj IS NULL
    --取消日が空である
    AND tg.dd_torikesi IS NULL
    --戻し売上日が空である
    AND tg.dd_moduriag IS NULL
    --売上予定日が当月である
    AND date_format(tg.dd_uriagyot, 'yyyyMM') =
        date_format(CAST(current_timestamp() AS DATE), 'yyyyMM')
GROUP BY
    tg.cd_hansya,
    tg.cd_kaisya,
    tg.cd_jytyuten,
    UPPER(NVL(tbv0232m.mj_syamei, '')),
    CONCAT(
        NVL(tbbc001g.mj_21syamek, ''),
        NVL(tbbc001g.mj_21syasyu, ''),
        NVL(tbbc001g.mj_21syamak, ''),
        NVL(tbbc001g.no_21syaren, ''),
        NVL(tbbc001g.mj_21syanin, '')
    ),
    dd_uriagyot,
    tbbc001g.no_syaryou
;

-- Source file: 001_新車車両日報/新車車両日報.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi001001
SELECT
	--販社コード
	cd_hansya,
	--会社コード
	cd_kaisya,
	--店舗コード
	cd_tenpo,
	--日付
    CAST(to_date(dd_date) AS DATE) AS dd_date,
	--車名コード
	cd_ncsyamei,
	--車名
	kn_syame,
	--新車受注実績
	nullif(SUM(su_sinsya_jucyu), 0) AS su_sinsya_jucyu,
	--新車受注取消
	nullif(SUM(su_sinsya_jucyu_torikesi), 0) AS su_sinsya_jucyu_torikesi,
	--新車受注合計
	nullif(SUM(su_sinsya_jucyu) - SUM(su_sinsya_jucyu_torikesi), 0) AS su_sinsya_jucyu_goukei,
	--新車受注残
	nullif(SUM(su_sinsya_jucyucan), 0) AS su_sinsya_jucyucan
FROM
	(
	SELECT
		--販社コード
		tg.cd_hansya,
		--会社コード
		tg.cd_kaisya,
		--店舗コード
		tg.cd_tenpo,
		--日付
		tg.dd_jucyuke AS dd_date,
		--車名コード
		tbbf001m.cd_ncsyamei,
		--車名
		UPPER(NVL(tbbf001m.kn_syame, '')) AS kn_syame,
		--新車受注実績
        CASE
			WHEN tg.dd_jucyuke IS NOT NULL THEN 1
			ELSE 0
		END AS su_sinsya_jucyu,
		--新車受注取消
        0 AS su_sinsya_jucyu_torikesi,
        --新車受注残
		CASE
			WHEN tg.dd_jucyuke IS NOT NULL
			AND tg.dd_touroku IS NULL THEN 1
			ELSE 0
		END AS su_sinsya_jucyucan
	FROM
		ai21rep_ve_dx.tbba001g tg	-- 新車受注基本情報ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf008m tbbf008m	-- 車両スペック２ＤＢ
        ON
		tg.cd_kaisya = tbbf008m.cd_kaisya
		AND tg.cd_hansya = tbbf008m.cd_hansya
		AND tg.mj_sinkysed = tbbf008m.mj_sinkysed
		AND tg.mj_gaihansy = tbbf008m.cd_spec
		AND tg.mj_hantenkt = tbbf008m.mj_hantenkt
		-- スペック区分が 「G」 である
		AND tbbf008m.kb_spec = 'G'
	LEFT JOIN ai21rep_ve_dx.tbbf001m tbbf001m -- 車名ＤＢ
        ON
		tbbf001m.cd_kaisya = tbbf008m.cd_kaisya
		AND tbbf001m.cd_hansya = tbbf008m.cd_hansya
		AND tbbf001m.cd_ncsyamei = tbbf008m.mj_syamei
	WHERE
		-- 払出区分が　「00」　「40」　以外である
		tg.kb_haraidas NOT IN ('00', '40')
		-- 受注計上日が空ではない
		AND tg.dd_jucyuke IS NOT NULL
		-- 受注計上日が前月1日より大きい
		AND date_format(tg.dd_jucyuke, 'yyyyMM') >= date_format(add_months(CAST(current_timestamp() AS DATE), -1), 'yyyyMM')
UNION ALL
	SELECT
		--販社コード
		tg.cd_hansya,
		--会社コード
		tg.cd_kaisya,
		--店舗コード
		tg.cd_tenpo,
		--日付
		tg.dd_torikesi AS dd_date,
		--車名コード
		tbbf001m.cd_ncsyamei,
		--車名
		UPPER(NVL(tbbf001m.kn_syame, '')) AS kn_syame,
		--新車受注実績
		0 AS su_sinsya_jucyu,
		--新車受注取消
		CASE
			WHEN tg.dd_torikesi IS NOT NULL THEN 1
			ELSE 0
		END AS su_sinsya_jucyu_torikesi,
		--新車受注残
		0 AS su_sinsya_jucyucan
	FROM
		ai21rep_ve_dx.tbba001g tg -- 新車受注基本情報ＤＢ
	LEFT JOIN ai21rep_ve_dx.tbbf008m tbbf008m -- 車両スペック２ＤＢ
        ON
		tg.cd_kaisya = tbbf008m.cd_kaisya
		AND tg.cd_hansya = tbbf008m.cd_hansya
		AND tg.mj_sinkysed = tbbf008m.mj_sinkysed
		AND tg.mj_gaihansy = tbbf008m.cd_spec
		AND tg.mj_hantenkt = tbbf008m.mj_hantenkt
		-- スペック区分が 「G」 である
		AND tbbf008m.kb_spec = 'G'
	LEFT JOIN ai21rep_ve_dx.tbbf001m tbbf001m -- 車名ＤＢ
        ON
		tbbf001m.cd_kaisya = tbbf008m.cd_kaisya
		AND tbbf001m.cd_hansya = tbbf008m.cd_hansya
		AND tbbf001m.cd_ncsyamei = tbbf008m.mj_syamei
	WHERE
		-- 払出区分が　「00」　「40」　以外である
		tg.kb_haraidas NOT IN ('00', '40')
		-- 取消日が空ではない
		AND tg.dd_torikesi IS NOT NULL
		-- 取消日が前月1日より大きい
		AND date_format(tg.dd_torikesi, 'yyyyMM') >= date_format(add_months(CAST(current_timestamp() AS DATE), -1), 'yyyyMM')
) combined
GROUP BY
	cd_hansya,
	cd_kaisya,
	cd_tenpo,
	to_date(dd_date),
	cd_ncsyamei,
	kn_syame
;

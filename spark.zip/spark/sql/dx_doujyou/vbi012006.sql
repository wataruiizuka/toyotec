-- Source file: 012_SMB空き枠カレンダー（ストール軸管理向け）/smbcalendar.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi012002
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi012006
select
	--ソート順
	row_number() over(partition by v12002.cd_hansya, v12002.cd_kaisya order by v12002.mj_sortjyun, v12002.cd_tenpo) as `ソート順`,
	--販社コード
	v12002.cd_hansya as `販社コード`,
	--会社コード
	v12002.cd_kaisya as `会社コード`,
	--店舗コード
	v12002.cd_tenpo as `店舗コード`,
	--店舗名
	regexp_replace(t201m.kj_tenpomei, '　+$', '') as `店舗名`,
	--販社会社店舗コード
	concat(v12002.cd_hansya, v12002.cd_kaisya, v12002.cd_tenpo) as `販社会社店舗コード`
--ストールマスタ_充足率対象ＤＢ
from gold.vbi012002 v12002
-- 共通店舗ＤＢ
left join ai21rep_ve_stg_kudu.tbv0201m t201m on t201m.cd_hansya = v12002.cd_hansya
and t201m.cd_kaisya = v12002.cd_kaisya
and t201m.cd_tenpo = v12002.cd_tenpo
group by v12002.cd_hansya, v12002.cd_kaisya, v12002.cd_tenpo, t201m.kj_tenpomei, v12002.mj_sortjyun
;

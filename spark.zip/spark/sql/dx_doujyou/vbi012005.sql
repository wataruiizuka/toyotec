-- Source file: 012_SMB空き枠カレンダー（ストール軸管理向け）/smbcalendar.sql
-- Dependency level: 2
-- Internal Gold dependencies: gold.vbi012003, gold.vbi012004
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi012005
select
	--販社コード
	v12003.cd_hansya as `販社コード`,
	--会社コード
	v12003.cd_kaisya as `会社コード`,
	--店舗コード
	v12003.cd_tenpo as `店舗コード`,
	--販社会社店舗コード
	concat(v12003.cd_hansya, v12003.cd_kaisya, v12003.cd_tenpo) as `販社会社店舗コード`,
	--ストール番号
	v12003.no_stall as `ストール番号`,
	--ストール名称
	v12003.mj_stallmei as `ストール名称`,
	--ストール選択
	v12003.kb_stallsentaku as `ストール選択`,
	--日付
	v12003.dd_date as `日付`,
	--時刻
	bt.tm_jikoku as `時刻`,
	--予約不可フラグ
	if (
		v12003.kb_kyukei = 1,
		1,
		case bt.tm_jikoku
			when '08:00' then if ((v12003.dd_date + INTERVAL 510 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 480 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '08:30' then if ((v12003.dd_date + INTERVAL 540 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 510 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '09:00' then if ((v12003.dd_date + INTERVAL 570 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 540 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '09:30' then if ((v12003.dd_date + INTERVAL 600 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 570 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '10:00' then if ((v12003.dd_date + INTERVAL 630 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 600 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '10:30' then if ((v12003.dd_date + INTERVAL 660 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 630 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '11:00' then if ((v12003.dd_date + INTERVAL 690 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 660 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '11:30' then if ((v12003.dd_date + INTERVAL 720 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 690 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '12:00' then if ((v12003.dd_date + INTERVAL 750 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 720 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '12:30' then if ((v12003.dd_date + INTERVAL 780 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 750 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '13:00' then if ((v12003.dd_date + INTERVAL 810 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 780 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '13:30' then if ((v12003.dd_date + INTERVAL 840 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 810 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '14:00' then if ((v12003.dd_date + INTERVAL 870 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 840 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '14:30' then if ((v12003.dd_date + INTERVAL 900 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 870 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '15:00' then if ((v12003.dd_date + INTERVAL 930 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 900 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '15:30' then if ((v12003.dd_date + INTERVAL 960 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 930 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '16:00' then if ((v12003.dd_date + INTERVAL 990 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 960 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '16:30' then if ((v12003.dd_date + INTERVAL 1020 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 990 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '17:00' then if ((v12003.dd_date + INTERVAL 1050 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 1020 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '17:30' then if ((v12003.dd_date + INTERVAL 1080 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 1050 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '18:00' then if ((v12003.dd_date + INTERVAL 1110 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 1080 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '18:30' then if ((v12003.dd_date + INTERVAL 1140 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 1110 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '19:00' then if ((v12003.dd_date + INTERVAL 1170 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 1140 MINUTES) < v12004.dt_siyoed, 1, 0)
			when '19:30' then if ((v12003.dd_date + INTERVAL 1200 MINUTES) > v12004.dt_siyost and (v12003.dd_date + INTERVAL 1170 MINUTES) < v12004.dt_siyoed, 1, 0)
		end
	) as `予約不可フラグ`
--ストールマスタ_充足率対象ＤＢ_14日
from gold.vbi012003 v12003
-- SMB異常管理ボード集計対象店舗一覧
inner join dx_ve.tbi003001m t3001m on t3001m.cd_hansya = v12003.cd_hansya
and t3001m.cd_kaisya = v12003.cd_kaisya
and t3001m.cd_tenpo = v12003.cd_tenpo
--tbsa005g_ストール予約明細ＤＢ_退避含_14日
left join gold.vbi012004 v12004 on v12004.cd_hansya = v12003.cd_hansya
and v12004.cd_kaisya = v12003.cd_kaisya
and v12004.cd_tenpo = v12003.cd_tenpo
and v12004.no_stall = v12003.no_stall
and ((v12004.dt_siyost >= v12003.dd_date and v12004.dt_siyost < date_add(v12003.dd_date, 1))
	or (v12004.dt_siyoed >= v12003.dd_date and v12004.dt_siyoed < date_add(v12003.dd_date, 1))
)
and v12003.kb_kyukei = 0
cross join (
	VALUES ('08:00'), ('08:30'), ('09:00'), ('09:30'), ('10:00'), ('10:30'), ('11:00'), ('11:30'), ('12:00'), ('12:30'), ('13:00'), ('13:30'), ('14:00'), ('14:30'), ('15:00'), ('15:30'), ('16:00'), ('16:30'), ('17:00'), ('17:30'), ('18:00'), ('18:30'), ('19:00'), ('19:30')
) AS bt(tm_jikoku)
--開店時間の前五桁 <= 時刻
where left(t3001m.tm_kaiten, 5) <= bt.tm_jikoku
--閉店時間の前五桁 >= 時刻
and left(t3001m.tm_heiten, 5) > bt.tm_jikoku
;

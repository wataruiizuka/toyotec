-- Source file: 003_ストール充足率見える化（ストール軸管理向け）/smb.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi003002
select
	--ソート順
	dense_rank() over(partition by t3002m.cd_hansya, t3002m.cd_kaisya order by  IF(
                t033m.kj_zonmei IS NULL OR regexp_replace(t033m.kj_zonmei, '[ 　]+', '') = '',
                '999999',
                IF(
                    t033m.cd_zon IS NULL OR regexp_replace(t033m.cd_zon, '[ 　]+', '') = '',
                    '999998',
                    t033m.cd_zon
                )
            ), t9003m.mj_sortjyun, t3002m.cd_tenpo) as mj_sortjyun,
	--販社コード
	t3002m.cd_hansya,
	--会社コード
	t3002m.cd_kaisya,
	--店舗コード
	t3002m.cd_tenpo,
	--店舗名
	regexp_replace(t201m.kj_tenpomei, '　+$', '') as kj_tenpomei,
	--エリアコード
	IF(
    	t033m.kj_zonmei IS NULL OR regexp_replace(t033m.kj_zonmei, '[ 　]+', '') = '',
    	'999999',
    	IF(
        	t033m.cd_zon IS NULL OR regexp_replace(t033m.cd_zon, '[ 　]+', '') = '',
        	'999998',
        	t033m.cd_zon
    	)
	) AS cd_zon,
	--エリア名
	regexp_replace(t033m.kj_zonmei, '　+$', '') as kj_zonmei,
	--ストール番号
	t3002m.no_stall,
	--ストール名称
	t3002m.mj_stallmei,
	--集計対象判別
	t3002m.kb_shuukeitaishou,
	--販社会社店舗ストール番号
	concat(t3002m.cd_hansya, t3002m.cd_kaisya, t3002m.cd_tenpo, cast(t3002m.no_stall as string)) as cd_hansyakaisyatenpostall,
	--ストール選択
	concat(cast(t3002m.no_stall as string), '　', t3002m.mj_stallmei) as kb_stallsentaku,
	-- 出勤時間
	t3001m.tm_kaiten,
	--出勤時間_秒
	unix_timestamp(concat('1970-01-01 ', t3001m.tm_kaiten)) as tm_shukkinsecond,
	-- 退勤時間
	t3001m.tm_heiten,
	--退勤時間_秒
	unix_timestamp(concat('1970-01-01 ', t3001m.tm_heiten)) as tm_taikinsecond,
	--残業時間
	date_format((CAST(concat('1970-01-01 ', t3001m.tm_heiten) AS TIMESTAMP) + INTERVAL 2 HOURS), 'HH:mm:ss') as tm_zangyo,
	--定外規定
	1440 / 12 as kb_teigaikitei,
	--定内規定
	(unix_timestamp(concat('1970-01-01 ', t3001m.tm_heiten)) - unix_timestamp(concat('1970-01-01 ', t3001m.tm_kaiten))) / 60 - 60 as kb_teinaikitei,
	--販社会社店舗コード
	concat(t3002m.cd_hansya, t3002m.cd_kaisya, t3002m.cd_tenpo) as cd_hansyakaisyatenpo
-- ストール集計対象一覧
from dx_ve.tbi003002m t3002m
-- 店舗表示設定
inner join dx_ve.tbi999003m t9003m on t9003m.cd_hansya = t3002m.cd_hansya
and t9003m.cd_kaisya = t3002m.cd_kaisya
and t9003m.cd_tenpo = t3002m.cd_tenpo
and t9003m.mj_cyohyoid = '003'
and t9003m.kb_tenji = 1
-- SMB異常管理ボード集計対象店舗一覧
inner join dx_ve.tbi003001m t3001m on t3001m.cd_hansya = t3002m.cd_hansya
and t3001m.cd_kaisya = t3002m.cd_kaisya
and t3001m.cd_tenpo = t3002m.cd_tenpo
-- 共通店舗ＤＢ
left join ai21rep_ve_dx.tbv0201m t201m on t201m.cd_hansya = t3002m.cd_hansya
and t201m.cd_kaisya = t3002m.cd_kaisya
and t201m.cd_tenpo = t3002m.cd_tenpo
-- サービス店舗ＤＢ
left join ai21rep_ve_dx.tbv0202m t202m on t202m.cd_hansya = t201m.cd_hansya
and t202m.cd_kaisya = t201m.cd_kaisya
and t202m.cd_tenpo = t201m.cd_tenpo
-- ＭゾーンコードＤＢ
left join ai21rep_ve_dx.tbv0033m t033m on t033m.cd_hansya = t202m.cd_hansya
and t033m.cd_kaisya = t202m.cd_kaisya
and t033m.cd_zon = t202m.cd_zon
and t033m.kb_syohin  = '3'
where t3002m.kb_shuukeitaishou = '1'
-- ISERROR(SEARCH("コント", [ストール名称], 1))
and instr(t3002m.mj_stallmei, 'コント') = 0
-- ISERROR(SEARCH("外注", [ストール名称], 1))
and instr(t3002m.mj_stallmei, '外注') = 0
;

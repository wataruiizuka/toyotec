-- Source file: 012_SMB空き枠カレンダー（ストール軸管理向け）/smbcalendar.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi012001_en, gold.vbi012002
-- Runtime requirements: Spark SQL 3.3+

with t275m as (
	select
		--販社コード
		t275m.cd_hansya,
		--会社コード
		t275m.cd_kaisya,
		--店舗コード
		t275m.cd_tenpo,
		--稼動日付
		v12001.dd_date as dd_kado,
		--稼動区分
		case day(v12001.dd_date)
			when 1 then t275m.kb_kado1
			when 2 then t275m.kb_kado2
			when 3 then t275m.kb_kado3
			when 4 then t275m.kb_kado4
			when 5 then t275m.kb_kado5
			when 6 then t275m.kb_kado6
			when 7 then t275m.kb_kado7
			when 8 then t275m.kb_kado8
			when 9 then t275m.kb_kado9
			when 10 then t275m.kb_kado10
			when 11 then t275m.kb_kado11
			when 12 then t275m.kb_kado12
			when 13 then t275m.kb_kado13
			when 14 then t275m.kb_kado14
			when 15 then t275m.kb_kado15
			when 16 then t275m.kb_kado16
			when 17 then t275m.kb_kado17
			when 18 then t275m.kb_kado18
			when 19 then t275m.kb_kado19
			when 20 then t275m.kb_kado20
			when 21 then t275m.kb_kado21
			when 22 then t275m.kb_kado22
			when 23 then t275m.kb_kado23
			when 24 then t275m.kb_kado24
			when 25 then t275m.kb_kado25
			when 26 then t275m.kb_kado26
			when 27 then t275m.kb_kado27
			when 28 then t275m.kb_kado28
			when 29 then t275m.kb_kado29
			when 30 then t275m.kb_kado30
			when 31 then t275m.kb_kado31
		end as kb_kado
	-- 店舗稼動日程ＤＢ
	from ai21rep_ve_stg_kudu.tbfy275m t275m
	--ストールマスタ_充足率対象ＤＢ
	inner join gold.vbi012001_en v12001 on v12001.dd_month = t275m.dd_kadoyymm
)
INSERT OVERWRITE TABLE gold.vbi012003
select
	--販社コード
	v12002.cd_hansya,
	--会社コード
	v12002.cd_kaisya,
	--店舗コード
	v12002.cd_tenpo,
	--ストール番号
	v12002.no_stall,
	--ストール名称
	v12002.mj_stallmei,
	--ストール選択
	v12002.kb_stallsentaku,
	--休憩区分
	if(
		-- 店舗休みの場合、休みとみなす
		t275m.kb_kado not in('1', '9')
		-- 店舗休みではない場合、ストールの[非稼動区分]が1でない場合、稼働とみなす
		or t002m.kb_hikado = '1',
		1,
		0
	) as kb_kyukei,
	--日付
	v12001.dd_date
-- ストールマスタ_充足率対象ＤＢ
from gold.vbi012002 v12002
cross join gold.vbi012001_en v12001
-- 店舗稼動日程ＤＢ
left join t275m on t275m.cd_hansya = v12002.cd_hansya
and t275m.cd_kaisya = v12002.cd_kaisya
and t275m.cd_tenpo = v12002.cd_tenpo
and t275m.dd_kado = v12001.dd_date
and t275m.kb_kado <> 'Z'
-- ストール稼動予定マスタＤＢ
left join ai21rep_ve_stg_kudu.tbsa002m t002m on t002m.cd_hansya = v12002.cd_hansya
and t002m.cd_kaisya = v12002.cd_kaisya
and t002m.cd_tenpo = v12002.cd_tenpo
and t002m.no_stall = v12002.no_stall
and t002m.dd_hikado = v12001.`dd_yyyyMMdd`
;

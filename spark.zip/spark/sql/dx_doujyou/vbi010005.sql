-- Source file: 010_経営主要項目実績/VBI010001-VBI010006.sql
-- Dependency level: 0
-- Internal Gold dependencies: none
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.VBI010005
SELECT  
	t201m.cd_hansya AS `販社コード`, --販社コード
	t201m.cd_kaisya AS `会社コード`, --会社コード
	t201m.cd_tenpo AS `店舗コード`, --店舗コード
	CONCAT(t201m.cd_hansya, t201m.cd_kaisya, t201m.cd_tenpo) AS `販社会社店舗`, --販社会社店舗
	NVL(newcar_daitei.`新車代替`, 0) AS `新車代替`, --新車代替
	NVL(newcar_daitei.`新車実績`, 0) AS `新車実績` --新車実績
FROM
	ai21rep_ve_dx.tbv0201m t201m --共通店舗ＤＢ
LEFT JOIN
( --新車代替
	SELECT
		tbba001g.cd_hansya, --販社コード
		tbba001g.cd_kaisya, --会社コード
		tbba001g.cd_tenpo, --店舗コード
		SUM( IF(tbba056g.mj_jucyuke4 IN ('02','03'),calflg ,0)) AS `新車代替`, --新車代替
		SUM(calflg) AS `新車実績` --新車実績
	FROM
		(
		SELECT
			tbba001g.cd_hansya, --販社コード
			tbba001g.cd_kaisya, --会社コード
			tbba001g.cd_tenpo, --店舗コード
			tbba001g.no_cyumon, --注文ＮＯ
			tbba001g.no_cyumoned, --注文ＮＯ枝番
			tbba001g.mj_sinkysed, --新旧世代
			tbba001g.mj_gaihansy, --外鈑色
			tbba001g.mj_hantenkt, --販売店型式
			(CASE
				WHEN ft168g.dd_torokei IS NULL THEN tbba001g.dd_uriagekj
				ELSE ft168g.dd_torokei
			END) AS `日付`,
			1 AS calflg
		FROM
			ai21rep_ve_dx.tbba001g tbba001g --新車受注基本情報ＤＢ 
		LEFT JOIN(
		    SELECT
		        t168g.cd_hansya, --販社コード
		        t168g.cd_kaisya, --会社コード
		        t168g.no_cyumon, --注文ＮＯ
		        min(t168g.dd_torokei) AS dd_torokei --登録計上日
		    FROM ai21rep_ve_dx.tbbg168g t168g --履歴登録ＤＢ
		    WHERE -- 業務ＮＯ=「07」、処理ＮＯ=「01」　
		    	t168g.no_gyomu = '07'
		      AND t168g.no_syori = '01'
		    GROUP BY t168g.cd_hansya, t168g.cd_kaisya, t168g.no_cyumon
		) ft168g ON
			ft168g.cd_kaisya = tbba001g.cd_kaisya
			AND ft168g.cd_hansya = tbba001g.cd_hansya
			AND ft168g.no_cyumon = tbba001g.no_cyumon
		WHERE -- 払出区分 =「00」or「40」、受注計上日に値があり、かつ履歴登録ＤＢの登録計上日がNULLと新車受注基本情報ＤＢの売上計上日に値があり、或いは履歴登録ＤＢの登録計上日に値がある
			tbba001g.kb_haraidas NOT IN ('00', '40')
				AND tbba001g.dd_jucyuke IS NOT NULL
				AND ( (ft168g.dd_torokei IS NULL
					AND tbba001g.dd_uriagekj IS NOT NULL)
					OR  (ft168g.dd_torokei IS NOT NULL)
		)
		UNION ALL
			SELECT
				tbba001g.cd_hansya, --販社コード
				tbba001g.cd_kaisya , --会社コード
				tbba001g.cd_tenpo, --店舗コード
				tbba001g.no_cyumon, --注文ＮＯ
				tbba001g.no_cyumoned, --注文ＮＯ枝番
				tbba001g.mj_sinkysed, --新旧世代
				tbba001g.mj_gaihansy, --外鈑色
				tbba001g.mj_hantenkt, --販売店型式
				tbba001g.dd_uritrkkj AS dd_uritrkkj, --売上取消計上日
				-1 AS calflg
			FROM
				ai21rep_ve_dx.tbba001g tbba001g --新車受注基本情報ＤＢ
			WHERE --払出区分 =「00」or「40」、受注計上日、売上取消計上日が空白ではない
				tbba001g.kb_haraidas NOT IN ('00', '40')
					AND tbba001g.dd_jucyuke IS NOT NULL
					AND tbba001g.dd_uritrkkj IS NOT NULL
		) tbba001g
		LEFT JOIN ai21rep_ve_dx.tbba056g tbba056g  --新車お客様詳細情報ＤＢ 
			ON tbba001g.cd_hansya = TBBA056G.cd_hansya
			AND tbba001g.cd_kaisya = TBBA056G.cd_kaisya
			AND tbba001g.no_cyumon = TBBA056G.no_cyumon
			AND TRIM(tbba001g.no_cyumoned) = TRIM(TBBA056G.no_cyumoned)
	GROUP BY
		tbba001g.cd_hansya,
		tbba001g.cd_kaisya,
		tbba001g.cd_tenpo
	) newcar_daitei --新車代替	
	ON t201m.cd_hansya = newcar_daitei.cd_hansya
	AND t201m.cd_kaisya = newcar_daitei.cd_kaisya
	AND t201m.cd_tenpo = newcar_daitei.cd_tenpo
;

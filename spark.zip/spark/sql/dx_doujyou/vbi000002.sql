-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi000002_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000002
select
	--販社コード
	cd_hansya as `販社コード`,
	--会社コード
	cd_kaisya as `会社コード`,
	--取替部品品番
	mj_toribhhn as `取替部品品番`,
	--取替部品品名
	mj_torihnme as `取替部品品名`
from gold.vbi000002_en
;

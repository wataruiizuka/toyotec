-- Source file: 000_市場処置の実施状況と部品管理見える化/recallslim_iceberg.sql
-- Dependency level: 1
-- Internal Gold dependencies: gold.vbi000002_en
-- Runtime requirements: Spark SQL 3.3+

INSERT OVERWRITE TABLE gold.vbi000009
select
	--販社コード
	t206m.cd_hansya as `販社コード`,
	--会社コード
	t206m.cd_kaisya as `会社コード`,
	--整理ＮＯ
	t206m.no_seiri as `整理ＮＯ`,
	--フレーム型式
	t206m.mj_framekat as `フレーム型式`,
	--支払区分
	t206m.kb_siharai as `支払区分`,
	--取替部品品番
	trim(t206m.mj_toribhhn) as `取替部品品番`,
	--取替部品個数
	t206m.su_toribhsu as `取替部品個数`,
	--販社会社整理ＮＯフレーム型式支払区分
	concat(t206m.cd_hansya, t206m.cd_kaisya, t206m.no_seiri, trim(t206m.mj_framekat),t206m.kb_siharai) as `販社会社整理ＮＯフレーム型式支払区分`
--リコール展開明細ＤＢ
from ai21rep_ve_dx.tbfy206m t206m
--部品品名マスタ
left semi join gold.vbi000002_en v0002 on v0002.cd_hansya = t206m.cd_hansya
and v0002.cd_kaisya = t206m.cd_kaisya
and v0002.mj_toribhhn = trim(t206m.mj_toribhhn)
;

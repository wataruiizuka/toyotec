-- Source file: 011_メンテナンスパック契約客ステータス一覧/メンテナンスパック契約客ステータス一覧.sql
-- Dependency level: 2
-- Internal Gold dependencies: gold.vbi011001, gold.vbi011004, gold.vbi011005
-- Runtime requirements: Spark SQL 3.3+, spark.sql.session.timeZone=Asia/Tokyo

INSERT OVERWRITE TABLE gold.vbi011006
SELECT 
		--販社コード
    	tz030m.cd_hansya AS `販社コード`,
		--会社コード
		tz030m.cd_kaisya AS `会社コード`,
		--お客様コード
		tz030m.cd_okyaku AS `お客様コード`,
		--スタッフエリアコード
		vbi011005.cd_zon AS `スタッフエリアコード`,
		--スタッフエリア名
		vbi011005.kj_zonmei AS `スタッフエリア名`,
		--スタッフ店舗名
		vbi011005.kj_tenpomei AS `スタッフ店舗名`,
		--テーブル店舗名
		vbi011005.kj_tenpomei AS `テーブル店舗名`,
		--スタッフ名
		vbi011005.kj_syainmei AS `スタッフ名`,
		--店舗スタッフ
		CONCAT(vbi011005.cd_stafften, vbi011005.cd_staff) AS `店舗スタッフ`,
		--実施区分
		tz031m.kb_jissi AS `実施区分`,
		--メンテパック名称
		vbi011001.kj_kanyusyu AS `メンテパック名称`,
		--項目利用整備名称
		vbi011001.kj_riyoseim AS `項目利用整備名称`,
		--契約区分
		vbi011001.kb_keiyaku AS `契約区分`,
		--税込金額
		vbi011001.totalcount AS `税込金額`,
		--新規連番
		DENSE_RANK() OVER (
			PARTITION BY 
			CONCAT(tz030m.cd_okyaku, tz030m.cd_norikusi, tz030m.kb_nosyasyu, tz030m.cd_nogyotai, tz030m.no_noseiri, vbi011001.kb_keiyaku, vbi011001.kj_kanyusyu)
			ORDER BY tz031m.dd_jisiyote ASC, vbi011001.no_renban ASC
		) AS `新規連番`,
		--実施予定年月日
		tz031m.dd_jisiyote AS `実施予定年月日`,
		--実施予定年月スライサー
		IF(tz031m.dd_jisiyote IS NULL, NULL
	    , IF(tz031m.dd_jisiyote >= DATE_ADD(CAST(current_timestamp() AS DATE), INTERVAL -3 MONTH)
	    	, CONCAT(date_format(tz031m.dd_jisiyote, 'yy年MM月'), '分')
	    	, CONCAT(date_format(DATE_ADD(CAST(current_timestamp() AS DATE), INTERVAL -3 MONTH), 'yy年MM月'), '以前分')
	    	)
	    ) AS `実施予定年月スライサー`,
		--契約終了予定年月スライサー
	    IF(tz030m.dd_mntkanry IS NULL, NULL
	    ,IF(
	    	date_format(CAST(current_timestamp() AS DATE), 'yyyyMM') > date_format(tz030m.dd_mntkanry, 'yyyyMM')
	    	, CONCAT(date_format(CAST(current_timestamp() AS DATE), 'yy年MM月'), '以前分')
	    	, CONCAT(date_format(tz030m.dd_mntkanry, 'yy年MM月'), '分')
	    	)
	    ) AS `契約終了予定年月スライサー`,
		--登録ＮＯ
		CONCAT(
			tz030m.cd_hansya,
			tz030m.cd_kaisya,
			tz030m.cd_okyaku,
			tz030m.cd_norikusi,
			tz030m.kb_nosyasyu,
			tz030m.cd_nogyotai,
			tz030m.no_noseiri
			) AS `登録ＮＯ`,
		--入庫区分漢字
	    CASE
		    	WHEN INSTR(vbi011001.kj_riyoseim, '無') > 0 THEN '無点'
			  	WHEN INSTR(vbi011001.kj_riyoseim, '１２') > 0 THEN '１２点'
			  	WHEN INSTR(vbi011001.kj_riyoseim, '６') > 0 THEN '６点'
			  	WHEN INSTR(vbi011001.kj_riyoseim, '車検') > 0 THEN '車検'
		    ELSE NULL 
	    END AS `入庫区分漢字`,
		--SMB予約入庫日時
		(IF(vbi011004.dt_nyuukoyt >= DATE_ADD(tz031m.dd_jisiyote, INTERVAL -2 MONTH) 
				AND vbi011004.dt_nyuukoyt <= DATE_ADD(tz031m.dd_jisiyote, INTERVAL 1 MONTH)
				,vbi011004.dt_nyuukoyt
				,NULL)) AS `SMB予約入庫日時`
	--メンテパック契約DB
    FROM ai21rep_ve_dx.tbaz030m tz030m
    LEFT JOIN gold.vbi011001
		ON tz030m.cd_hansya = vbi011001.cd_hansya
		AND tz030m.cd_kaisya = vbi011001.cd_kaisya
		AND tz030m.kb_mntkeiya = TRIM(vbi011001.kb_keiyaku)
		AND tz030m.no_edaban = vbi011001.no_edaban
		AND CAST(tz030m.nu_sotezert AS INT) = vbi011001.nu_sotezert
	--メンテパック明細ＤＢ
    LEFT JOIN ai21rep_ve_dx.tbaz031m tz031m
		ON tz030m.cd_hansya = tz031m.cd_hansya
		AND tz030m.cd_kaisya = tz031m.cd_kaisya
		AND tz030m.cd_okyaku = tz031m.cd_okyaku
		AND tz030m.cd_norikusi = tz031m.cd_norikusi
		AND tz030m.kb_nosyasyu = tz031m.kb_nosyasyu
		AND tz030m.cd_nogyotai = tz031m.cd_nogyotai
		AND tz030m.no_noseiri = tz031m.no_noseiri
		AND vbi011001.no_renban = LPAD(CAST(tz031m.no_table AS STRING), 2, '0')
	-- サービス入庫区分DB
	LEFT JOIN ai21rep_ve_dx.tbfy232m ty232m
		ON tz030m.cd_hansya = ty232m.cd_hansya
		AND tz030m.cd_kaisya = ty232m.cd_kaisya
		--= Table.SelectRows(#"名前が変更された列 ", each ([詳細入庫区分] = " "))
		AND ty232m.kb_syosnyuk = ' '
		AND CASE
		    	WHEN INSTR(vbi011001.kj_riyoseim, '無') > 0 THEN '無点'
			  	WHEN INSTR(vbi011001.kj_riyoseim, '１２') > 0 THEN '１２点'
			  	WHEN INSTR(vbi011001.kj_riyoseim, '６') > 0 THEN '６点'
			  	WHEN INSTR(vbi011001.kj_riyoseim, '車検') > 0 THEN '車検'
			    ELSE NULL 
		    END = REPLACE(REPLACE(ty232m.kj_nyuukom, '　', ''), ' ', '')
	LEFT JOIN(
		SELECT 
			--販社コード
			cd_hansya,
			--会社コード
			cd_kaisya,
			--お客様コード
			cd_okyaku,
			--登録ＮＯ陸支コード
			cd_norikusi,
			--登録ＮＯ車種区分
			kb_nosyasyu,
			--登録ＮＯ業態コード
			cd_nogyotai,
			--登録ＮＯ整理番号
			no_noseiri,
			--入庫区分
			kb_nyuuko,
            --入庫予定日時
			max(dt_nyuukoyt) as `dt_nyuukoyt`
		FROM gold.vbi011004
		GROUP BY
			cd_hansya,
			cd_kaisya,
			cd_okyaku,
			cd_norikusi,
			kb_nosyasyu,
			cd_nogyotai,
			no_noseiri,
			kb_nyuuko
	)vbi011004
		ON tz030m.cd_hansya = vbi011004.cd_hansya
		AND tz030m.cd_kaisya = vbi011004.cd_kaisya
		AND tz030m.cd_okyaku = vbi011004.cd_okyaku
		AND tz030m.cd_norikusi = vbi011004.cd_norikusi
		AND tz030m.kb_nosyasyu = vbi011004.kb_nosyasyu
		AND tz030m.cd_nogyotai = vbi011004.cd_nogyotai
		AND tz030m.no_noseiri = vbi011004.no_noseiri
		AND vbi011004.kb_nyuuko = ty232m.kb_nyuuko
INNER JOIN gold.vbi011005
	ON tz030m.cd_hansya = vbi011005.cd_hansya
	AND tz030m.cd_kaisya = vbi011005.cd_kaisya
	AND tz030m.cd_okyaku = vbi011005.cd_okyaku
;

CREATE TABLE IF NOT EXISTS gold.vbi012005 (
    `販社コード`       STRING COMMENT '販社コード',
    `会社コード`       STRING COMMENT '会社コード',
    `店舗コード`       STRING COMMENT '店舗コード',
    `販社会社店舗コード`   STRING COMMENT '販社会社店舗コード',
    `ストール番号`      STRING COMMENT 'ストール番号',
    `ストール名称`      STRING COMMENT 'ストール名称',
    `ストール選択`      STRING COMMENT 'ストール選択',
    `日付`          STRING COMMENT '日付',
    `時刻`          STRING COMMENT '時刻',
    `予約不可フラグ`     STRING COMMENT '予約不可フラグ'
)
COMMENT 'ストール使用状況_14日'
STORED AS PARQUET;

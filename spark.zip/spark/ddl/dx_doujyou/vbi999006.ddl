CREATE TABLE IF NOT EXISTS gold.vbi999006 (
    `販売店コード`         STRING COMMENT '販売店コード',
    `帳票ID`           STRING COMMENT '帳票ID',
    URL              STRING COMMENT 'URL',
    `販売店名`           STRING COMMENT '販売店名',
    `マスタメンテナンスURL`   STRING COMMENT 'マスタメンテナンスURL',
    `削除フラグ`          STRING COMMENT '削除フラグ'
)
COMMENT 'vbi999006'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi001003 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `車名`       STRING COMMENT '車名',
    `店舗名称`     STRING COMMENT '店舗名称',
    `店舗短縮名称`   STRING COMMENT '店舗短縮名称',
    `ゾーンコード`   STRING COMMENT 'ゾーンコード',
    `ゾーン名称`    STRING COMMENT 'ゾーン名称',
    `新車受注実績`   STRING COMMENT '新車受注実績',
    `新車受注取消`   STRING COMMENT '新車受注取消',
    `新車受注合計`   STRING COMMENT '新車受注合計',
    `新車受注残`    STRING COMMENT '新車受注残',
    `新車販売実績`   STRING COMMENT '新車販売実績',
    `新車販売取消`   STRING COMMENT '新車販売取消',
    `新車販売合計`   STRING COMMENT '新車販売合計',
    `受注日付`     STRING COMMENT '受注日付',
    `新車販売日付`   STRING COMMENT '新車販売日付',
    `店舗ソート順`   STRING COMMENT '店舗ソート順',
    `車名ソート順`   STRING COMMENT '車名ソート順'
)
COMMENT '新車車両日報'
STORED AS PARQUET;

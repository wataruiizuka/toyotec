CREATE TABLE IF NOT EXISTS gold.vbi013001_en (
    su_store                     STRING COMMENT '店舗数',
    cd_hansya_kaisya_tenpo       STRING COMMENT '販社会社店舗コード',
    cd_hansya_kaisya_zon_tenpo   STRING COMMENT '販社会社ゾーン店舗コード',
    cd_hansya                    STRING COMMENT '販社コード',
    cd_kaisya                    STRING COMMENT '会社コード',
    cd_tenpo                     STRING COMMENT '店舗コード',
    kj_tenpomei                  STRING COMMENT '店舗名称',
    kj_tentanms                  STRING COMMENT '店舗短縮名称',
    cd_zon                       STRING COMMENT 'ゾーンコード',
    cd_nczon                     STRING COMMENT 'ゾーンコード1',
    kj_zonmei                    STRING COMMENT 'ゾーン名',
    zone_name                    STRING COMMENT 'ゾーン名(略)',
    mj_sortjyun                  STRING COMMENT 'ソート順'
)
COMMENT '売掛金店舗別_en'
STORED AS PARQUET;

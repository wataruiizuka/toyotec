CREATE TABLE IF NOT EXISTS gold.vbi016006 (
    `販社コード`       STRING COMMENT '販社コード',
    `会社コード`       STRING COMMENT '会社コード',
    `番号`          STRING COMMENT '番号',
    `自社他社`        STRING COMMENT '自社他社',
    `車名`          STRING COMMENT '車名',
    `カテゴリー`       STRING COMMENT 'カテゴリー',
    `カテゴリー車名`     STRING COMMENT 'カテゴリー車名',
    `カテゴリーソート順`   STRING COMMENT 'カテゴリーソート順'
)
COMMENT '売上取消計上日と取消日=NULL'
STORED AS PARQUET;

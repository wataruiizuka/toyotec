CREATE TABLE IF NOT EXISTS gold.vbi012001 (
    `日付`              STRING COMMENT '日付',
    `日付_月`            STRING COMMENT '日付_月',
    `日付_yyyy/MM/dd`   STRING COMMENT '日付_yyyy/MM/dd',
    `日付_yyyyMMdd`     STRING COMMENT '日付_yyyyMMdd',
    `日付_曜日`           STRING COMMENT '日付_曜日',
    `先週/来週`           STRING COMMENT '先週/来週'
)
COMMENT '日付_14日'
STORED AS PARQUET;

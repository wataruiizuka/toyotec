CREATE TABLE IF NOT EXISTS gold.vbi000008 (
    `販社コード`   STRING COMMENT '販社コード',
    `会社コード`   STRING COMMENT '会社コード',
    `店舗コード`   STRING COMMENT '店舗コード',
    `品番`      STRING COMMENT '品番',
    `在庫数`     STRING COMMENT '在庫数',
    `発注数`     STRING COMMENT '発注数'
)
COMMENT '部品在庫数と今後の予約状況_在庫数&発注数'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi000002_en (
    cd_hansya     STRING COMMENT '販社コード',
    cd_kaisya     STRING COMMENT '会社コード',
    mj_toribhhn   STRING COMMENT '取替部品品番',
    mj_torihnme   STRING COMMENT '取替部品品名'
)
COMMENT '部品品名マスタ'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi010001 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `店舗名称`     STRING COMMENT '店舗名称',
    `店舗短縮名称`   STRING COMMENT '店舗短縮名称',
    `ソート順`     STRING COMMENT 'ソート順',
    `販社会社店舗`   STRING COMMENT '販社会社店舗',
    `ゾーン名称`    STRING COMMENT 'ゾーン名称',
    `商品区分`     STRING COMMENT '商品区分',
    `pn区分`     STRING COMMENT 'pn区分',
    `tl区分`     STRING COMMENT 'tl区分',
    `新U区分`     STRING COMMENT '新U区分',
    `本部店舗区分`   STRING COMMENT '本部店舗区分'
)
COMMENT '店舗'
STORED AS PARQUET;

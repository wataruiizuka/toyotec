CREATE TABLE IF NOT EXISTS gold.vbi016010 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `ゾーンコード`   STRING COMMENT 'ゾーンコード',
    `エリア店舗`    STRING COMMENT 'エリア店舗',
    `区分名称`     STRING COMMENT '区分名称'
)
COMMENT '販社コード, 会社コード , 問題コード , 検索キー, 答名１ ～ 答名２０　　											WHERE条件：問題コード は商談動機、購入形態（レクサス、トヨタ）かつ新中区分= ''1'''
STORED AS PARQUET;

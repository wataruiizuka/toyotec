CREATE TABLE IF NOT EXISTS gold.vbi003008 (
    `ソート順`        STRING COMMENT 'ソート順',
    `販社コード`       STRING COMMENT '販社コード',
    `会社コード`       STRING COMMENT '会社コード',
    `店舗コード`       STRING COMMENT '店舗コード',
    `販社会社店舗コード`   STRING COMMENT '販社会社店舗コード',
    `エリアコード`      STRING COMMENT 'エリアコード',
    `エリア名`        STRING COMMENT 'エリア名',
    `店舗名`         STRING COMMENT '店舗名'
)
COMMENT 'ストールマスタ_充足率対象ＤＢ_店舗'
STORED AS PARQUET;

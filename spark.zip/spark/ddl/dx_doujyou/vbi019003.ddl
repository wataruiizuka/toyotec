CREATE TABLE IF NOT EXISTS gold.vbi019003 (
    `販社コード`         STRING COMMENT '販社コード',
    `会社コード`         STRING COMMENT '会社コード',
    `店舗コード`         STRING COMMENT '店舗コード',
    `店舗名称`          STRING COMMENT '店舗名称',
    `販売スタッフコード`     STRING COMMENT '販売スタッフコード',
    `社員名`           STRING COMMENT '社員名',
    `月`             STRING COMMENT '月',
    `受注`            STRING COMMENT '受注',
    `受注キャンセル反映`     STRING COMMENT '受注キャンセル反映',
    `受注除軽`          STRING COMMENT '受注除軽',
    `受注除軽キャンセル反映`   STRING COMMENT '受注除軽キャンセル反映',
    `販売`            STRING COMMENT '販売',
    `販売キャンセル反映`     STRING COMMENT '販売キャンセル反映',
    `販売除軽`          STRING COMMENT '販売除軽',
    `販売除軽キャンセル反映`   STRING COMMENT '販売除軽キャンセル反映',
    `割賦`            STRING COMMENT '割賦',
    `メンテナンスパック`     STRING COMMENT 'メンテナンスパック',
    `ソート順`          STRING COMMENT 'ソート順'
)
COMMENT '中古車'
STORED AS PARQUET;

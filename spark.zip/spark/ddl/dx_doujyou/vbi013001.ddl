CREATE TABLE IF NOT EXISTS gold.vbi013001 (
    `店舗数`            STRING COMMENT '店舗数',
    `販社会社店舗コード`      STRING COMMENT '販社会社店舗コード',
    `販社会社ゾーン店舗コード`   STRING COMMENT '販社会社ゾーン店舗コード',
    `販社コード`          STRING COMMENT '販社コード',
    `会社コード`          STRING COMMENT '会社コード',
    `店舗コード`          STRING COMMENT '店舗コード',
    `店舗名称`           STRING COMMENT '店舗名称',
    `店舗短縮名称`         STRING COMMENT '店舗短縮名称',
    `ゾーンコード`         STRING COMMENT 'ゾーンコード',
    `ゾーンコード1`        STRING COMMENT 'ゾーンコード1',
    `ゾーン名`           STRING COMMENT 'ゾーン名',
    `ゾーン名(略)`        STRING COMMENT 'ゾーン名(略)',
    `ソート順`           STRING COMMENT 'ソート順'
)
COMMENT '売掛金店舗別'
STORED AS PARQUET;

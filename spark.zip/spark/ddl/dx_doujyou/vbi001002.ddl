CREATE TABLE IF NOT EXISTS gold.vbi001002 (
    cd_hansya                   STRING COMMENT '販社コード',
    cd_kaisya                   STRING COMMENT '会社コード',
    cd_tenpo                    STRING COMMENT '店舗コード',
    cd_ncsyamei                 STRING COMMENT '車名コード',
    kn_syame                    STRING COMMENT '車名',
    dd_date                     STRING COMMENT '日付',
    su_sinsya_hanbai            STRING COMMENT '新車販売実績',
    su_sinsya_hanbai_torikesi   STRING COMMENT '新車販売取消',
    su_sinsya_hanbai_goukei     STRING COMMENT '新車販売合計'
)
COMMENT '新車販売'
STORED AS PARQUET;

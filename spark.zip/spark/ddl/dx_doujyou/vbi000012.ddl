CREATE TABLE IF NOT EXISTS gold.vbi000012 (
    `ソート順`                 STRING COMMENT 'ソート順',
    `販社コード`                STRING COMMENT '販社コード',
    `会社コード`                STRING COMMENT '会社コード',
    `店舗コード`                STRING COMMENT '店舗コード',
    `店舗名称`                 STRING COMMENT '店舗名称',
    `整理ＮＯ`                 STRING COMMENT '整理ＮＯ',
    `フレーム型式`               STRING COMMENT 'フレーム型式',
    `フレームＮＯ`               STRING COMMENT 'フレームＮＯ',
    `受注ＮＯ`                 STRING COMMENT '受注ＮＯ',
    `入庫予定日時`               STRING COMMENT '入庫予定日時',
    `販社会社整理ＮＯフレーム型式支払区分`   STRING COMMENT '販社会社整理ＮＯフレーム型式支払区分',
    `入庫予定日0`               STRING COMMENT '入庫予定日0',
    `台数`                   STRING COMMENT '台数'
)
COMMENT '使用部品の予定詳細'
STORED AS PARQUET;

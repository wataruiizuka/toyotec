CREATE TABLE IF NOT EXISTS gold.vbi000005 (
    `販社コード`       STRING COMMENT '販社コード',
    `会社コード`       STRING COMMENT '会社コード',
    `フォロー店舗コード`   STRING COMMENT 'フォロー店舗コード',
    `入庫予定店舗 `     STRING COMMENT '入庫予定店舗',
    `整理ＮＯ`        STRING COMMENT '整理ＮＯ',
    `フレーム型式`      STRING COMMENT 'フレーム型式',
    `リコール名称`      STRING COMMENT 'リコール名称',
    `適用期間始期`      STRING COMMENT '適用期間始期',
    `一時抹消`        STRING COMMENT '一時抹消: [抹消区分]="1" && [実施区分]="0"'
)
COMMENT '市場処置案件一覧_main'
STORED AS PARQUET;

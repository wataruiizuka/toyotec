CREATE TABLE IF NOT EXISTS gold.vbi016008 (
    `販社コード`      STRING COMMENT '販社コード',
    `会社コード`      STRING COMMENT '会社コード',
    `店舗コード`      STRING COMMENT '店舗コード',
    `下取有無`       STRING COMMENT '下取有無',
    `下取車の車名`     STRING COMMENT '下取車の車名',
    `新車車名`       STRING COMMENT '新車車名',
    `受注計上日`      STRING COMMENT '受注計上日',
    `店舗短縮名称`     STRING COMMENT '店舗短縮名称',
    `ゾーンコード`     STRING COMMENT 'ゾーンコード',
    `ゾーン名称`      STRING COMMENT 'ゾーン名称',
    `下取車の自社他社`   STRING COMMENT '下取車の自社他社',
    `下取車の年式`     STRING COMMENT '下取車の年式',
    `ソート順`       STRING COMMENT 'ソート順',
    `車名ソート順`     STRING COMMENT '車名ソート順',
    `台数`         STRING COMMENT '台数',
    `下取台数`       STRING COMMENT '下取台数'
)
COMMENT '販社コード, 会社コード , 問題コード , 検索キー, 答名１ ～ 答名２０　　											WHERE条件：問題コード は商談動機、購入形態（レクサス、トヨタ）かつ新中区分= ''1'''
STORED AS PARQUET;

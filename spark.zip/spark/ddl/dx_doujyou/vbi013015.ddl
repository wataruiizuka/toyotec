CREATE TABLE IF NOT EXISTS gold.vbi013015 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `値`        STRING COMMENT '値',
    `アラート文言`   STRING COMMENT 'アラート文言'
)
COMMENT '条件検索'
STORED AS PARQUET;

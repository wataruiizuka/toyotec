CREATE TABLE IF NOT EXISTS gold.vbi002001_en (
    su_store_number              STRING COMMENT '店舗数',
    cd_hansya_kaisya_tenpo       STRING COMMENT '販社会社店舗コード',
    cd_hansya_kaisya_zon_tenpo   STRING COMMENT '販社会社ゾーン店舗コード',
    cd_hansya                    STRING COMMENT '販社コード',
    cd_kaisya                    STRING COMMENT '会社コード',
    cd_tenpo                     STRING COMMENT '店舗コード',
    kj_tenpomei                  STRING COMMENT '店舗名称',
    kj_tentanms                  STRING COMMENT '店舗短縮名称',
    cd_zon                       STRING COMMENT 'ゾーンコード',
    cd_nczon                     STRING COMMENT 'ンゾン',
    kj_zonmei                    STRING COMMENT 'ゾーン名称',
    zone_name_abbreviation       STRING COMMENT 'ゾーン名略',
    sort_order                   STRING COMMENT 'ソート順'
)
COMMENT '新車売掛金店舗別_en'
STORED AS PARQUET;

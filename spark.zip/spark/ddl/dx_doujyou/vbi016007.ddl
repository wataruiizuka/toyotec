CREATE TABLE IF NOT EXISTS gold.vbi016007 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `ゾーン名称`    STRING COMMENT 'ゾーン名称',
    `ゾーンコード`   STRING COMMENT 'ゾーンコード',
    `店舗短縮名称`   STRING COMMENT '店舗短縮名称',
    `新車車名`     STRING COMMENT '新車車名',
    `受注計上日`    STRING COMMENT '受注計上日',
    `購入形態`     STRING COMMENT '購入形態',
    `法人個人区分`   STRING COMMENT '法人個人区分',
    `年齢別`      STRING COMMENT '年齢別',
    `商談動機`     STRING COMMENT '商談動機',
    `支払区分`     STRING COMMENT '支払区分',
    `ソート順`     STRING COMMENT 'ソート順',
    `車名ソート順`   STRING COMMENT '車名ソート順',
    `台数`       STRING COMMENT '台数'
)
COMMENT '売上取消計上日と取消日=NULL 受注計上日!=NULL'
STORED AS PARQUET;

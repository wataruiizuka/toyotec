CREATE TABLE IF NOT EXISTS gold.vbi002004 (
    `販社コード`             STRING COMMENT '販社コード',
    `会社コード`             STRING COMMENT '会社コード',
    `店舗コード`             STRING COMMENT '店舗コード',
    `販社会社店舗コード`         STRING COMMENT '販社会社店舗コード',
    `受注台数`              STRING COMMENT '受注台数',
    `登録台数`              STRING COMMENT '登録台数',
    `当月登録内下取車なし`        STRING COMMENT '当月登録内下取車なし',
    `当月回収完了分平均リードタイム`   STRING COMMENT '当月回収完了分平均リードタイム',
    `現在登録済未回収件数`        STRING COMMENT '現在登録済未回収件数',
    `現在登録済未回収金額`        STRING COMMENT '現在登録済未回収金額',
    `前月登録済未回収件数`        STRING COMMENT '前月登録済未回収件数',
    `前月登録済未回収金額`        STRING COMMENT '前月登録済未回収金額',
    `前月以前登録済未回収件数`      STRING COMMENT '前月以前登録済未回収件数',
    `前月以前登録済未回収金額`      STRING COMMENT '前月以前登録済未回収金額',
    `件数`                STRING COMMENT '件数',
    `金額`                STRING COMMENT '金額',
    `ソート順`              STRING COMMENT 'ソート順'
)
COMMENT '新車売掛金回収状況'
STORED AS PARQUET;

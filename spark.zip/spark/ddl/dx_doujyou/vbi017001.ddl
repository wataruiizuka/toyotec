CREATE TABLE IF NOT EXISTS gold.vbi017001 (
    cd_hansya                  STRING COMMENT '販社コード',
    cd_kaisya                  STRING COMMENT '会社コード',
    cd_tenpo                   STRING COMMENT '店舗コード',
    kj_tenpomei                STRING COMMENT '店舗名称',
    cd_hanstaff                STRING COMMENT '販売スタッフコード',
    kj_syainmei                STRING COMMENT '社員名',
    month                      STRING COMMENT '月',
    su_jucyu                   STRING COMMENT '受注',
    su_jucyucancelhane         STRING COMMENT '受注キャンセル反映',
    su_jucyujyokei             STRING COMMENT '受注除軽',
    su_jucyucanceljyokeihane   STRING COMMENT '受注除軽キャンセル反映',
    su_kap                     STRING COMMENT '割賦',
    su_maintenancepack         STRING COMMENT 'メンテナンスパック',
    su_sitadori                STRING COMMENT '下取り'
)
COMMENT '新車受注'
STORED AS PARQUET;

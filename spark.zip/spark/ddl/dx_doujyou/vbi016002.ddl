CREATE TABLE IF NOT EXISTS gold.vbi016002 (
    `販社コード`   STRING COMMENT '販社コード',
    `会社コード`   STRING COMMENT '会社コード',
    `品名カナ`    STRING COMMENT '品名カナ',
    `車名受注日`   STRING COMMENT '車名受注日',
    `新車車名`    STRING COMMENT '車名受注日',
    `グレード`    STRING COMMENT 'グレード',
    `台数`      STRING COMMENT '台数'
)
COMMENT '売上取消計上日と取消日=NULL、受注計上日!=NULL'
STORED AS PARQUET;

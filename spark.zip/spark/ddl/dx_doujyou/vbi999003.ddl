CREATE TABLE IF NOT EXISTS gold.vbi999003 (
    `No.`       STRING COMMENT 'No',
    `販社コード`     STRING COMMENT '販社コード',
    `会社コード`     STRING COMMENT '会社コード',
    `新車中古車区分`   STRING COMMENT '新車中古車区分',
    `リードタイム日`   STRING COMMENT 'リードタイム日',
    `未納車経過日`    STRING COMMENT '未納車経過日',
    `登録経過日`     STRING COMMENT '登録経過日',
    `振当経過日`     STRING COMMENT '振当経過日',
    `受注経過日`     STRING COMMENT '受注経過日'
)
COMMENT '帳票ＩＤ = 指定したID'
STORED AS PARQUET;

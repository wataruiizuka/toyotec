CREATE TABLE IF NOT EXISTS gold.vbi002003 (
    `月`           STRING COMMENT '月',
    `販社コード`       STRING COMMENT '販社コード',
    `会社コード`       STRING COMMENT '会社コード',
    `販社会社店舗コード`   STRING COMMENT '販社会社店舗コード',
    `前年売掛金残高`     STRING COMMENT '前年売掛金残高',
    `前年売上額`       STRING COMMENT '前年売上額',
    `売掛金残高`       STRING COMMENT '売掛金残高',
    `売上額`         STRING COMMENT '売上額'
)
COMMENT '新車売掛金回転日数'
STORED AS PARQUET;

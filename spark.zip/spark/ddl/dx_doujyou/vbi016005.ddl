CREATE TABLE IF NOT EXISTS gold.vbi016005 (
    `販社コード`     STRING COMMENT '販社コード',
    `会社コード`     STRING COMMENT '会社コード',
    `新車車名`      STRING COMMENT '新車車名',
    `購入形態`      STRING COMMENT '購入形態',
    `下取車の年式`    STRING COMMENT '下取車の年式',
    `下取車の車名`    STRING COMMENT '下取車の車名',
    `カテゴリー`     STRING COMMENT 'カテゴリー',
    `カテゴリー車名`   STRING COMMENT 'カテゴリー車名',
    `自社他社`      STRING COMMENT '自社他社',
    `車名受注日`     STRING COMMENT '車名受注日',
    `下取台数`      STRING COMMENT '下取台数',
    `台数`        STRING COMMENT '台数'
)
COMMENT '売上取消計上日と取消日=NULL 受注計上日!=NULL'
STORED AS PARQUET;

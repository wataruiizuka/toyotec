CREATE TABLE IF NOT EXISTS gold.vbi003005 (
    cd_hansya          STRING COMMENT '販社コード',
    cd_kaisya          STRING COMMENT '会社コード',
    cd_tenpo           STRING COMMENT '店舗コード',
    no_stall           STRING COMMENT 'ストール番号',
    no_stlkyuke        STRING COMMENT 'ストール休憩番号',
    mj_kyukeyko        STRING COMMENT '休憩有効フラグ',
    tm_kyukest         STRING COMMENT '休憩開始時間',
    tm_kyukestsecond   STRING COMMENT '休憩開始時間_秒',
    tm_kyukeen         STRING COMMENT '休憩終了時間',
    tm_kyukeensecond   STRING COMMENT '休憩終了時間_秒'
)
COMMENT 'ストール休憩マスタＤＢ'
STORED AS PARQUET;

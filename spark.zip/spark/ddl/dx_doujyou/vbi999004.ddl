CREATE TABLE IF NOT EXISTS gold.vbi999004 (
    `No.`      STRING COMMENT 'No',
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `店舗名`      STRING COMMENT '店舗名',
    `ストール番号`   STRING COMMENT 'ストール番号',
    `ストール名称`   STRING COMMENT 'ストール名称',
    `集計対象判別`   STRING COMMENT '集計対象判別'
)
COMMENT '帳票ＩＤ = 指定したID'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi022003 (
    cd_hansya                STRING COMMENT '販社コード',
    cd_kaisya                STRING COMMENT '会社コード',
    cd_tenpo                 STRING COMMENT '受注店舗コード',
    kn_syame                 STRING COMMENT '車名',
    cd_ncsyamei              STRING COMMENT '車名コード',
    dd_uriagyot              STRING COMMENT '売上予定日',
    su_jusya_hanbai_mikomi   STRING COMMENT '中古車販売見込み'
)
COMMENT '中古車販売見込み'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi022002 (
    cd_hansya                  STRING COMMENT '販社コード',
    cd_kaisya                  STRING COMMENT '会社コード',
    cd_tenpo                   STRING COMMENT '受注店舗コード',
    cd_ncsyamei                STRING COMMENT '車名コード',
    kn_syame                   STRING COMMENT '車名',
    dd_date                    STRING COMMENT '日付',
    su_jusya_hanbai            STRING COMMENT '中古車販売実績',
    su_jusya_hanbai_torikesi   STRING COMMENT '中古車販売取消',
    su_jusya_hanbai_goukei     STRING COMMENT '中古車販売合計',
    su_jusya_hanbai_current    STRING COMMENT '当月中古車販売'
)
COMMENT '中古車販売'
STORED AS PARQUET;

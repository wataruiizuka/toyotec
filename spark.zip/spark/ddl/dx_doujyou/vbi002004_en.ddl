CREATE TABLE IF NOT EXISTS gold.vbi002004_en (
    cd_hansya                                                                STRING COMMENT '販社コード',
    cd_kaisya                                                                STRING COMMENT '会社コード',
    cd_tenpo                                                                 STRING COMMENT '店舗コード',
    cd_hansya_kaisya_tenpo                                                   STRING COMMENT '販社会社店舗コード',
    su_order                                                                 STRING COMMENT '受注台数',
    su_registered_vehicle                                                    STRING COMMENT '登録台数',
    su_no_trade_in_vehicle_registered_this_month                             STRING COMMENT '当月登録内下取車なし',
    su_average_lead_time_for_collections_completed_this_month                STRING COMMENT '当月回収完了分平均リードタイム',
    su_currently_registered_but_uncollected_case                             STRING COMMENT '現在登録済未回収件数',
    su_currently_registered_uncollected_amount                               STRING COMMENT '現在登録済未回収金額',
    su_registered_but_uncollected_items_from_the_previous_month              STRING COMMENT '前月登録済未回収件数',
    su_uncollected_amount_registered_in_the_previous_month                   STRING COMMENT '前月登録済未回収金額',
    su_registered_but_uncollected_items_from_the_previous_month_or_earlier   STRING COMMENT '前月以前登録済未回収件数',
    su_uncollected_amount_registered_in_the_previous_month_or_earlier        STRING COMMENT '前月以前登録済未回収金額',
    su_pieces                                                                STRING COMMENT '件数',
    su_amount                                                                STRING COMMENT '金額',
    sort_order                                                               STRING COMMENT 'ソート順'
)
COMMENT '新車売掛金回収状況_en'
STORED AS PARQUET;

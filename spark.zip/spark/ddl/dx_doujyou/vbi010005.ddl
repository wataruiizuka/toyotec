CREATE TABLE IF NOT EXISTS gold.vbi010005 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `販社会社店舗`   STRING COMMENT '販社会社店舗',
    `新車代替`     STRING COMMENT '新車代替',
    `新車実績`     STRING COMMENT '新車実績'
)
COMMENT '売上区分 = ''11'', ''14'', ''20'''
STORED AS PARQUET;

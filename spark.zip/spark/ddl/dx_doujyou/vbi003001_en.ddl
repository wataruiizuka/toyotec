CREATE TABLE IF NOT EXISTS gold.vbi003001_en (
    dd_date           STRING COMMENT '日付',
    dd_month          STRING COMMENT '日付_月',
    `dd_yyyy/MM/dd`   STRING COMMENT '日付_yyyy/MM/dd',
    dd_yyyyMMdd       STRING COMMENT '日付_yyyyMMdd',
    kb_week           STRING COMMENT '週末判定'
)
COMMENT '日付_14日'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi019002 (
    cd_hansya                   STRING COMMENT '販社コード',
    cd_kaisya                   STRING COMMENT '会社コード',
    cd_tenpo                    STRING COMMENT '店舗コード',
    kj_tenpomei                 STRING COMMENT '店舗名称',
    cd_hanstaff                 STRING COMMENT '販売スタッフコード',
    kj_syainmei                 STRING COMMENT '社員名',
    month                       STRING COMMENT '月',
    su_hanbai                   STRING COMMENT '販売',
    su_hanbaicancelhane         STRING COMMENT '販売キャンセル反映',
    su_hanbaijyokei             STRING COMMENT '販売除軽',
    su_hanbaicanceljyokeihene   STRING COMMENT '販売除軽キャンセル反映'
)
COMMENT '中古車販売'
STORED AS PARQUET;

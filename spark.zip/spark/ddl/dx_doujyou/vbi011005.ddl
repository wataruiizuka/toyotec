CREATE TABLE IF NOT EXISTS gold.vbi011005 (
    cd_hansya     STRING COMMENT '販社コード',
    cd_kaisya     STRING COMMENT '会社コード',
    cd_okyaku     STRING COMMENT 'お客様コード',
    cd_stafften   STRING COMMENT 'スタッフ店舗コード',
    cd_staff      STRING COMMENT 'スタッフコード',
    cd_zon        STRING COMMENT 'エリアコード',
    kj_zonmei     STRING COMMENT 'エリア名',
    kj_tenpomei   STRING COMMENT '店舗名',
    mj_sortjyun   STRING COMMENT 'ソート順',
    kj_syainmei   STRING COMMENT '社員名'
)
COMMENT 'TBAZ006M_顧客担当ＤＢ'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi012003 (
    cd_hansya         STRING COMMENT '販社コード',
    cd_kaisya         STRING COMMENT '会社コード',
    cd_tenpo          STRING COMMENT '店舗コード',
    no_stall          STRING COMMENT 'ストール番号',
    mj_stallmei       STRING COMMENT 'ストール名称',
    kb_stallsentaku   STRING COMMENT 'ストール選択',
    kb_kyukei         STRING COMMENT '休憩区分',
    dd_date           STRING COMMENT '日付'
)
COMMENT 'ストールマスタ_充足率対象ＤＢ_14日'
STORED AS PARQUET;

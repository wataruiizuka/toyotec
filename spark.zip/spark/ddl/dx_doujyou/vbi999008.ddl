CREATE TABLE IF NOT EXISTS gold.vbi999008 (
    `販社コード`   STRING COMMENT '販社コード',
    `会社コード`   STRING COMMENT '会社コード',
    `メッセージ`   STRING COMMENT 'メッセージ'
)
COMMENT '帳票ＩＤ = 指定したID'
STORED AS PARQUET;

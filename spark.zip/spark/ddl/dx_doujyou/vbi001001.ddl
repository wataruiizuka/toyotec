CREATE TABLE IF NOT EXISTS gold.vbi001001 (
    cd_hansya                  STRING COMMENT '販社コード',
    cd_kaisya                  STRING COMMENT '会社コード',
    cd_tenpo                   STRING COMMENT '店舗コード',
    dd_date                    STRING COMMENT '日付',
    cd_ncsyamei                STRING COMMENT '車名コード',
    kn_syame                   STRING COMMENT '車名',
    su_sinsya_jucyu            STRING COMMENT '新車受注実績',
    su_sinsya_jucyu_torikesi   STRING COMMENT '新車受注取消',
    su_sinsya_jucyu_goukei     STRING COMMENT '新車受注合計',
    su_sinsya_jucyucan         STRING COMMENT '新車受注残'
)
COMMENT '新車受注'
STORED AS PARQUET;

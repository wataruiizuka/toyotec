CREATE TABLE IF NOT EXISTS gold.vbi000001_en (
    mj_sortjyun   STRING COMMENT 'ソート順',
    cd_hansya     STRING COMMENT '販社コード',
    cd_kaisya     STRING COMMENT '会社コード',
    cd_tenpo      STRING COMMENT '店舗コード',
    kj_tenpomei   STRING COMMENT '店舗名称'
)
COMMENT '店舗'
STORED AS PARQUET;

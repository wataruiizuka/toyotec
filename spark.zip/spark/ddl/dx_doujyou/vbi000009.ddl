CREATE TABLE IF NOT EXISTS gold.vbi000009 (
    `販社コード`                STRING COMMENT '販社コード',
    `会社コード`                STRING COMMENT '会社コード',
    `整理ＮＯ`                 STRING COMMENT '整理ＮＯ',
    `フレーム型式`               STRING COMMENT 'フレーム型式',
    `支払区分`                 STRING COMMENT '支払区分',
    `取替部品品番`               STRING COMMENT '取替部品品番',
    `取替部品個数`               STRING COMMENT '取替部品個数',
    `販社会社整理ＮＯフレーム型式支払区分`   STRING COMMENT '販社会社整理ＮＯフレーム型式支払区分'
)
COMMENT '部品在庫数と今後の予約状況_予約数_基数'
STORED AS PARQUET;

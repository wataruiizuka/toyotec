CREATE TABLE IF NOT EXISTS gold.vbi013004_en (
    cd_hansya                                                  STRING COMMENT '販社コード',
    cd_kaisya                                                  STRING COMMENT '会社コード',
    cd_jytyuten                                                STRING COMMENT '店舗コード',
    cd_hansya_kaisya_jytyuten                                  STRING COMMENT '販社会社店舗コード',
    su_jucyu                                                   STRING COMMENT '受注台数',
    su_touroku                                                 STRING COMMENT '登録台数',
    no_trade_in_vehicles_registered_this_month                 STRING COMMENT '当月登録内下取車なし',
    currently_registered_but_uncollected_cases                 STRING COMMENT '現在登録済未回収件数',
    currently_registered_uncollected_amount                    STRING COMMENT '現在登録済未回収金額',
    registered_but_uncollected_items_from_the_previous_month   STRING COMMENT '前月登録済未回収件数',
    uncollected_amount_registered_in_the_previous_month        STRING COMMENT '前月登録済未回収金額',
    uncollected_cases_registered_two_months_prior              STRING COMMENT '前々月以前登録済未回収件数',
    uncollected_amount_registered_two_months_prior             STRING COMMENT '前々月以前登録済未回収金額',
    su_pieces                                                  STRING COMMENT '件数',
    su_amount                                                  STRING COMMENT '金額',
    mj_sortjyun                                                STRING COMMENT 'ソート順'
)
COMMENT '中古車売掛金回収状況_en'
STORED AS PARQUET;

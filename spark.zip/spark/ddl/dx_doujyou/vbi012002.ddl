CREATE TABLE IF NOT EXISTS gold.vbi012002 (
    cd_hansya              STRING COMMENT '販社コード',
    cd_kaisya              STRING COMMENT '会社コード',
    cd_tenpo               STRING COMMENT '店舗コード',
    no_stall               STRING COMMENT 'ストール番号',
    mj_stallmei            STRING COMMENT 'ストール名称',
    kb_stallsentaku        STRING COMMENT 'ストール選択',
    cd_hansyakaisyatenpo   STRING COMMENT '販社会社店舗コード',
    mj_sortjyun            STRING COMMENT 'ソート順'
)
COMMENT 'ストールマスタ_充足率対象ＤＢ'
STORED AS PARQUET;

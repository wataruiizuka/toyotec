CREATE TABLE IF NOT EXISTS gold.vbi011008 (
    `販社コード`      STRING COMMENT '販社コード',
    `会社コード`      STRING COMMENT '会社コード',
    `お客様コード`     STRING COMMENT 'お客様コード',
    `ソート順`       STRING COMMENT 'ソート順',
    `テーブルソート順`   STRING COMMENT 'テーブルソート順',
    `車名`         STRING COMMENT '車名',
    `登録番号`       STRING COMMENT '登録番号 = RELATED(''TBV0013M_Ｍ陸支コードDB''[陸支名称])&[登録NO陸支除]',
    `登録ＮＯ`       STRING COMMENT '登録ＮＯ'
)
COMMENT '入庫予定日時'
STORED AS PARQUET;

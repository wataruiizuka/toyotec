CREATE TABLE IF NOT EXISTS gold.vbi016003 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗短縮名称`   STRING COMMENT '店舗短縮名称',
    `新車車名`     STRING COMMENT '新車車名',
    `店舗コード`    STRING COMMENT '店舗コード',
    `車名受注日`    STRING COMMENT '車名受注日',
    `ソート順`     STRING COMMENT 'ソート順',
    `台数`       STRING COMMENT '台数'
)
COMMENT '売上取消計上日と取消日=NULL、受注計上日!=NULL'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi003001 (
    `日付`              STRING COMMENT '日付',
    `日付_月`            STRING COMMENT '日付_月',
    `日付_yyyy/MM/dd`   STRING COMMENT '日付_yyyy/MM/dd',
    `日付_yyyyMMdd`     STRING COMMENT '日付_yyyyMMdd',
    `週末判定`            STRING COMMENT '週末判定'
)
COMMENT '日付_14日'
STORED AS PARQUET;

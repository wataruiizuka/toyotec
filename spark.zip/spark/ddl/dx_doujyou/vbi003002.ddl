CREATE TABLE IF NOT EXISTS gold.vbi003002 (
    mj_sortjyun                 STRING COMMENT 'ソート順',
    cd_hansya                   STRING COMMENT '販社コード',
    cd_kaisya                   STRING COMMENT '会社コード',
    cd_tenpo                    STRING COMMENT '店舗コード',
    kj_tenpomei                 STRING COMMENT '店舗名',
    cd_zon                      STRING COMMENT 'エリアコード',
    kj_zonmei                   STRING COMMENT 'エリア名',
    no_stall                    STRING COMMENT 'ストール番号',
    mj_stallmei                 STRING COMMENT 'ストール名称',
    kb_shuukeitaishou           STRING COMMENT '集計対象判別',
    cd_hansyakaisyatenpostall   STRING COMMENT '販社会社店舗ストール番号',
    kb_stallsentaku             STRING COMMENT 'ストール選択',
    tm_kaiten                   STRING COMMENT '出勤時間',
    tm_shukkinsecond            STRING COMMENT '出勤時間_秒',
    tm_heiten                   STRING COMMENT '退勤時間',
    tm_taikinsecond             STRING COMMENT '退勤時間_秒',
    tm_zangyo                   STRING COMMENT '残業時間',
    kb_teigaikitei              STRING COMMENT '定外規定',
    kb_teinaikitei              STRING COMMENT '定内規定',
    cd_hansyakaisyatenpo        STRING COMMENT '販社会社店舗コード'
)
COMMENT 'ストールマスタ_充足率対象ＤＢ'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi012004 (
    cd_hansya   STRING COMMENT '販社コード',
    cd_kaisya   STRING COMMENT '会社コード',
    cd_tenpo    STRING COMMENT '店舗コード',
    no_stall    STRING COMMENT 'ストール番号',
    dt_siyost   STRING COMMENT '使用開始日時',
    dt_siyoed   STRING COMMENT '使用終了日時'
)
COMMENT 'tbsa005g_ストール予約明細ＤＢ_退避含_14日'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi012001_en (
    dd_date           STRING COMMENT '日付',
    dd_month          STRING COMMENT '日付_月',
    `dd_yyyy/MM/dd`   STRING COMMENT '日付_yyyy/MM/dd',
    dd_yyyyMMdd       STRING COMMENT '日付_yyyyMMdd',
    dd_week           STRING COMMENT '日付_曜日',
    kb_senshuraishu   STRING COMMENT '先週/来週'
)
COMMENT 'vbi012001_en'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi016011 (
    `販社コード`     STRING COMMENT '販社コード',
    `会社コード`     STRING COMMENT '会社コード',
    `店舗コード`     STRING COMMENT '店舗コード',
    `ソート順`      STRING COMMENT 'ソート順',
    `車名ソート順`    STRING COMMENT '車名ソート順',
    `店舗短縮名称`    STRING COMMENT '店舗短縮名称',
    `ゾーンコード`    STRING COMMENT 'ゾーンコード',
    `ゾーン名称`     STRING COMMENT 'ゾーン名称',
    `注文ＮＯ`      STRING COMMENT '注文ＮＯ',
    `新車車名`      STRING COMMENT '新車車名',
    `受注計上日`     STRING COMMENT '受注計上日',
    `グレード`      STRING COMMENT 'グレード',
    `品名カナ`      STRING COMMENT '品名カナ',
    `法人個人区分`    STRING COMMENT '法人個人区分',
    `年齢別`       STRING COMMENT '年齢別',
    `商談動機`      STRING COMMENT '商談動機',
    `購入形態`      STRING COMMENT '購入形態',
    `下取有無`      STRING COMMENT '下取有無',
    `メーカー区分`    STRING COMMENT 'メーカー区分',
    `下取車名`      STRING COMMENT '下取車名',
    `車種分類`      STRING COMMENT '車種分類',
    `下取車年式`     STRING COMMENT '下取車年式',
    `下取車メーカー`   STRING COMMENT '下取車メーカー'
)
COMMENT '販社コード, 会社コード , 問題コード , 検索キー, 答名１ ～ 答名２０　　											WHERE条件：問題コード は商談動機、購入形態（レクサス、トヨタ）かつ新中区分= ''1'''
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi022004 (
    `販社コード`      STRING COMMENT '販社コード',
    `会社コード`      STRING COMMENT '会社コード',
    `店舗コード`      STRING COMMENT '店舗コード',
    `車名`         STRING COMMENT '車名',
    `店舗名称`       STRING COMMENT '店舗名称',
    `店舗短縮名称`     STRING COMMENT '店舗短縮名称',
    `ゾーンコード`     STRING COMMENT 'ゾーンコード',
    `ゾーン名称`      STRING COMMENT 'ゾーン名称',
    `中古車受注実績`    STRING COMMENT '中古車受注実績',
    `中古車受注取消`    STRING COMMENT '中古車受注取消',
    `中古車受注合計`    STRING COMMENT '中古車受注合計',
    `中古車受注残`     STRING COMMENT '中古車受注残',
    `中古車販売実績`    STRING COMMENT '中古車販売実績',
    `中古車販売取消`    STRING COMMENT '中古車販売取消',
    `中古車販売合計`    STRING COMMENT '中古車販売合計',
    `当月中古車販売`    STRING COMMENT '当月中古車販売',
    `中古車販売見込み`   STRING COMMENT '中古車販売見込み',
    `受注日付`       STRING COMMENT '受注日付',
    `中古車販売日付`    STRING COMMENT '中古車販売日付',
    `中古車見込み日付`   STRING COMMENT '中古車見込み日付',
    `店舗ソート順`     STRING COMMENT '店舗ソート順',
    `車名ソート順`     STRING COMMENT '車名ソート順'
)
COMMENT '中古車車両日報'
STORED AS PARQUET;

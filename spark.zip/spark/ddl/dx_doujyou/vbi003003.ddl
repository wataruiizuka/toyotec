CREATE TABLE IF NOT EXISTS gold.vbi003003 (
    mj_sortjyun                     STRING COMMENT 'ソート順',
    cd_hansya                       STRING COMMENT '販社コード',
    cd_kaisya                       STRING COMMENT '会社コード',
    cd_tenpo                        STRING COMMENT '店舗コード',
    kj_tenpomei                     STRING COMMENT '店舗名',
    cd_hansyakaisyatenpostall       STRING COMMENT '販社会社店舗ストール番号',
    no_stall                        STRING COMMENT 'ストール番号',
    mj_stallmei                     STRING COMMENT 'ストール名称',
    kb_stallsentaku                 STRING COMMENT 'ストール選択',
    cd_zon                          STRING COMMENT 'エリアコード',
    kj_zonmei                       STRING COMMENT 'エリア名',
    kb_teigaikitei                  STRING COMMENT '定外規定',
    kb_teinaikitei                  STRING COMMENT '定内規定',
    kb_kyukei                       STRING COMMENT '休憩区分',
    dd_date                         STRING COMMENT '日付',
    cd_hansyakaisyatenpostalldate   STRING COMMENT '販社会社店舗ストール番号日付',
    kb_week                         STRING COMMENT '週末判定'
)
COMMENT 'ストールマスタ_充足率対象ＤＢ_14日'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi012006 (
    `ソート順`        STRING COMMENT 'ソート順',
    `販社コード`       STRING COMMENT '販社コード',
    `会社コード`       STRING COMMENT '会社コード',
    `店舗コード`       STRING COMMENT '店舗コード',
    `店舗名`         STRING COMMENT '店舗名',
    `販社会社店舗コード`   STRING COMMENT '販社会社店舗コード'
)
COMMENT '店舗'
STORED AS PARQUET;

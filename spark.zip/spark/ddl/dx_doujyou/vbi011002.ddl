CREATE TABLE IF NOT EXISTS gold.vbi011002 (
    cd_hansya     STRING COMMENT '販社コード',
    cd_kaisya     STRING COMMENT '会社コード',
    cd_tenpo      STRING COMMENT '店舗コード',
    kj_tenpomei   STRING COMMENT '店舗名称',
    cd_zon        STRING COMMENT 'ゾーンコード',
    kj_zonmei     STRING COMMENT 'ゾーン名称',
    mj_sortjyun   STRING COMMENT 'ソート順'
)
COMMENT 'エリア_店舗'
STORED AS PARQUET;

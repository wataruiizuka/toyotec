CREATE TABLE IF NOT EXISTS gold.vbi011006 (
    `販社コード`           STRING COMMENT '販社コード',
    `会社コード`           STRING COMMENT '会社コード',
    `お客様コード`          STRING COMMENT 'お客様コード',
    `スタッフエリアコード`      STRING COMMENT 'スタッフエリアコード',
    `スタッフエリア名`        STRING COMMENT 'スタッフエリア名',
    `スタッフ店舗名`         STRING COMMENT 'スタッフ店舗名',
    `テーブル店舗名`         STRING COMMENT 'テーブル店舗名',
    `スタッフ名`           STRING COMMENT 'スタッフ名',
    `店舗スタッフ`          STRING COMMENT '店舗スタッフ',
    `実施区分`            STRING COMMENT '実施区分',
    `メンテパック名称`        STRING COMMENT 'メンテパック名称',
    `項目利用整備名称`        STRING COMMENT '項目利用整備名称',
    `契約区分`            STRING COMMENT '契約区分',
    `税込金額`            STRING COMMENT '税込金額',
    `新規連番`            STRING COMMENT '新規連番',
    `実施予定年月日`         STRING COMMENT '実施予定年月日',
    `実施予定年月スライサー`     STRING COMMENT '実施予定年月スライサー',
    `契約終了予定年月スライサー`   STRING COMMENT '契約終了予定年月スライサー',
    `登録ＮＯ`            STRING COMMENT '登録ＮＯ',
    `入庫区分漢字`          STRING COMMENT '入庫区分漢字',
    `SMB予約入庫日時`       STRING COMMENT 'SMB予約入庫日時'
)
COMMENT 'Table.SelectRows(#"名前が変更された列 ", each ([会社コード] = "01") and ([#"担当分類区分 "] = "1"))'
STORED AS PARQUET;

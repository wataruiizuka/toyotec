CREATE TABLE IF NOT EXISTS gold.vbi999001 (
    `販売店コード`   STRING COMMENT '販売店コード',
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `会社名`      STRING COMMENT '会社名',
    `メール`      STRING COMMENT 'メール',
    `メールSP`    STRING COMMENT 'メールSP'
)
COMMENT 'vbi999001'
STORED AS PARQUET;

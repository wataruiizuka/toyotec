CREATE TABLE IF NOT EXISTS gold.vbi013005 (
    `販社コード`       STRING COMMENT '販社コード',
    `会社コード`       STRING COMMENT '会社コード',
    `販社会社店舗コード`   STRING COMMENT '販社会社店舗コード',
    `登録済件数`       STRING COMMENT '登録済件数',
    `下取車なし総件数`    STRING COMMENT '下取車なし総件数',
    `未回収総件数`      STRING COMMENT '未回収総件数',
    `未回収総金額`      STRING COMMENT '未回収総金額',
    `未回収現金総件数`    STRING COMMENT '未回収現金総件数',
    `未回収現金総金額`    STRING COMMENT '未回収現金総金額',
    `未回収割賦総総件数`   STRING COMMENT '未回収割賦総総件数',
    `未回収割賦総総金額`   STRING COMMENT '未回収割賦総総金額',
    `未回収下取総件数`    STRING COMMENT '未回収下取総件数',
    `未回収下取総金額`    STRING COMMENT '未回収下取総金額',
    `登録済未納車件数`    STRING COMMENT '登録済未納車件数'
)
COMMENT '中古車売掛金残高'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi003007 (
    `ソート順`             STRING COMMENT 'ソート順',
    `販社コード`            STRING COMMENT '販社コード',
    `会社コード`            STRING COMMENT '会社コード',
    `店舗コード`            STRING COMMENT '店舗コード',
    `販社会社店舗コード`        STRING COMMENT '販社会社店舗コード',
    `エリアコード`           STRING COMMENT 'エリアード',
    `エリア名`             STRING COMMENT 'エリア名',
    `店舗名`              STRING COMMENT '店舗名',
    `ストール番号`           STRING COMMENT 'ストール番号',
    `ストール名称`           STRING COMMENT 'ストール名称',
    `販社会社店舗ストール番号日付`   STRING COMMENT '販社会社店舗ストール番号日付',
    `ストール選択`           STRING COMMENT 'ストール選択',
    `日付`               STRING COMMENT '日付',
    `定内規定`             STRING COMMENT '定内規定',
    `予約`               STRING COMMENT '予約'
)
COMMENT 'ストール充足状況_14日'
STORED AS PARQUET;

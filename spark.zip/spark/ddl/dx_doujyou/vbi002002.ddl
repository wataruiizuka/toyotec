CREATE TABLE IF NOT EXISTS gold.vbi002002 (
    `エリア統括部と店舗`      STRING COMMENT 'エリア統括部と店舗',
    `区分名称`           STRING COMMENT '区分名称',
    `区分コード`          STRING COMMENT '区分コード',
    `販社コード`          STRING COMMENT '販社コード',
    `会社コード`          STRING COMMENT '会社コード',
    `ゾーンコード`         STRING COMMENT 'ゾーンコード',
    `店舗コード`          STRING COMMENT '店舗コード',
    `販社会社店舗コード`      STRING COMMENT '販社会社店舗コード',
    `販社会社ゾーン店舗コード`   STRING COMMENT '販社会社ゾーン店舗コード',
    `件数`             STRING COMMENT '件数',
    `金額`             STRING COMMENT '金額',
    `ソート順`           STRING COMMENT 'ソート順'
)
COMMENT 'エリア統括部と店舗別'
STORED AS PARQUET;

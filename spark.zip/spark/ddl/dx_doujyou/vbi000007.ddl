CREATE TABLE IF NOT EXISTS gold.vbi000007 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `整理ＮＯ`     STRING COMMENT '整理ＮＯ',
    `入庫予定日0`   STRING COMMENT '入庫予定日0',
    `予約済台数`    STRING COMMENT '予約済台数'
)
COMMENT '市場処置案件一覧_予約済台数'
STORED AS PARQUET;

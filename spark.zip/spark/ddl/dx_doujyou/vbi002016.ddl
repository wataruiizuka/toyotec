CREATE TABLE IF NOT EXISTS gold.vbi002016 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    Value      STRING,
    `アラート文言`   STRING COMMENT 'アラート文言'
)
COMMENT '条件検索'
STORED AS PARQUET;

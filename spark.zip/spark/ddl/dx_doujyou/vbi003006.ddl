CREATE TABLE IF NOT EXISTS gold.vbi003006 (
    `販社コード`            STRING COMMENT '販社コード',
    `会社コード`            STRING COMMENT '会社コード',
    `店舗コード`            STRING COMMENT '店舗コード',
    `予約ＩＤ`             STRING COMMENT '予約ＩＤ',
    `予約明細ＩＤ`           STRING COMMENT '予約明細ＩＤ',
    `ストール番号`           STRING COMMENT 'ストール番号',
    `ご用命`              STRING COMMENT 'ご用',
    `工程区分`             STRING COMMENT '工程区分',
    `入庫予定日時`           STRING COMMENT '入庫予定日時',
    `出庫予定日時`           STRING COMMENT '出庫予定日時',
    `使用所要時間`           STRING COMMENT '使用所要時間',
    `入庫区分`             STRING COMMENT '入庫区分',
    `実績ステータス`          STRING COMMENT '実績ステータス',
    `実績ステータス名`         STRING COMMENT '実績ステータス名',
    `休憩跨ぎ区分`           STRING COMMENT '休憩跨ぎ区分',
    `ＳＭＢ削除フラグ`         STRING COMMENT 'ＳＭＢ削除フラグ',
    `販社会社店舗ストール番号日付`   STRING COMMENT '販社会社店舗ストール番号日付',
    `入庫予定日`            STRING COMMENT '入庫予定日',
    `予約`               STRING COMMENT '予約',
    `出勤時間`             STRING COMMENT '出勤時間',
    `退勤時間`             STRING COMMENT '退勤時間',
    `残業時間`             STRING COMMENT '残業時間'
)
COMMENT 'ストール予約明細_分析対象ＤＢ_14日'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi016009 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `店舗短縮名称`   STRING COMMENT '店舗短縮名称',
    `ゾーンコード`   STRING COMMENT 'ゾーンコード',
    `ゾーン名称`    STRING COMMENT 'ゾーン名称',
    `グレード`     STRING COMMENT 'グレード',
    `品名カナ`     STRING COMMENT '品名カナ',
    `新車車名`     STRING COMMENT '新車車名',
    `受注計上日`    STRING COMMENT '受注計上日',
    `ソート順`     STRING COMMENT 'ソート順',
    `車名ソート順`   STRING COMMENT '車名ソート順',
    `台数`       STRING COMMENT '台数'
)
COMMENT '販社コード, 会社コード , 問題コード , 検索キー, 答名１ ～ 答名２０　　											WHERE条件：問題コード は商談動機、購入形態（レクサス、トヨタ）かつ新中区分= ''1'''
STORED AS PARQUET;

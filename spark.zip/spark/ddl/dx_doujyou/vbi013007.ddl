CREATE TABLE IF NOT EXISTS gold.vbi013007 (
    `主キー`        STRING COMMENT '主キー',
    `販社コード`      STRING COMMENT '販社コード',
    `会社コード`      STRING COMMENT '会社コード',
    `注文ＮＯ`       STRING COMMENT '注文ＮＯ',
    `販社会社注文NO`   STRING COMMENT '販社会社注文NO',
    `日付_順番用`     STRING COMMENT '日付_順番用',
    `日付`         STRING COMMENT '日付',
    `項目名`        STRING COMMENT '項目名',
    `発生額`        STRING COMMENT '発生額',
    `入金額`        STRING COMMENT '入金額',
    `空白欄`        STRING COMMENT '空白欄',
    `伝票番号`       STRING COMMENT '伝票番号',
    `業務区分`       STRING COMMENT '業務区分',
    `入金区分`       STRING COMMENT '入金区分',
    `件数`         STRING COMMENT '件数'
)
COMMENT '中古車売掛金履歴'
STORED AS PARQUET;

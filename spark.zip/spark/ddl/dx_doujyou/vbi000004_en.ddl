CREATE TABLE IF NOT EXISTS gold.vbi000004_en (
    cd_hansya     STRING COMMENT '販社コード',
    cd_kaisya     STRING COMMENT '会社コード',
    no_seiri      STRING COMMENT '整理ＮＯ',
    kj_recallme   STRING COMMENT 'リコール名称'
)
COMMENT 'リコール名称'
STORED AS PARQUET;

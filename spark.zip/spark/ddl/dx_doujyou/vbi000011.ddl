CREATE TABLE IF NOT EXISTS gold.vbi000011 (
    `販社コード`                STRING COMMENT '販社コード',
    `会社コード`                STRING COMMENT '会社コード',
    `店舗コード`                STRING COMMENT '店舗コード',
    `取替部品品番`               STRING COMMENT '取替部品品番',
    `整理ＮＯ`                 STRING COMMENT '整理ＮＯ',
    `フレーム型式`               STRING COMMENT 'フレーム型式',
    `支払区分`                 STRING COMMENT '支払区分',
    `販社会社整理ＮＯフレーム型式支払区分`   STRING COMMENT '販社会社整理ＮＯフレーム型式支払区分',
    `取替部品個数`               STRING COMMENT '取替部品個数',
    `取替部品品名`               STRING COMMENT '取替部品品名'
)
COMMENT '使用部品の詳細'
STORED AS PARQUET;

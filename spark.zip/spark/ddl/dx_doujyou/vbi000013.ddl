CREATE TABLE IF NOT EXISTS gold.vbi000013 (
    `ソート順`    STRING COMMENT 'ソート順',
    `販社コード`   STRING COMMENT '販社コード',
    `会社コード`   STRING COMMENT '会社コード',
    `店舗コード`   STRING COMMENT '店舗コード',
    `店舗名称`    STRING COMMENT '店舗名称',
    `品番`      STRING COMMENT '品番',
    `品名`      STRING COMMENT '品名',
    `在庫数`     STRING COMMENT '在庫数'
)
COMMENT '店舗の在庫数'
STORED AS PARQUET;

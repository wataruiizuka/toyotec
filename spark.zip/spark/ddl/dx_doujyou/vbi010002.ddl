CREATE TABLE IF NOT EXISTS gold.vbi010002 (
    `販社コード`       STRING COMMENT '販社コード',
    `会社コード`       STRING COMMENT '会社コード',
    `店舗コード`       STRING COMMENT '店舗コード',
    `販社会社店舗`      STRING COMMENT '販社会社店舗',
    `新車軽OEM数`     STRING COMMENT '新車軽OEM数',
    `新車登録車数`      STRING COMMENT '新車登録車数',
    `新車軽OEM収益`    STRING COMMENT '新車軽OEM収益',
    `新車登録収益`      STRING COMMENT '新車登録収益',
    `新車軽OEM売上`    STRING COMMENT '新車軽OEM売上',
    `新車登録売上`      STRING COMMENT '新車登録売上',
    `TAD販売実績`     STRING COMMENT 'TAD販売実績',
    `TAD売上実績`     STRING COMMENT 'TAD売上実績',
    `TAD収益実績`     STRING COMMENT 'TAD収益実績',
    `新車スタッフ数`     STRING COMMENT '新車スタッフ数',
    `UCar小売`      STRING COMMENT 'UCar小売',
    `UCar卸`       STRING COMMENT 'UCar卸',
    `UCar卸収益`     STRING COMMENT 'UCar卸収益',
    `UCar小売売上`    STRING COMMENT 'UCar小売売上',
    `UCar卸売上`     STRING COMMENT 'UCar卸売上',
    `UCar小売収益`    STRING COMMENT 'UCar小売収益',
    `Ucarスタッフ数`   STRING COMMENT 'Ucarスタッフ数'
)
COMMENT '﻿CREATE VIEW dx_ve.VBI010002 AS'
STORED AS PARQUET;

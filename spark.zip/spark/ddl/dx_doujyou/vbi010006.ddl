CREATE TABLE IF NOT EXISTS gold.vbi010006 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `販社会社店舗`   STRING COMMENT '販社会社店舗',
    `Ucar実績`   STRING COMMENT 'Ucar実績',
    `Ucar代替`   STRING COMMENT 'Ucar代替',
    `TAD実績`    STRING COMMENT 'TAD実績',
    `TAD代替`    STRING COMMENT 'TAD代替'
)
COMMENT '売上区分 = ''11'', ''14'', ''20'''
STORED AS PARQUET;

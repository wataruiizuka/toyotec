CREATE TABLE IF NOT EXISTS gold.vbi016004 (
    `販社コード`        STRING COMMENT '販社コード',
    `会社コード`        STRING COMMENT '会社コード',
    `新車車名`         STRING COMMENT '新車車名',
    `法人個人区分`       STRING COMMENT '法人個人区分',
    `法人個人区分ソート順`   STRING COMMENT '法人個人区分ソート順',
    `年齢別`          STRING COMMENT '年齢別',
    `商談動機`         STRING COMMENT '商談動機',
    `業直区分`         STRING COMMENT '業直区分',
    `支払区分`         STRING COMMENT '支払区分',
    `車名受注日`        STRING COMMENT '車名受注日',
    `台数`           STRING COMMENT '台数',
    `受注台数`         STRING COMMENT '受注台数'
)
COMMENT '売上取消計上日と取消日=NULL'
STORED AS PARQUET;

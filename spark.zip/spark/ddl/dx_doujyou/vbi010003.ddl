CREATE TABLE IF NOT EXISTS gold.vbi010003 (
    `販社コード`     STRING COMMENT '販社コード',
    `会社コード`     STRING COMMENT '会社コード',
    `店舗コード`     STRING COMMENT '店舗コード',
    `販社会社店舗`    STRING COMMENT '販社会社店舗',
    `新車下取数`     STRING COMMENT '新車下取数',
    `新車入会数`     STRING COMMENT '新車入会数',
    `新車直販数`     STRING COMMENT '新車直販数',
    `直販下取数`     STRING COMMENT '直販下取数',
    `新車軽OEM数`   STRING COMMENT '新車軽OEM数',
    `新車登録車数`    STRING COMMENT '新車登録車数'
)
COMMENT '売上区分 ＝''11'', ''14'', ''20'''
STORED AS PARQUET;

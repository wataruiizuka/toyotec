CREATE TABLE IF NOT EXISTS gold.vbi010004 (
    `販社コード`     STRING COMMENT '販社コード',
    `会社コード`     STRING COMMENT '会社コード',
    `店舗コード`     STRING COMMENT '店舗コード',
    `販社会社店舗`    STRING COMMENT '販社会社店舗',
    `TAD販売実績`   STRING COMMENT 'TAD販売実績',
    `TAD下取数`    STRING COMMENT 'TAD下取数',
    `TAD入会数`    STRING COMMENT 'TAD入会数',
    `Ucar下取数`   STRING COMMENT 'Ucar下取数',
    `UCar買取数`   STRING COMMENT 'UCar買取数',
    `UCar入会数`   STRING COMMENT 'UCar入会数',
    `UCar小売`    STRING COMMENT 'UCar小売',
    `UCar卸`     STRING COMMENT 'UCar卸'
)
COMMENT '売上区分 ＝''11'', ''14'', ''20'''
STORED AS PARQUET;

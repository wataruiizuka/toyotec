CREATE TABLE IF NOT EXISTS gold.vbi016001 (
    `販社コード`   STRING COMMENT '販社コード',
    `会社コード`   STRING COMMENT '会社コード',
    `新車車名`    STRING COMMENT '新車車名',
    `受注計上日`   STRING COMMENT '受注計上日',
    `月別`      STRING COMMENT '月別',
    `車名受注日`   STRING COMMENT '車名受注日',
    `ソート順`    STRING COMMENT 'ソート順',
    `台数`      STRING COMMENT '台数'
)
COMMENT 'vbi016001'
STORED AS PARQUET;

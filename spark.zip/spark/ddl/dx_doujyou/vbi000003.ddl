CREATE TABLE IF NOT EXISTS gold.vbi000003 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `整理ＮＯ`     STRING COMMENT '整理ＮＯ',
    `フレーム型式`   STRING COMMENT 'フレーム型式',
    `データ分類`    STRING COMMENT 'データ分類'
)
COMMENT '整理ＮＯ'
STORED AS PARQUET;

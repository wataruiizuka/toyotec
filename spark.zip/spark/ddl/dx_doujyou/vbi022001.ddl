CREATE TABLE IF NOT EXISTS gold.vbi022001 (
    cd_hansya                 STRING COMMENT '販社コード',
    cd_kaisya                 STRING COMMENT '会社コード',
    cd_tenpo                  STRING COMMENT '受注店舗コード',
    dd_date                   STRING COMMENT '日付',
    cd_ncsyamei               STRING COMMENT '車名コード',
    kn_syame                  STRING COMMENT '車名',
    su_jusya_jucyu            STRING COMMENT '中古車受注実績',
    su_jusya_jucyu_torikesi   STRING COMMENT '中古車受注取消',
    su_jusya_jucyu_goukei     STRING COMMENT '中古車受注合計',
    su_jusya_jucyucan         STRING COMMENT '中古車受注残'
)
COMMENT '中古車受注'
STORED AS PARQUET;

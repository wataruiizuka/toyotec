CREATE TABLE IF NOT EXISTS gold.vbi003006_en (
    cd_hansya                       STRING COMMENT '販社コード',
    cd_kaisya                       STRING COMMENT '会社コード',
    cd_tenpo                        STRING COMMENT '店舗コード',
    no_yoyakuid                     STRING COMMENT '予約ＩＤ',
    cd_yoykmsai                     STRING COMMENT '予約明細ＩＤ',
    no_stall                        STRING COMMENT 'ストール番号',
    mj_gyme                         STRING COMMENT 'ご用命',
    kb_koutei                       STRING COMMENT '工程区分',
    dt_nyuukoyt                     STRING COMMENT '入庫予定日時',
    dt_shukkoyt                     STRING COMMENT '出庫予定日時',
    tm_siyotime                     STRING COMMENT '使用所要時間',
    kb_nyuuko                       STRING COMMENT '入庫区分',
    cd_jisekist                     STRING COMMENT '実績ステータス',
    mj_jisekist                     STRING COMMENT '実績ステータス名',
    cd_restcros                     STRING COMMENT '休憩跨ぎ区分',
    mj_sakujyo                      STRING COMMENT 'ＳＭＢ削除フラグ',
    cd_hansyakaisyatenpostalldate   STRING COMMENT '販社会社店舗ストール番号日付',
    dd_nyuukoyt                     STRING COMMENT '入庫予定日',
    mj_yoyaku                       STRING COMMENT '予約',
    tm_shukkin                      STRING COMMENT '出勤時間',
    tm_taikin                       STRING COMMENT '退勤時間',
    tm_zangyo                       STRING COMMENT '残業時間'
)
COMMENT 'ストール予約明細_分析対象ＤＢ_14日'
STORED AS PARQUET;

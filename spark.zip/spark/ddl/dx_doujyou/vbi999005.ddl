CREATE TABLE IF NOT EXISTS gold.vbi999005 (
    `No.`      STRING COMMENT 'No',
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `車名コード`    STRING COMMENT '車名コード',
    `車名（漢字）`   STRING COMMENT '車名（漢字）',
    `車名（カナ）`   STRING COMMENT '車名（カナ）',
    `表示可否`     STRING COMMENT '表示可否',
    `ソート順`     STRING COMMENT 'ソート順'
)
COMMENT '帳票ＩＤ = 指定したID'
STORED AS PARQUET;

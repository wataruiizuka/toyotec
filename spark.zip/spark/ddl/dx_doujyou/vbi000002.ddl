CREATE TABLE IF NOT EXISTS gold.vbi000002 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `取替部品品番`   STRING COMMENT '取替部品品番',
    `取替部品品名`   STRING COMMENT '取替部品品名'
)
COMMENT '部品品名マスタ'
STORED AS PARQUET;

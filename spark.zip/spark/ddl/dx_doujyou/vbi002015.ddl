CREATE TABLE IF NOT EXISTS gold.vbi002015 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    Value      STRING,
    `アラート文言`   STRING COMMENT 'アラート文言'
)
COMMENT 'アラート'
STORED AS PARQUET;

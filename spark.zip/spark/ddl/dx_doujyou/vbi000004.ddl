CREATE TABLE IF NOT EXISTS gold.vbi000004 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `整理ＮＯ`     STRING COMMENT '整理ＮＯ',
    `リコール名称`   STRING COMMENT 'リコール名称'
)
COMMENT 'リコール名称'
STORED AS PARQUET;

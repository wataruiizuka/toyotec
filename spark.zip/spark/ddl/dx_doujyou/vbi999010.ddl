CREATE TABLE IF NOT EXISTS gold.vbi999010 (
    `No.`        STRING COMMENT '番号',
    `販社コード`      STRING COMMENT '販社コード',
    `会社コード`      STRING COMMENT '会社コード',
    `入金区分`       STRING COMMENT '入金区分',
    `入金区分名`      STRING COMMENT '入金区分名',
    `現金`         STRING COMMENT '現金',
    `クレジットカード`   STRING COMMENT 'クレジットカード'
)
COMMENT '帳票ＩＤ = 指定したID'
STORED AS PARQUET;

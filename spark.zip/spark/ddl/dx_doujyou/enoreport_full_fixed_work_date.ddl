CREATE TABLE IF NOT EXISTS gold.enoreport_full_fixed_work_date (
    cd_hansya   STRING,
    cd_kaisya   STRING,
    mj_youbi    STRING
)
COMMENT 'enoreport_full_fixed_work_date'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi999009 (
    `No.`     STRING COMMENT 'No',
    `販社コード`   STRING COMMENT '販社コード',
    `会社コード`   STRING COMMENT '会社コード',
    `車名コード`   STRING COMMENT '車名コード',
    `カナ車名`    STRING COMMENT 'カナ車名',
    `漢字車名`    STRING COMMENT '漢字車名',
    `表示可否`    STRING COMMENT '表示可否',
    `車名並び順`   STRING COMMENT '車名並び順'
)
COMMENT '帳票ＩＤ = 指定したID'
STORED AS PARQUET;

CREATE TABLE IF NOT EXISTS gold.vbi011001 (
    cd_hansya     STRING COMMENT '販社コード',
    cd_kaisya     STRING COMMENT '会社コード',
    kb_keiyaku    STRING COMMENT '契約区分',
    no_edaban     STRING COMMENT '枝番',
    nu_sotezert   STRING COMMENT '想定税率',
    no_renban     STRING COMMENT '連番',
    kj_riyoseim   STRING COMMENT '利用整備名称',
    kj_kanyusyu   STRING COMMENT '加入商品名',
    totalcount    STRING COMMENT '税込金額 = 合計金額 + 消費税'
)
COMMENT 'パック商品'
STORED AS PARQUET;

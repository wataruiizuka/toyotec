CREATE TABLE IF NOT EXISTS gold.vbi011004 (
    cd_hansya     STRING COMMENT '販社コード',
    cd_kaisya     STRING COMMENT '会社コード',
    cd_okyaku     STRING COMMENT 'お客様コード',
    cd_norikusi   STRING COMMENT '登録ＮＯ陸支コード',
    kb_nosyasyu   STRING COMMENT '登録ＮＯ車種区分',
    cd_nogyotai   STRING COMMENT '登録ＮＯ業態コード',
    no_noseiri    STRING COMMENT '登録ＮＯ整理番号',
    dt_nyuukoyt   STRING COMMENT '入庫予定日時',
    kb_nyuuko     STRING COMMENT '入庫区分'
)
COMMENT 'TBSA005G_ストール予約明細DB'
STORED AS PARQUET;

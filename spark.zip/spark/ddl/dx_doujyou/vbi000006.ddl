CREATE TABLE IF NOT EXISTS gold.vbi000006 (
    `販社コード`    STRING COMMENT '販社コード',
    `会社コード`    STRING COMMENT '会社コード',
    `店舗コード`    STRING COMMENT '店舗コード',
    `整理ＮＯ`     STRING COMMENT '整理ＮＯ',
    `対象車両台数`   STRING COMMENT '対象車両台数',
    `自店実施台数`   STRING COMMENT '自店実施台数',
    `他店実施台数`   STRING COMMENT '他店実施台数',
    `他社実施台数`   STRING COMMENT '他社実施台数'
)
COMMENT '市場処置案件一覧_対象台数&実施台数'
STORED AS PARQUET;

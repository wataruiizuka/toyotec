CREATE TABLE IF NOT EXISTS gold.vbi003004 (
    cd_hansya           STRING COMMENT '販社コード',
    cd_kaisya           STRING COMMENT '会社コード',
    cd_tenpo            STRING COMMENT '店舗コード',
    no_yoyakuid         STRING COMMENT '予約ＩＤ',
    cd_yoykmsai         STRING COMMENT '予約明細ＩＤ',
    no_msaiedmx         STRING COMMENT '明細枝番最大番号',
    no_stall            STRING COMMENT 'ストール番号',
    mj_stallno          STRING COMMENT 'ストール番号_文字列',
    mj_gyme             STRING COMMENT 'ご用命',
    kb_koutei           STRING COMMENT '工程区分',
    dt_siyost           STRING COMMENT '使用開始日時',
    dd_nyuukoyt         STRING COMMENT '入庫予定日',
    tm_nyuukoytsecond   STRING COMMENT '入庫予定時間_秒',
    dt_siyoed           STRING COMMENT '使用終了日時',
    dd_shukkoyt         STRING COMMENT '出庫予定日',
    tm_shukkoytsecond   STRING COMMENT '出庫予定時間_秒',
    tm_siyotime         STRING COMMENT '使用所要時間',
    kb_nyuuko           STRING COMMENT '入庫区分',
    cd_jisekist         STRING COMMENT '実績ステータス',
    cd_restcros         STRING COMMENT '休憩跨ぎ区分',
    su_sgyninz          STRING COMMENT '作業人数',
    dt_nyukjisk         STRING COMMENT '入庫実績日時',
    dt_sesnjisk         STRING COMMENT '精算実績日時',
    mj_sakujyo          STRING COMMENT 'ＳＭＢ削除フラグ'
)
COMMENT 'tbsa005g_ストール予約明細ＤＢ_退避含_14日'
STORED AS PARQUET;

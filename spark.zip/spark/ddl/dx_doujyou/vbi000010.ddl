CREATE TABLE IF NOT EXISTS gold.vbi000010 (
    `販社コード`                STRING COMMENT '販社コード',
    `会社コード`                STRING COMMENT '会社コード',
    `店舗コード`                STRING COMMENT '店舗コード',
    `整理ＮＯ`                 STRING COMMENT '整理ＮＯ',
    `フレーム型式`               STRING COMMENT 'フレーム型式',
    `支払区分`                 STRING COMMENT '支払区分',
    `販社会社整理ＮＯフレーム型式支払区分`   STRING COMMENT '販社会社整理ＮＯフレーム型式支払区分',
    `入庫予定日0`               STRING COMMENT '入庫予定日0',
    `台数`                   STRING COMMENT '台数'
)
COMMENT '部品在庫数と今後の予約状況_予約数_台数'
STORED AS PARQUET;
